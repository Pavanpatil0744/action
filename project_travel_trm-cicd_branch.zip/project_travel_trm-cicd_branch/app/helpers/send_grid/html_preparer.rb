# frozen_string_literal: true

module SendGrid::HtmlPreparer
  def replace_token_placeholders(tokenable, object, text, placeholder_replacer = 'token_value', with_alias: false)
    tokenable.tokens.each do |token|
      text.gsub!(token.placeholder, public_send(placeholder_replacer, token.identifier, object) || "")
    end

    text
  end

  def token_value(identifier, object)
    case identifier
    when "application_deadline", "form_deadline_date"
      object.mailer_deadline
    when "application_status", "form_status"
      object.display_status
    when "first_name"
      object.mailer_first_name
    when "program_name"
      object.program_title
    when "term_name"
      object.term_name
    when "term_start_date"
      start_date = object.start_date&.in_time_zone(object.client_account_org_timezone)

      return '' unless start_date.present?

      object.use_exact_dates ? start_date.strftime("%b %d, %Y") : start_date.strftime("%b %Y")
    when "term_end_date"
      end_date = object.end_date&.in_time_zone(object.client_account_org_timezone)

      return '' unless end_date.present?

      object.use_exact_dates ? end_date.strftime("%b %d, %Y") : end_date.strftime("%b %Y")
    when "home_campus"
      object.client_account_org_name
    when "program_organization_name"
      object.program_org_name
    when "program_type"
      object.program.program_types.pluck(:name).join(", ")
    when "form_name"
      object.template_name
    when "withdrawal_reason"
      return '' unless object.status == 'withdrawn'

      most_recent_reasons(object)
    when "deferred_reason"
      return '' unless object.status == 'deferred'

      most_recent_reasons(object)
    end
  end

  def most_recent_reasons(object)
    change_log = object
                .submission_status_change_logs
                .where(status: object.status)&.order(:created_at)&.last

    return '' if change_log.nil?

    reasons = change_log.display_reasons(true)
    user = User.find_by_id(change_log.user_id)

    if reasons.nil?
      ''
    elsif user&.admin_role?
      change_log.reasons_without_other.join(", ")
    else
      reasons.join(", ")
    end
  end

  def recommendation_token_value(identifier, object)
    submission = object.recommendation_responses&.first&.submission
    user = submission&.user

    profile = user&.profile

    case identifier
    when 'first_name'
      profile&.first_name
    when 'last_name'
      profile&.last_name
    when 'email'
      profile&.email
    when 'student_id'
      user&.student_id
    when 'program_name'
      submission&.program_title
    when 'term_name'
      submission&.term_name
    when 'application_deadline'
      submission&.mailer_deadline
    when 'major_primary'
      user&.primary_major
    when 'minor_primary'
      user&.primary_minor
    when 'gpa_cumulative'
      user&.cumulative_gpa.to_s
    end
  end
end
