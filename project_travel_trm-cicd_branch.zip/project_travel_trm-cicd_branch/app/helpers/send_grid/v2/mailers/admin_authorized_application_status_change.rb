# frozen_string_literal: true

class SendGrid::V2::Mailers::AdminAuthorizedApplicationStatusChange
  include Sidekiq::Worker

  sidekiq_options queue: :mailers

  def perform(admin_ids, application_id, application_status, client_account_logo, program_end_date, program_name, program_start_date, traveler_name)
    admin_objects = admin_objects(admin_ids)

    return if admin_objects.empty?

    personalizations = SendGrid::V2::Personalizers::AdminAuthorizedApplicationStatusChange.personalize(
      admin_objects,
      application_id,
      application_status,
      client_account_logo,
      program_end_date,
      program_name,
      program_start_date,
      traveler_name
    )

    SendGrid::SendMailer.call(
      objects: admin_objects,
      personalizations: personalizations,
      send_grid_mailer_type: send_grid_mailer_type
    )
  end

  private

  def admin_objects(admin_ids)
    sql_select = <<~ESQL
      client_account_infos.subdomain,
      client_accounts.id AS client_account_id,
      client_accounts.org_name,
      users.email,
      users.id AS user_id
    ESQL

    User.select(sql_select).joins(client_account: :client_account_info).where(id: admin_ids)
        .where(
          "NOT EXISTS (
            SELECT id FROM mailer_opt_outs
            WHERE mailer_opt_outs.user_id = users.id
            AND mailer_opt_outs.archived = ?
            AND mailer_opt_outs.send_grid_mailer_type_id = ?
          )",
          false,
          send_grid_mailer_type.id
        )
  end

  def send_grid_mailer_type
    @send_grid_mailer_type ||= SendGridMailerType.find_by_name(
      "admin_authorized_application_status_change"
    )
  end
end
