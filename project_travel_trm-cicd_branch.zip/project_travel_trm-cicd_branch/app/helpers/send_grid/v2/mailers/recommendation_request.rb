# frozen_string_literal: true

class SendGrid::V2::Mailers::RecommendationRequest
  include Sidekiq::Worker

  sidekiq_options queue: :mailers

  def perform(client_account_logo, recommendation_instructions, recommendation_request_id, traveler_name)
    recommendation_object = recommendation_object(recommendation_request_id)

    return unless recommendation_object

    personalizations = SendGrid::V2::Personalizers::RecommendationRequest.personalize(
      client_account_logo,
      recommendation_instructions,
      recommendation_object,
      recommendation_request_id,
      traveler_name
    )

    SendGrid::SendMailer.call(
      objects: [recommendation_object],
      personalizations: personalizations,
      send_grid_mailer_type: send_grid_mailer_type
    )
  end

  private

  def recommendation_object(recommendation_request_id)
    sql_select = <<~ESQL
      client_account_infos.subdomain,
      client_accounts.id AS client_account_id,
      client_accounts.org_name,
      programs.id AS program_id,
      programs.title,
      recommendation_requests.user_email AS email,
      recommendation_requests.token,
      program_ranges.start_date AS program_start_date,
      program_ranges.end_date AS program_end_date,
      program_ranges.use_exact_dates AS use_exact_dates,
      NULL AS user_id
    ESQL

    RecommendationRequest.select(sql_select).joins(
      recommendation_request_responses: [
        recommendation_response: [
          submission: [
            program_range: :program,
            client_account: :client_account_info
          ]
        ]
      ]
    ).where(
      "NOT EXISTS (
        SELECT mailer_opt_outs.id FROM mailer_opt_outs
        INNER JOIN users ON mailer_opt_outs.user_id = users.id
        WHERE recommendation_requests.user_email = users.email
        AND mailer_opt_outs.archived = ?
        AND mailer_opt_outs.send_grid_mailer_type_id = ?
      )",
      false,
      send_grid_mailer_type.id
    ).find_by(id: recommendation_request_id)
  end

  def send_grid_mailer_type
    @send_grid_mailer_type ||= SendGridMailerType.find_by_name("recommendation_request_v2")
  end
end
