# frozen_string_literal: true

class SendGrid::V2::Mailers::ApplicationDeadlineReminder
  include Sidekiq::Worker

  sidekiq_options queue: :mailers

  def perform
    application_ids = Submission.applications_with_deadlines.map(&:id)
    application_objects = application_objects(application_ids)

    return if application_objects.empty?

    personalizations = SendGrid::V2::Personalizers::ApplicationDeadlineReminder.personalize(
      application_objects
    )

    SendGrid::SendMailer.call(
      objects: application_objects,
      personalizations: personalizations,
      send_grid_mailer_type: send_grid_mailer_type
    )
  end

  private

  def application_objects(application_ids)
    sql_select = <<~ESQL
      client_account_infos.subdomain,
      client_accounts.id AS client_account_id,
      client_accounts.org_name,
      profiles.first_name AS profile_first_name,
      programs.title AS program_name,
      traveler_infos.preferred_first_name AS traveler_infos_preferred_first_name,
      submissions.id,
      submissions.deadline,
      submissions.program_range_id,
      submissions.user_id,
      users.email,
      users.first_name
    ESQL

    Submission.select(sql_select).joins(
      program_range: :program,
      user: [
        :profile,
        :traveler_info, {
          client_travelers: [client_account: :client_account_info]
        }
      ]
    ).where(id: application_ids).where(
      "NOT EXISTS (
        SELECT id FROM mailer_opt_outs
        WHERE mailer_opt_outs.user_id = submissions.user_id
        AND mailer_opt_outs.archived = ?
        AND mailer_opt_outs.send_grid_mailer_type_id = ?
      )",
      false,
      send_grid_mailer_type.id
    ).distinct
  end

  def send_grid_mailer_type
    @send_grid_mailer_type ||= SendGridMailerType.find_by_name("application_deadline_reminder")
  end
end
