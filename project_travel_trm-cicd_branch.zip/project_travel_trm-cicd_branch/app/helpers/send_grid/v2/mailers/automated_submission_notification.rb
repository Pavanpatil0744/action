# frozen_string_literal: true

class SendGrid::V2::Mailers::AutomatedSubmissionNotification
  include Sidekiq::Worker

  sidekiq_options queue: :mailers, lock: :until_and_while_executing, lock_args_method: :lock_args

  def perform(automation_mailer_id, submission_id)
    automation_mailer = AutomationMailer.find(automation_mailer_id)
    submission = Submission.find_by_id(submission_id)

    return unless submission.present?

    personalizations = SendGrid::V2::Personalizers::AutomatedSubmissionNotification.personalize(
      automation_mailer,
      submission
    )

    SendGrid::SendMailer.call(
      automation_mailer: automation_mailer,
      objects: [submission],
      personalizations: personalizations,
      send_grid_mailer_type: send_grid_mailer_type
    )
  end

  def self.lock_args(args)
    submission = Submission.find(args.last)
    automation = AutomationMailer.find(args.first).automation
    conditions = automation.automation_triggers.map { |t| t.automation_conditions.map(&:identifier) }.flatten

    if submission.form? && conditions.include?('form_is_added')
      [args.first, submission.corresponding_application_id]
    else
      args
    end
  end

  private

  def send_grid_mailer_type
    @send_grid_mailer_type ||= SendGridMailerType.find_by_name("automated_notification")
  end
end
