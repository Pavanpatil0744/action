# frozen_string_literal: true

class SendGrid::V2::Mailers::RecommendationSubmission
  include Sidekiq::Worker

  sidekiq_options queue: :mailers

  def perform(application_id, client_account_logo)
    application_object = application_object(application_id)

    return unless application_object

    personalizations = SendGrid::V2::Personalizers::RecommendationSubmission.personalize(
      application_object,
      client_account_logo
    )

    SendGrid::SendMailer.call(
      objects: [application_object],
      personalizations: personalizations,
      send_grid_mailer_type: send_grid_mailer_type
    )
  end

  private

  def application_object(application_id)
    sql_select = <<~ESQL
      client_account_infos.subdomain,
      client_accounts.id AS client_account_id,
      client_accounts.org_name,
      programs.title AS program_name,
      submissions.id,
      submissions.program_range_id,
      submissions.user_id,
      users.email
    ESQL

    Submission.select(sql_select).joins(
      program_range: :program,
      user: [client_travelers: [client_account: :client_account_info]]
    ).where(
      "NOT EXISTS (
        SELECT id FROM mailer_opt_outs
        WHERE mailer_opt_outs.user_id = users.id
        AND mailer_opt_outs.archived = ?
        AND mailer_opt_outs.send_grid_mailer_type_id = ?
      )",
      false,
      send_grid_mailer_type.id
    ).find_by(id: application_id)
  end

  def send_grid_mailer_type
    @send_grid_mailer_type ||= SendGridMailerType.find_by_name("recommendation_submission")
  end
end
