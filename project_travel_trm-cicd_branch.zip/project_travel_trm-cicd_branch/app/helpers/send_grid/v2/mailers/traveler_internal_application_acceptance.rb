# frozen_string_literal: true

class SendGrid::V2::Mailers::TravelerInternalApplicationAcceptance
  include Sidekiq::Worker

  sidekiq_options queue: :mailers

  def perform(client_account_logo, program_end_date, program_name, program_start_date, traveler_id)
    traveler_object = traveler_object(traveler_id)

    return unless traveler_object

    personalizations = SendGrid::V2::Personalizers::TravelerInternalApplicationAcceptance.personalize(
      client_account_logo,
      program_end_date,
      program_name,
      program_start_date,
      traveler_object
    )

    SendGrid::SendMailer.call(
      objects: [traveler_object],
      personalizations: personalizations,
      send_grid_mailer_type: send_grid_mailer_type
    )
  end

  private

  def traveler_object(traveler_id)
    sql_select = <<~ESQL
      client_account_infos.subdomain,
      client_accounts.id AS client_account_id,
      client_accounts.org_name,
      profiles.first_name AS profile_first_name,
      traveler_infos.preferred_first_name AS traveler_infos_preferred_first_name,
      users.email,
      users.first_name,
      users.id AS user_id
    ESQL

    User.select(sql_select)
        .joins(:profile, :traveler_info, client_travelers: { client_account: :client_account_info })
        .where(
          "NOT EXISTS (
            SELECT id FROM mailer_opt_outs
            WHERE mailer_opt_outs.user_id = users.id
            AND mailer_opt_outs.archived = ?
            AND mailer_opt_outs.send_grid_mailer_type_id = ?
          )",
          false,
          send_grid_mailer_type.id
        ).find_by(id: traveler_id)
  end

  def send_grid_mailer_type
    @send_grid_mailer_type ||= SendGridMailerType.find_by_name("traveler_internal_application_acceptance")
  end
end
