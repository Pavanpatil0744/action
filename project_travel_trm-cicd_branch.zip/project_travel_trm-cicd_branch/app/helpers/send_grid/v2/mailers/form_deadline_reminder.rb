# frozen_string_literal: true

class SendGrid::V2::Mailers::FormDeadlineReminder
  include Sidekiq::Worker

  sidekiq_options queue: :mailers

  def perform
    form_ids = Submission.forms_with_deadlines.map(&:id)
    form_objects = form_objects(form_ids)

    return if form_objects.empty?

    personalizations = SendGrid::V2::Personalizers::FormDeadlineReminder.personalize(
      form_objects
    )

    SendGrid::SendMailer.call(
      objects: form_objects,
      personalizations: personalizations,
      send_grid_mailer_type: send_grid_mailer_type
    )
  end

  private

  def form_objects(form_ids)
    sql_select = <<~ESQL
      client_account_infos.subdomain,
      client_accounts.id AS client_account_id,
      client_accounts.org_name,
      profiles.first_name AS profile_first_name,
      programs.title AS program_name,
      traveler_infos.preferred_first_name AS traveler_infos_preferred_first_name,
      submissions.id,
      submissions.deadline,
      submissions.program_range_id,
      submissions.user_id,
      templates.name,
      users.email,
      users.first_name
    ESQL

    Submission.select(sql_select).joins(
      [
        :template,
        {
          program_range: :program,
          user: [
            :profile,
            :traveler_info, {
              client_travelers: [client_account: :client_account_info]
            }
          ]
        }
      ]
    ).where(id: form_ids).where(
      "NOT EXISTS (
        SELECT id FROM mailer_opt_outs
        WHERE mailer_opt_outs.user_id = submissions.user_id
        AND mailer_opt_outs.archived = ?
        AND mailer_opt_outs.send_grid_mailer_type_id = ?
      )",
      false,
      send_grid_mailer_type.id
    ).distinct
  end

  def send_grid_mailer_type
    @send_grid_mailer_type ||= SendGridMailerType.find_by_name("form_deadline_reminder")
  end
end
