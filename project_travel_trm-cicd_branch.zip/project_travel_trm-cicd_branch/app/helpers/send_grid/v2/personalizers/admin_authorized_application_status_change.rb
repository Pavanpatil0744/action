# frozen_string_literal: true

class SendGrid::V2::Personalizers::AdminAuthorizedApplicationStatusChange < SendGrid::V2::Personalizers::Base
  def self.personalize(admin_objects, application_id, application_status, client_account_logo, program_end_date, program_name, program_start_date, traveler_name)
    submission = Submission.find(application_id)
    most_recent_reasons = submission.submission_status_change_logs.where(status: ["withdrawn", "deferred"])&.order(:created_at)&.last&.display_reasons(true)

    reasons =
      if ['withdrawn', 'deferred'].include?(submission.status) && most_recent_reasons.present?
        most_recent_reasons.join(", ")
      else
        ''
      end

    admin_objects.map do |admin_object|
      subdomain = admin_object.subdomain

      {
        to: [
          {
            email: admin_object.email
          }
        ],
        dynamic_template_data: {
          application_status: application_status,
          cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}client/form-review/#{application_id}",
          home_campus: admin_object.org_name,
          home_campus_logo: client_account_logo,
          program_end_date: program_end_date,
          program_name: program_name,
          program_start_date: program_start_date,
          traveler_name: traveler_name,
          reason: reasons
        }
      }
    end
  end
end
