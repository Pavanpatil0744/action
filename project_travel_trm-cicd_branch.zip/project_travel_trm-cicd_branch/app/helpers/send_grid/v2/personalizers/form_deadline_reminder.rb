# frozen_string_literal: true

class SendGrid::V2::Personalizers::FormDeadlineReminder < SendGrid::V2::Personalizers::Base
  def self.personalize(form_objects)
    form_objects.map do |form_object|
      client_account = ClientAccount.find(form_object.client_account_id)
      subdomain = form_object.subdomain

      {
        to: [
          {
            email: form_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}traveler/form-submission/#{form_object.id}",
          first_name: first_name(form_object),
          form_deadline_date: form_object.deadline.strftime("%b %d, %Y"),
          form_id: form_object.id,
          form_name: form_object.name,
          home_campus: form_object.org_name,
          home_campus_logo: client_account.logo.url,
          program_name: form_object.program_name
        }
      }
    end
  end
end
