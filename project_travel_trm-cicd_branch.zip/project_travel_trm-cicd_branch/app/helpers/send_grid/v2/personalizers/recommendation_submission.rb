# frozen_string_literal: true

class SendGrid::V2::Personalizers::RecommendationSubmission < SendGrid::V2::Personalizers::Base
  def self.personalize(application_object, client_account_logo)
    subdomain = application_object.subdomain

    [
      {
        to: [
          {
            email: application_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}traveler/form-submission/#{application_object.id}",
          home_campus: application_object.org_name,
          home_campus_logo: client_account_logo,
          program_name: application_object.program_name
        }
      }
    ]
  end
end
