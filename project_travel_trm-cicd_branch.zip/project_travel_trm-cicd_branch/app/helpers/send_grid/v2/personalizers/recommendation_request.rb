# frozen_string_literal: true

class SendGrid::V2::Personalizers::RecommendationRequest < SendGrid::V2::Personalizers::Base
  extend SendGrid::HtmlPreparer

  def self.personalize(client_account_logo, recommendation_instructions, recommendation_object, recommendation_request_id, traveler_name)
    subdomain = recommendation_object.subdomain
    object = RecommendationRequest.find(recommendation_request_id)
    template_type = TemplateType.find_by_name('Recommendation')

    if recommendation_object.use_exact_dates
      program_end_date = recommendation_object.program_end_date.strftime("%b %d, %Y")
      program_start_date = recommendation_object.program_start_date.strftime("%b %d, %Y")
    else
      program_end_date = recommendation_object.program_end_date.strftime("%b %Y")
      program_start_date = recommendation_object.program_start_date.strftime("%b %Y")
    end

    [
      {
        to: [
          {
            email: recommendation_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{subdomain}.#{front_end_uri}visitor/recommendation_submissions/#{recommendation_object.token}",
          home_campus: recommendation_object.org_name,
          home_campus_logo: client_account_logo,
          program_end_date: program_end_date,
          program_link: "https://#{subdomain}.#{front_end_uri}program_brochure/#{recommendation_object.program_id}",
          program_name: recommendation_object.title,
          program_start_date: program_start_date,
          recommendation_instructions: replace_token_placeholders(template_type, object, recommendation_instructions, 'recommendation_token_value'),
          traveler_name: traveler_name
        }
      }
    ]
  end
end
