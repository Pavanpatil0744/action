# frozen_string_literal: true

class SendGrid::V2::Personalizers::RecommendationReminder < SendGrid::V2::Personalizers::Base
  def self.personalize(client_account_logo, recommendation_object, traveler_name)
    subdomain = recommendation_object.subdomain

    [
      {
        to: [
          {
            email: recommendation_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{subdomain}.#{front_end_uri}visitor/recommendation_submissions/#{recommendation_object.token}",
          home_campus: recommendation_object.org_name,
          home_campus_logo: client_account_logo,
          program_link: "https://#{subdomain}.#{front_end_uri}program_brochure/#{recommendation_object.program_id}",
          program_name: recommendation_object.title,
          traveler_name: traveler_name
        }
      }
    ]
  end
end
