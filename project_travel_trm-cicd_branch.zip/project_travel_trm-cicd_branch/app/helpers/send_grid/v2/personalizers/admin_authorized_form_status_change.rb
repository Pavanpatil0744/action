# frozen_string_literal: true

class SendGrid::V2::Personalizers::AdminAuthorizedFormStatusChange < SendGrid::V2::Personalizers::Base
  def self.personalize(admin_objects, client_account_logo, form_name, form_status, program_end_date, program_name, program_start_date, form_id, traveler_name)
    admin_objects.map do |admin_object|
      subdomain = admin_object.subdomain

      {
        to: [
          {
            email: admin_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}client/form-review/#{form_id}",
          form_name: form_name,
          form_status: form_status,
          home_campus: admin_object.org_name,
          home_campus_logo: client_account_logo,
          program_end_date: program_end_date,
          program_name: program_name,
          program_start_date: program_start_date,
          traveler_name: traveler_name
        }
      }
    end
  end
end
