# frozen_string_literal: true

class SendGrid::V2::Personalizers::FreemiumProviderNewApplication < SendGrid::V2::Personalizers::Base
  def self.personalize(admin_objects, program_end_date, program_name, program_provider_logo, program_start_date)
    admin_objects.map do |admin_object|
      {
        to: [
          {
            email: admin_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "mailto:info@via-trm.com",
          home_campus: admin_object.org_name,
          home_campus_logo: program_provider_logo,
          program_end_date: program_end_date,
          program_name: program_name,
          program_start_date: program_start_date
        }
      }
    end
  end
end
