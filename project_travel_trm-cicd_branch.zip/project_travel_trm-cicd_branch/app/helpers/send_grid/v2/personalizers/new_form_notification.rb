# frozen_string_literal: true

class SendGrid::V2::Personalizers::NewFormNotification < SendGrid::V2::Personalizers::Base
  def self.personalize(client_account_logo, user_object)
    subdomain = user_object.subdomain

    [
      {
        to: [
          {
            email: user_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}traveler/my-programs",
          first_name: first_name(user_object),
          home_campus: user_object.org_name,
          home_campus_logo: client_account_logo
        }
      }
    ]
  end
end
