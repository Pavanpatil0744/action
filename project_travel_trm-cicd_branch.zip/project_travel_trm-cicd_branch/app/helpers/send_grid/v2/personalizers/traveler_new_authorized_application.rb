# frozen_string_literal: true

class SendGrid::V2::Personalizers::TravelerNewAuthorizedApplication < SendGrid::V2::Personalizers::Base
  def self.personalize(client_account_logo, intro_text, program_end_date, program_name, program_provider_org_name, program_range_id, program_start_date, traveler_object)
    subdomain = traveler_object.subdomain

    [
      {
        to: [
          {
            email: traveler_object.email
          }
        ],
        dynamic_template_data: {
          authorized_organization: program_provider_org_name,
          cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}traveler/my-programs",
          custom_authorized_message: intro_text,
          first_name: first_name(traveler_object),
          home_campus: traveler_object.org_name,
          home_campus_logo: client_account_logo,
          program_end_date: program_end_date,
          program_name: program_name,
          program_start_date: program_start_date
        }
      }
    ]
  end
end
