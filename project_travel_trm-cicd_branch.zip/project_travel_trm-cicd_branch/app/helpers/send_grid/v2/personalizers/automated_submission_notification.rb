# frozen_string_literal: true

class SendGrid::V2::Personalizers::AutomatedSubmissionNotification < SendGrid::V2::Personalizers::Base
  extend SendGrid::HtmlPreparer

  def self.personalize(automation_mailer, submission)
    base_url = "https://#{submission.client_account_subdomain}.#{front_end_uri}"
    path = automation_mailer.button_target.gsub(":id", submission.id.to_s)

    [
      {
        to: [
          {
            email: submission.email
          }
        ],
        dynamic_template_data: {
          body: replace_token_placeholders(automation_mailer.automation.automation_type, submission, automation_mailer.body),
          button_target: "#{base_url}?jmp=#{base_url}#{path}",
          button_text: automation_mailer.button_text,
          home_campus: submission.client_account_org_name,
          home_campus_logo: submission.client_account_logo_url,
          subject: replace_token_placeholders(automation_mailer.automation.automation_type, submission, automation_mailer.subject)
        }
      }
    ]
  end
end
