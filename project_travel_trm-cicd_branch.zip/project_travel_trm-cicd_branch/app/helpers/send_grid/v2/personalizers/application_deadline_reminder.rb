# frozen_string_literal: true

class SendGrid::V2::Personalizers::ApplicationDeadlineReminder < SendGrid::V2::Personalizers::Base
  def self.personalize(application_objects)
    application_objects.map do |application_object|
      client_account = ClientAccount.find(application_object.client_account_id)
      subdomain = application_object.subdomain
      application_deadline = application_object.deadline&.in_time_zone(client_account.org_timezone)
                                                        &.strftime("%b %d, %Y at %I:%M %p %Z")

      {
        to: [
          {
            email: application_object.email
          }
        ],
        dynamic_template_data: {
          application_deadline: application_deadline,
          application_id: application_object.id,
          cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}traveler/form-submission/#{application_object.id}",
          first_name: first_name(application_object),
          home_campus: application_object.org_name,
          home_campus_logo: client_account.logo.url,
          program_name: application_object.program_name
        }
      }
    end
  end
end
