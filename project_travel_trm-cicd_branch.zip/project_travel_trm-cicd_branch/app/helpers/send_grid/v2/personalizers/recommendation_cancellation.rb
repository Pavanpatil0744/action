# frozen_string_literal: true

class SendGrid::V2::Personalizers::RecommendationCancellation < SendGrid::V2::Personalizers::Base
  def self.personalize(client_account_logo, recommendation_object, traveler_name)
    [
      {
        to: [
          {
            email: recommendation_object.email
          }
        ],
        dynamic_template_data: {
          home_campus: recommendation_object.org_name,
          home_campus_logo: client_account_logo,
          traveler_name: traveler_name
        }
      }
    ]
  end
end
