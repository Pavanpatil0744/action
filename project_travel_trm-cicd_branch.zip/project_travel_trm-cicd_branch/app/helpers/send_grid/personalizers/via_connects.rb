# frozen_string_literal: true

class SendGrid::Personalizers::ViaConnects < SendGrid::Personalizers::Base
  def self.personalize(recipient_objects, client_account, lead_count)
    recipient_objects.map do |recipient_object|
      {
        to: [
          {
            email: recipient_object.email
          }
        ],
        dynamic_template_data: {
          home_campus: client_account.org_name,
          home_campus_logo: client_account.logo_url,
          lead_count: lead_count
        }
      }
    end
  end
end
