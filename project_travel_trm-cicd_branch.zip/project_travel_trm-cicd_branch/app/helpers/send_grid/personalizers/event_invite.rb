# frozen_string_literal: true

class SendGrid::Personalizers::EventInvite < SendGrid::Personalizers::Base
  def self.personalize(client_account_logo, event_traveler_object)
    [
      {
        to: [
          {
            email: event_traveler_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{event_traveler_object.subdomain}.#{front_end_uri}visitor/events/#{event_traveler_object.event_id}",
          event_location: event_traveler_object.event_location,
          event_name: event_traveler_object.event_name,
          event_start: event_traveler_object.event_start.in_time_zone(event_traveler_object.event_timezone).strftime("%B %d, %Y at %I:%M %p %Z"),
          first_name: event_traveler_object.first_name,
          home_campus: event_traveler_object.org_name,
          home_campus_logo: client_account_logo
        }
      }
    ]
  end
end
