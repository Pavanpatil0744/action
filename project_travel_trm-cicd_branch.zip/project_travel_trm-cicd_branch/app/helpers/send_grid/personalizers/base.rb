# frozen_string_literal: true

class SendGrid::Personalizers::Base
  def self.first_name(object)
    first_name = object.traveler_infos_preferred_first_name
    first_name = object.profile_first_name if first_name.blank?
    first_name = object.first_name if first_name.blank?

    first_name.blank? ? nil : first_name
  end

  def self.front_end_uri
    Rails.configuration.front_end_uri
  end
end
