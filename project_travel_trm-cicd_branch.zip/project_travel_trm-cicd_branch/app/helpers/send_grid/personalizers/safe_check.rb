# frozen_string_literal: true

class SendGrid::Personalizers::SafeCheck < SendGrid::Personalizers::Base
  def self.personalize(client_account_logo, receipt_uuid, short_text, text, traveler_object)
    [
      {
        to: [
          {
            email: traveler_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{traveler_object.subdomain}.#{front_end_uri}safecheck/checkin/#{receipt_uuid}",
          home_campus: traveler_object.org_name,
          home_campus_logo: client_account_logo,
          safe_check_short_form: short_text,
          safe_check_long_form: text
        }
      }
    ]
  end
end
