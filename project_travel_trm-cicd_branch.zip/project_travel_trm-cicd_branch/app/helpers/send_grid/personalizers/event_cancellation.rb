# frozen_string_literal: true

class SendGrid::Personalizers::EventCancellation < SendGrid::Personalizers::Base
  def self.personalize(client_account_logo, event_traveler_objects)
    event_traveler_objects.map do |event_traveler_object|
      subdomain = event_traveler_object.subdomain

      cta_path = if event_traveler_object.user_id
                   "https://#{subdomain}.#{front_end_uri}"
                 else
                   "https://#{subdomain}.#{front_end_uri}traveler/sign_up"
                 end

      {
        to: [
          {
            email: event_traveler_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: cta_path,
          event_name: event_traveler_object.event_name,
          event_start: event_traveler_object.event_start.in_time_zone(event_traveler_object.event_timezone).strftime("%B %d, %Y at %I:%M %p %Z"),
          first_name: event_traveler_object.first_name,
          home_campus: event_traveler_object.org_name,
          home_campus_logo: client_account_logo
        }
      }
    end
  end
end
