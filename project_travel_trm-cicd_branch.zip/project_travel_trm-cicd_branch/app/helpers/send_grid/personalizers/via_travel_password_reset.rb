# frozen_string_literal: true

class SendGrid::Personalizers::ViaTravelPasswordReset < SendGrid::Personalizers::Base
  def self.personalize(client_account_logo, plan_name, user_object)
    subdomain = user_object.subdomain

    [
      {
        to: [
          {
            email: user_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{subdomain}.#{front_end_uri}visitor/set_password/#{user_object.reset_password_token}?jmp=https://#{subdomain}.#{front_end_uri}traveler/dashboard",
          home_campus: user_object.org_name,
          home_campus_logo: client_account_logo,
          plan_name: plan_name
        }
      }
    ]
  end
end
