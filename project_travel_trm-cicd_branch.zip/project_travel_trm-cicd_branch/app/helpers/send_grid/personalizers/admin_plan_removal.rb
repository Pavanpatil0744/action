# frozen_string_literal: true

class SendGrid::Personalizers::AdminPlanRemoval < SendGrid::Personalizers::Base
  def self.personalize(admin_objects, client_account_logo, plan_canceller, plan_name)
    admin_objects.map do |admin_object|
      {
        to: [
          {
            email: admin_object.email
          }
        ],
        dynamic_template_data: {
          home_campus: admin_object.org_name,
          home_campus_logo: client_account_logo,
          plan_canceller: plan_canceller,
          plan_name: plan_name,
        }
      }
    end
  end
end
