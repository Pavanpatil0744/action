# frozen_string_literal: true

class SendGrid::Personalizers::PasswordReset < SendGrid::Personalizers::Base
  def self.personalize(client_account_logo, user_object)
    [
      {
        to: [
          {
            email: user_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{user_object.subdomain}.#{front_end_uri}visitor/set_password/#{user_object.reset_password_token}",
          home_campus: user_object.org_name,
          home_campus_logo: client_account_logo
        }
      }
    ]
  end
end
