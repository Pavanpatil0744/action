# frozen_string_literal: true

module SendGrid
  module Personalizers
    module StandardReports
      class ReadyToDownloadNotification < SendGrid::Personalizers::Base
        def self.personalize(client_account_logo, admin_object)
          [
            {
              to: [
                {
                  email: admin_object.email
                }
              ],
              dynamic_template_data: {
                home_campus_logo: client_account_logo,
                cta_path: "https://#{admin_object.subdomain}.#{front_end_uri}reports/downloads"
              }
            }
          ]
        end
      end
    end
  end
end