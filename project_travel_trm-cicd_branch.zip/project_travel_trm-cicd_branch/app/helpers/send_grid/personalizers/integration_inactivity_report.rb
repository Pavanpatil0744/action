# frozen_string_literal: true

class SendGrid::Personalizers::IntegrationInactivityReport < SendGrid::Personalizers::Base
  def self.personalize(inactivity_report_html)
    [
      {
        to: [{ email: ENV["INTEGRATION_INACTIVITY_REPORT_EMAIL"] }],
        dynamic_template_data: { inactivity_report_html: inactivity_report_html }
      }
    ]
  end
end
