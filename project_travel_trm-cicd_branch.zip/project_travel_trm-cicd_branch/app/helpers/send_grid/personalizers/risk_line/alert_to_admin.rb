# frozen_string_literal: true

module SendGrid
  module Personalizers
    module RiskLine
      # Admin alert Notification
      class AlertToAdmin < SendGrid::Personalizers::Base
        def self.personalize(alert_object)
          alerts = []
          alert_object.each do |l|
            subdomain = l.user.client_account.subdomain
            alerts << {
              to: [
                {
                  email: l.user.email
                }
              ],
              dynamic_template_data: {
                cta_path: "https://#{subdomain}.#{front_end_uri}client/alert-detail/#{l.trm_risk_alert.guid}",
                alert_headline: l.trm_risk_alert.title,
                alert_citystate: l.trm_risk_alert.alert_location,
                home_campus: l.user.client_account.org_name,
                home_campus_logo: l.user.client_account.logo&.url,
                risk_level: l.trm_risk_alert.trm_risk_level.name,
                risk_type: l.trm_risk_alert.trm_risk_category.name
              }
            }
          end
          alerts
        end
      end
    end
  end
end