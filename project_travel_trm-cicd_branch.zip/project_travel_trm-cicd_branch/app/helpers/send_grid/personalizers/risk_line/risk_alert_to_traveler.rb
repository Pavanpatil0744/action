# frozen_string_literal: true

module SendGrid
  module Personalizers
    module RiskLine
      # Traveler alert Notification
      class RiskAlertToTraveler < SendGrid::Personalizers::Base
        def self.personalize(alert_object, client_account)
          alerts = []
          subdomain = client_account.subdomain
          alert_object.each do |l|
            alerts << {
              to: [
                {
                  email: l.user.email
                }
              ],
              dynamic_template_data: {
                cta_path: "https://#{subdomain}.#{front_end_uri}traveler-alert-detail/#{l.uuid}",
                alert_headline: l.trm_risk_alert.title,
                alert_citystate: l.trm_risk_alert.alert_location,
                first_name: l.user.first_name,
                home_campus: client_account.org_name,
                home_campus_logo: client_account.logo&.url
              }
            }
          end
          alerts
        end
      end
    end
  end
end