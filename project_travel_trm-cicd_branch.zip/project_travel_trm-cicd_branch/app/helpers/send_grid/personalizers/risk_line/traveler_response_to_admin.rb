# frozen_string_literal: true

module SendGrid
  module Personalizers
    module RiskLine
      # Traveler alert Notification to admin
      class TravelerResponseToAdmin < SendGrid::Personalizers::Base
        def self.personalize(traveler, recipients, client_account)
          subdomain = client_account.subdomain
          recipient_emails = []
          recipients.each do |l|
            recipient_emails << {
              to: [
                {
                  email: l.email
                }
              ],
              dynamic_template_data: {
                cta_path: "https://#{subdomain}.#{front_end_uri}client/alert-detail/#{traveler.trm_risk_alert.guid}",
                alert_headline: traveler.trm_risk_alert.title,
                alert_citystate: traveler.trm_risk_alert.alert_location,
                checkin_message: traveler.custom_message,
                checkin_location: traveler&.location_detail.values.join("; "),
                first_name: l.first_name,
                home_campus: client_account.org_name,
                home_campus_logo: client_account.logo&.url,
                onsite_phone: traveler.on_site_phone_number,
                safecheck_phone: traveler.safe_check_phone_number,
                traveler_email: traveler.user.email,
                traveler_name: traveler.user.name
              }
            }
          end
          recipient_emails
        end
      end
    end
  end
end