# frozen_string_literal: true

class SendGrid::Personalizers::TravelerPlanCreation < SendGrid::Personalizers::Base
  def self.personalize(client_account_logo, plan_id, plan_name, traveler_object)
    subdomain = traveler_object.subdomain

    [
      {
        to: [
          {
            email: traveler_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}plans/plan-overview/#{plan_id}",
          first_name: first_name(traveler_object),
          home_campus: traveler_object.org_name,
          home_campus_logo: client_account_logo,
          plan_name: plan_name
        }
      }
    ]
  end
end
