# frozen_string_literal: true

module SendGrid
  module Personalizers
    module AuthorizedProgram
      # personalizer for favorite program to freemium program provider mailer data
      class FavoriteProgramToFreemiumProgramProvider < SendGrid::Personalizers::Base
        def self.personalize(admin_objects, program_name, program_provider_logo)
          admin_objects.map do |admin_object|
            {
              to: [
                {
                  email: admin_object.email
                }
              ],
              dynamic_template_data: {
                home_campus: admin_object.org_name,
                home_campus_logo: program_provider_logo,
                program_name: program_name
              }
            }
          end
        end
      end
    end
  end
end