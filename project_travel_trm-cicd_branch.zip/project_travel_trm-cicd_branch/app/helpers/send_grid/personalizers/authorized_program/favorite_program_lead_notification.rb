# frozen_string_literal: true

module SendGrid
  module Personalizers
    module AuthorizedProgram
      # Personalizer for favorite program lead notification
      class FavoriteProgramLeadNotification < SendGrid::Personalizers::Base
        def self.personalize(program_name, program_provider_org_name)
          [
            {
              to: [
                {
                  email: "leads@via-trm.com"
                }
              ],
              dynamic_template_data: {
                authorized_organization: program_provider_org_name,
                program_name: program_name
              }
            }
          ]
        end
      end
    end
  end
end