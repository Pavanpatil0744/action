# frozen_string_literal: true

module SendGrid
  module Personalizers
    module AuthorizedProgram
      # Personalizer for favorite program to program provider
      class FavoriteProgramToProgramProvider < SendGrid::Personalizers::Base
        def self.personalize(admin_objects, program_name, program_provider_logo, traveler_email, traveler_name)
          admin_objects.map do |admin_object|
            {
              to: [
                {
                  email: admin_object.email
                }
              ],
              dynamic_template_data: {
                home_campus: admin_object.org_name,
                home_campus_logo: program_provider_logo,
                program_name: program_name,
                traveler_email: traveler_email,
                traveler_name: traveler_name
              }
            }
          end
        end
      end
    end
  end
end
