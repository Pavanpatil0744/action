# frozen_string_literal: true

class SendGrid::Personalizers::TravelerPlanRemoval < SendGrid::Personalizers::Base
  def self.personalize(client_account_logo, plan_canceller, plan_name, traveler_objects)
    traveler_objects.map do |traveler_object|
      {
        to: [
          {
            email: traveler_object.email
          }
        ],
        dynamic_template_data: {
          first_name: first_name(traveler_object),
          home_campus: traveler_object.org_name,
          home_campus_logo: client_account_logo,
          plan_canceller: plan_canceller,
          plan_name: plan_name
        }
      }
    end
  end
end
