# frozen_string_literal: true

class SendGrid::Personalizers::AdminBatchMessage < SendGrid::Personalizers::Base
  def self.personalize(admin_objects, client_account_logo, message_body, message_count, sender_full_name_or_email)
    admin_objects.map do |admin_object|
      {
        to: [
          {
            email: admin_object.email
          }
        ],
        dynamic_template_data: {
          admin_name: sender_full_name_or_email,
          home_campus: admin_object.org_name,
          home_campus_logo: client_account_logo,
          message_content: message_body,
          number_messages: message_count
        }
      }
    end
  end
end
