# frozen_string_literal: true

class SendGrid::Personalizers::AskAQuestionLeadNotification < SendGrid::Personalizers::Base
  def self.personalize(home_campus, program_name, program_provider_org_name)
    [
      {
        to: [
          {
            email: "leads@via-trm.com"
          }
        ],
        dynamic_template_data: {
          authorized_organization: program_provider_org_name,
          home_campus: home_campus,
          program_name: program_name
        }
      }
    ]
  end
end
