# frozen_string_literal: true

class SendGrid::Personalizers::MessageFromAdminToTraveler < SendGrid::Personalizers::Base
  def self.personalize(client_account_logo, message_body, message_subject, sender_full_name_or_email, traveler_objects)
    traveler_objects.map do |traveler_object|
      subdomain = traveler_object.subdomain

      {
        to: [
          {
            email: traveler_object.email
          }
        ],
        dynamic_template_data: {
          admin_name: sender_full_name_or_email,
          cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}traveler/messages",
          first_name: first_name(traveler_object),
          home_campus: traveler_object.org_name,
          home_campus_logo: client_account_logo,
          message_content: message_body,
          message_subject: message_subject
        }
      }
    end
  end
end
