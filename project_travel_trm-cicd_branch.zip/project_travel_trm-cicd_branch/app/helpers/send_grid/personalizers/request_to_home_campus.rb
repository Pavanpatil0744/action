# frozen_string_literal: true

class SendGrid::Personalizers::RequestToHomeCampus < SendGrid::Personalizers::Base
  def self.personalize(admin_objects, client_account_logo, program_name, program_provider_org_name, traveler_id, traveler_email, traveler_name)
    admin_objects.map do |admin_object|
      subdomain = admin_object.subdomain

      {
        to: [
          {
            email: admin_object.email
          }
        ],
        dynamic_template_data: {
          authorized_organization: program_provider_org_name,
          cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}client/travelers/#{traveler_id}?tab=messages",
          home_campus: admin_object.org_name,
          home_campus_logo: client_account_logo,
          program_name: program_name,
          traveler_email: traveler_email,
          traveler_name: traveler_name
        }
      }
    end
  end
end
