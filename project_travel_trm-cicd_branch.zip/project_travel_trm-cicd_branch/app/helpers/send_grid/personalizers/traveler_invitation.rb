# frozen_string_literal: true

class SendGrid::Personalizers::TravelerInvitation < SendGrid::Personalizers::Base
  def self.personalize(client_account_logo, inviter_full_name_or_email, traveler_invitation_object)
    client_account = ClientAccount.find(traveler_invitation_object.client_account_id)
    redirect_path = client_account.sso? ? "authV2/welcome" : "traveler/sign_up"

    [
      {
        to: [
          {
            email: traveler_invitation_object.email
          }
        ],
        dynamic_template_data: {
          admin_name: inviter_full_name_or_email,
          cta_path: "https://#{traveler_invitation_object.subdomain}.#{front_end_uri}#{redirect_path}",
          first_name: traveler_invitation_object.first_name,
          home_campus: traveler_invitation_object.org_name,
          home_campus_logo: client_account_logo
        }
      }
    ]
  end
end
