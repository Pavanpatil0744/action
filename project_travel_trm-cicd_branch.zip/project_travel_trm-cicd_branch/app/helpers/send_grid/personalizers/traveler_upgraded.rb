# frozen_string_literal: true

class SendGrid::Personalizers::TravelerUpgraded < SendGrid::Personalizers::Base
  def self.personalize(admin_object, client_account_logo)
    [
      {
        to: [
          {
            email: admin_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{admin_object.subdomain}.#{front_end_uri}",
          home_campus: admin_object.org_name,
          home_campus_logo: client_account_logo
        }
      }
    ]
  end
end
