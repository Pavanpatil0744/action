# frozen_string_literal: true

class SendGrid::Personalizers::RequestToFreemiumProgramProvider < SendGrid::Personalizers::Base
  def self.personalize(admin_objects, home_campus, program_name, program_provider_logo)
    admin_objects.map do |admin_object|
      {
        to: [
          {
            email: admin_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "mailto:info@via-trm.com",
          home_campus: home_campus,
          home_campus_logo: program_provider_logo,
          program_name: program_name
        }
      }
    end
  end
end
