# frozen_string_literal: true

module SendGrid
  module Personalizers
    class MinorApplicationSubmissionToAdmin < SendGrid::Personalizers::Base
      def self.personalize(admin_objects, submission_id)
        submission = Submission.find submission_id
        client_account = submission.client_account
        subdomain = client_account.subdomain
        program_range = submission.program_range

        admin_objects.map do |l|
          {
            to: [
              {
                email: l.email
              }
            ],
            dynamic_template_data: {
              cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}client/travelers/#{submission.user.id}",
              home_campus: client_account.org_name,
              home_campus_logo: client_account.logo&.url,
              first: submission.user.name,
              last: submission.user.name,
              email: submission.user.email,
              user_id: submission.user.id,
              program_name: program_range.program.title,
              term_start_date: program_range.start_date.strftime("%b %d, %Y"),
              term_end_date: program_range.end_date.strftime("%b %d, %Y")
            }
          }
        end
      end
    end
  end
end
