# frozen_string_literal: true

class SendGrid::Personalizers::TravelerNewAccountCreation < SendGrid::Personalizers::Base
  def self.personalize(client_account_logo, traveler_object)
    subdomain = traveler_object.subdomain

    [
      {
        to: [
          {
            email: traveler_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{subdomain}.#{front_end_uri}",
          first_name: first_name(traveler_object),
          home_campus: traveler_object.org_name,
          home_campus_logo: client_account_logo,
        }
      }
    ]
  end
end
