# frozen_string_literal: true

module SendGrid
  module Personalizers
    module WithdrawRequest
      # Admin Request Notification
      class RequestNotificationToAdmin < SendGrid::Personalizers::Base
        def self.personalize(admin_objects, withdraw_request)
          submission = withdraw_request.submission
          client_account = submission.client_account
          subdomain = client_account.subdomain
          program_range = submission.program_range

          admin_objects.map do |l|
            {
              to: [
                {
                  email: l.email
                }
              ],
              dynamic_template_data: {
                cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}client/form-review/#{submission.id}",
                home_campus: client_account.org_name,
                home_campus_logo: client_account.logo&.url,
                traveler_name: submission.user.name,
                program_name: program_range.program.title,
                term_start_date: program_range.start_date.strftime("%b %d, %Y"),
                term_end_date: program_range.end_date.strftime("%b %d, %Y"),
                application_status: submission.submission_status.name,
                withdraw_request_reason: withdraw_request.reason
              }
            }
          end
        end
      end
    end
  end
end
