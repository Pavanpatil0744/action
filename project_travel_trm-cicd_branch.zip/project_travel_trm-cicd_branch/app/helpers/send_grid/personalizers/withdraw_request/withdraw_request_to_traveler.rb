# frozen_string_literal: true

module SendGrid
  module Personalizers
    module WithdrawRequest
      # Admin alert Notification
      class WithdrawRequestToTraveler < SendGrid::Personalizers::Base
        def self.personalize(withdraw_request)
          submission = withdraw_request.submission
          client_account = submission.client_account
          traveler = submission.user
          subdomain = client_account.subdomain

          [
            {
              to: [
                {
                  email: traveler.email
                }
              ],
              dynamic_template_data: {
                cta_path: "https://#{subdomain}.#{front_end_uri}?jmp=https://#{subdomain}.#{front_end_uri}traveler/my-programs/details/#{withdraw_request.submission_id}",
                home_campus: client_account.org_name,
                home_campus_logo: client_account.logo&.url,
                traveler_name: traveler.name,
                program_name: submission.program_range.program.title,
                withdraw_request_status: withdraw_request.status == "accepted" ? "Approved" : "Declined"
              }
            }
          ]
        end
      end
    end
  end
end
