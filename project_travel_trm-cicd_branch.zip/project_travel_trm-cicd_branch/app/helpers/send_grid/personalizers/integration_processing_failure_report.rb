# frozen_string_literal: true

class SendGrid::Personalizers::IntegrationProcessingFailureReport < SendGrid::Personalizers::Base
  def self.personalize(failure_report_html)
    [
      {
        to: [{ email: ENV["INTEGRATION_PROCESSING_FAILURE_REPORT_EMAIL"] }],
        dynamic_template_data: { failure_report_html: failure_report_html }
      }
    ]
  end
end
