# frozen_string_literal: true

class SendGrid::Personalizers::TravelerPlanStatusUpdate < SendGrid::Personalizers::Base
  def self.personalize(client_account_logo, plan_name, plan_status, traveler_objects)
    traveler_objects.map do |traveler_object|
      {
        to: [
          {
            email: traveler_object.email
          }
        ],
        dynamic_template_data: {
          cta_path: "https://#{traveler_object.subdomain}.#{front_end_uri}",
          first_name: first_name(traveler_object),
          home_campus: traveler_object.org_name,
          home_campus_logo: client_account_logo,
          plan_name: plan_name,
          plan_status: plan_status
        }
      }
    end
  end
end
