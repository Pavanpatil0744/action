# frozen_string_literal: true

module Api::DashboardCardsHelper
  def role_names(user)
    user.roles.pluck(:name)&.map(&:to_sym)
  end

  def restricted_access?(user, client_account, setting_name, setting_type)
    setting = client_account.client_account_info.role_settings[setting_name]

    return true if setting.nil?

    role_names(user).select { |role| setting[setting_type][role] == true }.any? ? false : true
  end

  def counters(identifier, user, client_account, end_date)
    case identifier
    # when "travelers"
    #   interested_count = travelers_count(user, client_account, "Interested")
    #   applying_count = travelers_count(user, client_account, "Applying")

    #   [
    #     {
    #       count: interested_count,
    #       description: "Interested #{client_account.use_custom_aliases ? client_account.alias_travelers : 'Travelers'}"
    #     },
    #     {
    #       count: applying_count,
    #       description: "Applying #{client_account.use_custom_aliases ? client_account.alias_travelers : 'Travelers'}"
    #     }
    #   ]
    # when "applications"
    #   [
    #     {
    #       count: applications_count(user, client_account, "Submitted", end_date),
    #       description: "Submitted Applications"
    #     },
    #     {
    #       count: applications_count(user, client_account, "Incomplete", end_date),
    #       description: "Incomplete Applications"
    #     }
    #   ]
    # when "forms"
    #   [
    #     {
    #       count: forms_count(user, client_account, ["Submitted"], end_date),
    #       description: "Forms Submitted"
    #     },
    #     {
    #       count: forms_count(user, client_account, ["Started", "Not Started"], end_date),
    #       description: "Forms Not Started / Started"
    #     }
    #   ]
    when "internal_programs"
      program_count = internal_programs_count(user, client_account)

      [
        {
          count: program_count,
          description: "Published #{client_account.use_custom_aliases ? client_account.alias_programs : 'Programs'}"
        }
      ]
    # when "authorized_programs"
    #   program_count = authorized_programs_count(user, client_account)

    #   [
    #     {
    #       count: program_count,
    #       description: "Authorized #{client_account.use_custom_aliases ? client_account.alias_programs : 'Programs'}"
    #     }
    #   ]
    # when "builder"
    #   [
    #     {
    #       count: builder_count(client_account, :form_templates),
    #       description: "Published Forms"
    #     },
    #     {
    #       count: builder_count(client_account, :application_templates),
    #       description: "Published Applications"
    #     }
    #   ]
    # when "events"
    #   [
    #     {
    #       count: events_count(client_account),
    #       description: "Upcoming Events"
    #     }
    #   ]
    # when "via_travel"
    #   [
    #     {
    #       count: plans_count(client_account, "on_site"),
    #       description: "On-site Plans"
    #     },
    #     {
    #       count: plans_count(client_account, "upcoming"),
    #       description: "Upcoming Plans"
    #     }
    #   ]
    when "engagement_analytics"
      [
        {
          count: engagement_analytics_count(client_account),
          description: 'Actions taken year to date'
        }
      ]
    else
      []
    end
  end

  private

  # def travelers_count(user, client_account, step)
  #   admin_ids = client_account.users.without_role(:traveler).not_actively_applying.pluck(:id)

  #   if user.is_occasional_user?
  #     client_account.report_travelers.where(user_id: user.assigned_travelers.pluck(:id))
  #   else
  #     client_account.report_travelers
  #   end.where.not(user_id: admin_ids).where("tracking_steps LIKE ?", "%#{step}%").size
  # end

  # def applications_count(user, client_account, status, end_date)
  #   report_applications = if user.is_occasional_user?
  #                           client_account.report_submissions.where(
  #                             submission_id: user.assigned_application_submissions
  #                           )
  #                         else
  #                           client_account.report_submissions.where(
  #                             submission_id: client_account.application_submissions
  #                           )
  #                         end.where(status: status)

  #   if end_date.present?
  #     report_applications.where("program_range_end_date_raw >= ?", end_date).size
  #   else
  #     report_applications.size
  #   end
  # end

  # def forms_count(user, client_account, statuses, end_date)
  #   report_forms = if user.is_occasional_user?
  #                    client_account.report_submissions.where(
  #                      submission_id: user.assigned_form_submissions
  #                    )
  #                  else
  #                    client_account.report_submissions.where(
  #                      submission_id: client_account.form_submissions
  #                    )
  #                  end.where(status: statuses)

  #   if end_date.present?
  #     report_forms.where("program_range_end_date_raw >= ?", end_date).size
  #   else
  #     report_forms.size
  #   end
  # end

  def internal_programs_count(user, client_account)
    if user.is_occasional_user?
      user.assigned_programs.where(status: 1, primary_client_account_id: user.client_account_id).size
    else
      client_account.internal_programs.where(status: 1).size
    end
  end

  # def authorized_programs_count(user, client_account)
  #   user.is_occasional_user? ? 0 : client_account.authorized_programs.size
  # end

  # def builder_count(client_account, item)
  #   client_account.send(item).where(status: 1).size
  # end

  # def events_count(client_account)
  #   client_account.events.where("start >= ?", DateTime.current).size
  # end

  # def plans_count(client_account, type)
  #   plans = client_account.plans

  #   if type == "upcoming"
  #     plans.where("start_date >= ?", DateTime.current).size
  #   elsif type == "on_site"
  #     plans.where("start_date < ? AND end_date >= ?", DateTime.current, DateTime.current).size
  #   end
  # end

  def engagement_analytics_count(client_account)
    ViaConnectAction.select('DISTINCT ON (action, program_name, user_email) *')
                    .where(
                      "program_provider = ? AND
                      CAST(via_connect_actions.created_at AT TIME ZONE 'UTC' AT TIME ZONE ? AS TEXT)::DATE BETWEEN ? AND ?",
                      client_account.org_name,
                      client_account.org_timezone,
                      Date.today.beginning_of_year.to_date,
                      Date.today.to_date
                    ).where(internal: false).length
  end
end
