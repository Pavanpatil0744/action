# frozen_string_literal: true

module Api::Client::ProgramsHelper
  def available_email(user)
    user.profile.email || user.email
  end
end
