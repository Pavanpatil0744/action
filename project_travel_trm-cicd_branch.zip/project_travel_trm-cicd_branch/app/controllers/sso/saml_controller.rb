module Sso
  class SamlController < ApplicationController
    skip_before_action :verify_authenticity_token, only: [:acs]
    before_action :redirect_signed_in_user, only: [:log_in]

    respond_to :xml, only: [:metadata]

    def metadata
      if org_name
        render xml: metadata_xml, content_type: 'application/samlmetadata+xml'
      else
        render body: nil, status: 422
      end
    end

    def log_in
      session[:source] = params[:source]
      redirect_to sign_in_redirect_url
    rescue Sso::Errors::NoResponse # redirect to traveler's sign in page for now
      redirect_to traveler_new_user_session_path,
        alert: "Organization with subdomain '#{org_name}' SSO is not available at this time."
    end

    def acs
      if acs_response.valid?
        "SamlController#acs sees acs_response:"
        pp acs_response
        sign_in(sso_user)
        set_up_session_for(sso_user)
        complete_traveler_invitation if sso_user.is_traveler?
        create_sign_in_log
        redirect_to after_sign_in_path_for(sso_user)
        sso_authentication = SsoAuthentication.where(user_id: sso_user.id, client_account_id: client_account.id).first
        IntegrationAtLoginWorker.perform_async(sso_authentication.id) if sso_authentication
      else
        logger.error(acs_response.errors.join(', '))
        redirect_to traveler_new_user_session_path,
          alert: "Unable to sign in."
      end
    rescue Sso::Errors::NoResponse # redirect to traveler's sign in page for now
      redirect_to traveler_new_user_session_path,
        alert: "Organization with subdomain '#{org_name}' SSO is not available at this time."
    rescue Sso::UnauthorizedUserError => e
      redirect_to traveler_new_user_session_path,
        alert: e.message
    end

    private
    def metadata_xml
      settings = Sso::BuildSettings.new(setting_options, Rails.cache).execute
      Sso::Metadata.new(settings).execute
    end

    def sso_user
      @sso_user ||= Sso::User.new(acs_response, signup_source_data).execute
    end

    def complete_traveler_invitation
      Traveler::CompleteInvitation.new(sso_user, client_account.id, signup_source_data).execute
    end

    def client_account
      ClientAccountInfo.find_by_subdomain(org_name).client_account
    end

    def set_up_session_for(user)
      Sso::Session.new(session, user, acs_response).execute
    end

    def sign_in_redirect_url
      Sso::SignIn.new(settings_with_idp).redirect_url
    end

    def acs_response
      @acs_response ||= (
        Sso::Acs.new(
          params[:SAMLResponse],
          settings_with_idp,
          org_name
        ).response
      )
    end

    def settings_with_idp
      Sso::BuildSettings.with_idp(setting_options, Rails.cache)
    end

    def setting_options
      {
        assertion_consumer_service_url: sso_acs_url(org: org_name),
        issuer: sso_metadata_url,
        secrets: secrets,
        single_logout_service_url: sso_log_out_url(org: org_name),
        subdomain: org_name
      }
    end

    def signup_source_data
      @signup_source_data ||= (
        begin
          Crypto::Secrets.new(secrets.secret_key_base).decrypt(source)
        rescue Crypto::InvalidPayload
          {}
        end
      )
    end

    def source
      session[:source]
    end

    def secrets
      @secrets ||= Rails.application.secrets
    end

    def redirect_signed_in_user
      if user_signed_in?
        redirect_to after_sign_in_path_for(current_user)
      end
    end

    def org_name
      @org_name ||= params[:org]
    end

    def create_sign_in_log
      SignInLog.create(
        sign_in_type: 'sso',
        user_id: sso_user.id,
        client_account_id: client_account.id
      )
    end
  end
end
