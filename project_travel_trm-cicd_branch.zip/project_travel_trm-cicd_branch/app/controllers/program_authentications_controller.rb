# frozen_string_literal: true

class ProgramAuthenticationsController < ApplicationController
  before_action :find_program, only: :create
  before_action :validate_params, only: :create
  before_action :validate_code, only: :create

  def create
    render json: { message: "Access granted" }, status: :ok
  end

  private

  def find_program
    @program = Program.find_by_id(params[:program_id])

    return not_found unless @program
  end

  def validate_params
    errors = []

    errors << "Access code can't be blank" if params[:access_code].nil?
    errors << "Program ID can't be blank" if params[:program_id].nil?

    render json: { message: errors }, status: :bad_request if errors.any?
  end

  def validate_code
    valid = params[:access_code] == @program.access_code

    render json: { message: "Invalid code entered" }, status: :forbidden unless valid
  end
end
