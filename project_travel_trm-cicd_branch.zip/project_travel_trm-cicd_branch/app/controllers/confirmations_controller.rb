class ConfirmationsController < Devise::ConfirmationsController

  protected

  def after_confirmation_path_for(resource_name, resource)
    if resource.is_traveler?
      traveler_new_user_session_path
    elsif resource.client_user_role?
      client_new_user_session_path
    else
      root_path
    end
  end

end
