# frozen_string_literal: true

require "controllers/sanitized_referrer"

class ApplicationController < ActionController::Base
  include Controllers::SanitizedReferrer
  include ErrorHandler
  include Pundit::Authorization
  # include CustomAuthentication

  protect_from_forgery with: :exception
  protect_from_forgery with: :null_session, if: proc { |c| c.request.format == "application/json" }

  add_flash_types :info

  acts_as_token_authentication_handler_for User, fallback: :none

  before_action :permissions_policy_header
  before_action :set_paper_trail_whodunnit
  before_action :init_user
  before_action :set_current_user
  after_action :log_activity

  def init_user
    @user = current_user || User.new
  end

  def after_sign_in_path_for(user)
    if user.instance_of?(AdminUser)
      admin_dashboard_path
    elsif user.role_name == "pt_master"
      sidekiq_web_path
    else
      session["user_return_to"] || after_login_path(user)
    end
  end

  def no_cache
    response.headers["Cache-Control"] = "no-cache, no-store, max-age=0, must-revalidate"
    response.headers["Expires"] = "Fri, 01 Jan 1990 00:00:00 GMT"
    response.headers["Pragma"] = "no-cache"
  end

  def after_sign_out_path_for(resource_or_scope)
    new_admin_user_session_path
  end

  def authenticate_user!
    request.env["warden"].request.env["devise.skip_trackable"] = "1"
    token_user = User.find_by(authentication_token: params["user_token"])
    # token = request.headers["HTTP_X_USER_TOKEN"]
    # token_user = User.find_by(authentication_token: token) || VtAuthenticationToken.find_by(token: token)&.user

    if user_signed_in? && @user == token_user
      if sso_authenticated?
        if sso_session_expired?
          sign_out(@user)

          return unauthorized
        else
          update_sso_session

          super
        end
      else
        # if AuthenticationToken::TokenService.new(token_user).validate_token(token)
        #   sign_out(token_user)
        # end
        # sign_in(token_user)
        super
      end
    else
      sign_out(@user)

      return unauthorized
    end
  end

  rescue_from Pundit::NotAuthorizedError, with: :user_not_authorized

  rescue_from CanCan::AccessDenied do |exception|
    render json: { message: exception.message }, status: :forbidden
  end

  protected

  def permissions_policy_header
    response.headers["Permissions-Policy"] =
      "camera=(), geolocation=(), gyroscope=(), microphone=(), payment=(), usb=()"
  end

  private

  def log_activity
    return unless %i[delete patch post put].include?(request.method_symbol)

    request_params = request.request_parameters

    deep_transform_values(request_params)

    log_details = {
      current_user_id: current_user&.id,
      ip: request.remote_ip,
      method: request.method,
      params: request_params,
      path: request.path
    }

    ::HttpRequestActivityLog.create(details: log_details)
  end

  def user_not_authorized
    flash[:warning] =
      "You are not authorized to perform this action according to the permissions for your organization."

    redirect_to(request.referrer || root_path)
  end

  def update_sso_session
    Sso::Session.new(session, current_user).execute
  end

  def sso_authenticated?
    @sso_authenticated ||= Sso::Authenticated.new(session).execute
  end

  def sso_session_expired?
    @sso_session_expired ||= Sso::SessionExpired.new(session).execute
  end

  def after_login_path(user)
    if user.tap_agreement
      user.admin_sign_in ? "/client/dashboard" : "/traveler/dashboard?login=true"
    else
      "/terms"
    end
  end

  def deep_transform_values(request_params)
    request_params.each do |key, value|
      if %w[file password password_confirmation].include?(key) && value.is_a?(String)
        value.replace("[FILTERED]")
      elsif value.is_a?(Hash)
        deep_transform_values(value)
      elsif value.is_a?(Array)
        value.flatten.each { |obj| deep_transform_values(obj) if obj.is_a?(Hash) }
      elsif value.is_a?(ActionDispatch::Http::UploadedFile)
        request_params[key] = value.original_filename
      end
    end

    request_params
  end

  def subdomain
    subdomains = request.subdomains - ["api"]

    subdomains.last
  end

  def set_current_user
    User.current = current_user
  end

  def unauthorized
    render json: { message: "Please log in to continue" }, status: :unauthorized
  end
end
