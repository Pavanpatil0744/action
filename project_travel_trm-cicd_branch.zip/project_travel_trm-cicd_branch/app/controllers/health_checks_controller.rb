# frozen_string_literal: true

class HealthChecksController < ApplicationController
  before_action :set_errors, only: :db_health_check

  def db_health_check
    read_success = successful_read
    write_success = successful_write
    db_health_check = { read_success: read_success, write_success: write_success }

    db_health_check.merge!(read_error: read_error) unless read_error.blank?
    db_health_check.merge!(write_error: write_error) unless write_error.blank?

    status = read_success && write_success ? :ok : :internal_server_error

    render(json: db_health_check, status: status)
  end

  def health_check
    render(json: {}, status: :ok)
  end

  private

  attr_accessor :read_error, :write_error

  def set_errors
    @read_error = ""
    @write_error = ""
  end

  def successful_read
    ActiveRecord::Base.connection.execute("SELECT 1")

    true
  rescue StandardError => e
    @read_error += e.message

    false
  end

  def successful_write
    timestamp = Time.now.strftime("%Y-%m-%d %H:%M:%S")

    ActiveRecord::Base.transaction do
      ActiveRecord::Base.connection.execute(
        "INSERT INTO health_checks (created_at, updated_at) VALUES ('#{timestamp}', '#{timestamp}')"
      )
    end

    true
  rescue StandardError => e
    @write_error += e.message

    false
  end
end
