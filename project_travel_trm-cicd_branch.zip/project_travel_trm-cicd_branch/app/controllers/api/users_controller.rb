# frozen_string_literal: true

class Api::UsersController < Api::BaseController
  before_action :validate_access_change, only: :change_role

  def change_role
    if new_access == current_user.admin_sign_in.to_s
      render json: {
        message: "User admin sign in already #{new_access}"
      }, status: :unprocessable_entity
    else
      current_user.update(admin_sign_in: new_access)

      render json: {
        message: "User admin sign in updated to #{new_access}",
        user: current_user
      }, status: :ok
    end
  end

  def accept_terms_and_policy
    tap_agreement = params[:user] && params[:user][:tap_agreement]

    if tap_agreement.present? && [true, 'true'].include?(tap_agreement)
      UsersTermsAndPolicyAgreement.create(user_id: current_user.id, terms_and_policy_id: TermsAndPolicyAgreement.last.id)
      current_user.update(tap_agreement: tap_agreement)

      render(
        json: { message: "Terms and Policy has accepted successfully!" },
        status: :ok
      )
    else
      render(
        json: { errors: "Failed to accept Terms and Policy Agreement" },
        status: :bad_request
      )
    end
  end

  private

  def user_params
    params.require(:user).permit(:admin_sign_in)
  end

  def new_access
    user_params[:admin_sign_in].to_s
  end

  def validate_access_change
    return unless !current_user.admin_role? && new_access == "true"

    render json: {
      message: "Non-admin users may not change to Admin access"
    }, status: :forbidden
  end
end
