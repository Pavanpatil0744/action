# frozen_string_literal: true

class Api::AutomationsController < Api::BaseController
  before_action :validate_admin_user
  before_action :find_automation, only: %i[show update destroy]

  rescue_from ActiveRecord::RecordNotFound, with: :record_not_found

  def index
    automations = client_account.automations

    authorize!(:index, automations)

    render(json: AutomationSerializer.new(automations), status: :ok)
  end

  def show
    authorize!(:show, @automation)

    render(json: AutomationSerializer.new(@automation), status: :ok)
  end

  def create
    updated_params = if automation_params[:automation_triggers_attributes].present?
                       add_condition_for_dynamic_fields(automation_params)
                     else
                       automation_params
                     end

    automation = client_account.automations.new(updated_params)

    authorize!(:create, automation)

    return bad_request(automation) unless automation.save

    render(json: AutomationSerializer.new(automation), status: :created)
  end

  def update
    updated_params = if automation_params[:automation_triggers_attributes].present?
                       add_condition_for_dynamic_fields(automation_params)
                     else
                       automation_params
                     end
    authorize!(:update, @automation)

    return bad_request(@automation) unless @automation.update(updated_params)

    render(json: AutomationSerializer.new(@automation), status: :ok)
  end

  def destroy
    @automation.destroy

    render(json: {}, status: :no_content)
  end

  def status_history
    automation_history = ChangeStatusHistory.select("change_status_histories.id, change_status_histories.user_id,
                                                     change_status_histories.automation_id, change_status_histories.user_email,
                                                     change_status_histories.user_first_name, change_status_histories.user_last_name,
                                                     change_status_histories.automation_type, change_status_histories.trigger_text,
                                                     change_status_histories.updated_status_to, change_status_histories.template_id,
                                                     change_status_histories.template_name, change_status_histories.submission_id,
                                                     change_status_histories.created_at AT TIME ZONE 'UTC' AT TIME ZONE cai.org_timezone as sent_date_time
                                                     ")
                                                     .joins("
                                                     INNER JOIN automations a ON a.id = change_status_histories.automation_id
                                                     INNER JOIN client_account_infos cai ON cai.client_account_id = a.client_account_id")
                                                     .where(automation_id: params[:automation_id])
    automation_name = Automation.find(params[:automation_id])&.name
    render json: {
      automation_history: automation_history,
      automation_name: automation_name
    }, status: :ok
  end

  private

  def automation_params
    params.require(:automation).permit(
      :active,
      :automation_action_id,
      :automation_type_id,
      :name,
      automation_mailers_attributes: %i[
        id
        automation_button_target_id
        body
        button_text
        subject
        _destroy
      ],
      automation_triggers_attributes: [
        :id,
        :automation_precondition_id,
        :automation_qualifier_id,
        :_destroy,
        { automation_trigger_conditions_attributes: %i[
          id
          automation_condition_id
          condition_text
          program_id
          template_id
          term_tag_id
          cumulative_gpa
          application_form_tag_id
          _destroy
        ] }
      ],
      automation_forms_attributes: [
        :id,
        { template_ids: [] },
        :deadline_type,
        :days_count,
        :conjuction,
        :time,
        :month,
        :day,
        :_destroy
      ],
      automation_change_statuses_attributes: [
        :id,
        :automation_id,
        :status,
        :reason,
        :message
      ],
      automation_tags_attributes: [
        :id,
        { tag_ids: [] },
        :_destroy
      ]
    )
  end

  def current_ability
    @current_ability ||= AutomationAbility.new(current_user)
  end

  def find_automation
    @automation = client_account.automations.find_by_id(params[:id])

    return not_found unless @automation
  end

  def validate_admin_user
    return forbidden unless admin_user?
  end

  def add_condition_for_dynamic_fields(updated_params)
    qualifier_ids = AutomationQualifier.where(
                                                identifier: [
                                                              "application_program_name",
                                                              "form_program_name",
                                                              "application_term_name",
                                                              "form_term_name",
                                                              "application_program",
                                                              "form_program",
                                                              "application_template",
                                                              "general_form_template",
                                                              "associated_application_template",
                                                              "form_template",
                                                              "application_term_tag",
                                                              "application_tag",
                                                              "form_tag",
                                                              "form_application_tag",
                                                              "form_cumulative_gpa",
                                                              "application_cumulative_gpa"
                                                            ]
                                             ).pluck(:id)

    updated_params[:automation_triggers_attributes].each do |l|
      next unless qualifier_ids.include? l[:automation_qualifier_id].to_i

      precondition = AutomationPrecondition.find(l[:automation_precondition_id])
      precondition_identifier = precondition.identifier

      if %w[application_program_is form_program_is].include?(precondition_identifier)
        l[:automation_trigger_conditions_attributes].each do |m|
          next if m[:automation_condition_id].present?

          program = client_account.programs.find_by_id(m[:program_id])

          next if program.blank?

          automation_condition = AutomationCondition.create(
            automation_precondition_id: l[:automation_precondition_id],
            display_name: "#{m[:program_id]}",
            identifier: "#{precondition_identifier}_#{m[:program_id]}",
            actionable: false
          )

          m[:automation_condition_id] = automation_condition.id
          m.delete(:program_id)
        end
      elsif %w[application_template_is general_form_template_is associated_application_template_is form_template_is].include?(precondition_identifier)
        l[:automation_trigger_conditions_attributes].each do |m|
          next if m[:automation_condition_id].present?

          template = client_account.templates.find(m[:template_id])

          if template.present?
            automation_condition = AutomationCondition.create(
              automation_precondition_id: l[:automation_precondition_id],
              display_name: "#{m[:template_id]}",
              identifier: "#{precondition_identifier}_#{m[:template_id]}",
              actionable: false
            )

            m[:automation_condition_id] = automation_condition.id
          end
          m.delete(:template_id)
        end
      elsif %w[application_term_tag_is application_term_tag_is_not].include?(precondition_identifier)
        l[:automation_trigger_conditions_attributes].each do |m|
          next if m[:automation_condition_id].present?

          term_tag = client_account.tags.program_range_tags.find(m[:term_tag_id])

          if term_tag.present?
            automation_condition = AutomationCondition.create(
              automation_precondition_id: l[:automation_precondition_id],
              display_name: m[:term_tag_id].to_s,
              identifier: "#{precondition_identifier}_#{m[:term_tag_id]}",
              actionable: false
            )

            m[:automation_condition_id] = automation_condition.id
          end
          m.delete(:term_tag_id)
        end
      elsif %w[application_tag_is form_tag_is form_application_tag_is form_application_tag_is_not application_tag_is_not form_tag_is_not].include?(precondition_identifier)
        l[:automation_trigger_conditions_attributes].each do |m|
          next if m[:automation_condition_id].present?

          tag = client_account.tags.find(m[:application_form_tag_id])

          if tag.present?
            automation_condition = AutomationCondition.create(
              automation_precondition_id: l[:automation_precondition_id],
              display_name: m[:application_form_tag_id].to_s,
              identifier: "#{precondition_identifier}_#{m[:application_form_tag_id]}",
              actionable: false
            )

            m[:automation_condition_id] = automation_condition.id
          end
          m.delete(:application_form_tag_id)
        end
      elsif %w[
          form_cumulative_gpa_is_greater_than
          form_cumulative_gpa_is_less_than
          form_cumulative_gpa_is_greater_than_or_equal
          form_cumulative_gpa_is_less_than_or_equal
          application_cumulative_gpa_is_greater_than
          application_cumulative_gpa_is_less_than
          application_cumulative_gpa_is_greater_than_or_equal
          application_cumulative_gpa_is_less_than_or_equal
        ].include?(precondition_identifier)
        l[:automation_trigger_conditions_attributes].each do |m|
          next if m[:automation_condition_id].present?

          cumulative_gpa = m[:cumulative_gpa]

          if cumulative_gpa.present?
            automation_condition = AutomationCondition.create(
              automation_precondition_id: l[:automation_precondition_id],
              display_name: m[:cumulative_gpa].to_s,
              identifier: "#{precondition_identifier}_#{m[:cumulative_gpa]}",
              actionable: false
            )

            m[:automation_condition_id] = automation_condition.id
          end
          m.delete(:cumulative_gpa)
        end
      else
        l[:automation_trigger_conditions_attributes].each do |m|
          next if m[:condition_text].blank?

          condition_text = m[:condition_text]
          identifier = "#{precondition_identifier}_#{condition_text.gsub(' ', '_').downcase}"
          if m[:automation_condition_id].present?
            automation_condition = AutomationCondition.find(m[:automation_condition_id])
            automation_condition.update_attributes(display_name: condition_text, identifier: identifier)
          else
            automation_condition = AutomationCondition.create(
              automation_precondition_id: l[:automation_precondition_id],
              display_name: condition_text,
              identifier: identifier,
              actionable: false
            )
            m[:automation_condition_id] = automation_condition.id
          end
          m.delete(:condition_text)
        end
      end
    end

    updated_params
  end

  def record_not_found
    render json: { errors: "Record not found" }, status: :not_found
  end
end
