# frozen_string_literal: true

class Api::ReportTravelersController < Api::BaseController
  include QueryHandler

  def index
    render json: query_to_json(report_travelers_query), status: :ok
  end

  private

  def admin_ids
    ActiveRecord::Base.connection.execute(
      prepared_query(ADMIN_IDS_SQL, { CLIENT_ACCOUNT_ID: client_account_id })
    ).values.flatten.join(", ")
  end

  def assigned_traveler_ids
    current_user.assigned_travelers.pluck(:id).join(", ")
  end

  def report_travelers_query
    if occasional_user? && assigned_traveler_ids.empty?
      ""
    elsif occasional_user? && admin_ids.empty?
      prepared_query(
        ALL_REPORT_TRAVELERS_OCCASIONAL_USER_SQL,
        {
          CLIENT_ACCOUNT_ID: client_account_id,
          ASSIGNED_TRAVELER_IDS: assigned_traveler_ids
        }
      )
    elsif occasional_user?
      prepared_query(
        REPORT_TRAVELERS_OCCASIONAL_USER_SQL,
        {
          CLIENT_ACCOUNT_ID: client_account_id,
          ASSIGNED_TRAVELER_IDS: assigned_traveler_ids,
          ADMIN_IDS: admin_ids
        }
      )
    elsif admin_ids.empty?
      prepared_query(ALL_REPORT_TRAVELERS_SQL, { CLIENT_ACCOUNT_ID: client_account_id })
    else
      prepared_query(
        REPORT_TRAVELERS_SQL,
        { CLIENT_ACCOUNT_ID: client_account_id, ADMIN_IDS: admin_ids }
      )
    end
  end
end
