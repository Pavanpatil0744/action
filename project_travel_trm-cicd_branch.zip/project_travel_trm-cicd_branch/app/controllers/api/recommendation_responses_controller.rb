# frozen_string_literal: true

class Api::RecommendationResponsesController < Api::BaseController
  before_action :authorize_actions, if: :admin_role?
  before_action :validate_params, only: :add_recommendations
  before_action :validate_assignment, only: :add_recommendations, if: :occasional_user?
  before_action :find_question, only: :add_recommendations
  before_action :find_submission, only: :add_recommendations
  before_action :find_template, only: :add_recommendations
  before_action :validate_client_account, only: :add_recommendations
  before_action :validate_user_submission, only: :add_recommendations, if: :traveler_user?
  before_action :validate_template_association, only: :add_recommendations

  def add_recommendations
    authorize!(:update, @submission) if admin_user?

    requests = []
    responses = @submission.recommendation_responses
    response = responses.find_or_initialize_by(question_id: @question.id)

    requests_attributes.each do |recommender|
      requestee_user = User.find_by(email: recommender[:user_email])

      requests << response.recommendation_requests.new(
        recommendation_template_id: @question.detailable.recommendation_template_id,
        sent_at: DateTime.current,
        token: SecureRandom.uuid,
        user_id: requestee_user&.id,
        user_email: recommender[:user_email],
        user_first_name: requestee_user&.first_name,
        user_last_name: requestee_user&.last_name
      )
    end

    return bad_request(response) unless response.save

    requests.each do |request|
      SendGrid::V2::Mailers::RecommendationRequest.perform_async(
        client_account_logo,
        response.question.details.recommender_instructions,
        request.id,
        @submission.user.full_name_or_email
      )
    end

    update_report_submission_associations(@submission)

    render json: RecommendationResponseSerializer.new(response), status: :ok
  end

  private

  def rec_params
    params.require(:response).permit(
      :question_id,
      :submission_id,
      recommendation_requests_attributes: :user_email
    )
  end

  def authorize_actions
    authorize_admin unless current_user.submissions.find_by_id(submission_id)
  end

  def find_question
    @question = Question.find_by_id(question_id)
    question_type = @question&.detailable_type

    return not_found unless @question && question_type == "RecommendationQuestion"
  end

  def find_submission
    @submission = client_account.submissions.find_by_id(submission_id)

    return not_found unless @submission
  end

  def find_template
    @template = @question.template

    return not_found unless @template
  end

  def question_id
    rec_params[:question_id]
  end

  def requests_attributes
    rec_params[:recommendation_requests_attributes]
  end

  def submission_id
    rec_params[:submission_id]
  end

  def validate_params
    errors = []

    errors << "Question ID required" unless question_id
    errors << "Submission ID required" unless submission_id
    errors << "At least 1 recommendation request required" unless requests_attributes&.any?

    render json: { errors: errors }, status: 400 if errors.any?
  end

  def validate_assignment
    assigned_travelers = current_user.assigned_travelers
    submission = Submission.find(submission_id)

    assigned = assigned_travelers.find_by_id(submission[:user_id])

    render json: { message: "Unauthorized" }, status: :unauthorized unless assigned
  end

  def validate_client_account
    validated = if admin_user?
                  client_account_id == @submission.client_account_id
                else
                  client_account_id == @template.client_account_id
                end

    render json: { message: "Unauthorized" }, status: :unauthorized unless validated
  end

  def validate_template_association
    return not_found unless @question.template_id == @submission.template_id
  end

  def validate_user_submission
    return not_found unless current_user_id == @submission.user_id
  end

  def current_ability
    @current_ability ||= SubmissionAbility.new(current_user)
  end

  def update_report_submission_associations(submission)
    submission_id = submission.id

    ReportSubmission.find_by_submission_id(submission_id)&.update(sync_required: true)
    UpdateReportSubmission.perform_in(10.seconds, submission_id)
  end
end
