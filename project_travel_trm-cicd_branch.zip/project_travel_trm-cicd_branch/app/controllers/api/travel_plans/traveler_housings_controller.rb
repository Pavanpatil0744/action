# frozen_string_literal: true

class Api::TravelPlans::TravelerHousingsController < Api::TravelPlans::BaseController
  include QueryHandler

  def index
    if version_2?
      render(json: query_to_json(traveler_housings_query), status: :ok)
    else
      render(json: TravelerHousingSerializer.new(travelers).serialized_json, status: :ok)
    end
  end

  private

  def traveler_housings_query
    if admin_user?
      prepared_query(TRAVELER_HOUSINGS_ADMIN_QUERY, { CLIENT_ACCOUNT_ID: client_account_id })
    else
      prepared_query(
        TRAVELER_HOUSINGS_QUERY,
        { CLIENT_ACCOUNT_ID: client_account_id, TRAVELER_ID: current_user_id }
      )
    end
  end

  def travelers
    PlansUsersHousing.where(plans_user_id: plans_users.pluck(:id))
                     .includes(plan_housing: :location, plans_user: %i[plan user])
  end
end
