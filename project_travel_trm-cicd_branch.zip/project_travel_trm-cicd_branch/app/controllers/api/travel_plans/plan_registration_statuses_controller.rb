# frozen_string_literal: true

class Api::TravelPlans::PlanRegistrationStatusesController < Api::TravelPlans::BaseController
  def index
    render json: PlanRegistrationStatusSerializer.new(PlanRegistrationStatus.in_order)
                                                 .serialized_json, status: :ok
  end
end
