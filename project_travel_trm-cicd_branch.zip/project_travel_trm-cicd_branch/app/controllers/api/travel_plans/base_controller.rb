# frozen_string_literal: true

class Api::TravelPlans::BaseController < Api::BaseController
  private

  def group_lead?(plan)
    plan ? plan.plans_users.exists?(group_lead: true, user_id: current_user_id) : false
  end

  def plan_activities
    if admin_user?
      client_account.plan_activities
    else
      client_account.plan_activities_for_traveler(current_user_id)
    end
  end

  def plan_housings
    if admin_user?
      client_account.plan_housings
    else
      client_account.plan_housings_for_traveler(current_user_id)
    end
  end

  def plan_transportations
    if admin_user?
      client_account.plan_transportations
    else
      client_account.plan_transportations_for_traveler(current_user_id)
    end
  end

  def plans
    admin_user? ? client_account.plans : client_account.plans_for_traveler(current_user_id)
  end

  def plans_users
    if admin_user?
      client_account.plans_users
    else
      current_user.plans_users_for_traveler
    end
  end

  def version
    @version ||= params[:version]
  end

  def version_2?
    version&.to_i == 2
  end
end
