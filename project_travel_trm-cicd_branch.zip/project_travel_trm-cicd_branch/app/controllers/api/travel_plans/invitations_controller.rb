# frozen_string_literal: true

class Api::TravelPlans::InvitationsController < Api::TravelPlans::BaseController
  before_action :find_plan

  def create
    csv = params[:csv_upload]

    if csv
      plans_users = BatchInviteTravelers.call(
        client_account: client_account,
        csv: csv,
        plan: @plan
      ).plans_users

      TrmRiskTraveler.add_traveler(@plan, plans_users.map(&:user_id))
      Plan.update_traveler_count(@plan)

      render json: PlansUserSerializer.new(plans_users).serialized_json, status: :created
    else
      email = traveler_params[:email].downcase

      return invalid_email_response unless email.match?(Devise.email_regexp)

      client_traveler = client_account.travelers.find_by(email: email)

      return unauthorized_email_response if !client_traveler && User.exists?(email: email)

      plans_user = if client_traveler
                     InviteExistingTraveler.call(plan: @plan, traveler: client_traveler).plans_user
                   else
                     password = SecureRandom.base64(15)
                     password = Devise.friendly_token until password.match?(%r{^(?=.*[A-Z])(?=.*[!"#$%&'()*+,-./:;<=>?@\[\\\]^_`{|}~]).{8,}$})
                     InviteNewTraveler.call(
                       client_account: client_account,
                       email: email,
                       first_name: traveler_params[:first_name],
                       last_name: traveler_params[:last_name],
                       password: password,
                       plan: @plan,
                       sign_up_source: "Via Travel Invitation"
                     ).plans_user
                   end

      TrmRiskTraveler.add_traveler(@plan, [plans_user.user_id])
      Plan.update_traveler_count(@plan)

      render json: PlansUserSerializer.new(plans_user).serialized_json, status: :created
    end
  end

  private

  def traveler_params
    params.require(:traveler).permit(:email, :first_name, :last_name)
  end

  def find_plan
    @plan = client_account.plans.find_by(id: params[:plan_id])

    return not_found unless @plan
  end
end
