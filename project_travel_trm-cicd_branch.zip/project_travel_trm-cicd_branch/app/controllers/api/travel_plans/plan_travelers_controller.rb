# frozen_string_literal: true

class Api::TravelPlans::PlanTravelersController < Api::TravelPlans::BaseController
  include QueryHandler

  def index
    authorize :plan, :view_travelers?

    render json: query_to_json(report_plan_users_query), status: :ok
  end

  private

  def serializer_params
    { plan_travelers: true }
  end

  def report_plan_users_query
    prepared_query(REPORT_PLANS_USERS_ADMIN_SQL, { CLIENT_ACCOUNT_ID: client_account_id })
  end
end
