# frozen_string_literal: true

class Api::TravelPlans::ItinerariesController < Api::TravelPlans::BaseController
  before_action :find_plan_activities
  before_action :find_plan_housings
  before_action :find_plan_transportations
  before_action :find_plans_users

  def create
    itinerary.each do |detail|
      @plans_users.each do |plans_user|
        plans_users_details = plans_users_details_by_type(detail)
        plans_users_detail = plans_users_details.find_or_initialize_by(plans_user_id: plans_user.id)

        next unless plans_users_detail.new_record? || plans_users_detail.removed?

        plans_users_detail.update(removed: false)

        plan = plans_user.plan

        next unless admin_or_group_lead?(plan) && !plans_user.removed?

        update_report_association(plans_user)

        SendGrid::SendTravelerPlanDetailAdditionMailer.perform_async(
          plan.client_account.logo.url,
          detail.formatted_location,
          detail.formatted_name,
          plan.id,
          plan.name,
          plans_user.user_id
        )
      end
    end

    render json: { message: "Itinerary details added" }, status: 201
  end

  def update
    plans_user_ids = @plans_users.pluck(:id)
    removed = params[:removed]

    itinerary.each do |detail|
      plans_users_details = plans_users_details_by_type(detail).where(plans_user_id: plans_user_ids)

      plans_users_details.each do |plans_users_detail|
        next if plans_users_detail.removed == removed

        plans_users_detail.update(removed: removed)

        plans_user = plans_users_detail.plans_user
        plan = plans_user.plan

        update_report_association(plans_user)

        next unless admin_or_group_lead?(plan) && !plans_user.removed?

        client_account_logo = plan.client_account.logo.url
        detail_location = detail.formatted_location
        detail_name = detail.formatted_name
        plan_id = plan.id
        plan_name = plan.name
        traveler = plans_user.user
        traveler_id = traveler.id

        if plans_users_detail.removed?
          SendGrid::SendTravelerPlanDetailRemovalMailer.perform_async(
            client_account_logo,
            detail_location,
            detail_name,
            plan_id,
            plan_name,
            traveler_id
          )
        else
          SendGrid::SendTravelerPlanDetailAdditionMailer.perform_async(
            client_account_logo,
            detail_location,
            detail_name,
            plan_id,
            plan_name,
            traveler_id
          )
        end
      end
    end

    render json: { message: "Itinerary details updated" }, status: 200
  end

  private

  def find_plan_activities
    @plan_activities = plan_activities.where(id: params[:plan_activity_ids])
  end

  def find_plan_housings
    @plan_housings = plan_housings.where(id: params[:plan_housing_ids])
  end

  def find_plan_transportations
    @plan_transportations = plan_transportations.where(id: params[:plan_transportation_ids])
  end

  def find_plans_users
    @plans_users = plans_users.where(id: params[:plans_user_ids])
  end

  def admin_or_group_lead?(plan)
    admin_user? || group_lead?(plan)
  end

  def itinerary
    itinerary = @plan_activities
    itinerary += @plan_housings
    itinerary + @plan_transportations
  end

  def plans_users_details_by_type(detail)
    case detail
    when PlanActivity
      detail.plans_users_activities
    when PlanHousing
      detail.plans_users_housings
    when PlanTransportation
      detail.plans_users_transportations
    end
  end

  def update_report_association(plans_user)
    plan = plans_user.plan

    ReportPlanUser.find_by_plans_users_id(plans_user.id)&.update(sync_required: true)
    UpdateReportPlanUser.perform_in(10.seconds, plans_user.id)

    ReportPlan.find_by_plan_id(plan.id)&.update(sync_required: true)
    UpdateReportPlan.perform_in(10.seconds, plan.id)
  end
end