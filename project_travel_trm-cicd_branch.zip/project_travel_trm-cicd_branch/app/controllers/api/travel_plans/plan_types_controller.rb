# frozen_string_literal: true

class Api::TravelPlans::PlanTypesController < Api::TravelPlans::BaseController
  def index
    render json: PlanTypeSerializer.new(PlanType.in_order).serialized_json, status: :ok
  end
end
