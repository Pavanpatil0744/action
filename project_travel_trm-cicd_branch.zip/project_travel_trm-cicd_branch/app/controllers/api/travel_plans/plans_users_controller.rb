# frozen_string_literal: true

class Api::TravelPlans::PlansUsersController < Api::TravelPlans::BaseController
  before_action :find_plan, only: %i[index create]
  before_action :find_plans_user, only: %i[update destroy]

  def index
    render json: PlansUserSerializer.new(@plan.plans_users).serialized_json, status: :ok
  end

  def create
    plans_user = @plan.plans_users.new(plans_user_params)
    plans_user.removed = true if @plan.cancelled?

    return bad_request(plans_user) unless plans_user.save

    Plan.update_traveler_count(@plan)
    ForceAddPlanDetails.call(plan: @plan, plans_user: plans_user)

    UpdateReportPlan.perform_in(10.seconds, @plan.id)
    UpdateReportPlanUser.perform_in(10.seconds, plans_user.id)

    SendGrid::SendPlansUserCreationMailers.call(plans_user: plans_user, user: current_user)

    render json: PlansUserSerializer.new(plans_user).serialized_json, status: :created
  end

  def update
    @plans_user.assign_attributes(plans_user_params)

    updated_fields = @plans_user.changed

    return bad_request(@plans_user) unless @plans_user.save

    Plan.update_traveler_count(@plans_user.plan) if updated_fields.include?("removed")

    ReportPlanUser.find_by_plans_users_id(@plans_user.id)&.update(sync_required: true)
    UpdateReportPlanUser.perform_in(10.seconds, @plans_user.id)

    plan_id = @plans_user.plan_id

    ReportPlan.find_by_plan_id(plan_id)&.update(sync_required: true)
    UpdateReportPlan.perform_in(10.seconds, plan_id)

    SendGrid::SendPlansUserUpdateMailers.call(
      plans_user: @plans_user,
      updated_fields: updated_fields,
      user: current_user
    )

    render json: PlansUserSerializer.new(@plans_user).serialized_json, status: :ok
  end

  def destroy
    @plans_user.destroy

    render json: {}, status: :no_content
  end

  private

  def plans_user_params
    plans_user_params = %i[user_id removed]

    plans_user_params += %i[group_lead] if admin_user?

    params.require(:plans_user).permit(plans_user_params)
  end

  def find_plan
    @plan = plans.find_by(id: params[:plan_id])

    return not_found unless @plan
  end

  def find_plans_user
    @plans_user = plans_users.find_by(id: params[:id])

    return not_found unless @plans_user
  end
end
