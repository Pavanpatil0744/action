# frozen_string_literal: true

class Api::TravelPlans::PlansController < Api::TravelPlans::BaseController
  include QueryHandler

  before_action :find_plan, only: %i[show update destroy]
  before_action :validate_plan_params, only: :create_from_program_term

  def index
    authorize :plan, :access_travel_plans? if admin_user?

    render json: query_to_json(report_plans_query), status: :ok
  end

  def show
    authorize :plan, :access_travel_plans? if admin_user?

    render json: PlanSerializer.new(@plan, params: serializer_params).serialized_json, status: :ok
  end

  def create
    authorize :plan, :create_plan_and_itinerary? if admin_user?

    plan = client_account.plans.new(plan_params)
    plan.owner = current_user

    return bad_request(plan) unless plan.save

    locations = plan.locations

    plan.update(
      end_date: locations.maximum(:end_date),
      start_date: locations.minimum(:start_date)
    )

    unless plan_params[:group]
      current_user.plans << plan
      Plan.update_traveler_count(plan)
      SendGrid::SendPlanCreationMailers.call(plan: plan, traveler: current_user)
    end

    update_report_associations(plan)

    render json: PlanSerializer.new(plan, params: serializer_params)
                               .serialized_json, status: :created
  end

  def update
    authorize :plan, :update_plan_and_itinerary? if admin_user?

    active_group_leads = @plan.group_leads.load
    active_travelers = @plan.travelers.load
    previously_cancelled = @plan.cancelled?
    program_range = @plan.program_range

    @plan.assign_attributes(plan_params)

    updated_fields = @plan.changed

    return bad_request(@plan) unless @plan.save

    SendGrid::SendPlanUpdateMailers.call(
      active_group_leads: active_group_leads,
      active_travelers: active_travelers,
      plan: @plan,
      previously_cancelled: previously_cancelled,
      updated_fields: updated_fields,
      user: current_user
    )

    CreatePlansUsers.call(plan: @plan) if updated_fields.include?("program_range_id")
    Plan.update_traveler_count(@plan) if @plan.cancelled?

    update_report_associations(@plan)

    if (params[:plan][:program_range_id].nil? && program_range.present?) || (params[:plan][:program_range_id].present?)
      program_range ||= ProgramRange.find(params[:plan][:program_range_id])

      ReportProgramRange.find_by(client_account_id: client_account_id,
                                 program_range_id: program_range.id
                                ).update(sync_required: true)
      UpdateReportProgramRange.perform_in(10.seconds, client_account.id, program_range.id)
    end

    render json: PlanSerializer.new(@plan, params: serializer_params).serialized_json, status: :ok
  end

  def destroy
    authorize :plan, :delete_plan_and_itinerary? if admin_user?

    program_range = @plan.program_range

    @plan.destroy

    if program_range.present?
      ReportProgramRange.find_by(
        client_account_id: client_account_id,
        program_range_id: program_range.id
      ).update(sync_required: true)
      UpdateReportProgramRange.perform_in(10.seconds, client_account.id, program_range.id)
    end

    render json: {}, status: :no_content
  end

  def create_from_program_term
    authorize :plan, :create_plan_and_itinerary? if admin_user?

    created = []
    failures = []

    params[:term_ids].each do |term_id|
      program_range = ProgramRange.find_by_id(term_id)

      next unless program_range.present?

      program = program_range.program
      location = program.program_locations&.first

      if location.present? && location.google_place_id.present?
        new_plan = client_account.plans.new(
          program_range_id: program_range.id,
          name: program.title,
          description: program.program_highlight&.text,
          plan_type_id: params[:plan_type_id],
          private: (params[:plan_availability] == 'private'),
          plan_status_id: params[:plan_status_id],
          plan_registration_status_id: params[:plan_registration_status_id],
          group: true,
          start_date: program_range.start_date.to_date,
          end_date: program_range.end_date.to_date
        )

        new_plan.locations.new(
          start_date: program_range.start_date.to_date,
          end_date: program_range.end_date.to_date,
          country_alpha2_code: location.alpha2,
          country_common_name: location.country_common_name,
          county_or_region: location.county_or_region,
          formatted_address: location.formatted_address,
          google_place_id: location.google_place_id,
          lat: location.lat,
          locality: location.locality,
          lng: location.lat,
          postal_code: location.postal_code,
          postal_code_suffix: location.postal_code_suffix,
          state_or_province: location.state_or_province,
          state_or_province_code: location.state_or_province_code,
          street: location.street,
          street_number: location.street_number,
          time_zone: location.time_zone,
          time_zone_offset: location.time_zone_offset
        )

        if new_plan.save
          CreatePlansUsers.call(plan: new_plan)
          Plan.update_traveler_count(new_plan.reload)
          UpdateReportPlan.perform_in(10.seconds, new_plan.id)
          ReportProgramRange.find_by(client_account_id: client_account_id,
                                     program_range_id: program_range.id
                                    )&.update(sync_required: true)
          UpdateReportProgramRange.perform_in(10.seconds, client_account.id, program_range.id)
          created << { plan_name: new_plan.name, term_name: program_range.name, travelers_going: new_plan.plans_users.count }
        else
          failures << { term_name: program_range.name, reason: "Fail to create plan" }
        end
      elsif location.present?
        failures << {
          term_name: program_range.term_title,
          reason: "Invalid #{program_alias} location",
          program_name: program.title,
          program_id: program.id,
          term_start_date: program_range.start_date,
          term_end_date: program_range.end_date
        }
      else
        failures << {
          term_name: program_range.term_title,
          reason: "Missing #{program_alias} location",
          program_name: program.title,
          program_id: program.id,
          term_start_date: program_range.start_date,
          term_end_date: program_range.end_date
        }
      end
    end

    render json: { created: created, failures: failures }, status: :ok
  end

  private

  def load_plans
    plans.includes(
      :locations,
      :plan_registration_status,
      :plan_status,
      :plan_type,
      plan_activities: %i[location tp_activity_type],
      plan_housings: %i[location tp_housing_type],
      plan_transportations: %i[
        arrival_location
        departure_location
        plans_users_transportations
        tp_transportation_type
      ],
      program_range: [program: [:program_highlight]],
      plans_users: [
        :plan_transportations, {
          plan_activities: %i[location plans_users_activities tp_activity_type],
          plan_housings: %i[location plans_users_housings tp_housing_type],
          user: [
            :client_account, :custom_field_texts, :profile, {
              traveler_info: %i[gender_identity passport]
            }
          ]
        }
      ]
    )
  end

  def plan_params
    plan_params = [
      :client_account_id,
      :description,
      :name,
      :notes,
      :plan_registration_status_id,
      :plan_status_id,
      :plan_type_id,
      :private,
      :removed,
      {
        locations_attributes: %i[
          id
          country_alpha2_code
          country_common_name
          county_or_region
          end_date
          formatted_address
          google_place_id
          lat
          locality
          lng
          postal_code
          postal_code_suffix
          start_date
          state_or_province
          state_or_province_code
          street
          street_number
          time_zone
          time_zone_offset
          _destroy
        ]
      }
    ]

    plan_params += %i[group program_range_id] if admin_user?

    params.require(:plan).permit(plan_params)
  end

  def find_plan
    @plan = plans.find_by(id: params[:id])

    return not_found unless @plan
  end

  def serializer_params
    serializer_params = {
      admin: admin_user? || group_lead?(@plan),
      action: params[:action]
    }

    serializer_params.merge!({ traveler_id: current_user_id }) unless admin_user?

    serializer_params
  end

  def program_alias
    @program_alias ||= use_custom_aliases? ? client_account.alias_program.downcase : "programs"
  end

  def use_custom_aliases?
    client_account.use_custom_aliases
  end

  def validate_plan_params
    errors = []

    unless PlanRegistrationStatus.where(id: params[:plan_registration_status_id]).exists?
      errors << "Plan Registration Status does not exists"
    end

    unless PlanType.where(id: params[:plan_type_id]).exists?
      errors << "Plan Type does not exists"
    end

    unless PlanStatus.where(id: params[:plan_status_id]).exists?
      errors << "Plan Status does not exists"
    end

    return unless errors.any?

    return (render json: { errors: errors.join(', ') }, status: :unprocessable_entity)
  end

  def report_plans_query
    if admin_user?
      prepared_query(REPORT_PLANS_ADMIN_SQL, { CLIENT_ACCOUNT_ID: client_account_id })
    else
      prepared_query(REPORT_PLANS_SQL, { CLIENT_ACCOUNT_ID: client_account_id, TRAVELER_ID: current_user_id })
    end
  end

  def update_report_associations(plan)
    ReportPlan.find_by_plan_id(plan.id)&.update(sync_required: true)
    UpdateReportPlan.perform_in(10.seconds, plan.id)

    plan.plans_users.each do |plan_user|
      ReportPlanUser.find_by_plans_users_id(plan_user.id)&.update(sync_required: true)
      UpdateReportPlanUser.perform_in(10.seconds, plan_user.id)
    end
  end
end
