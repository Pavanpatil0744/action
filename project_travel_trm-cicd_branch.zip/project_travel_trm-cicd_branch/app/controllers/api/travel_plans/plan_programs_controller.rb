# frozen_string_literal: true

class Api::TravelPlans::PlanProgramsController < Api::TravelPlans::BaseController
  def index
    render json: PlanProgramSerializer.new(programs.order_by_title).serialized_json, status: :ok
  end

  private

  def programs
    client_account.programs.joins(:program_ranges).published.distinct
  end
end
