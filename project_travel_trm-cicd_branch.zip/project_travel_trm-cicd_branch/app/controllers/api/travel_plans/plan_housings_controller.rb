# frozen_string_literal: true

class Api::TravelPlans::PlanHousingsController < Api::TravelPlans::BaseController
  before_action :find_plan, only: %i[index create]
  before_action :find_plan_housing, only: %i[show update destroy]

  def index
    render json: PlanHousingSerializer.new(@plan.plan_housings).serialized_json, status: :ok
  end

  def show
    render json: PlanHousingSerializer.new(@plan_housing).serialized_json, status: :ok
  end

  def create
    authorize :plan, :create_plan_and_itinerary? if admin_user?

    plan_housing = @plan.plan_housings.new(plan_housing_params)

    return bad_request(plan_housing) unless plan_housing.save

    if plan_housing.force_add
      @plan.plans_users.each do |plans_user|
        ForceAddPlanDetail.call(plan: @plan, plan_detail: plan_housing, plans_user: plans_user)
      end
    end

    unless plan_housing_params[:group]
      plans_user = @plan.plans_users.find_by(user_id: current_user_id)

      plans_user.plans_users_housings.create(plan_housing_id: plan_housing.id) if plans_user
    end

    update_report_association(@plan)

    SendGrid::SendPlanDetailCreationMailers.call(plan_detail: plan_housing, user: current_user)

    render json: PlanHousingSerializer.new(plan_housing).serialized_json, status: :created
  end

  def update
    authorize :plan, :update_plan_and_itinerary? if admin_user?

    @plan_housing.assign_attributes(plan_housing_params)

    updated_fields = @plan_housing.changed

    return bad_request(@plan_housing) unless @plan_housing.save

    SendGrid::SendPlanDetailUpdateMailers.call(
      plan_detail: @plan_housing,
      updated_fields: updated_fields,
      user: current_user
    )
    update_report_association(@plan_housing.plan)

    render json: PlanHousingSerializer.new(@plan_housing).serialized_json, status: :ok
  end

  def destroy
    authorize :plan, :delete_plan_and_itinerary? if admin_user?

    update_report_association(@plan_housing.plan)

    @plan_housing.destroy

    render json: {}, status: :no_content
  end

  private

  def plan_housing_params
    plan_housing_params = [
      :arrival_date,
      :arrival_time,
      :confirmation_number,
      :departure_date,
      :departure_time,
      :email_address,
      :name,
      :nickname,
      :nickname,
      :notes,
      :phone_number,
      :removed,
      :room_number,
      :tp_housing_type_id,
      :website,
      location_attributes: %i[
        id
        country_alpha2_code
        country_common_name
        county_or_region
        formatted_address
        google_place_id
        lat
        locality
        lng
        postal_code
        postal_code_suffix
        state_or_province
        state_or_province_code
        street
        street_number
        time_zone
        time_zone_offset
        _destroy
      ]
    ]

    plan_housing_params += %i[force_add group] if admin_user? || group_lead?(@plan)

    params.require(:plan_housing).permit(plan_housing_params)
  end

  def find_plan
    @plan = plans.find_by(id: params[:plan_id])

    return not_found unless @plan
  end

  def find_plan_housing
    @plan_housing = plan_housings.find_by(id: params[:id])

    return not_found unless @plan_housing
  end

  def update_report_association(plan)
    report_plan = ReportPlan.find_by_plan_id(plan.id)
    report_plan&.update(sync_required: true)
    UpdateReportPlan.perform_in(10.seconds, plan.id)
  end
end
