# frozen_string_literal: true

class Api::TravelPlans::PlanActivitiesController < Api::TravelPlans::BaseController
  before_action :find_plan, only: %i[index create]
  before_action :find_plan_activity, only: %i[show update destroy]

  def index
    render json: PlanActivitySerializer.new(@plan.plan_activities).serialized_json, status: :ok
  end

  def show
    render json: PlanActivitySerializer.new(@plan_activity).serialized_json, status: :ok
  end

  def create
    authorize :plan, :create_plan_and_itinerary? if admin_user?

    plan_activity = @plan.plan_activities.new(plan_activity_params)

    return bad_request(plan_activity) unless plan_activity.save

    if plan_activity.force_add
      @plan.plans_users.each do |plans_user|
        ForceAddPlanDetail.call(plan: @plan, plan_detail: plan_activity, plans_user: plans_user)
      end
    end

    unless plan_activity_params[:group]
      plans_user = @plan.plans_users.find_by(user_id: current_user_id)

      plans_user.plans_users_activities.create(plan_activity_id: plan_activity.id) if plans_user
    end

    update_report_association(@plan)
    SendGrid::SendPlanDetailCreationMailers.call(plan_detail: plan_activity, user: current_user)

    render json: PlanActivitySerializer.new(plan_activity).serialized_json, status: :created
  end

  def update
    authorize :plan, :update_plan_and_itinerary? if admin_user?

    @plan_activity.assign_attributes(plan_activity_params)

    updated_fields = @plan_activity.changed

    return bad_request(@plan_activity) unless @plan_activity.save

    SendGrid::SendPlanDetailUpdateMailers.call(
      plan_detail: @plan_activity,
      updated_fields: updated_fields,
      user: current_user
    )

    update_report_association(@plan_activity.plan)

    render json: PlanActivitySerializer.new(@plan_activity).serialized_json, status: :ok
  end

  def destroy
    authorize :plan, :delete_plan_and_itinerary? if admin_user?

    update_report_association(@plan_activity.plan)
    @plan_activity.destroy

    render json: {}, status: :no_content
  end

  private

  def plan_activity_params
    plan_activity_params = [
      :confirmation_number,
      :end_date,
      :end_time,
      :name,
      :nickname,
      :notes,
      :provider_contact_name,
      :provider_name,
      :start_date,
      :start_time,
      :removed,
      :tp_activity_type_id,
      location_attributes: %i[
        id
        country_alpha2_code
        country_common_name
        county_or_region
        formatted_address
        google_place_id
        lat
        locality
        lng
        postal_code
        postal_code_suffix
        state_or_province
        state_or_province_code
        street
        street_number
        time_zone
        time_zone_offset
        _destroy
      ]
    ]

    plan_activity_params += %i[force_add group] if admin_user? || group_lead?(@plan)

    params.require(:plan_activity).permit(plan_activity_params)
  end

  def find_plan
    @plan = plans.find_by(id: params[:plan_id])

    return not_found unless @plan
  end

  def find_plan_activity
    @plan_activity = plan_activities.find_by(id: params[:id])

    return not_found unless @plan_activity
  end

  def update_report_association(plan)
    report_plan = ReportPlan.find_by_plan_id(plan.id)
    report_plan.update(sync_required: true)
    UpdateReportPlan.perform_in(10.seconds, plan.id)
  end
end
