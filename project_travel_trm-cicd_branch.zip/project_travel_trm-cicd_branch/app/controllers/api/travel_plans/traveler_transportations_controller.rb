# frozen_string_literal: true

class Api::TravelPlans::TravelerTransportationsController < Api::TravelPlans::BaseController
  include QueryHandler

  def index
    if version_2?
      render(json: query_to_json(traveler_transportations_query), status: :ok)
    else
      render(json: TravelerTransportationSerializer.new(travelers).serialized_json, status: :ok)
    end
  end

  private

  def traveler_transportations_query
    if admin_user?
      prepared_query(TRAVELER_TRANSPORTATIONS_ADMIN_QUERY, { CLIENT_ACCOUNT_ID: client_account_id })
    else
      prepared_query(
        TRAVELER_TRANSPORTATIONS_QUERY,
        { CLIENT_ACCOUNT_ID: client_account_id, TRAVELER_ID: current_user_id }
      )
    end
  end

  def travelers
    PlansUsersTransportation.where(plans_user_id: plans_users.pluck(:id))
                            .includes(
                              plan_transportation: %i[arrival_location departure_location],
                              plans_user: %i[plan user]
                            )
  end
end
