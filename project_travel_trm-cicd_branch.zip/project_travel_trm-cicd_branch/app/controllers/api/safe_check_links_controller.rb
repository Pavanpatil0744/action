# frozen_string_literal: true

class Api::SafeCheckLinksController < ApplicationController
  before_action :find_safe_check_link_by_slug

  def show
    @safe_check_link.update(clicked: @safe_check_link.clicked + 1)

    redirect_to(@safe_check_link.url)
  end

  private

  def find_safe_check_link_by_slug
    @safe_check_link = SafeCheckLink.find_by_slug(params[:slug])

    return not_found unless @safe_check_link
  end
end
