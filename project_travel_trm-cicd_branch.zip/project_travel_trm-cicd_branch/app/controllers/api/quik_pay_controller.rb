# frozen_string_literal: true

class Api::QuikPayController < Api::BaseController
  skip_before_action :authenticate_user!

  before_action :find_or_create_payment_response, only: :postback
  before_action :find_submission, only: :create
  before_action :find_question, only: :create

  def create
    amount = @qp_question.cost ? (@qp_question.cost.to_i * 100).to_s : "0"
    user = @submission.user

    require "quik_pay/#{subdomain}" rescue require "quik_pay"

    initial_request_params = {
      amount: amount,
      email: user.email,
      full_name: user.profile_full_name,
      orderNumber: "#{@qp_question.question_id}|#{@submission.id}|#{params[:user_id]}",
      student_id: user.student_id
    }
    payment_url = quik_pay.payment_url(initial_request_params)

    redirect_to(payment_url)
  end

  def postback
    @payment_response.api_transaction = true
    @payment_response.attributes = { payment_status: payment_status("paid") } if success
    @payment_response.save

    payment_log = create_payment_response_status_change_log(@payment_response)

    create_payment_response_status_change_log_payload(payment_log)

    render html: confirm_html(success), status: :created
  end

  private

  def quik_pay
    @quik_pay ||= Object.const_get("QuikPay::#{subdomain.gsub('-', '_').camelize}").new
  end

  def quik_pay_params
    params.permit(
      :orderNumber,
      :orerType,
      :transactionDate,
      :transactionDescription,
      :transactionId,
      :transactionResultCode,
      :transactionResultMessage,
      :transactionStatus,
      :transactionTotalAmount
    )
  end

  def create_payment_response_status_change_log(response)
    payor = User.find_by_id(@payor_id)

    response.payment_response_status_change_logs.create(
      notes: "QuikPay transaction",
      payment_status_id: response.payment_status_id,
      status: response.payment_status_identifier,
      transaction_id: quik_pay_params[:transactionId],
      transaction_response: quik_pay_params[:transactionResultMessage],
      transaction_success: success,
      user_id: payor&.id,
      user_email: payor&.email,
      user_first_name: payor&.first_name,
      user_last_name: payor&.last_name
    )
  end

  def create_payment_response_status_change_log_payload(payment_log)
    PaymentResponseStatusChangeLogPayload.create(
      payload: params.to_json,
      payment_response_status_change_log: payment_log
    )
  end

  def confirm_html(success)
    content = success ? <<~EHTML
      <html>
        <head>
          <style>
            h3 {text-align: center;}
            p {text-align: center;}
            div {text-align: center;}
          </style>
        </head>
        <body>
          <br>
          <h3>Transaction Complete</h3>
          <p>Your payment has been processed.</p>
          <p>Return to your application or form and refresh the page to update your transaction information and payment status.</p>
          <div>
            <button type="button" onclick="javascript:window.close()">Close</button>
          </div>
        </body>
      </html>
    EHTML
    : <<~EHTML
      <html>
        <head>
          <style>
            h3 {text-align: center;}
            p {text-align: center;}
            div {text-align: center;}
          </style>
        </head>
        <body>
          <br><br>
          <h3>Credit Card Processing Failure</h3>
          <p>There was an issue processing your payment, and your fees have not been paid.</p>
          <p>If you'd like to attempt again, return to your Via TRM application or form and click 'Make a Payment' to re-start the payment process.</p>
          <p>If you think you've reached this message in error, reach out to your bank or credit card provider for more information.</p><br>
          <div>
            <button type="button" onclick="javascript:window.close()">Close</button>
          </div>
        </body>
      </html>
    EHTML

    content.html_safe
  end

  def find_or_create_payment_response
    internal_transaction_id = quik_pay_params[:orderNumber]
    question_id, submission_id, @payor_id = internal_transaction_id.split("|", 3)
    question = Question.find_by_id(question_id)

    @payment_response = PaymentResponse.find_by(
      question: question,
      submission_id: submission_id
    )

    return if @payment_response

    @payment_response = PaymentResponse.new(
      payment_status: payment_status("not_paid"),
      question: question,
      submission_id: submission_id
    )
  end

  def find_question
    question_id = params[:question_id]
    template = @submission.template

    @qp_question = template.quik_pay_questions.find_by_id(question_id)

    not_found unless @qp_question
  end

  def find_submission
    @submission = Submission.find_by_id(params[:submission_id])

    not_found unless @submission
  end

  def payment_status(identifier)
    PaymentStatus.find_by_identifier(identifier)
  end

  def success
    quik_pay_params[:transactionStatus].to_s == "1"
  end

  def subdomain
    @subdomain ||= @submission.client_account.subdomain
  end
end
