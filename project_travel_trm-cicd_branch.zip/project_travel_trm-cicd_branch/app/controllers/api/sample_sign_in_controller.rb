# frozen_string_literal: true

class Api::SampleSignInController < ApplicationController
  # This will be removed
  def index
    user = User.find_by_email params["user_email"]
    if user_signed_in?
      render json: {
        user: user
      }, status: 200
    else
      render json: {
        error: "User not found"
      }, status: :unprocessable_entity
    end
  end
end
