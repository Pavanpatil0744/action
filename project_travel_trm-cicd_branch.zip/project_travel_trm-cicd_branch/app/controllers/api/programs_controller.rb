# frozen_string_literal: true

class Api::ProgramsController < Api::BaseController
  include QueryHandler

  before_action :find_program, only: %i[show update destroy]
  before_action :find_traveler, only: :available_for_application

  def index
    if admin_user?
      render json: query_to_json(report_programs_query), status: :ok
    else
      render json: ::Reports::ReportProgramSerializer.new(
        report_programs,
        params: {
          intake_completed: intake_completed?,
          program_favorite_ids: program_favorite_ids,
          program_match_percentages: program_match_percentages
        }
      ), status: :ok
    end
  end

  def show
    render(
      json: ::V2::ProgramSerializer.new(
        @program,
        params: { action: params[:action], current_user: current_user }
      ).serialized_json,
      status: :ok
    )
  end

  def create
    program = client_account.programs.new(title: "New Program")

    program.build_associations
    program.build_program_contact(user: current_user)
    program.program_managers.build(user: current_user)

    program.image_requested = true
    program.primary_client_account = client_account

    program.save(validate: false)

    client_account.programs << program

    update_client_specific_report_program_associations([program.id], [])

    render(
      json: ::V2::ProgramSerializer.new(
        program,
        params: { current_user: current_user }
      ).serialized_json,
      status: :created
    )
  end

  def update
    program_images_attributes = program_params[:program_images_attributes]
    uploaded_program_image = program_images_attributes[0] if program_images_attributes
    s3_store = uploaded_program_image[:s3_store] if uploaded_program_image

    @program.program_images.destroy_all if s3_store
    @program.assign_attributes(program_params)

    if program_params[:status] == "inactive"
      @program.inactive_at = DateTime.current
      @program.inactive_by = current_user.name
    end

    if @program.unspecified_location?
      @program.program_locations.destroy_all
      @program.program_locations.find_or_create_by(
        alpha2: "UL",
        city: "",
        lat: "37.0902",
        lng: "-95.7129"
      )
    else
      @program.program_locations.find_by(
        alpha2: "UL",
        city: "",
        lat: "37.0902",
        lng: "-95.7129"
      )&.destroy
    end

    if @program.unspecified_location? ||
       @program.program_locations.empty? ||
       program_params[:program_locations_attributes]&.all? { |location| location[:_destroy] == true }
      @program.program_map.included = false
    end

    successful_save = @program.published? ? @program.save : @program.save(validate: false)

    return bad_request(@program) unless successful_save

    HandleProgramImage.call(program: @program)

    update_all_report_program_associations(@program)

    render(
      json: ::V2::ProgramSerializer.new(
        @program,
        params: { action: params[:action], current_user: current_user }
      ).serialized_json,
      status: :ok
    )
  end

  def destroy
    if @program.draft?
      return bad_request(@program) unless @program.destroy

      render json: {}, status: :no_content
    else
      render json: { error: "Non-draft Programs cannot be destroyed" }, status: :bad_request
    end
  end

  def available_for_application
    traveler_applications = @traveler.application_submissions
    traveler_application_term_ids = traveler_applications.pluck(:program_range_id)
    current_term = params[:term_id]

    internal = client_account.internal_applicable_programs
                             .includes(program_ranges: :term_name).map do |program|
      program_ranges = program.program_ranges.map do |pr|
        pr_id = pr.id

        next if current_term && pr.id == current_term

        application = traveler_applications.find { |a| a.program_range_id == pr_id }
        application_details = application_details(application) if application.present?

        {
          end_date: pr.end_date,
          id: pr_id,
          name: pr.term_title,
          program_id: pr.program_id,
          start_date: pr.start_date,
          use_exact_dates: pr.use_exact_dates,
          application: application_details
        }
      end

      next unless program_ranges.any?

      {
        id: program.id,
        title: program.title,
        active_applications: (
          (program_ranges.map { |pr| pr[:id] }) & traveler_application_term_ids
        ).any?,
        program_ranges: program_ranges.compact
      }
    end.compact

    authorized = if client_account.allow_authorized_programs?
                   suitcase_name_map = {}

                   client_account.suitcase_program_ranges.joins(:suitcase)
                                 .includes(suitcase: :term_name).map do |s|
                     suitcase_name_map[s.program_range_id] = s.suitcase_name
                   end

                   client_account.authorized_report_programs_with_suitcases.map do |report_program|
                     program_ranges = []

                     report_program.program_ranges.each do |pr|
                       pr_id = pr.id

                       next if current_term && pr_id == current_term

                       suitcase_name = suitcase_name_map[pr_id]

                       next unless suitcase_name.present?

                       application = traveler_applications.find { |a| a.program_range_id == pr_id }
                       application_details = application_details(application) if application.present?

                       program_ranges << {
                         end_date: pr.end_date,
                         id: pr_id,
                         name: suitcase_name,
                         program_id: pr.program_id,
                         start_date: pr.start_date,
                         use_exact_dates: pr.use_exact_dates,
                         application: application_details
                       }
                     end

                     {
                       id: report_program.id,
                       title: report_program.program_name,
                       active_applications: (
                         (program_ranges.map { |pr| pr[:id] }) & traveler_application_term_ids
                       ).any?,
                       program_ranges: program_ranges.compact
                     }
                   end
                 else
                   []
                 end.compact

    render json: internal.concat(authorized)
  end

  def available_for_authorization
    programs = Program.authorizable(params[:provider_id]).includes(
      :primary_client_account,
      :program_amenities,
      :program_eligibility,
      :program_review,
      :program_scholarship_info,
      :subject_areas,
      program_languages: :language,
      program_locations: :via_country,
      program_ranges: :tags,
      included_program_housings: :housing_type,
      included_program_type_connections: :program_type,
      program_contact: [user: %i[profile traveler_info]],
      program_managers: [user: %i[profile traveler_info]]
    ).where.not(id: client_account.programs.pluck(:id))

    render json: {
      programs: ProgramSerializer.new(
        programs,
        params: { client_account_id: client_account_id, source: "unauthorized" }
      ).to_hash,
      amenities: AmenitySerializer.new(Amenity.all).to_hash
    }, status: :ok
  end

  private

  def assigned_program_ids
    current_user.assigned_programs.pluck(:id).join(", ")
  end

  def find_program
    @program = client_account.programs.includes(
      :admin_program_attachments,
      { program_amenities: [:amenity_category, :amenity] },
      :program_attachments,
      { program_contact: { user: :traveler_info } },
      :program_eligibility,
      :program_highlight,
      :program_housings,
      :program_images,
      :program_languages,
      :program_locations,
      :program_location_highlight,
      { program_managers: :user },
      :program_map,
      :program_review,
      :program_scholarship_info,
      :program_subjects,
      { program_type_connections: :program_type }
    ).find_by(id: params[:id])

    return not_found unless @program
  end

  def find_traveler
    @traveler = client_account.travelers.find(params[:traveler_id])

    return not_found unless @traveler
  end

  def program_favorite_ids
    return [] if admin_user?

    @program_favorite_ids ||= current_user.program_favorites.pluck(:program_id)
  end

  def program_match_percentages
    return [] if admin_user?

    @program_match_percentages ||= Traveler::AlguruMatchUpdate.new(traveler_info, client_account)
                                                              .execute
  end

  def program_params
    params.require(:program).permit(
      :academic_notes,
      :access_code,
      :access_code_protected,
      :activity_notes,
      :background_photo,
      :external_application_url,
      :host_organization,
      :host_organization_notes,
      :housing_notes,
      :image_requested,
      :institution_only,
      :is_authorizable,
      :language_immersion,
      :location_notes,
      :notes,
      :pactivities,
      :padd_ons,
      :pexcursions,
      :pcourses,
      :private,
      :status,
      :title,
      :embed_course_list_url,
      :unspecified_location,
      admin_program_attachments_attributes: %i[id file title _destroy],
      program_amenities_attributes: %i[id amenity_id excluded included _destroy],
      program_attachments_attributes: %i[id file title _destroy],
      program_contact_attributes: %i[id user_id _destroy],
      program_eligibility_attributes: %i[id eligibility_info _destroy],
      program_highlight_attributes: %i[id text _destroy],
      program_housings_attributes: %i[id housing_type_id included _destroy],
      program_images_attributes: %i[id client_account_id file_name primary s3_store _destroy],
      program_languages_attributes: %i[id iso_639_3 _destroy],
      program_locations_attributes: %i[
        id
        alpha2
        city
        continent
        country_common_name
        county_or_region
        formatted_address
        google_place_id
        image_url
        lat
        lng
        locality
        postal_code
        postal_code_suffix
        state_or_province
        state_or_province_code
        street
        street_number
        time_zone
        time_zone_offset
        _destroy
      ],
      program_location_highlight_attributes: %i[id text _destroy],
      program_managers_attributes: %i[id user_id _destroy],
      program_map_attributes: %i[id address included _destroy],
      program_review_attributes: %i[id reviewer_details reviewer_name review_text _destroy],
      program_scholarship_info_attributes: %i[id scholarship_info _destroy],
      program_subjects_attributes: %i[id included subject_area_id _destroy],
      program_type_connections_attributes: %i[id included program_type_id _destroy]
    )
  end

  def report_programs
    client_account.report_programs.traveler_or_visitor_viewable
  end

  def report_programs_query
    authorized = params[:source] == "authorized"

    if !authorized && occasional_user? && assigned_program_ids.empty?
      ""
    elsif !authorized && occasional_user?
      prepared_query(
        INTERNAL_PROGRAMS_OCCASIONAL_USER_SQL,
        {
          CLIENT_ACCOUNT_ID: client_account.id,
          PROGRAM_IDS: assigned_program_ids
        }
      )
    elsif !authorized
      prepared_query(INTERNAL_PROGRAMS_SQL, { CLIENT_ACCOUNT_ID: client_account.id })
    elsif !occasional_user? && client_account.enrollment?
      prepared_query(AUTHORIZED_PROGRAMS_SQL, { CLIENT_ACCOUNT_ID: client_account.id })
    else
      ""
    end
  end

  def authorized_programs
    ActiveRecord::Base.connection.execute(
      prepared_query(AUTHORIZED_PROGRAMS_SQL, { CLIENT_ACCOUNT_ID: client_account.id })
    )
  end

  def internal_programs
    ActiveRecord::Base.connection.execute(
      prepared_query(INTERNAL_PROGRAMS_SQL, { CLIENT_ACCOUNT_ID: client_account.id })
    )
  end

  def occasional_user_internal_programs
    if assigned_program_ids.empty?
      {}
    else
      ActiveRecord::Base.connection.execute(
        prepared_query(
          INTERNAL_PROGRAMS_OCCASIONAL_USER_SQL,
          {
            CLIENT_ACCOUNT_ID: client_account.id,
            PROGRAM_IDS: assigned_program_ids
          }
        )
      )
    end
  end

  def update_client_specific_report_program_associations(program_ids, program_range_ids)
    ReportProgram.where(client_account_id: client_account_id, program_id: program_ids)
                 .update_all(sync_required: true)
    ReportProgramRange.where(
      client_account_id: client_account_id,
      program_range_id: program_range_ids
    ).update_all(sync_required: true)

    UpdateClientSpecificReportProgramAssociations.perform_async(
      client_account_id,
      program_ids,
      program_range_ids
    )
  end

  def update_all_report_program_associations(program)
    program_id = program.id

    ReportProgram.where(program_id: program_id).update_all(sync_required: true)
    ReportProgramRange.where(program_range_id: program.program_range_ids)
                      .update_all(sync_required: true)

    UpdateAllReportProgramAssociations.perform_async(program_id)
  end

  def application_details(application)
    { id: application.id, name: application.template_name, status: application.status }
  end
end
