# frozen_string_literal: true

class Api::TpHousingTypesController < ApplicationController
  def index
    render json: TpHousingTypeSerializer.new(TpHousingType.in_order).serialized_json, status: :ok
  end
end
