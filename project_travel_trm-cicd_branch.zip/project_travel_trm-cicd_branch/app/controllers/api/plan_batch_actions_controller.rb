# frozen_string_literal: true

class Api::PlanBatchActionsController < Api::BaseController
  def update_plan_registatration_statuses
    authorize :plan, :update_status?

    new_status_id = params[:new_status_id]
    failures = []
    updated_plans = []

    plans.each do |plan|
      if plan.plan_registration_status_id != new_status_id
        active_group_leads = plan.group_leads.load
        active_travelers = plan.travelers.load
        previously_cancelled = plan.cancelled?

        plan.update(plan_registration_status_id: new_status_id)

        SendGrid::SendPlanUpdateMailers.call(
          active_group_leads: active_group_leads,
          active_travelers: active_travelers,
          plan: plan,
          previously_cancelled: previously_cancelled,
          updated_fields: ["plan_registration_status_id"],
          user: current_user
        )

        update_report_plan(plan.id)

        updated_plans << plan
      else
        failures << plan
      end
    end

    render json: build_response(updated_plans, failures), status: :ok
  end

  def update_plan_statuses
    authorize :plan, :update_status?

    new_status_id = params[:new_status_id]
    failures = []
    updated_plans = []

    plans.each do |plan|
      if plan.plan_status_id != new_status_id
        active_group_leads = plan.group_leads.load
        active_travelers = plan.travelers.load

        plan.update(plan_status_id: new_status_id)
        update_report_plan(plan.id)

        SendGrid::SendPlanUpdateMailers.call(
          active_group_leads: active_group_leads,
          active_travelers: active_travelers,
          plan: plan,
          previously_cancelled: false,
          updated_fields: ["plan_status_id"],
          user: current_user
        )

        updated_plans << plan
      else
        failures << plan
      end
    end

    render json: build_response(updated_plans, failures), status: :ok
  end

  private

  def plans
    plans = client_account.plans

    plans.where(id: params[:plan_ids])
  end

  def build_response(updated_plans, failures)
    response = PlanSerializer.new(updated_plans).to_hash

    response.merge!({ failures: failures.map(&:id) }) if failures.count.positive?

    response
  end

  def update_report_plan(plan_id)
    report_plan = ReportPlan.find_by_plan_id(plan_id)
    report_plan.update(sync_required: true)
    UpdateReportPlan.perform_in(10.seconds, plan_id)
  end
end
