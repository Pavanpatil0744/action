# frozen_string_literal: true

class Api::ProgramRangeBatchActionsController < Api::BaseController
  before_action :authorize_admin
  before_action :validate_enrollment_client

  def add_application_template
    return unauthorized unless internal_source

    program_ranges_to_update = program_ranges.reject(&:application_template)

    program_ranges_to_update.each do |program_range|
      program_range.update(
        application_template_id: application_params[:application_template_id],
        deadline: application_params[:application_deadline]
      )

      program_id = program_range.program_id
      program_range_id = program_range.id

      ReportProgram.find_by(client_account_id: client_account_id, program_id: program_id)
                   &.update(sync_required: true)
      ReportProgramRange.find_by(
        client_account_id: client_account_id,
        program_range_id: program_range_id
      )&.update(sync_required: true)
      UpdateReportProgram.perform_in(10.seconds, client_account_id, program_id)
      UpdateReportProgramRange.perform_in(10.seconds, client_account_id, program_range_id)
    end

    render json: ProgramRangeSerializer.new(
      program_ranges_to_update,
      params: { client_account: client_account }
    ).serialized_json, status: :ok
  end

  def add_form_templates
    return unauthorized unless internal_source

    updated_program_ranges = []

    program_ranges.each do |program_range|
      prfg_params[:program_range_form_groupings_attributes].each do |grouping|
        prfgt_attributes = grouping[:program_range_form_grouping_templates_attributes]
        form_template_ids = prfgt_attributes.map { |attribute| attribute[:form_template_id] }

        form_template_ids.each do |template_id|
          form_grouping = program_range.program_range_form_groupings.new(
            deadline: grouping[:deadline]
          )

          template = client_account.templates.find_by_id(template_id)

          next unless template

          form_grouping.form_templates << template unless program_range.form_attached?(template_id)

          next unless form_grouping.form_templates.any?

          form_grouping.save
        end

        updated_program_ranges << program_range unless updated_program_ranges.include?(program_range)
      end

      next unless updated_program_ranges.any?

      updated_program_ranges.each do |updated_program_range|
        applications = client_account.application_submissions.where(
          program_range_id: updated_program_range.id,
          traveler_submission_status: SubmissionStatus.statuses_with_forms
        )

        applications.each { |app| CreateRequiredForms.perform_async(app.id, client_account_id) }
      end

      update_client_specific_report_program_associations(
        updated_program_ranges.map(&:program_id).uniq,
        updated_program_ranges.map(&:id)
      )
    end

    render json: ProgramRangeSerializer.new(
      updated_program_ranges,
      params: { client_account: client_account }
    ).serialized_json, status: :created
  end

  def add_suitcase
    return unauthorized unless authorized_source

    program_ranges_to_update = program_ranges.reject do |program_range|
      client_account.corresponding_suitcase?(program_range)
    end

    program_ranges_to_update.each do |program_range|
      program_range.suitcase_program_ranges.create(
        suitcase_id: suitcase_params[:suitcase_id]
      )
    end

    update_client_specific_report_program_associations(
      program_ranges_to_update.map(&:program_id).uniq,
      program_ranges_to_update.map(&:id)
    )

    render json: ProgramRangeSerializer.new(
      program_ranges_to_update,
      params: { client_account: client_account }
    ).serialized_json, status: :created
  end

  def remove_suitcase
    return unauthorized unless authorized_source

    failures = []
    program_ranges_to_update = []
    suitcase_program_ranges = []

    program_ranges.each do |program_range|
      spr = client_account.suitcase_program_ranges.find_by(program_range_id: program_range.id)

      if spr && !client_account.applications_for_term?(program_range)
        program_ranges_to_update << program_range
        suitcase_program_ranges << spr
      else
        program_title = program_range.program_title

        failures << (spr ? "#{spr.suitcase_name}, #{program_title}" : program_title)
      end
    end

    suitcase_program_ranges.each(&:destroy)

    update_client_specific_report_program_associations(
      program_ranges_to_update.map(&:program_id).uniq,
      program_ranges_to_update.map(&:id)
    )

    render json: ProgramRangeSerializer.new(
      program_ranges_to_update,
      params: { client_account: client_account }
    ).to_hash.merge!({ failures: failures }), status: :ok
  end

  private

  def application_params
    params.permit(:application_deadline, :application_template_id, :program_range_ids)
  end

  def prfg_params
    params.permit(
      :program_range_ids,
      program_range_form_groupings_attributes: [
        :id,
        :deadline,
        { program_range_form_grouping_templates_attributes: %i[id form_template_id] }
      ]
    )
  end

  def suitcase_params
    params.permit(:program_range_ids, :suitcase_id)
  end

  def authorized_source
    @authorized_source ||= params[:source] == "authorized"
  end

  def internal_source
    @internal_source ||= params[:source] == "internal"
  end

  def program_ranges
    @program_ranges ||= if internal_source && occasional_user?
                          current_user.assigned_program_ranges
                        elsif internal_source
                          client_account.internal_program_ranges
                        else
                          client_account.external_program_ranges
                        end.where(id: params[:program_range_ids]).includes(
                          :alternate_tags,
                          :application_template,
                          :submissions,
                          :tags,
                          program_range_form_groupings: :form_templates,
                          program: [
                            :primary_client_account,
                            :program_amenities,
                            :program_eligibility,
                            :program_highlight,
                            :program_location_highlight,
                            :program_review,
                            :program_scholarship_info,
                            :subject_areas,
                            {
                              program_languages: :language,
                              program_locations: :via_country,
                              program_ranges: :tags,
                              included_program_housings: :housing_type,
                              included_program_type_connections: :program_type,
                              program_contact: [user: %i[profile traveler_info]],
                              program_managers: [user: %i[profile traveler_info]]
                            }
                          ]
                        )
  end

  def update_client_specific_report_program_associations(program_ids, program_range_ids)
    ReportProgram.where(client_account_id: client_account_id, program_id: program_ids)
                 .update_all(sync_required: true)
    ReportProgramRange.where(
      client_account_id: client_account_id,
      program_range_id: program_range_ids
    ).update_all(sync_required: true)

    UpdateClientSpecificReportProgramAssociations.perform_async(
      client_account_id,
      program_ids,
      program_range_ids
    )
  end

  def validate_enrollment_client
    return unauthorized unless client_account.enrollment?
  end
end
