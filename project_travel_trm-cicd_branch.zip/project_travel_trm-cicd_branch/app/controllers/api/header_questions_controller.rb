# frozen_string_literal: true

class Api::HeaderQuestionsController < Api::BaseController
  before_action :authorize_admin
  before_action :find_template, only: %i[create update destroy]
  before_action :find_question, only: %i[update destroy]

  def create
    authorize!(:update, @template)

    hq = @template.header_questions.new(hq_params)

    return bad_request(hq) unless hq.save

    AddQuestionToTemplateLayout.call(question: hq.question, template: @template)

    update_report_submission_associations(@template)

    render(
      json: HeaderQuestionSerializer.new(hq, params: { action: params[:action] }),
      status: :created
    )
  end

  def update
    authorize!(:update, @template)

    return bad_request(@question) unless @question.update(hq_params)

    update_report_submission_associations(@template)

    render json: HeaderQuestionSerializer.new(@question), status: :ok
  end

  def destroy
    authorize!(:update, @template)

    question_id = @question.question_id
    template_layout = @template.template_layout

    if @question.destroy
      RemoveQuestionFromTemplateLayout.call(
        question_id: question_id,
        template_layout: template_layout
      )

      update_report_submission_associations(@template)

      render json: { template_layout: template_layout }, status: :ok
    else
      render json: { errors: @question.errors }, status: :bad_request
    end
  end

  private

  def hq_params
    params.require(:question).permit(:text)
  end

  def find_template
    @template = client_account.templates.find_by_id(params[:form_template_id])

    return not_found unless @template
  end

  def find_question
    @question = @template.header_questions.find_by_id(params[:id])

    return not_found unless @question
  end

  def current_ability
    @current_ability ||= TemplateAbility.new(current_user, params)
  end

  def update_report_submission_associations(template)
    template.submissions&.each do |submission|
      submission_id = submission.id

      ReportSubmission.find_by_submission_id(submission_id)&.update(sync_required: true)
      UpdateReportSubmission.perform_in(10.seconds, submission_id)
    end
  end
end
