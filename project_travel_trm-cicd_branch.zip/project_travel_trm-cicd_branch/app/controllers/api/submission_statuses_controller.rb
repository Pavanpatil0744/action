# frozen_string_literal: true

class Api::SubmissionStatusesController < Api::BaseController
  skip_before_action :authenticate_user!

  before_action :find_submission_type, only: :index

  def index
    render json: SubmissionStatusSerializer.new(submission_statuses), status: :ok
  end

  private

  def submission_statuses
    @submission_type.submission_statuses
  end

  def find_submission_type
    @submission_type = SubmissionType.find_by_identifier(params[:type])

    return not_found unless @submission_type
  end
end
