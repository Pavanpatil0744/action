# frozen_string_literal: true

class Api::YearInSchoolOptionsController < Api::BaseController
  def index
    render json: TravelerInfo::YEAR_IN_SCHOOL_OPTIONS, status: :ok
  end
end
