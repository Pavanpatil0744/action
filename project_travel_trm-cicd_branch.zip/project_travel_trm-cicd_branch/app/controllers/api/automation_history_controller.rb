# frozen_string_literal: true

class Api::AutomationHistoryController < Api::BaseController
  include QueryHandler

  def index
    render json: query_to_json(history_query), status: :ok
  end

  private

  def sql_variables
    {
      CLIENT_ACCOUNT_ID: client_account_id,
      AUTOMATION_ID: params[:automation_id]
    }
  end

  def sql_statement
    if params[:automation_action] == "add_tags"
      AUTOMATION_ADD_TAG_HISTORY
    end
  end

  def history_query
    prepared_query(sql_statement, sql_variables)
  end
end