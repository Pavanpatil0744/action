# frozen_string_literal: true

class Api::EventsController < Api::BaseController
  include QueryHandler

  def index
    render json: query_to_json(report_events_query), status: :ok
  end

  private

  def report_events_query
    prepared_query(REPORT_EVENTS_SQL, { CLIENT_ACCOUNT_ID: client_account_id })
  end
end
