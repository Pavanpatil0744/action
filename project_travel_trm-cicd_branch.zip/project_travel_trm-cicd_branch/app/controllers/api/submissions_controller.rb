# frozen_string_literal: true

class Api::SubmissionsController < Api::BaseController
  include AgeCalculator

  before_action :validate_assignment, only: %i[create show update destroy transfer update_tags_notes], if: :occasional_user?
  before_action :find_submission, only: %i[update destroy transfer update_tags_notes]
  # before_action :find_or_create_cash_net_codes, only: :show
  before_action :validate_submission_status, only: :update, if: :traveler_user?
  before_action :validate_tag_type, only: :update
  after_action :log_http_response_activity

  def show
    @submission =
      if occasional_user?
        assigned_submissions_ids = current_user.assigned_submissions.pluck(:id)

        if assigned_submissions_ids.any?
          assigned_traveler_submissions_ids = @assigned.submissions.pluck(:id)
          ids = assigned_submissions_ids + assigned_traveler_submissions_ids
          client_account.submissions.where(id: ids)
        else
          @assigned.submissions
        end
      elsif admin_user?
        client_account.submissions
      else
        current_user.submissions
      end.where(id: params[:id]).first
      # .includes(
      #   :submission_withdrawal_requests,
      #   :cash_net_codes,
      #   :submission_tracking_step,
      #   :submission_type,
      #   :submission_status,
      #   :traveler_submission_status,
      #   :traveler_submission_tracking_step,
      #   :user,
      #   :tags,
      #   alternate_program_ranges: :program_range,
      #   submission_status_change_logs: [:deferred_and_withdrawal_reasons],
      #   template: [questions: [:detailable, :question_type, :sourceable]],
      #   submission_review: [:submission_review_logs],
      #   responses: [:respondable, question: :sourceable],
      #   program_range: [:program],
      #   client_account: [:request_to_withdraw_setting, :client_account_info]
      # )

    return not_found unless @submission

    find_or_create_cash_net_codes

    authorize!(:show, @submission) if admin_user?

    @submission.sync_responses_from_user_profile

    update_report_submission_associations(@submission)

    render(
      json: SubmissionSerializer.new(
        @submission,
        params: { admin: admin_user?, client_account_id: client_account_id, user_id: current_user.id }
      ),
      status: :ok
    )
  end

  def update
    authorize!(:update, @submission) if admin_user?

    if @submission.type == "application" && !admin_user? && cannot_withdraw?
      return render(
        json: { errors: ["Can't withdraw application, Request to withdraw setting is activated"] },
        status: :bad_request
      )
    end

    attributes = if admin_user?
                   submission_params
                 else
                   submission_params.except(:payment_responses_attributes)
                 end

    msu_traveler = client_account.msu? && traveler_role?
    pre_save_status = @submission.status
    traveler = @submission.user

    if submission_status&.identifier == "submitted" && traveler_role?
      required_responses_present = @submission.required_responses_present?(submission_params)

      unless required_responses_present
        return render(
          json: { errors: ["One or more required fields are blank"] },
          status: :bad_request
        )
      end
    end

    attributes.delete(:taggables_attributes)
    attributes.delete(:submission_review_attributes) if params[:non_updatable_notes_tags_reviews] == "true"

    return bad_request(@submission) unless @submission.update(attributes)

    new_status = @submission.status

    if %w[withdrawn deferred].include? new_status
      @submission.program_range.plans.each do |l|
        plan_user = l.plans_users.find_by_user_id(@submission.user_id)
        if plan_user.present?
          plan_user.update_attribute(:removed, true)
          ReportPlanUser.find_by_plans_users_id(plan_user.id)&.update(sync_required: true)
          UpdateReportPlanUser.perform_in(10.seconds, plan_user.id)
        end

        Plan.update_traveler_count(l)
      end
    end

    if new_status != pre_save_status ||
       (%w[withdrawn deferred].include?(@submission.status) && params[:reasons].present?)

      log_submission_status_change
    end

    if new_status != pre_save_status
      case @submission.type
      when "application"
        SendGrid::V2::SendApplicationStatusChangeMailers.call(
          application: @submission,
          client_account: client_account,
          drt_elaps_trigger: false
        )

        if msu_traveler && new_status == "submitted"
          UpdateApplicationStatusViaAdvocateService.perform_async(@submission.id)
        end
        if new_status == "submitted" && @submission.user.traveler_info.dob.present? && calculate_age(@submission.user.traveler_info.dob.to_date) < 18
          SendGrid::SendMinorApplicationSubmissionToAdminMailer.perform_async(
            @submission.id
          )
        end

        if new_status == "committed"
          plans = client_account.plans.where(program_range_id: @submission.program_range_id)

          plans.each { |plan| InviteExistingTraveler.call(plan: plan, traveler: traveler) }
        end
      when "form"
        SendGrid::V2::SendFormStatusChangeMailers.call(
          client_account: client_account,
          form: @submission
        )
      end
    end

    if params[:non_updatable_notes_tags_reviews] != "true"
      attach_remove_tags(submission_params[:taggables_attributes], "Submission")
    end

    update_report_submission_associations(@submission)
    update_report_traveler_associations(traveler.id)

    render(
      json: SubmissionSerializer.new(
        @submission,
        params: { admin: admin_user?, client_account_id: client_account_id }
      ),
      status: :ok
    )
  end

  def destroy
    authorize!(:destroy, @submission)

    corresponding_application = @submission.corresponding_application

    return bad_request(@submission) unless @submission.destroy

    if corresponding_application
      corresponding_application_id = corresponding_application.id
      report_form_grouping = ReportFormGrouping.find_by_submission_id(corresponding_application_id)

      if corresponding_application.corresponding_forms.any?
        report_form_grouping&.update(sync_required: true)

        UpdateReportFormGrouping.perform_in(10.seconds, corresponding_application_id)
      else
        report_form_grouping&.destroy
      end
    end

    log_submission_status_change(true)

    render(json: {}, status: :no_content)
  end

  def update_tags_notes
    authorize!(:update_tags_notes, @submission) if admin_user?
    attributes = tags_notes_params
    traveler = @submission.user

    attributes.delete(:taggables_attributes)
    return bad_request(@submission) unless @submission.update(attributes)

    attach_remove_tags(tags_notes_params[:taggables_attributes], "Submission")
    update_report_submission_associations(@submission)
    update_report_traveler_associations(traveler.id)

    render(
      json: SubmissionSerializer.new(
        @submission,
        params: { admin: admin_user?, client_account_id: client_account_id }
      ),
      status: :ok
    )
  end

  private

  def submission_params
    params[:submission][:taggables_attributes] ||= []
    params.require(:submission).permit(
      :deadline,
      :program_range_id,
      :submission_status_id,
      :template_id,
      :user_id,
      alternate_program_ranges_attributes: %i[id program_range_id ranking _destroy],
      date_responses_attributes: %i[id question_id value _destroy],
      dropdown_response_groupings_attributes: [
        :id,
        :question_id,
        :_destroy,
        { dropdown_responses_attributes: %i[id dropdown_question_option_id _destroy] }
      ],
      long_text_responses_attributes: %i[id question_id value _destroy],
      multiple_choice_response_groupings_attributes: [
        :id,
        :question_id,
        :_destroy,
        { multiple_choice_responses_attributes: %i[id multiple_choice_question_option_id _destroy] }
      ],
      payment_responses_attributes: %i[id payment_status_id question_id _destroy],
      short_text_responses_attributes: %i[id question_id value _destroy],
      signature_responses_attributes: %i[id question_id value _destroy],
      single_choice_responses_attributes: %i[id question_id value _destroy],
      star_rating_responses_attributes: %i[id star_rating_question_option_id question_id _destroy],
      submission_review_attributes: [
        :id,
        :notes,
        :rating,
        :_destroy,
        { uploaded_files_attributes: %i[id filename s3_store _destroy] }
      ],
      taggables_attributes: %i[tag_id taggable_id status]
    )
  end

  def tags_notes_params
    params.require(:tags_notes).permit(
      :user_id,
      submission_review_attributes: [
        :id,
        :notes,
        :rating,
        :_destroy,
        { uploaded_files_attributes: %i[id filename s3_store _destroy] }
      ],
      taggables_attributes: %i[tag_id taggable_id status]
    )
  end

  def find_or_create_cash_net_codes
    cash_net_with_code_questions = @submission.template.cash_net_with_code_questions

    return if cash_net_with_code_questions.empty?

    cash_net_with_code_questions.each do |cnwcq|
      @submission.cash_net_codes.find_or_create_by(cash_net_with_code_question: cnwcq)
    end
  end

  def find_submission
    @submission = if occasional_user?
                    assigned_submissions = current_user.assigned_submissions
                    assigned_traveler_submissions = @assigned.submissions

                    if assigned_submissions.any?
                      assigned_submissions.merge(assigned_traveler_submissions)
                    else
                      assigned_traveler_submissions
                    end
                  elsif admin_user?
                    client_account.submissions
                  else
                    current_user.submissions
                  end.find_by(id: params[:id])

    return not_found unless @submission
  end

  def log_submission_status_change(deleted = false)
    log = @submission.submission_status_change_logs.create(
      status: deleted ? "deleted" : @submission.status,
      user_id: current_user.id,
      user_email: current_user.email,
      user_first_name: current_user.first_name || "",
      user_last_name: current_user.last_name || ""
    )

    log.add_reasons(params[:reasons])
  end

  def log_http_response_activity
    HttpResponseActivityLog.create(
      current_user_id: current_user&.id,
      ip: request.remote_ip,
      method: request.method,
      params: request.params,
      path: request.path,
      payload: JSON.parse(response.body),
      status_code: response.response_code,
      status_message: response.status_message
    )
  end

  def submission_status
    @submission_status ||= SubmissionStatus.find_by_id(submission_params[:submission_status_id])
  end

  def validate_submission_status
    return unless submission_status && !submission_status.traveler_updateable?

    render json: {
      errors: ["#{submission_status.name} status is not traveler updateable"]
    }, status: :bad_request
  end

  def validate_assignment
    assigned_travelers = current_user.assigned_travelers
    submissions = params[:submissions]

    @assigned = if submissions
                  user_ids = submissions.map { |submission| submission[:user_id].to_i }
                  assigned_user_ids = assigned_travelers.pluck(:id)

                  (user_ids.uniq - assigned_user_ids.uniq).empty?
                elsif params[:action] == "create"
                  assigned_travelers.find_by_id(submission_params[:user_id])
                else
                  submission = Submission.find_by_id(params[:id])

                  return not_found unless submission

                  assigned_travelers.find_by_id(submission[:user_id])
                end

    render json: { message: "Unauthorized" }, status: :unauthorized unless @assigned
  end

  def current_ability
    @current_ability ||= SubmissionAbility.new(current_user)
  end

  def update_report_submission_associations(submission)
    submissions_to_update = []
    submissions_to_update << submission
    submissions_to_update |= submission.corresponding_submissions

    submissions_to_update.each do |sub|
      sub_id = sub.id

      if sub.application?
        report_form_grouping = ReportFormGrouping.find_by_submission_id(sub_id)

        if sub.corresponding_forms.any?
          report_form_grouping&.update(sync_required: true)

          UpdateReportFormGrouping.perform_in(10.seconds, sub_id)
        else
          report_form_grouping&.destroy
        end
      end

      ReportSubmission.find_by_submission_id(sub_id)&.update(sync_required: true)
      UpdateReportSubmission.perform_in(10.seconds, sub_id)
    end

    program_id = submission.program_id

    ReportProgram.find_by_program_id(program_id)&.update(sync_required: true)
    UpdateReportProgram.perform_in(10.seconds, submission.client_account_id, program_id)
  end

  def update_report_traveler_associations(traveler_id)
    ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
    UpdateReportTraveler.perform_in(10.seconds, traveler_id)
  end

  def attach_remove_tags(tags, taggable_type)
    add = []
    remove = []
    tags.each do |l|
      add << { tag_id: l[:tag_id], taggable_id: l[:taggable_id], taggable_type: taggable_type } if l[:status] == "add"
      remove << l if l[:status] == "remove"
    end

    new_tags = ::Taggable.create(add) if add.any?

    return unless remove.any?

    ::Taggable.where(
      tag_id: remove.map { |m| m[:tag_id] },
      taggable_id: remove.first[:taggable_id],
      taggable_type: taggable_type
    ).destroy_all
  end

  def request_to_withdraw_active?
    setting = client_account.request_to_withdraw_setting
    params[:submission][:submission_status_id].present? && setting&.active && setting&.application_statuses.include?(@submission.status)
  end

  def cannot_withdraw?
    request_to_withdraw_active? && params[:submission][:submission_status_id].to_i == SubmissionStatus.find_by_identifier('withdrawn').id
  end

  def validate_tag_type
    return unless submission_params[:taggables_attributes].present?

    tag_ids = submission_params[:taggables_attributes].map { |tag| tag[:tag_id] }
    tag_type = Tag.where(id: tag_ids).pluck(:tag_type).uniq
    submission_type = @submission.submission_type.name
    invalid_tag_type = (tag_type.count > 1 || tag_type.first != submission_type)

    render json: { errors: "Tag is unacceptable for type #{submission_type}" }, status: 400 if invalid_tag_type
  end
end
