# frozen_string_literal: true

class Api::HousingTypesController < ApplicationController
  def index
    render json: (Rails.cache.fetch("housing_types", expires_in: 12.hours) do
      HousingTypeSerializer.new(HousingType.in_order).serializable_hash
    end), status: :ok
  end
end
