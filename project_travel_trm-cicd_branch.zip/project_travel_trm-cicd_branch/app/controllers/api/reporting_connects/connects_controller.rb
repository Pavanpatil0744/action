# frozen_string_literal: true

module Api
  module ReportingConnects
    # Reporting Connects apis
    class ConnectsController < Api::BaseController
      def index
        connects = ViaConnectAction.records_from(client_account).exclude_client.where("program_provider = ?", client_account.org_name).order("created_at DESC")

        render(
          json: ::ReportingConnects::ConnectsSerializer.new(
            connects
          ).serialized_json,
          status: :ok
        )
      end

      def graph_information
        render(
          json: json_object,
          status: :ok
        )
      end

      def popular_programs
        connects = ViaConnectAction.records_from(client_account)
                                   .exclude_client
                                   .select('DISTINCT ON (action, program_name, user_email) *')
                                   .where(
                                     "program_provider = ?
                                     AND CAST(via_connect_actions.created_at AT TIME ZONE 'UTC' AT TIME ZONE ? AS TEXT)::DATE BETWEEN ? AND ?",
                                     client_account.org_name,
                                     client_account.org_timezone,
                                     Date.today.beginning_of_year.to_date,
                                     Date.today.to_date
                                   ).group(:program_name)
                                   .count(:program_name)

        if connects
          sorted_connects = connects.sort_by { |_key, value| value }.reverse.first(5).to_h

          result = JSON.parse(
                               Program.select(:id, :title)
                               .where(title: sorted_connects.keys)
                               .sort_by { |p| sorted_connects.keys.index(p.title) }.to_json
                             )
          result.each do |l|
            l["connects"] = sorted_connects[l["title"]]
          end
        else
          result = []
        end
        render(
          json: result,
          status: :ok
        )
      end

      def recent_connects
        render(
          json: ::ReportingConnects::ViaConnectSerializer.new(
              ViaConnectAction.records_from(client_account).exclude_client.recent(client_account).order(created_at: :desc)
            ).serialized_json,
          status: :ok
        )
      end

      def program_authorized_graph
        authorizable_programs = client_account.programs.authorizable(client_account.id)
        hidden_client = ClientAccount.where(hidden: true).pluck(:id)
        authorized_by = ClientAccountProgram.where(program_id: authorizable_programs.pluck(:id))
                                            .where.not(client_account_id: [client_account.id, hidden_client].flatten)
        program_count = authorized_by.pluck(:program_id).uniq.count
        client_count = authorized_by.pluck(:client_account_id).uniq.count
        unauthorizable = authorizable_programs.pluck(:id).uniq - authorized_by.pluck(:program_id).uniq
        unauthorized = 0
        unauthorizable.each do |l|
          if PaperTrail::Version.where(event: 'destroy', item_type: "ClientAccountProgram").where_object(program_id: l).any?
            unauthorized += 1
          end
        end
        total = program_count + unauthorized
        result = [
          {
            label: "Programs Authorized #{program_count} by #{client_count} Organizations",
            value: program_count,
            percentage: ((program_count.to_f / total) * 100).round(2)
          },
          {
            label: "Programs UnAuthorized #{unauthorized}",
            value: unauthorized,
            percentage: ((unauthorized.to_f / total) * 100).round(2)
          }
        ]
        render(
          json: result,
          status: :ok
        )
      end

      def organization_insights
        client_accounts = ClientAccount.includes(client_account_info: :address).where(status: "enrollment", hidden: false)
        lead_authorizable_programs = Program.authorizable(client_account.id).pluck(:id)
        lead_programs_set = Set.new(lead_authorizable_programs)
        insights = client_accounts.map do |c|
          address = c.client_account_info.address
          client_authorizable_program = Program.authorized_for(c).pluck(:id)
          intersection = Set.new(client_authorizable_program) & lead_programs_set
          percentage = (intersection.length/client_authorizable_program.length.to_f) * 100.0
          {
            org_id: c.id,
            org_name: c.org_name,
            org_logo: c.logo.url,
            org_address: "#{address&.city}, #{address&.state}",
            authorizing_status: intersection.length.positive? ? "Authorizing" : "Not Authorizing",
            authorizing_percentage: percentage.nil? ? 0.0 : percentage.round(1)
          }
        end

        render(
          json: insights,
          status: :ok
        )
      end

      def organization_info
        org = ClientAccount.includes(client_account_info: :address).find(params[:org_id])
        address = org.client_account_info.address

        lead_authorizable_programs = Program.authorizable(client_account.id)
        lead_programs_set = Set.new(lead_authorizable_programs.pluck(:id))
        intersection = Set.new(org.programs.pluck(:id)) & lead_programs_set
        programs = lead_authorizable_programs.includes(:program_ranges, :program_locations, :client_account_programs).where(id: intersection.to_a)
        actions = ViaConnectAction.actions.keys
        program_data = programs.map do |l|
          via_connects = ViaConnectAction.where(
            home_campus: org.org_name,
            program_provider: client_account.org_name,
            program_name: l.title
          )
          {
            id: l.id,
            title: l.title,
            location: l.program_locations.pluck(:formatted_address).join(';'),
            program_favorites: via_connects.select { |record| record.action == actions[0] }.length,
            asked_a_question: via_connects.select { |record| record.action == actions[1] }.length,
            learn_request: via_connects.select { |record| record.action == actions[2] }.length,
            started_application: via_connects.select { |record| record.action == actions[3] }.length,
            last_authorized_date: l.client_account_programs.where(client_account_id: org.id).last&.created_at.strftime("%b %d, %Y"),
            ytd: Submission.select(:id).where(
              "submissions.program_range_id IN (?) AND submissions.client_account_id = ? AND
              CAST(submissions.created_at AT TIME ZONE 'UTC' AT TIME ZONE ? AS TEXT)::DATE BETWEEN ? AND ?",
              l.program_ranges.pluck(:id),
              org.id,
              client_account.org_timezone,
              Date.today.beginning_of_year.to_date,
              Date.today.to_date
            ).count
          }
        end
        total_authorized_program = Program.authorized_for(org).count
        org_info = {
          org_address: "#{address&.city}, #{address&.state}",
          org_name: org.org_name,
          org_logo: org.logo.url,
          program_data: program_data,
          authorize_program: programs.count,
          total_authorize_program: total_authorized_program,
          percentage: (programs.count/total_authorized_program.to_f) * 100,
          authorizing_status: intersection.length.positive? ? "Authorizing" : "Not Authorizing"
        }
        render(
          json: org_info,
          status: :ok
        )
      end

      private

      def json_object
        connects = ViaConnectAction.records_from(client_account)
                                   .exclude_client
                                   .select('DISTINCT ON (action, program_name, user_email) *')
                                   .where(
                                      "program_provider = ? AND
                                      CAST(via_connect_actions.created_at AT TIME ZONE 'UTC' AT TIME ZONE ? AS TEXT)::DATE BETWEEN ? AND ?",
                                      client_account.org_name,
                                      client_account.org_timezone,
                                      Date.today.beginning_of_year.to_date,
                                      Date.today.to_date
                                    )
        doughnut = {}
        connects.group_by(&:action).each { |a| doughnut[a[0]] = a[1].count }
        result_doughnut = []
        total_doughnut_connect = connects.length
        doughnut.each_key do |l|
          result_doughnut << { label: l, value: doughnut[l], percentage: ((doughnut[l].to_f / total_doughnut_connect) * 100).round(2) }
        end
        bar = connects.group(:home_campus).count(:home_campus)
        total_bar_connect = bar.values.sum
        result_bar = []
        bar.each_key do |l|
          result_bar << { label: l, value: bar[l], percentage: ((bar[l].to_f / total_bar_connect) * 100).round(2) }
        end
        geo_connects = ViaConnectAction.records_from(client_account)
                                       .exclude_client
                                       .select('DISTINCT ON (action, program_name, user_email) *, program_locations.country_common_name')
                                       .joins(
                                          "left join programs on programs.title = via_connect_actions.program_name
                                          left join program_locations on program_locations.program_id = programs.id "
                                       )
                                       .where(
                                         "program_provider = ? AND CAST(via_connect_actions.created_at AT TIME ZONE 'UTC' AT TIME ZONE ? AS TEXT)::DATE BETWEEN ? AND ?",
                                         client_account.org_name,
                                         client_account.org_timezone,
                                         Date.today.beginning_of_year.to_date,
                                         Date.today.to_date
                                       )
        geo = geo_connects.group("program_locations.country_common_name").count("program_locations.country_common_name")

        {
          doughnut: { doughnut: result_doughnut, total: doughnut.values.sum },
          bar: result_bar,
          geo: geo.map { |l| l }
        }
      end
    end
  end
end