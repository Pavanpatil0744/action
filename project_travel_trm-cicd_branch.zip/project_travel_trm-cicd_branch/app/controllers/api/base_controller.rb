# frozen_string_literal: true

class Api::BaseController < ApplicationController
  before_action :authenticate_user!

  private

  def admin_role?
    @admin_role ||= current_user.admin_role?
  end

  def admin_user?
    @admin_user ||= current_user.admin_sign_in?
  end

  def authorize_admin
    return forbidden unless admin_user?
  end

  def client_account
    @client_account ||= current_user.client_account || current_user.clients.first
  end

  def client_account_id
    @client_account_id ||= client_account.id
  end

  def client_account_info
    @client_account_info ||= client_account.client_account_info
  end

  def client_account_logo
    @client_account_logo ||= client_account.logo.url
  end

  def current_user_email
    @current_user_email ||= current_user.email
  end

  def current_user_id
    @current_user_id ||= current_user.id
  end

  def intake_completed?
    @intake_completed ||= !admin_user? && current_user.program_preference.present?
  end

  def occasional_user?
    @occasional_user ||= admin_user? && current_user.is_occasional_user?
  end

  def program_alias
    @program_alias ||= client_account_info.alias_program
  end

  def traveler_alias
    @traveler_alias ||= client_account_info.alias_traveler
  end

  def travelers_alias
    @travelers_alias ||= client_account_info.alias_travelers
  end

  def traveler_user?
    @traveler_user ||= !current_user.admin_sign_in?
  end

  def traveler_info
    @traveler_info ||= current_user.traveler_info
  end

  def traveler_role?
    @traveler_role ||= current_user.is_traveler?
  end

  def via_global?
    @via_global ||= client_account.via_global?
  end

  def via_travel?
    @via_travel ||= client_account.via_travel?
  end
end
