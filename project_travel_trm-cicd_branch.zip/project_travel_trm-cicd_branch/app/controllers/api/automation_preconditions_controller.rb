# frozen_string_literal: true

class Api::AutomationPreconditionsController < Api::BaseController
  before_action :validate_admin_user, only: :index
  before_action :validate_presence_of_qualifier, only: :index
  before_action :find_automation_qualifier, only: :index

  def index
    render(
      json: AutomationPreconditionSerializer.new(automation_preconditions).serialized_json,
      status: :ok
    )
  end

  private

  def automation_preconditions
    @automation_qualifier.automation_preconditions.in_order
  end

  def find_automation_qualifier
    @automation_qualifier = AutomationQualifier.find_by_identifier(params[:qualifier])

    return not_found unless @automation_qualifier
  end

  def validate_admin_user
    return forbidden unless admin_user?
  end

  def validate_presence_of_qualifier
    return if params[:qualifier].present?

    render(json: { message: "Please provide a qualifier" }, status: :unprocessable_entity)
  end
end
