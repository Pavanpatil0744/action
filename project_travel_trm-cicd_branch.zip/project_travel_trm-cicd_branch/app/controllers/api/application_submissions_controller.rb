# frozen_string_literal: true

class Api::ApplicationSubmissionsController < Api::SubmissionsController
  before_action :find_traveler, only: :index
  before_action :validate_client_account, only: :index, if: :admin_user?
  before_action :validate_application_timeframe, only: :create
  before_action :admin_assigned, only: :index, if: :occasional_user?

  def index
    authorize!(:index, traveler_applications) if admin_user?

    applications = SubmissionSerializer.new(
      traveler_applications,
      params: { admin: admin_user?, client_account_id: client_account_id }
    ).to_hash

    render json: { data: deadline_sorted(applications) }, status: :ok
  end

  def create
    submission = if admin_user?
                   client_account.submissions.new(submission_params)
                 else
                   current_user.submissions.new(submission_params)
                 end

    deadline_present = submission.deadline.present?
    program_range = submission.program_range

    return no_program_range_specified unless program_range.present?

    if program_range.primary_client_account_id != client_account_id
      suitcase = client_account.suitcase_by_program_range(program_range)

      return no_suitcase_assigned unless suitcase

      deadline = suitcase.application_deadline
      template = suitcase.application_template
    else
      deadline = program_range.deadline
      template = program_range.application_template
    end

    return deadline_has_passed if !admin_user? && deadline_has_passed?(deadline)

    submission.client_account = client_account unless admin_user?
    submission.deadline = deadline unless deadline_present
    submission.submission_status = SubmissionStatus.find_by_identifier("incomplete")
    submission.submission_type = SubmissionType.find_by_identifier("application")
    submission.template = template

    authorize!(:create, submission) if admin_user?

    return bad_request(submission) unless submission.save

    send_new_application_mailers(program_range, submission)
    update_report_submission_associations(submission)
    track_activity(submission, program_range) unless admin_user?

    render(
      json: SubmissionSerializer.new(
        submission,
        params: { admin: admin_user?, client_account_id: client_account_id }
      ),
      status: :created
    )
  end

  def transfer
    return forbidden unless admin_user?

    authorize!(:transfer, @submission)

    term = client_account.program_ranges.find(params[:program_range_id])
    transferred_status = SubmissionStatus.find_by_identifier("transferred")
    traveler = @submission.user
    applied_terms = traveler.application_submissions.pluck(:program_range_id)

    if applied_terms.include?(term.id)
      return render json: {
        error: "Unable to transfer; application for this term already exists."
      }, status: :unprocessable_entity
    end

    if term.primary_client_account_id != client_account_id
      suitcase = client_account.suitcase_by_program_range(term)

      return no_suitcase_assigned unless suitcase

      deadline = suitcase.application_deadline
      template = suitcase.application_template
    else
      deadline = term.deadline
      template = term.application_template
    end

    new_submission = if @submission.template == template
                       @submission.duplicate(term, new_submission_status)
                     else
                       client_account.submissions.create(
                         created_by_transfer: true,
                         deadline: deadline,
                         program_range: term,
                         template: template,
                         submission_status: new_submission_status || @submission.submission_status,
                         submission_type: @submission.submission_type,
                         user: traveler
                       )
                     end

    if new_submission.status == "committed"
      plans = client_account.plans.where(program_range: term)

      plans.each { |plan| InviteExistingTraveler.call(plan: plan, traveler: traveler) }
    end

    @submission.copy_associated_forms(new_submission) if copy_associated_forms?

    create_submission_transfer_log(new_submission)

    @submission.update(submission_status: transferred_status)

    log_submission_status_change

    unless new_submission.subject_to_decision_release?
      transfer_chain = new_submission.transfer_chain

      transfer_chain.each do |app|
        app.update(
          decision_released: true,
          traveler_submission_status: app.submission_status,
          traveler_submission_tracking_step: app.submission_tracking_step
        )
      end
    end

    update_report_submission_associations(new_submission)
    update_report_submission_associations(@submission)

    render(
      json: SubmissionSerializer.new(
        new_submission.reload,
        params: { admin: admin_user?, client_account_id: client_account_id }
      ),
      status: :created
    )
  end

  private

  def admin_assigned
    assigned_travelers = current_user.assigned_travelers
    assigned = assigned_travelers.pluck(:id).include?(@traveler.id)

    render(json: { message: "Unauthorized" }, status: :unauthorized) unless assigned
  end

  def copy_associated_forms?
    [true, 'true'].include?(params[:copy_associated_forms])
  end

  def create_submission_transfer_log(new_submission)
    SubmissionTransferLog.create(
      new_submission: new_submission,
      submission_id: @submission.id,
      transferred_at: DateTime.current,
      user_id: current_user_id,
      user_email: current_user.email,
      user_first_name: current_user.first_name,
      user_last_name: current_user.last_name
    )
  end

  def current_ability
    @current_ability ||= SubmissionAbility.new(current_user)
  end

  def deadline_has_passed
    render(json: { errors: ["Deadline has passed"] }, status: :unprocessable_entity)
  end

  def deadline_has_passed?(deadline)
    return false unless deadline.present?

    deadline.in_time_zone(client_account.org_timezone) < organization_current_date_time
  end

  def deadline_sorted(applications)
    now = organization_current_date_time

    applications.first.last.sort do |a, b|
      a_attributes = a[:attributes]
      b_attributes = b[:attributes]
      a_deadline = a_attributes[:deadline]&.to_datetime
      b_deadline = b_attributes[:deadline]&.to_datetime
      a_start_date = a_attributes[:program_range][:start_date]&.to_datetime
      b_start_date = b_attributes[:program_range][:start_date]&.to_datetime
      a_status = a_attributes[:submission_status][:name]
      b_status = b_attributes[:submission_status][:name]
      a_tracking_step = a_attributes[:submission_tracking_step][:identifier]
      b_tracking_step = b_attributes[:submission_tracking_step][:identifier]

      if a_status == "Incomplete" && b_status == "Incomplete"
        if a_deadline.blank? || b_deadline.blank?
          if a_deadline.blank? && (b_deadline.blank? || (b_deadline.present? && (b_deadline < now || b_deadline > now.advance(days: 14))))
            if a_tracking_step == 'deferred_withdrawn_closed' && b_tracking_step != 'deferred_withdrawn_closed'
              1
            elsif a_tracking_step == 'deferred_withdrawn_closed'
              1
            else
              b_tracking_step == 'deferred_withdrawn_closed' ? -1 : (a_start_date <=> b_start_date)
            end
          elsif a_deadline.blank? && (b_deadline.present? && b_deadline >= now && b_deadline <= now.advance(days: 14))
            1
          else
            -1
          end
        elsif a_deadline >= now && a_deadline <= now.advance(days: 7) && b_deadline >= now && b_deadline <= now.advance(days: 7)
          if a_start_date && b_start_date
            a_start_date <=> b_start_date
          else
            a_start_date ? -1 : 1
          end
        elsif a_deadline >= now && a_deadline <= now.advance(days: 7)
          -1
        elsif b_deadline >= now && b_deadline <= now.advance(days: 7)
          1
        elsif a_deadline >= now.advance(days: 7) && a_deadline <= now.advance(days: 14) && b_deadline >= now.advance(days: 7) && b_deadline <= now.advance(days: 14)
          if a_start_date && b_start_date
            a_start_date <=> b_start_date
          else
            a_start_date ? -1 : 1
          end
        elsif a_deadline >= now.advance(days: 7) && a_deadline <= now.advance(days: 14)
          -1
        elsif b_deadline >= now && b_deadline <= now.advance(days: 14)
          1
        else
          a_start_date && b_start_date ? a_start_date <=> b_start_date : a_start_date ? -1 : 1
        end
      elsif a_status == "Incomplete"
        -1
      else
        b_status == "Incomplete" ? 1 : a_start_date <=> b_start_date
      end
    end
  end

  def find_traveler
    @traveler = if admin_user?
                  client_account.travelers.find_by_id(params[:user_id])
                else
                  current_user
                end

    render(json: { errors: ["User id is required"] }, status: :bad_request) unless @traveler
  end

  def no_program_range_specified
    render(json: { errors: ["Please specify a term"] }, status: :bad_request)
  end

  def no_suitcase_assigned
    render(json: { errors: ["No suitcase assigned to term"] }, status: :unprocessable_entity)
  end

  def non_transferred_submissions_subject_to_decision_release(submissions)
    hidden_submission_ids = []

    submissions.each do |submission|
      next unless submission.subject_to_decision_release? && submission.transferred?

      headless_transfer_chain = submission.transfer_chain.drop(1)
      hidden_submission_ids += headless_transfer_chain.map(&:id)
    end

    submissions.reject do |submission|
      hidden_submission_ids.include?(submission.id)
    end
  end

  def organization_current_date_time
    Time.now.in_time_zone(client_account.org_timezone).to_datetime
  end

  def send_new_application_mailers(program_range, submission)
    if client_account == program_range.primary_client_account
      SendGrid::V2::SendNewInternalApplicationMailers.call(
        application: submission,
        client_account: client_account
      )
    elsif program_range.primary_client_account.active?
      SendGrid::V2::SendNewAuthorizedApplicationMailers.call(
        application: submission,
        client_account: client_account
      )
    end
  end

  def new_submission_status
    @new_submission_status ||= begin
      submission_status = params[:submission_status]

      SubmissionStatus.find_by_id(submission_status) if submission_status
    end
  end

  def traveler_applications
    if occasional_user?
      current_user.assigned_application_submissions.where(
        user_id: @traveler.id
      ).to_a
    elsif admin_user?
      client_account.application_submissions.where(user_id: @traveler.id).to_a
    else
      non_transferred_submissions_subject_to_decision_release(
        current_user.application_submissions
      )
    end
  end

  def validate_application_timeframe
    program_range = ProgramRange.find_by_id(submission_params[:program_range_id])
    user = admin_user? ? User.find_by_id(submission_params[:user_id]) : current_user

    return unless program_range

    application_timeframe_violation = user.application_timeframe_violation?(program_range)
    override = admin_user? && params[:override_application_timeframe_violation]

    return if !application_timeframe_violation || override

    render(
      json: { error: "Client account limits travelers to one program per timeframe" },
      status: :unprocessable_entity
    )
  end

  def validate_client_account
    validated = current_user.client_account == @traveler.client

    render(json: { message: "Unauthorized" }, status: :unauthorized) unless validated
  end

  def track_activity(application, program_range)
    program = application.program
    action_time = Time.now.utc
    program_countries = program.via_countries.compact.map(&:name).join(", ")

    ViaConnectAction.create(
      action_date: action_time.to_date,
      action_time: action_time,
      action: 3,
      user_id: current_user.id,
      user_preferred_first_name: current_user.preferred_first_name,
      user_first_name: current_user.first_name,
      user_last_name: current_user.last_name,
      user_email: current_user.email,
      home_campus: client_account.org_name,
      program_name: program.title,
      program_provider: program.primary_client_account.org_name,
      term_name: application.term_name,
      term_start_date: program_range.start_date,
      term_end_date: program_range.end_date,
      source: "Via TRM",
      internal: program.internal?(client_account),
      program_id: program.id,
      program_countries: program_countries,
      student_id: current_user.student_id
    )
  end
end
