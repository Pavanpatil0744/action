# frozen_string_literal: true

class Api::RegistrationsController < Devise::RegistrationsController
  before_action :validate_registration, only: :create

  def create
    cfl_attributes = client_account.client_feature_list.attributes.except(
      "id",
      "client_account_id",
      "created_at",
      "updated_at"
    )
    email = registration_params[:email].downcase
    self_registration = client_account.traveler_invitations.where(email: email).empty?

    traveler = CreateTraveler.call(
      client_account: client_account,
      email: email,
      password: registration_params[:password],
      sign_up_source: self_registration ? "Self Registration" : "Via Global Invitation"
    ).traveler

    SendGrid::SendNewAccountCreationMailers.call(client_account: client_account, traveler: traveler)

    render json: {
      client_feature_list: cfl_attributes,
      is_success: true,
      message: "Sign up successful",
      user: traveler
    }, status: :created
  end

  private

  def registration_params
    params.permit(:client_account_id, :email, :password, :password_confirmation)
  end

  def client_account
    @client_account ||= ClientAccount.find(registration_params[:client_account_id])
  end

  def validate_registration
    email = registration_params[:email]
    password = registration_params[:password]
    password_confirmation = registration_params[:password_confirmation]

    if !client_account.active?
      render json: { message: "Client account is inactive" }, status: :forbidden
    elsif !email&.match?(Devise.email_regexp)
      render json: { message: "Please provide a valid email address" }, status: :bad_request
    elsif !password || !password_confirmation
      render json: { message: "Please provide a password and password confirmation" }, status: :bad_request
    elsif password != password_confirmation
      render json: { message: "Password and password confirmation do not match" }, status: :bad_request
    elsif User.exists?(email: email)
      render json: { message: "An account already exists for this email address" }, status: :conflict
    end
  end
end
