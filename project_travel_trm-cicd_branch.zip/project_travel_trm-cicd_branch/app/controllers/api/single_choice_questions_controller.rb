# frozen_string_literal: true

class Api::SingleChoiceQuestionsController < Api::BaseController
  before_action :authorize_admin
  before_action :find_template, only: %i[create update destroy]
  before_action :find_question, only: %i[update destroy]

  def create
    authorize!(:update, @template)

    scq = @template.single_choice_questions.new(scq_params)

    return bad_request(scq) unless scq.save

    AddQuestionToTemplateLayout.call(question: scq.question, template: @template)

    update_report_submission_associations(@template)

    render(
      json: SingleChoiceQuestionSerializer.new(scq, params: { action: params[:action] }),
      status: :created
    )
  end

  def update
    authorize!(:update, @template)

    return bad_request(@question) unless @question.update(scq_params)

    update_report_submission_associations(@template)

    render json: SingleChoiceQuestionSerializer.new(@question), status: :ok
  end

  def destroy
    authorize!(:update, @template)

    question_id = @question.question_id
    template_layout = @template.template_layout

    if @question.destroy
      RemoveQuestionFromTemplateLayout.call(
        question_id: question_id,
        template_layout: template_layout
      )

      update_report_submission_associations(@template)

      render json: { template_layout: template_layout }, status: :ok
    else
      render json: { errors: @question.errors }, status: :bad_request
    end
  end

  private

  def scq_params
    params.require(:question).permit(
      :admin_only,
      :correct_option,
      :instructions,
      :label,
      :required,
      single_choice_question_logic_attributes: [
        :child_question_type,
        :correct_option,
        :trigger,
        child_question_attributes: %i[
          id
          character_limit
          instructions
          label
          required
          template_id
        ]
      ]
    )
  end

  def find_template
    @template = client_account.templates.find_by_id(params[:form_template_id])

    return not_found unless @template
  end

  def find_question
    @question = @template.single_choice_questions.find_by_id(params[:id])

    return not_found unless @question
  end

  def current_ability
    @current_ability ||= TemplateAbility.new(current_user, params)
  end

  def update_report_submission_associations(template)
    template.submissions&.each do |submission|
      submission_id = submission.id

      ReportSubmission.find_by_submission_id(submission_id)&.update(sync_required: true)
      UpdateReportSubmission.perform_in(10.seconds, submission_id)
    end
  end
end
