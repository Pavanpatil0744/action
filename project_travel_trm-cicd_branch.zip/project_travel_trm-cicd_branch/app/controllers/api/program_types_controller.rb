# frozen_string_literal: true

class Api::ProgramTypesController < ApplicationController
  def index
    render json: ProgramTypeSerializer.new(ProgramType.in_order).serialized_json,
           status: :ok
  end
end
