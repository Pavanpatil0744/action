# frozen_string_literal: true

class Api::PaymentStatusesController < Api::BaseController
  def index
    render json: PaymentStatusSerializer.new(payment_statuses), status: :ok
  end

  private

  def payment_statuses
    PaymentStatus.in_order
  end
end
