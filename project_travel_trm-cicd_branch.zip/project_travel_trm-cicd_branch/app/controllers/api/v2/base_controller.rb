# frozen_string_literal: true

class Api::V2::BaseController < ApplicationController
  before_action :authenticate_user!

  private

  def admin_user?
    @admin_user ||= current_user.admin_sign_in?
  end

  def client_account
    @client_account ||= current_user.client_account || current_user.clients.first
  end

  def client_account_id
    @client_account_id ||= client_account.id
  end

  def client_account_info
    @client_account_info ||= client_account.client_account_info
  end

  def client_account_logo
    @client_account_logo ||= client_account.logo.url
  end

  def current_user_id
    @current_user_id ||= current_user.id
  end

  def intake_completed?
    @intake_completed ||= !admin_user? && current_user.program_preference.present?
  end

  def occasional_user?
    @occasional_user ||= admin_user && current_user.is_occasional_user?
  end

  def traveler_info
    @traveler_info ||= current_user.traveler_info
  end

  def via_global?
    @via_global ||= client_account.via_global?
  end

  def via_travel?
    @via_travel ||= client_account.via_travel?
  end
end
