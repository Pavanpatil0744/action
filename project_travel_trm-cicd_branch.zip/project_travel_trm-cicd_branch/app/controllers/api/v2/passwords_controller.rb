# frozen_string_literal: true

class Api::V2::PasswordsController < Api::V2::BaseController
  before_action :find_user, only: %i[show reset]
  before_action :validate_password, only: %i[reset update]

  skip_before_action :authenticate_user!, except: :update

  def show
    render json: @user.as_json.merge(reset_password_token: @user.reset_password_token), status: :ok
  end

  def update
    return bad_request(current_user) unless current_user.update(password: @password)

    render json: { message: "Password successfully updated" }, status: :ok
  end

  def forgot
    email = params[:email]&.downcase

    return render json: { message: "Please provide an email" }, status: :bad_request unless email

    user = User.find_by_email(email)

    return not_found unless user

    user.set_reset_password_token

    admin_role = user.admin_role?
    client_account = admin_role ? user.client_account : user.clients.first

    SendGrid::SendPasswordResetMailer.perform_async(admin_role, client_account.logo.url, user.id)

    render json: { message: "Password reset email sent" }, status: :ok
  end

  def reset
    if @user.update(password: @password)
      if @user.sign_in_count.zero? && @user.admin_role? && @user.validate_inbound_permission?
        Inbound::VerifyInboundUsersWorker.perform_async(@user.id, @user.client.id)
      end

      render json: { message: "Password successfully reset" }, status: :ok
    else
      return bad_request(@user)
    end
  end

  private

  def find_user
    @user = User.find_by_reset_password_token(params[:reset_token])

    return render json: { message: "Reset token expired" }, status: :not_found unless @user
  end

  def validate_password
    @password = params[:password]
    password_confirmation = params[:password_confirmation]

    if !@password || !password_confirmation
      return render json: {
        message: "Please provide a password and password confirmation"
      }, status: :bad_request
    elsif @password != password_confirmation
      return render json: {
        message: "Password and password confirmation do not match"
      }, status: :bad_request
    end
  end
end
