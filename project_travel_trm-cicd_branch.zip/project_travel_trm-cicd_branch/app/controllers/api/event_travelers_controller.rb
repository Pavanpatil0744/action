# frozen_string_literal: true

class Api::EventTravelersController < Api::BaseController
  include QueryHandler

  def index
    render json: query_to_json(report_event_travelers_query), status: :ok
  end

  private

  def report_event_travelers_query
    prepared_query(REPORT_EVENT_TRAVELERS_SQL, { CLIENT_ACCOUNT_ID: client_account_id })
  end
end
