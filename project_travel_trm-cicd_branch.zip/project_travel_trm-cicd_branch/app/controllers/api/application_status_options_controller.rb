# frozen_string_literal: true

class Api::ApplicationStatusOptionsController < Api::BaseController
  def index
    render json: application_statuses, status: :ok
  end

  private

  def application_statuses
    SubmissionType.find_by_name("Application").submission_statuses.map(&:name)
  end
end
