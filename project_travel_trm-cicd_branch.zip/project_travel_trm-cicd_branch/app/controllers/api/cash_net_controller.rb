# frozen_string_literal: true

class Api::CashNetController < Api::BaseController
  skip_before_action :authenticate_user!

  before_action :find_cash_net_code, only: :postback_with_code
  before_action :find_or_create_payment_response, only: :postback
  before_action :find_submission, only: :create
  before_action :find_question, only: :create

  def create
    amount = @cn_question.cost ? format("%5.2f", @cn_question.cost).strip : "0.00"

    submission_user = @submission.user

    require "cashnet/#{client_subdomain}" rescue require "cashnet"

    field_params = {
      account: submission_user.id,
      amount: amount,
      amount_paid: amount,
      consumer_firstname: submission_user.first_name,
      consumer_lastname: submission_user.last_name,
      custcode: submission_user.student_id,
      element: "#{@cn_question.question_id}|#{@submission.id}|#{params[:user_id]}",
      request: request
    }

    form_input = cashnet_post(field_params, submission_user)
    fields = form_input[:variables]
    target = form_input[:target]

    render html: redirect_html(fields, target), status: :moved_permanently
  end

  def postback
    @payment_response.api_transaction = true
    @payment_response.attributes = { payment_status: payment_status("paid") } if success
    @payment_response.save

    payment_log = create_payment_response_status_change_log(@payment_response)

    create_payment_response_status_change_log_payload(payment_log)

    render html: confirm_html(success), status: :created
  end

  def postback_with_code
    question = @cash_net_code.cash_net_with_code_question.question
    submission = @cash_net_code.submission

    response = submission.payment_responses.find_by(question: question)

    if response.nil?
      response = submission.payment_responses.new(
        payment_status: payment_status("not_paid"),
        question: question
      )
    end

    response.api_transaction = true
    response.attributes = { payment_status: payment_status("paid") } if success
    response.save

    payment_log = create_payment_response_status_change_log(response)

    create_payment_response_status_change_log_payload(payment_log)

    render html: confirm_html(success), status: :created
  end

  private

  def cashnet_params
    params.permit(
      :ccerrorcode,
      :element,
      :failedtx,
      :ref1val1,
      :respmessage,
      :result,
      :tx
    )
  end

  def find_cash_net_code
    @cash_net_code = CashNetCode.find_by(code: cashnet_params[:ref1val1])

    return not_found unless @cash_net_code
  end

  def find_or_create_payment_response
    transaction_id = cashnet_params[:element]
    question_id, submission_id, @payor_id = transaction_id.split("|", 3)
    question = Question.find_by_id(question_id)

    @payment_response = PaymentResponse.find_by(
      question: question,
      submission_id: submission_id
    )

    return if @payment_response

    @payment_response = PaymentResponse.new(
      payment_status: payment_status("not_paid"),
      question: question,
      submission_id: submission_id
    )
  end

  def find_question
    question_id = params[:question_id]
    template = @submission.template
    @cn_question = template.cash_net_questions.find_by_id(question_id) ||
                   template.cash_net_with_code_questions.find_by_id(question_id)

    return not_found unless @cn_question
  end

  def find_submission
    @submission = Submission.find_by_id(params[:submission_id])

    return not_found unless @submission
  end

  def cashnet_post(values, user)
    klassname = "CashNet::#{client_subdomain.gsub('-', '_').camelize}"
    cashnet = Object.const_get(klassname).new

    cashnet.post(@cn_question, user, values)
  end

  def success
    cashnet_params[:result].to_s == "0"
  end

  def client_subdomain
    @submission.client_account.client_account_info.subdomain
  end

  def confirm_html(success)
    content = success ? <<~EHTML
      <html>
        <head>
          <style>
            h3 {text-align: center;}
            p {text-align: center;}
            div {text-align: center;}
          </style>
        </head>
        <body>
          <br>
          <h3>Transaction Complete</h3>
          <p>Your payment has been processed.</p>
          <p>Return to your application or form and refresh the page to update your transaction information and payment status.</p>
          <div>
            <button type="button" onclick="javascript:window.close()">Close</button>
          </div>
        </body>
      </html>
    EHTML
    : <<~EHTML
      <html>
        <head>
          <style>
            h3 {text-align: center;}
            p {text-align: center;}
            div {text-align: center;}
          </style>
        </head>
        <body>
          <br><br>
          <h3>Credit Card Processing Failure</h3>
          <p>Due to the reason indicated below, there was an issue processing your payment and your fees have not been paid.</p>
          <p><b>Reason: </b>#{decode_cc_error(cashnet_params[:ccerrorcode])}</p>
          <p>If you'd like to attempt again, return to your Via TRM application or form and click Make a Payment to re-start the payment process.</p>
          <p>If you think you've reached this message in error, reach out to your bank or credit card provider for more information.</p><br>
          <div>
            <button type="button" onclick="javascript:window.close()">Close</button>
          </div>
        </body>
      </html>
    EHTML

    content.html_safe
  end

  def create_payment_response_status_change_log(response)
    payor = User.find_by_id(@payor_id)

    response.payment_response_status_change_logs.create(
      notes: "CashNet transaction",
      payment_status_id: response.payment_status_id,
      status: response.payment_status_identifier,
      transaction_id: success ? cashnet_params[:tx].to_s : cashnet_params[:failedtx].to_s,
      transaction_response: cashnet_params[:respmessage].capitalize,
      transaction_success: success,
      user_id: payor&.id,
      user_email: payor&.email,
      user_first_name: payor&.first_name,
      user_last_name: payor&.last_name
    )
  end

  def create_payment_response_status_change_log_payload(payment_log)
    PaymentResponseStatusChangeLogPayload.create(
      payload: params.to_json,
      payment_response_status_change_log: payment_log
    )
  end

  def payment_status(identifier)
    PaymentStatus.find_by_identifier(identifier)
  end

  def redirect_html(fields, target)
    content = <<~EHTML
      <html>
        <head>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        </head>
        <body>
          <p>Please wait. Transfering you to the payment processor....</p>
          <form id="cashnet" name="cashnet" action="#{target}" method="POST">
            #{fields}
          </form>
          <script type="text/javascript">
            $(document).ready(function () {
              setTimeout(function () {
                $("#cashnet").submit();
              }, 0);
            });
          </script>
        </body>
      </html>
    EHTML

    content.html_safe
  end

  def decode_cc_error(code)
    case code
    when 1
      "Invalid customer code or no customer code specified"
    when 4
      "An invalid item code has been supplied"
    when 5
      "Negative amount is not allowed"
    when 6
      "Invalid credit card number or no credit card number provided"
    when 7
      "Invalid expiration date or no expiration date provided"
    when 9
      "Invalid ACH account number or no account number provided"
    when 10
      "Invalid routing/transit number or no routing/transit number provided"
    when 11
      "Invalid account type or no account type provided"
    when 12
      "Invalid check digit for routing/transit number"
    when 13
      "Unable to Process ACH since Account Number or Routing Transit Number is missing."
    when 21
      "Invalid merchant code or no merchant code has been supplied"
    when 22
      "Invalid client code or no client code has been supplied"
    when 25
      "Invalid amount or amount not provided"
    when 230
      "DECLINE. Your credit card has been declined. If you have questions about the decline, please call the number on the back of your credit card"
    when 231
      "REFERRAL. Your credit card has been declined. If you have questions about the decline, please call the number on the back of your credit card"
    when 232
      "AVS FAIL. For security reasons, we cannot accept your credit card"
    when 233
      "CID FAIL. For security reasons, we cannot accept your credit card"
    when 234
      "OTHER ERROR. Your credit card has been declined. If you have questions about the decline, please call the number on the back of your credit card"
    when 235
      "OTHER INTERNAL ERROR. An error occurred while processing your credit card. Your card has not been charged"
    when 701
      "This website has been disabled"
    when 702
      "Improper merchant code. Please contact the system administrator."
    when 703
      "This site is temporarily down for maintenance. We regret the inconvenience. Please try again later."
    when 704
      "Duplicate item violation"
    when 705
      "An invalid reference type has been passed into the system"
    when 706
      "Items violating unique selection have been passed in"
    when 801
      "Invalid Campus Card Number"
    when 802
      "Campus Card has insufficient funds"
    when 803
      "Campus Card processing failure"
    when 901
      "Customer Cancelled before processing payment (from fee notice)"
    when 902
      "Customer Cancelled before processing payment"
    else
      "Undefined Error #{code}"
    end
  end
end
