# frozen_string_literal: true

class Api::SubjectAreasController < ApplicationController
  def index
    render json: (Rails.cache.fetch("subject_areas", expires_in: 12.hours) do
      SubjectAreaSerializer.new(SubjectArea.in_order).serializable_hash
    end), status: :ok
  end
end
