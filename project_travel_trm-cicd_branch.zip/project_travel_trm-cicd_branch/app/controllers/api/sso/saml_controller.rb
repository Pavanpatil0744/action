# frozen_string_literal: true

class Api::Sso::SamlController < ApplicationController
  skip_before_action :verify_authenticity_token, only: :acs

  respond_to :xml, only: :metadata
  respond_to :json, except: :metadata

  def metadata
    if org_name
      render content_type: "application/samlmetadata+xml", xml: metadata_xml
    else
      render body: nil, status: :unprocessable_entity
    end
  end

  def log_in
    session[:source] = params[:source]

    render(json: { url: sign_in_redirect_url })
  rescue Sso::Errors::NoResponse
    render(json: { url: traveler_new_user_session_path })
  end

  def acs
    valid_response = acs_response.valid?

    issuers = begin
                acs_response.issuers
              rescue OneLogin::RubySaml::ValidationError
                []
              end

    saml_response_log = SamlResponseLog.create(
      client_account: client_account,
      issuers: issuers,
      saml_attributes: acs_response.attributes.to_h,
      saml_errors: acs_response.errors,
      saml_response_valid: valid_response
    )

    raise(Sso::Errors::InvalidResponse) unless valid_response

    sign_in(sso_user)
    create_session(sso_user)
    # create_sign_in_log

    user_id = sso_user.id

    ReportTraveler.find_by_user_id(user_id)&.update(sync_required: true)
    UpdateReportTraveler.perform_in(10.seconds, user_id)

    sso_user.application_submissions.each do |application|
      application_id = application.id
      corresponding_forms = application.corresponding_forms

      ReportFormGrouping.find_by_submission_id(application_id)&.update(sync_required: true)
      ReportSubmission.find_by_submission_id(application_id)&.update(sync_required: true)
      UpdateReportFormGrouping.perform_in(10.seconds, application_id)
      UpdateReportSubmission.perform_in(10.seconds, application_id)

      next unless corresponding_forms

      corresponding_forms.each do |form|
        ReportSubmission.find_by(submission_id: form.id)&.update(sync_required: true)
        UpdateReportSubmission.perform_in(10.seconds, form.id)
      end
    end

    sso_authentication = SsoAuthentication.find_by(
      user_id: user_id,
      client_account_id: client_account.id
    )

    IntegrationAtLoginWorker.perform_async(sso_authentication.id) if sso_authentication

    saml_response_log.update(login_successful: true)

    # token = AuthenticationToken::TokenService.new(sso_user).create_token

    render(
      json: {
        # expires_at: token.expires_at,
        url: after_sign_in_path_for(sso_user),
        user: sso_user,
        # authentication_token: token.token
      },
      status: :created
    )
  rescue *exceptions => e
    message = e.message

    saml_response_log.update(login_errors: [message], login_successful: false)

    render(
      json: { error_code: e.error_code, message: message, url: traveler_new_user_session_path },
      status: :unprocessable_entity
    )
  end

  private

  def acs_response
    @acs_response ||= Sso::Acs.new(params[:SAMLResponse], settings_with_idp, org_name).response
  end

  def client_account
    @client_account ||= ClientAccountInfo.find_by_subdomain(org_name).client_account
  end

  def create_session(user)
    Sso::Session.new(session, user, acs_response).execute
  end

  def exceptions
    [
      Sso::Errors::ExistingEmail,
      Sso::Errors::InvalidResponse,
      Sso::Errors::MissingAttribute,
      Sso::Errors::MissingSsoConfiguration,
      Sso::Errors::NoResponse
    ]
  end

  def metadata_xml
    settings = Sso::BuildSettings.new(setting_options, Rails.cache).execute

    Sso::Metadata.new(settings, org_name).execute
  end

  def org_name
    @org_name ||= params[:org]
  end

  def secrets
    @secrets ||= Rails.application.secrets
  end

  def setting_options
    {
      assertion_consumer_service_url: sso_acs_url(subdomain: org_name),
      issuer: sso_metadata_url,
      secrets: secrets,
      single_logout_service_url: sso_log_out_url(subdomain: org_name),
      subdomain: org_name
    }
  end

  def settings_with_idp
    Sso::BuildSettings.with_idp(setting_options, Rails.cache)
  end

  def sign_in_redirect_url
    Sso::SignIn.new(settings_with_idp).redirect_url
  end

  def sso_user
    @sso_user ||= Sso::User.new(acs_response).execute
  end

  def create_sign_in_log
    SignInLog.create(
      client_account_id: client_account&.id,
      sign_in_type: "sso",
      user_id: sso_user.id
    )
  end
end
