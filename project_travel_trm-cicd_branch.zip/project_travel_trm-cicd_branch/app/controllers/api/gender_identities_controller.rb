# frozen_string_literal: true

class Api::GenderIdentitiesController < ApplicationController
  def index
    render json: GenderIdentitySerializer.new(GenderIdentity.in_order).serialized_json, status: :ok
  end
end
