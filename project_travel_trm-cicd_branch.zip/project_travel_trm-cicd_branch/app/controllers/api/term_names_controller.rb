# frozen_string_literal: true

class Api::TermNamesController < Api::BaseController
  skip_before_action :authenticate_user!, only: :index
  before_action :find_term_name, only: %i[update destroy]

  def index
    # For visitors accept client_account_id in params
    client = params[:client_account_id].present? ? ClientAccount.find(params[:client_account_id]) : client_account

    term_names = client.term_names.in_order
    term_names = term_names.active if ["true", true].include?(params[:active])

    if (!user_signed_in? || !admin_user?) && !client.client_account_info&.enable_active_term_name_filtering
      term_names = term_names.joins("left join program_ranges on program_ranges.term_name_id = term_names.id")
                             .where(
                               "program_ranges.start_date >= ? OR
                               (program_ranges.start_date <= ? AND
                               program_ranges.end_date >= ? )",
                               Date.current,
                               Date.current,
                               Date.current
                             ).distinct
    end

    render json: TermNameSerializer.new(term_names), status: :ok
  end

  def create
    term_name = client_account.term_names.new(term_name_params)

    return bad_request(term_name) unless term_name.save

    render json: TermNameSerializer.new(term_name), status: :created
  end

  def update
    return bad_request(@term_name) unless @term_name.update(term_name_params)

    program_ids = @term_name.program_ids |
                  @term_name.authorized_program_ranges.flat_map(&:program_ids)
    program_range_ids = @term_name.program_range_ids |
                        @term_name.authorized_program_ranges.flat_map(&:program_range_ids)

    ReportProgram.where(client_account_id: client_account_id, program_id: program_ids)
                 .update_all(sync_required: true)
    ReportProgramRange.where(
      client_account_id: client_account_id,
      program_range_id: program_range_ids
    ).update_all(sync_required: true)

    UpdateClientSpecificReportProgramAssociations.perform_async(
      client_account_id,
      program_ids,
      program_range_ids
    )

    render json: TermNameSerializer.new(@term_name), status: :ok
  end

  def destroy
    @term_name.destroy

    render json: {}, status: :no_content
  end

  private

  def term_name_params
    params.require(:term_name).permit(:archived, :name)
  end

  def find_term_name
    @term_name = client_account.term_names.find_by(id: params[:id])

    return not_found unless @term_name
  end
end
