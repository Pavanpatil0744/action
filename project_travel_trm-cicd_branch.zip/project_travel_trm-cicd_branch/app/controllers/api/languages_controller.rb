# frozen_string_literal: true

class Api::LanguagesController < ApplicationController
  def index
    render json: (Rails.cache.fetch("languages", expires_in: 12.hours) do
      LanguageSerializer.new(Language.in_order).serializable_hash
    end), status: :ok
  end
end
