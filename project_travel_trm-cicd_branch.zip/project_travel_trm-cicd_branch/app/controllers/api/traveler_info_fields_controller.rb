# frozen_string_literal: true

class Api::TravelerInfoFieldsController < Api::BaseController
  def index
    response = TravelerInfoFieldCategorySerializer.new(traveler_info_field_categories).to_hash

    render(json: response.merge!(custom_fields: custom_fields), status: :ok)
  end

  private

  def custom_fields
    short_text_question = QuestionType.find_by_identifier("short_text")

    client_account.custom_fields.traveler_viewable.in_order.map do |custom_field|
      {
        id: custom_field.id,
        question_type_id: short_text_question.id,
        question_type_identifier: short_text_question.identifier,
        title: custom_field.title
      }
    end
  end

  def traveler_info_field_categories
    TravelerInfoFieldCategory.in_order
  end
end
