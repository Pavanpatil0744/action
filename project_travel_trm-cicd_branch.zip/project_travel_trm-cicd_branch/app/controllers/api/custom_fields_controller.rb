# frozen_string_literal: true

class Api::CustomFieldsController < Api::BaseController
  before_action :authorize_admin
  before_action :find_custom_field, only: :update
  before_action :validate_actions, only: :update
  before_action :validate_title, only: %i[create update]

  def index
    if active_custom_fields_present?
      custom_fields = client_account.custom_fields.active.pluck(:title)
      synced_fields_v1 = client_account.traveler_infos.pluck("DISTINCT JSON_OBJECT_KEYS(traveler_infos.custom_fields)")
      synced_fields_v2 = client_account.custom_integration_fields.active.pluck(:title)
      active_custom_fields = (custom_fields + synced_fields_v1 + synced_fields_v2).uniq.sort

      render(json: { active_custom_fields: active_custom_fields })
    else
      custom_fields = client_account.custom_fields
      synced_fields = client_account.custom_integration_fields
      combined_fields = (custom_fields + synced_fields).sort_by(&:title)

      render(json: CustomFieldSerializer.new(combined_fields), status: :ok)
    end
  end

  def create
    custom_field = client_account.custom_fields.new(custom_field_params)

    return bad_request(custom_field) unless custom_field.save

    update_report_records

    render json: CustomFieldSerializer.new(custom_field), status: :created
  end

  def update
    if @custom_field
      @custom_field.update(custom_field_params)

      update_report_records

      render json: CustomFieldSerializer.new(@custom_field), status: :ok
    else
      @synced_field.update(custom_field_params)

      render json: CustomFieldSerializer.new(@synced_field), status: :ok
    end
  end

  private

  def active_custom_fields
    @active_custom_fields ||= params[:active_custom_fields]
  end

  def active_custom_fields_present?
    active_custom_fields.present?
  end

  def custom_field_params
    params.require(:custom_field).permit(:archived, :private, :title)
  end

  def find_custom_field
    @custom_field = client_account.custom_fields.find_by(id: params[:id])
    @synced_field = client_account.custom_integration_fields.find_by(id: params[:id])

    return not_found unless @custom_field || @synced_field
  end

  def validate_actions
    return unless @synced_field

    errors = []
    errors << "Archive is not permitted" if custom_field_params[:archived]
    errors << "Edit is not permitted" if custom_field_params[:title] != @synced_field.name

    render json: { errors: errors }, status: 400 if errors.any?
  end

  def validate_title
    render json: { errors: ["Title is required"] }, status: 400 if custom_field_params[:title].blank?
  end

  def update_report_records
    ReportTraveler.where(client_account_id: client_account.id).update_all(sync_required: true)
    ReportPlanUser.where(client_account_id: client_account.id).update_all(sync_required: true)
    UpdateCustomFieldsOfTravelersWorker.perform_in(10.seconds, client_account.id)
  end
end
