# frozen_string_literal: true

class Api::StarRatingQuestionsController < Api::BaseController
  before_action :authorize_admin
  before_action :find_template, only: %i[create update destroy]
  before_action :find_question, only: %i[update destroy]
  before_action :validate_option_count, only: %i[create update]

  def create
    authorize!(:update, @template)

    srq = @template.star_rating_questions.new(srq_params)

    return bad_request(srq) unless srq.save

    AddQuestionToTemplateLayout.call(question: srq.question, template: @template)

    update_report_submission_associations(@template)

    render(
      json: StarRatingQuestionSerializer.new(srq, params: { action: params[:action] }),
      status: :created
    )
  end

  def update
    authorize!(:update, @template)

    return bad_request(@question) unless @question.update(srq_params)

    update_report_submission_associations(@template)

    render json: StarRatingQuestionSerializer.new(@question), status: :ok
  end

  def destroy
    authorize!(:update, @template)

    question_id = @question.question_id
    template_layout = @template.template_layout

    if @question.destroy
      RemoveQuestionFromTemplateLayout.call(
        question_id: question_id,
        template_layout: template_layout
      )

      update_report_submission_associations(@template)

      render json: { template_layout: template_layout }, status: :ok
    else
      render json: { errors: @question.errors }, status: :bad_request
    end
  end

  private

  def srq_params
    params.require(:question).permit(
      :admin_only,
      :instructions,
      :label,
      :required,
      star_rating_question_options_attributes: %i[id _destroy name order]
    )
  end

  def find_template
    @template = client_account.templates.find_by_id(params[:form_template_id])

    return not_found unless @template
  end

  def find_question
    @question = @template.star_rating_questions.find_by_id(params[:id])

    return not_found unless @question
  end

  def current_ability
    @current_ability ||= TemplateAbility.new(current_user, params)
  end

  def update_report_submission_associations(template)
    template.submissions&.each do |submission|
      submission_id = submission.id

      ReportSubmission.find_by_submission_id(submission_id)&.update(sync_required: true)
      UpdateReportSubmission.perform_in(10.seconds, submission_id)
    end
  end

  def validate_option_count
    options = srq_params[:star_rating_question_options_attributes]
    option_count = options.reject { |option| option[:_destroy] }.size

    render json: {
      errors: ["Star rating question must include between 3 and 5 options"]
    }, status: :bad_request unless (3..5).include?(option_count)
  end
end
