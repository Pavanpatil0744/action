# frozen_string_literal: true

class Api::FileUploadResponsesController < Api::BaseController
  before_action :authorize_actions, if: :admin_role?
  before_action :validate_params, only: %i[add_files remove_files]
  before_action :validate_assignment, only: %i[add_files remove_files], if: :occasional_user?
  before_action :find_question, only: %i[add_files remove_files]
  before_action :find_submission, only: %i[add_files remove_files]
  before_action :find_response, only: :remove_files
  before_action :find_template, only: %i[add_files remove_files]
  before_action :validate_client_account, only: %i[add_files remove_files]
  before_action :validate_user_submission, only: %i[add_files remove_files], if: :traveler_user?
  before_action :validate_template_association, only: %i[add_files remove_files]

  def add_files
    authorize!(:update, @submission) if admin_user?

    responses = @submission.file_upload_responses
    response = responses.find_or_initialize_by(question_id: @question.id)

    uploaded_files_attributes.each do |file|
      response.uploaded_files.new(
        filename: file[:filename],
        s3_store: file[:s3_store]
      )
    end

    return bad_request(response) unless response.save

    update_report_submission_associations(@submission)

    render json: FileUploadResponseSerializer.new(response), status: :ok
  end

  def remove_files
    authorize!(:update, @submission) if admin_user?

    return bad_request(@response) unless @response.update(file_params)

    update_report_submission_associations(@submission)

    if @response.uploaded_files.empty?
      @response.destroy

      render json: {}, status: :ok
    else
      render json: FileUploadResponseSerializer.new(@response), status: :ok
    end
  end

  private

  def file_params
    params.require(:response).permit(
      :question_id,
      :submission_id,
      uploaded_files_attributes: %i[id _destroy filename s3_store]
    )
  end

  def authorize_actions
    authorize_admin unless current_user.submissions.find_by_id(submission_id)
  end

  def find_question
    @question = Question.find_by_id(question_id)
    question_type = @question&.detailable_type

    return not_found unless @question && question_type == "FileUploadQuestion"
  end

  def find_response
    @response = FileUploadResponse.find_by(
      question_id: @question.id,
      submission_id: @submission.id
    )

    return not_found unless @response
  end

  def find_submission
    @submission = client_account.submissions.find_by_id(submission_id)

    return not_found unless @submission
  end

  def find_template
    @template = @question.template

    return not_found unless @template
  end

  def question_id
    file_params[:question_id]
  end

  def submission_id
    file_params[:submission_id]
  end

  def uploaded_files_attributes
    file_params[:uploaded_files_attributes]
  end

  def validate_params
    errors = []

    errors << "Question ID required" unless question_id
    errors << "Submission ID required" unless submission_id
    errors << "At least 1 uploaded file required" unless uploaded_files_attributes&.any?

    render json: { errors: errors }, status: 400 if errors.any?
  end

  def validate_assignment
    assigned_travelers = current_user.assigned_travelers
    submission = Submission.find(submission_id)

    assigned = assigned_travelers.find_by_id(submission[:user_id])

    render json: { message: "Unauthorized" }, status: :unauthorized unless assigned
  end

  def validate_client_account
    validated = if admin_user?
                  client_account_id == @submission.client_account_id
                else
                  client_account_id == @template.client_account_id
                end

    render json: { message: "Unauthorized" }, status: :unauthorized unless validated
  end

  def validate_template_association
    return not_found unless @question.template_id == @submission.template_id
  end

  def validate_user_submission
    return not_found unless current_user_id == @submission.user_id
  end

  def current_ability
    @current_ability ||= SubmissionAbility.new(current_user)
  end

  def update_report_submission_associations(submission)
    submission_id = submission.id

    ReportSubmission.find_by_submission_id(submission_id)&.update(sync_required: true)
    UpdateReportSubmission.perform_in(10.seconds, submission_id)
  end
end
