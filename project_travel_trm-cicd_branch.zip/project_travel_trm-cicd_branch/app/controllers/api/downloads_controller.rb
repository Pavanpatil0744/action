class Api::DownloadsController < ApplicationController
  respond_to :json

  PATH_PREFIX = "/uploads/"

  def download
    furi = URI.parse(params["f"])
    f = furi.path.gsub(/^#{PATH_PREFIX}/, "")

    if f
      uploader = Uploader.new
      uploader.retrieve_from_store!(f)

      authorize!(:download, uploader)

      redirect_to(uploader.url)
    else
      not_found
    end
  end
end
