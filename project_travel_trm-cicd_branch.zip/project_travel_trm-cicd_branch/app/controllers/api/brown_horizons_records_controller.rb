# frozen_string_literal: true

class Api::BrownHorizonsRecordsController < Api::BaseController
  def index
    render json: BrownHorizonsRecordSerializer.new(brown_horizons_records), status: :ok
  end

  private

  def brown_horizons_records
    brown = ClientAccountInfo.find_by(subdomain: "brown").client_account

    client_account == brown && admin_user? ? BrownHorizonsRecord.all : []
  end
end
