# frozen_string_literal: true

class Api::SubmissionBatchActionsController < Api::BaseController
  include AgeCalculator

  before_action :authorize_admin
  before_action :validate_type, only: :update_statuses
  before_action :validate_status, only: :update_statuses

  def add_forms
    applications_with_forms_added = []
    form_counts_by_application = {}
    form_templates = client_account.templates.where(id: params[:template_ids])

    submissions.each do |submission|
      application_id = submission.id
      forms_added = false
      not_started_status = SubmissionStatus.find_by_identifier("not_started")
      program_range = submission.program_range
      user = submission.user

      form_templates.each do |form_template|
        form = user.submissions.find_or_initialize_by(
          client_account: client_account,
          program_range: program_range,
          template: form_template
        )

        next unless form.new_record?

        form.manually_added = true
        form.submission_status = not_started_status
        form.submission_type = SubmissionType.find_by_identifier("form")
        form.deadline = params[:deadline]

        authorize!(:create, form) if admin_user?

        form.save

        applications_with_forms_added |= [application_id]

        if form_counts_by_application[application_id].nil?
          form_counts_by_application[application_id] = 1
        else
          form_counts_by_application[application_id] += 1
        end

        forms_added = true

        UpdateReportSubmission.perform_in(10.seconds, form.id)
      end

      next unless forms_added

      SendGrid::V2::Mailers::NewFormNotification.perform_async(client_account_logo, user.id) unless client_account.automations_enabled?
      UpdateReportFormGrouping.perform_in(10.seconds, application_id)
    end

    render json: {
      message: "Forms added",
      success_count: applications_with_forms_added.count,
      form_counts: form_counts_by_application
    }, status: :created
  end

  def send_messages
    attachment_count = params[:message][:attachment_count].to_i
    attachments = []
    message = current_user.messages.new(message_params)

    attachment_count.times do |index|
      attachments << params[:message]["attachment#{index + 1}"]
    end

    message.assign_attributes(attachments: attachments)

    return bad_request(message) unless message.save

    travelers = client_account.travelers.where(id: submissions.pluck(:user_id)).with_role(:traveler)

    travelers.each do |traveler|
      SendMessage.call(admin: current_user, message: message, traveler: traveler)
    end

    SendGrid::SendMessageFromAdminMailers.call(
      admin: current_user,
      message: message,
      traveler_ids: travelers.ids
    )

    render json: MessageSerializer.new(message).serialized_json, status: :created
  end

  def update_statuses
    failures = []
    updated_submissions = []

    submissions.each do |submission|
      if submission.submission_status_id != params[:submission_status_id].to_i &&
         submission.user_id != current_user_id &&
         valid_status?(submission)

        authorize!(:update, submission) if admin_user?

        submission.update(submission_status: @new_status)
        log_submission_status_change(submission)

        traveler = submission.user

        case type
        when "application"
          SendGrid::V2::SendApplicationStatusChangeMailers.call(
            application: submission,
            client_account: client_account,
            drt_elaps_trigger: false
          )

          if @new_status.identifier == "committed"
            plans = client_account.plans.where(program_range_id: submission.program_range_id)

            plans.each { |plan| InviteExistingTraveler.call(plan: plan, traveler: traveler) }
          elsif %w[withdrawn deferred].include? @new_status.identifier
            submission.program_range.plans.each do |l|
              plan_user = l.plans_users.find_by_user_id(submission.user_id)

              if plan_user.present?
                plan_user.update_attribute(:removed, true)
                ReportPlanUser.find_by_plans_users_id(plan_user.id)&.update(sync_required: true)
                UpdateReportPlanUser.perform_in(10.seconds, plan_user.id)
              end

              Plan.update_traveler_count(l)
            end
          elsif @new_status.identifier == "submitted" && submission.user.traveler_info.dob.present? && calculate_age(submission.user.traveler_info.dob.to_date) < 18
            SendGrid::SendMinorApplicationSubmissionToAdminMailer.perform_async(
              submission.id
            )
          end
        when "form"
          SendGrid::V2::SendFormStatusChangeMailers.call(
            client_account: client_account,
            form: submission
          )
        end

        update_report_submission_associations(submission)
        update_report_traveler_associations(traveler.id)

        updated_submissions << submission
      else
        failures << submission
      end
    end

    render json: { updated_submission_ids: updated_submissions.map(&:id), failures: failures.map(&:id) }, status: :ok
  end

  def add_tags
    updated_submission_ids = []
    tag_ids = Tag.where(id: params[:tag_ids], tag_type: params[:type]).pluck(:id)

    submissions.send(params[:type].downcase).each do |submission|
      tag_ids.each do |tag_id|
        submission.taggables.find_or_create_by(tag_id: tag_id)
      end

      update_report_submission_associations(submission, false)
      updated_submission_ids << submission.id
    end

    render json: { updated_submissions: updated_submission_ids }, status: :ok
  end

  def remove_tags
    updated_submission_ids = []

    submissions.send(params[:type].downcase).each do |submission|
      submission.taggables.where(tag_id: params[:tag_ids]).destroy_all

      update_report_submission_associations(submission, false)
      updated_submission_ids << submission.id
    end

    render json: { updated_submissions: updated_submission_ids }, status: :ok
  end

  def manual_data_sync
    render json: { message: "No submission_ids found." } unless manual_data_sync_params[:submission_ids]

    ManualDataSync.perform_async(
      manual_data_sync_params[:submission_ids],
      current_user.id,
      manual_data_sync_params[:application_type]
    )

    render json: { message: "Sync is in progress" }
  end

  private

  def message_params
    params.require(:message).permit(:body, :subject)
  end

  def manual_data_sync_params
    params.require(:manual_data_sync).permit(:application_type, submission_ids: [])
  end

  def current_ability
    @current_ability ||= SubmissionAbility.new(current_user)
  end

  def log_submission_status_change(submission)
    log = submission.submission_status_change_logs.create(
      status: submission.status,
      user_id: current_user.id,
      user_email: current_user.email,
      user_first_name: current_user.first_name || "",
      user_last_name: current_user.last_name || ""
    )

    log.add_reasons(params[:reasons] || [])
  end

  def submissions
    if occasional_user?
      current_user.assigned_submissions
    else
      client_account.submissions
    end.where(id: params[:submission_ids])
  end

  def type
    @type ||= params[:type]
  end

  def update_report_submission_associations(submission, update_corresponding_submissions = true)
    submissions_to_update = []
    submissions_to_update << submission

    # In case of adding/removing tags no need to update corresponding submisisons
    submissions_to_update |= submission.corresponding_submissions if update_corresponding_submissions

    submissions_to_update.each do |sub|
      sub_id = sub.id

      if sub.application?
        report_form_grouping = ReportFormGrouping.find_by_submission_id(sub_id)

        if sub.corresponding_forms.any?
          report_form_grouping&.update(sync_required: true)

          UpdateReportFormGrouping.perform_in(10.seconds, sub_id)
        else
          report_form_grouping&.destroy
        end
      end

      ReportSubmission.find_by_submission_id(sub_id)&.update(sync_required: true)
      UpdateReportSubmission.perform_in(10.seconds, sub_id)
    end
  end

  def update_report_traveler_associations(traveler_id)
    ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
    UpdateReportTraveler.perform_in(10.seconds, traveler_id)
  end

  def valid_status?(submission)
    valid_statuses(submission.type).include?(@new_status.identifier)
  end

  def valid_statuses(submission_type)
    if submission_type == "application"
      %w[
        accepted approved committed conditionally_accepted
        conditionally_approved deferred in_review incomplete nominated
        not_accepted submitted transferred waitlisted withdrawn
      ]
    else
      %w[accepted not_started started submitted]
    end
  end

  def validate_status
    @new_status = SubmissionStatus.find_by_id(params[:submission_status_id])

    return if valid_statuses(type).include?(@new_status.identifier)

    render(json: { message: "Submission status is invalid for the specfied type" }, status: :bad_request)
  end

  def validate_type
    return if type && %w[application form].include?(type)

    render(json: { message: "Valid type parameter is required" }, status: :bad_request)
  end
end
