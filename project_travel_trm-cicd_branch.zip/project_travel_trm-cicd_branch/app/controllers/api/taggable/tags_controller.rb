# frozen_string_literal: true

module Api
  module Taggable
    # Tag CRUD
    class TagsController < Api::BaseController
      def create
        tag = Tag.new(tag_params)
        if tag.save
          render(
            json: ::Tags::TagSerializer.new(tag).serialized_json,
            status: :ok
          )
        else
          render json: {
            error: tag.errors
          }, status: :unprocessable_entity
        end
      end

      def attach_tags
        tagged = submission.taggables.create(tag_id: params[:attach_tags][:tag_id])

        if tagged.save
          render(
            json: { message: "Tag is attached" },
            status: :ok
          )

          update_report_submission(submission.id)
        else
          render json: {
            error: tagged.errors
          }, status: :unprocessable_entity
        end
      end

      def remove_tags
        tagged = ::Taggable.find(params[:id])
        if tagged.update(deleted_at: DateTime.now)
          render(
            json: { message: "Tag is removed" },
            status: :ok
          )

          update_report_submission(submission.id)
        else
          render json: {
            error: tagged.errors
          }, status: :unprocessable_entity
        end
      end

      def update
        tag = Tag.find(params[:id])
        if tag.update(update_params)
          tag.submissions.each do |l|
            update_report_submission(l.id)
          end
          render(
            json: ::Tags::TagSerializer.new(tag).serialized_json,
            status: :ok
          )
        else
          render json: {
            error: tag.errors
          }, status: :unprocessable_entity
        end
      end

      def destroy
        tag = Tag.find(params[:id])
        if tag.update_attribute(:archive, true)
          tag.submissions.each do |l|
            update_report_submission(l.id)
          end
          render(
            json: { message: "Tag is archived" },
            status: :ok
          )
        else
          render(
            json: { message: "Something went wrong" },
            status: :unprocessable_entity
          )
        end
      end

      def index
        tags = natural_sort(client_account.tags.submission_tags(params[:tag_type]).not_archived)

        render(
          json: ::Tags::TagSerializer.new(tags),
          status: :ok
        )
      end

      private

      def tag_params
        params.require(:tags).permit(
          :name,
          :description,
          :emoji,
          :tag_color_id,
          :tag_type
        ).merge!(client_account_id: client_account.id)
      end

      def update_params
        params.require(:tags).permit(
          :name,
          :description,
          :emoji,
          :tag_color_id
        )
      end

      def natural_sort(tags)
        tags.sort_by { |e| e.name.split(/(\d+)/).map { |a| a =~ /\d+/ ? a.to_i : a } }
      end

      def submission
        @submission ||= Submission.find(params[:taggable_id] || params[:attach_tags][:taggable_id])
      end

      def update_report_submission(sub_id)
        selected_submission = Submission.find sub_id
        report_form_grouping = ReportFormGrouping.find_by_submission_id(sub_id)

        if selected_submission.corresponding_forms.any?
          report_form_grouping&.update(sync_required: true)

          UpdateReportFormGrouping.perform_in(10.seconds, sub_id)
        else
          report_form_grouping&.destroy
        end

        ReportSubmission.find_by_submission_id(sub_id)&.update(sync_required: true)
        UpdateReportSubmission.perform_in(10.seconds, sub_id)
      end
    end
  end
end