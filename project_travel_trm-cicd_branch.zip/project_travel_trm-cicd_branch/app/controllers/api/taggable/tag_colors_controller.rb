# frozen_string_literal: true

module Api
  module Taggable
    # TagColors CRUD
    class TagColorsController < Api::BaseController
      def index
        @tag_colors = TagColor.in_order

        render json: ::Tags::TagColorSerializer.new(@tag_colors), status: :ok
      end
    end
  end
end