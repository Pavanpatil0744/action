# frozen_string_literal: true

class Api::QuestionTypesController < Api::BaseController
  def index
    render json: QuestionCategorySerializer.new(question_categories), status: :ok
  end

  private

  def question_categories
    QuestionCategory.in_order
  end
end
