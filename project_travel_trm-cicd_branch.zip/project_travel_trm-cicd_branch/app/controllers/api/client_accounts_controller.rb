# frozen_string_literal: true

class Api::ClientAccountsController < Api::BaseController
  def index
    render json: ClientAccountSerializer.new(client_accounts).serialized_json, status: :ok
  end

  private

  def client_accounts
    (params[:provider] ? ClientAccount.with_authorizable_programs : ClientAccount.active).in_order
  end
end
