# frozen_string_literal: true

module Api
  module TermPolicy
    # TermPolicy api
    class TermPoliciesController < Api::TermPolicy::BaseController
      def index
        render(
          json: ::TermPolicy::TermPolicySerializer.new(
            TermsAndPolicyAgreement.order(created_at: :desc).limit(1)
          ).serialized_json,
          status: :ok
        )
      end
    end
  end
end
