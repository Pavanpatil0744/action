# frozen_string_literal: true

class Api::TermPolicy::BaseController < Api::BaseController; end
