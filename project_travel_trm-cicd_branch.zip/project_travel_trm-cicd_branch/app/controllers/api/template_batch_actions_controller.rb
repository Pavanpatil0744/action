# frozen_string_literal: true

class Api::TemplateBatchActionsController < Api::BaseController
  def update
    failures = []
    updated_templates = []

    templates.each do |template|
      if template_status != "draft" && template.status != template_status && template.update(template_params)
        updated_templates << template
      else
        failures << template.name
      end
    end

    render json: build_response(updated_templates, failures), status: :ok
  end

  private

  def template_params
    params.require(:template).permit(:status)
  end

  def template_status
    template_params[:status]
  end

  def templates
    client_account.templates.where(id: params[:template_ids], default: false)
  end

  def build_response(updated_templates, failures)
    FormTemplateSerializer.new(
      updated_templates
    ).to_hash.merge!(
      {
        failures: failures,
        message: "#{updated_templates.count} Form States Updated"
      }
    )
  end
end
