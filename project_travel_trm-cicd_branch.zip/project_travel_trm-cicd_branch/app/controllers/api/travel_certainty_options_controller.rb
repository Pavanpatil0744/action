# frozen_string_literal: true

class Api::TravelCertaintyOptionsController < Api::BaseController
  def index
    render json: TravelerInfo::TRAVELER_CERTAINTY_OPTIONS, status: :ok
  end
end
