# frozen_string_literal: true

class Api::AutomationConditionsController < Api::BaseController
  before_action :validate_admin_user, only: :index
  before_action :validate_presence_of_precondition, only: :index
  before_action :find_automation_precondition, only: :index

  def index
    render(
      json: AutomationConditionSerializer.new(automation_conditions).serialized_json,
      status: :ok
    )
  end

  private

  def automation_conditions
    @automation_precondition.automation_conditions.in_order
  end

  def find_automation_precondition
    @automation_precondition = AutomationPrecondition.find_by_identifier(params[:precondition])

    return not_found unless @automation_precondition
  end

  def validate_admin_user
    return forbidden unless admin_user?
  end

  def validate_presence_of_precondition
    return if params[:precondition].present?

    render(json: { message: "Please provide a precondition" }, status: :unprocessable_entity)
  end
end
