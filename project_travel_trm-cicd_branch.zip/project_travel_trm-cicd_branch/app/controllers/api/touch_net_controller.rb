# frozen_string_literal: true

class Api::TouchNetController < Api::BaseController
  skip_before_action :authenticate_user!

  before_action :find_or_create_payment_response, only: :postback
  before_action :find_submission, only: :create
  before_action :find_question, only: :create

  def create
    cost = @tn_question.cost.zero? ? "0.01" : format("%5.2f", @tn_question.cost).strip
    ticket_id = SecureRandom.uuid
    traveler = @submission.user

    require "touchnet/#{client_subdomain}" rescue require "touchnet"

    ticket_params = {
      detail_code: @tn_question.detail_code,
      payment_amount: cost,
      program_title: @submission.program.title,
      return_link: return_link,
      ticket_id: ticket_id,
      tracking_id: "#{@tn_question.id}|#{@submission.id}|#{params[:user_id]}",
      traveler_email: traveler.email,
      traveler_name: traveler.profile_full_name
    }

    response = request_ticket(client_account_info, ticket_params).body
    ticket_response = response[:generate_secure_link_ticket_response][:ticket]

    form_input = touchnet_post(ticket_response, ticket_id)
    field_values = form_input[:variables]
    target = form_input[:target]

    render html: redirect_html(field_values, target), status: :moved_permanently
  end

  def postback
    submission = @payment_response.submission
    client = submission.client_account.client_account_info
    session_id = touchnet_params[:session_identifier]

    authorization = authorize_payment(client, session_id).to_hash
    authorized = authorization.include?(:authorize_account_response)

    @payment_response.api_transaction = true
    @payment_response.attributes = { payment_status: payment_status("paid") } if authorized
    @payment_response.save

    transaction_log = create_payment_response_status_change_log(authorization)

    PaymentResponseStatusChangeLogPayload.create(
      payload: authorization.to_json,
      payment_response_status_change_log: transaction_log
    )

    render html: confirm_html(authorization), status: :created
  end

  private

  def touchnet_params
    params.permit(:EXT_TRANS_ID, :session_identifier, :sys_tracking_id)
  end

  def find_or_create_payment_response
    transaction_id = touchnet_params[:EXT_TRANS_ID]
    tn_question_id, submission_id, @payor_id = transaction_id.split("|", 3)

    @payment_response = PaymentResponse.find_by(
      question: TouchNetQuestion.find_by_id(tn_question_id).question,
      submission_id: submission_id
    )

    return if @payment_response

    @payment_response = PaymentResponse.new(
      payment_status: payment_status("not_paid"),
      question: TouchNetQuestion.find_by_id(tn_question_id).question,
      submission_id: submission_id
    )
  end

  def find_question
    template = @submission.template
    @tn_question = template.touch_net_questions.find_by_id(params[:question_id])

    return not_found unless @tn_question
  end

  def find_submission
    @submission = Submission.find_by_id(params[:submission_id])

    return not_found unless @submission
  end

  def authorize_payment(client, session_id)
    touchnet_connect(client).call(:authorize_account, message: { session: session_id })
  rescue Savon::SOAPFault => e
    e.to_hash[:fault][:detail]
  end

  def client_account_info
    @submission.client_account.client_account_info
  end

  def client_subdomain
    client_account_info.subdomain
  end

  def confirm_html(authorization)
    content = authorization[:authorize_account_response] ? <<~EHTML
      <html>
        <head>
          <style>
            h3 {text-align: center;}
            p {text-align: center;}
            div {text-align: center;}
          </style>
        </head>
        <body>
          <br>
          <h3>Transaction Complete</h3>
          <p>Your payment has been processed.</p>
          <p>Return to your application or form and refresh the page to update your transaction information and payment status.</p>
          <div>
            <button type="button" onclick="javascript:window.close()">Close</button>
          </div>
        </body>
      </html>
    EHTML
    : <<~EHTML
      <html>
        <head>
          <style>
            h3 {text-align: center;}
            p {text-align: center;}
            div {text-align: center;}
          </style>
        </head>
        <body>
          <br><br>
          <h3>Credit Card Processing Failure</h3>
          <p>Due to the reason indicated below, there was an issue processing your payment and your fees have not been paid.</p>
          <p><b>Reason: </b>#{authorization[:fault][:description]}</p>
          <p>If you'd like to attempt again, return to your Via TRM application or form and click Make a Payment to re-start the payment process.</p>
          <p>If you think you've reached this message in error, reach out to your bank or credit card provider for more information.</p><br>
          <div>
            <button type="button" onclick="javascript:window.close()">Close</button>
          </div>
        </body>
      </html>
    EHTML

    content.html_safe
  end

  def create_payment_response_status_change_log(authorization)
    authorized = authorization.include?(:authorize_account_response)
    payor = User.find_by_id(@payor_id)

    @payment_response.payment_response_status_change_logs.create(
      notes: "TouchNet transaction",
      payment_status_id: @payment_response.payment_status_id,
      status: @payment_response.payment_status_identifier,
      transaction_id: touchnet_params[:sys_tracking_id].to_s,
      transaction_response: authorized ? "Successful" : authorization[:fault][:description],
      transaction_success: authorized,
      user_id: payor&.id,
      user_email: payor&.email,
      user_first_name: payor&.first_name,
      user_last_name: payor&.last_name
    )
  end

  def payment_status(identifier)
    PaymentStatus.find_by_identifier(identifier)
  end

  def redirect_html(fields, target)
    content = <<~EHTML
      <html>
        <head>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js">
          </script>
        </head>
        <body>
          <p>Please wait. Transfering you to the payment processor...</p>
          <form id="touchnet" name="touchnet" action="#{target}" method="POST">
            #{fields}
          </form>
          <script type="text/javascript">
            $(document).ready(function () {
              setTimeout(function () {
                $("#touchnet").submit();
              }, 0);
            });
          </script>
        </body>
      </html>
    EHTML

    content.html_safe
  end

  def request_ticket(client, ticket_params)
    touchnet_connect(client).call(
      :generate_secure_link_ticket,
      message: {
        ticketName: ticket_params[:ticket_id],
        nameValuePairs: [
          { name: "AMT", value: ticket_params[:payment_amount] },
          { name: "EXT_TRANS_ID", value: ticket_params[:tracking_id] },
          { name: "SUCCESS_LINK", value: ticket_params[:return_link] },
          { name: "PROGRAM_NAME", value: ticket_params[:program_title] },
          { name: "CREDIT_ACCT_CODE", value: ticket_params[:detail_code] },
          { name: "STUDENT_EMAIL", value: ticket_params[:traveler_email] },
          { name: "STUDENT_NAME", value: ticket_params[:traveler_name] }
        ]
      }
    )
  end

  def return_link
    subdomain = Rails.configuration.front_end_uri.to_s
    protocol = subdomain == "localhost:3000/" ? "http" : "https"
    domain = subdomain == "localhost:3000/" ? "localhost:3090/" : "api.#{subdomain}"

    "#{protocol}://#{domain}api/touch_net/postback"
  end

  def touchnet_connect(client)
    Savon.client(
      basic_auth: [ENV["TN_USERNAME"], ENV["TN_PASSWORD"]],
      namespaces: { "xmlns:tns1" => "http://types.secureLink.touchnet.com" },
      wsdl: client.touchnet_service_url
    )
  end

  def touchnet_post(ticket_response, ticket_id)
    klassname = "TouchNet::#{client_subdomain.gsub('-', '_').camelize}"
    touchnet = Object.const_get(klassname).new

    touchnet.post(ticket_response, ticket_id)
  end
end
