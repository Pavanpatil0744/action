# frozen_string_literal: true

class Api::RaceOptionsController < Api::BaseController
  def index
    render json: TravelerInfo::RACE_OPTIONS, status: :ok
  end
end
