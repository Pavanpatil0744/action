# frozen_string_literal: true

class Api::TpTransportationTypesController < ApplicationController
  def index
    render json: TpTransportationTypeSerializer.new(TpTransportationType.in_order)
                                               .serialized_json, status: :ok
  end
end
