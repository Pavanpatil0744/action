# frozen_string_literal: true

class Api::ProgramRangesController < Api::BaseController
  include QueryHandler

  before_action :find_program_range, only: :available_for_alternates
  before_action :find_traveler, only: :available_for_alternates

  def index
    render json: query_to_json(report_program_ranges_query), status: :ok
  end

  def available_for_alternates
    authorized = client_account.allow_authorized_programs?
    range_id = @program_range.id
    alternates = ProgramRange.internal_alternates(client_account, range_id)

    if client_account == @program_range.primary_client_account

      if @program_range.alternate_all_programs
        range_ids = alternates.pluck(:id)

        range_ids += ProgramRange.authorized_alternates(client_account, range_id).pluck(:id) if authorized
      elsif @program_range.alternate
        range_ids = []
        alternate_tags = @program_range.alternate_tags.not_archived.ids.sort

        return render json: range_ids, status: :ok if alternate_tags.empty?

        alternates.each do |pr|
          range_ids << pr.id if pr.tags.not_archived.ids.sort == alternate_tags
        end
      else
        range_ids = []
      end
    else
      suitcase = client_account.suitcase_by_program_range(@program_range)

      if suitcase&.allow_alternates
        range_ids = alternates.pluck(:id)

        range_ids += ProgramRange.authorized_alternates(client_account, range_id).pluck(:id) if authorized
      else
        range_ids = []
      end
    end

    program_objects = []
    programs = Program.published.joins(:program_ranges).where(program_ranges: { id: range_ids }).distinct
    traveler_term_ids = @traveler.application_submissions.pluck(:program_range_id)

    programs.each do |program|
      program_ranges = program.program_ranges
                              .where(
                                "id IN (?) AND id <> ? AND start_date > ? ",
                                range_ids, range_id, DateTime.now
                              ).as_json

      program_ranges.each do |range|
        program_range = client_account.program_ranges.find(range["id"])

        if program.primary_client_account_id != client_account.id
          suitcase = client_account.suitcase_by_program_range(program_range)

          range.merge!(
            {
              alternate: suitcase&.allow_alternates,
              alternate_all_programs: suitcase&.allow_alternates,
              deadline: suitcase&.application_deadline,
              decision_release_date: nil,
              name: suitcase&.name,
              term_name_id: suitcase&.term_name_id
            }
          )
        else
          range.merge!({ name: program_range.term_title })
        end
      end

      active_applications = ((program_ranges.map { |pr| pr['id'] }) & traveler_term_ids).any?

      program_objects << program.as_json.merge({ active_applications: active_applications, program_ranges: program_ranges })
    end

    render json: program_objects, status: :ok
  end

  private

  def assigned_program_range_ids
    current_user.assigned_program_ranges.pluck(:id).join(", ")
  end

  def find_program_range
    @program_range = ProgramRange.find(params[:id])

    return not_found unless @program_range
  end

  def find_traveler
    @traveler = client_account.travelers.find(params[:traveler_id])

    return not_found unless @traveler
  end

  def report_program_ranges_query
    authorized = params[:source] == "authorized"

    if !authorized && occasional_user? && assigned_program_range_ids.empty?
      ""
    elsif !authorized && occasional_user?
      prepared_query(
        INTERNAL_TERMS_OCCASIONAL_USER_SQL,
        {
          CLIENT_ACCOUNT_ID: client_account.id,
          PROGRAM_RANGE_IDS: assigned_program_range_ids
        }
      )
    elsif !authorized
      prepared_query(
        INTERNAL_TERMS_SQL,
        {
          CLIENT_ACCOUNT_ID: client_account.id
        }
      )
    elsif !occasional_user? && client_account.enrollment?
      prepared_query(
        AUTHORIZED_TERMS_SQL,
        {
          CLIENT_ACCOUNT_ID: client_account.id
        }
      )
    else
      ""
    end
  end
end
