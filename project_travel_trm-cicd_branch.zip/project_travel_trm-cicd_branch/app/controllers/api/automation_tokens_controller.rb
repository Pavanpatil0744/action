# frozen_string_literal: true

class Api::AutomationTokensController < Api::BaseController
  before_action :validate_admin_user, only: :index
  before_action :validate_presence_of_type, only: :index
  before_action :find_automation_type, only: :index

  def index
    render(
      json: AutomationTokenSerializer.new(
        automation_tokens,
        params: { type: @automation_type.identifier }
      ).serialized_json,
      status: :ok
    )
  end

  private

  def automation_tokens
    Token.by_automation_type(params[:type])
  end

  def find_automation_type
    @automation_type = AutomationType.find_by_identifier(params[:type])

    return not_found unless @automation_type
  end

  def validate_admin_user
    return forbidden unless admin_user?
  end

  def validate_presence_of_type
    return if params[:type].present?

    render(json: { message: "Please provide a type" }, status: :unprocessable_entity)
  end
end
