# frozen_string_literal: true

class Api::TwilioWebhooksController < Api::BaseController
  skip_before_action :authenticate_user!

  def create
    body = params[:Body]&.downcase
    help_keywords = %w[help info]
    opt_in_keywords = %w[start unstop yes]
    opt_out_keywords = %w[cancel end quit stop stopall unsubscribe]
    all_keywords = help_keywords + opt_in_keywords + opt_out_keywords

    if all_keywords.include?(body)
      traveler_infos = TravelerInfo.where(safe_check_phone_number: params[:From])

      if traveler_infos.present?
        if opt_in_keywords.include?(body)
          traveler_infos.update_all(safe_check_enrollment_status: 1)
        elsif opt_out_keywords.include?(body)
          traveler_infos.update_all(safe_check_enrollment_status: 2)
        end

        traveler_infos.each do |ti|
          update_report_plan_user(ti.user_id)
        end
      end

      return render xml: {}, status: :ok
    else
      response = Twilio::TwiML::MessagingResponse.new

      response.message { |message| message.body(message_body) }

      render xml: response.to_xml, status: :ok
    end
  end

  private

  def message_body
    "This is a Do Not Reply number. "\
    "Please click the link in the message you received to reply. "\
    "Reply STOP to unsubscribe. Message & data rates may apply."
  end

  def update_report_plan_user(traveler_id)
    plans_users = PlansUser.where(user_id: traveler_id)

    plans_users.each do |plan_user|
      ReportPlanUser.find_by_plans_users_id(plan_user.id)&.update(sync_required: true)
      UpdateReportPlanUser.perform_in(10.seconds, plan_user.id)
    end
  end
end
