# frozen_string_literal: true

class Api::Visitor::PreSessionsController < Api::Visitor::BaseController
  before_action :validate_request, only: :show
  before_action :validate_user, only: :show

  def show
    client_account = if user&.admin_role?
                       user.client_account
                     elsif user
                       user.client
                     else
                       ClientAccountInfo.find_by_subdomain("ccfc").client_account
                     end

    sso = client_account.sso?
    subdomain = client_account.subdomain
    sso_url = sso_sign_in_url(subdomain: subdomain) if sso && subdomain

    render json: {
      archived: user&.archived?,
      client_account: {
        id: client_account.id,
        branding: client_account.branding,
        org_name: client_account.org_name,
        sso: sso,
        sso_url: sso_url,
        status: client_account.status,
        state: client_account.state.description,
        subdomain: subdomain
      },
      email: email,
      first_name: user&.first_name,
      inactive: user&.inactive?
    }, status: :ok
  end

  private

  def email
    @email ||= params[:email]
  end

  def validate_request
    return if email.present?

    render json: { message: "Please provide an email" }, status: :bad_request
  end

  def user
    @user = User.find_by_email(email)
  end

  def validate_user
    render json: { message: "Not found" }, status: :not_found if user.nil?
  end
end
