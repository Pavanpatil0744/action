# frozen_string_literal: true

module Api
  module Visitor
    class ProgramsController < Api::Visitor::BaseController
      respond_to :json

      def get_program_hash
        return not_found unless program

        provider = program.primary_client_account
        home_campus = ClientAccountInfo.find_by_subdomain(subdomain)&.client_account
        internal = home_campus == provider
        program_ranges = program.program_ranges.includes(form_groupings: :trm_form_templates)
                                .where("start_date > ?", Date.today).order(:start_date).as_json

        program_ranges.each do |program_range|
          pr = home_campus&.program_ranges&.find_by(id: program_range["id"])

          next unless pr

          if !internal
            suitcase = home_campus&.suitcase_by_program_range(pr)

            program_range.merge!(
              {
                "alternate" => suitcase&.allow_alternates,
                "alternate_all_programs" => suitcase&.allow_alternates,
                "deadline" => suitcase&.application_deadline,
                "decision_release_date" => nil,
                "name" => suitcase&.name,
                "provider_deadline" => pr&.deadline,
                "term_name_id" => suitcase&.term_name_id
              }
            )
          else
            program_range.merge!({ "name" => pr.term_title })
          end
        end

        ranges = program_ranges.map do |range|
          pr = home_campus&.program_ranges&.find_by(id: range["id"])

          next unless pr

          template = if internal
                       pr&.application_template
                     else
                       home_campus&.suitcase_application_template_by_program_range(pr)
                     end

          { application: template, range: range }
        end

        serialized_program = program.as_json

        if program.program_images.any?
          serialized_background_photo = program.serialized_primary_program_image

          serialized_program.merge!({ background_photo: serialized_background_photo })
        end

        program_brochure_section =
          if home_campus.present?
            program.program_brochure_sections
                   .where(client_account_id: home_campus.id)
                   .select('id, title, description').first
          else
            {}
          end

        render json: {
          internal: internal,
          program: serialized_program,
          program_types: program.program_types.sort_by(&:order).map(&:name),
          program_map: program.program_map.included,
          program_attachments: program.program_attachments.in_order,
          provider: provider&.name,
          program_highlight: program.program_highlight,
          program_location: program.program_location_highlight,
          locations: program.program_locations_array_of_objects,
          coordinates: [
            program.program_locations.in_order.map { |l| { data: { lat: l.lat, lon: l.lng } } }
          ],
          program_ranges: program_ranges,
          ranges: ranges,
          program_activity: program.program_activities,
          program_amenities: program.program_amenities.map { |sample| sample.amenity.name },
          program_amenities_included: program.program_amenities.included.map do |sample|
            sample.amenity.name
          end,
          ProgramAmenitiesIncludedWithId: (
            program.program_amenities.included + program.program_amenities.excluded
          ).sort.map do |pai|
            program_amenity_json(pai)
          end,
          program_amenities_excluded: program.program_amenities.excluded.map do |sample|
            sample.amenity.name
          end,
          program_courses: program.program_courses,
          program_review: program.program_review,
          program_eligibility: program.program_eligibility,
          program_scholarship: program.program_scholarship_info,
          program_languages: program.languages,
          program_housing: program.program_housings.map do |sample|
            { housing_type: sample.housing_type, included: sample.included }
          end,
          program_locations: program.program_locations.in_order.map do |pl|
            {
              id: pl.id,
              alpha2: pl.alpha2,
              city: pl.city,
              lat: pl.lat,
              lng: pl.lng,
              continent: pl.continent,
              country_common_name: pl.country_common_name,
              county_or_region: pl.county_or_region,
              formatted_address: pl.formatted_address,
              google_place_id: pl.google_place_id,
              image_url: pl.image_url,
              locality: pl.location,
              program_id: pl.program_id,
              postal_code: pl.postal_code,
              postal_code_suffix: pl.postal_code_suffix,
              state_or_province: pl.state_or_province,
              state_or_province_code: pl.state_or_province_code,
              street: pl.street,
              street_number: pl.street_number,
              time_zone: pl.time_zone,
              time_zone_offset: pl.time_zone_offset
            }
          end,
          program_subjects: program.program_subjects.map(&:subject_area).compact.sort_by(&:name),
          program_activities: program.program_activities,
          program_excursions: program.program_excursions,
          publish_status: program.status,
          program_opportunities: program.program_opportunities.map do |add_on|
            { id: add_on.id, info: add_on.info }
          end,
          organization_description: provider&.client_account_info&.description,
          organization_time_zone: provider&.client_account_info&.org_timezone,
          branding_theme: branding_theme,
          pactivities: program.pactivities,
          pexcursions: program.pexcursions,
          padd_ons: program.padd_ons,
          pcourses: program.pcourses,
          academic_notes: program.academic_notes,
          activity_notes: program.activity_notes,
          host_organization: program.host_organization,
          host_organization_notes: program.host_organization_notes,
          housing_notes: program.housing_notes,
          location_notes: program.location_notes,
          program_brochure_section: program_brochure_section
        }, status: :created
      end

      def program_brochure_details
        return not_found unless program

        provider = program.primary_client_account
        home_campus = ClientAccountInfo.find_by_subdomain(subdomain)&.client_account
        internal = home_campus == provider
        program_ranges = program.program_ranges.includes(form_groupings: :trm_form_templates)
                                .where("start_date > ?", Date.today).order(:start_date).as_json

        ranges = []

        program_ranges.each do |program_range|
          pr = home_campus&.program_ranges&.find_by_id(program_range["id"])

          next unless pr

          if !internal
            suitcase = home_campus&.suitcase_by_program_range(pr)

            program_range.merge!(
              {
                "deadline" => suitcase&.application_deadline,
                "name" => suitcase&.name,
                "term_name_id" => suitcase&.term_name_id
              }
            )

            template = home_campus.suitcase_application_template_by_program_range(pr)
          else
            program_range.merge!({ "name" => pr.term_title })
            template = pr.application_template
          end

          ranges << {
            application: template,
            range: program_range
          }
        end

        program_user = program.program_contact&.user
        program_contact = {
          id: program_user.id,
          first_name: program_user.first_name,
          last_name: program_user.last_name,
          email: program_user.email
        }
        serialized_program = program.as_json

        ppi = program.primary_program_image

        serialized_program.merge!({
          background_photo: ppi.background,
          program_list_img_url: ppi.list
        })

        program_brochure_section =
          if home_campus.present?
            program.program_brochure_sections
                   .where(client_account_id: home_campus.id)
                   .select('id, title, description').first
          else
            {}
          end

        render json: {
          program: serialized_program,
          program_attachments: program.program_attachments.in_order,
          program_types: program.program_types.sort_by(&:order).map(&:name),
          program_map: program.program_map&.included,
          program_highlight: program.program_highlight,
          program_location: program.program_location_highlight,
          locations: program.program_locations,
          coordinates: [
            program.program_locations.in_order.map { |l| { data: { lat: l.lat, lon: l.lng } } }
          ],
          ranges: ranges,
          program_amenities_included: program.program_amenities.included.map do |sample|
            sample.amenity.name
          end,
          program_amenities_excluded: program.program_amenities.excluded.map do |sample|
            sample.amenity.name
          end,
          program_eligibility: program.program_eligibility,
          program_scholarship: program.program_scholarship_info,
          program_languages: program.languages,
          program_housing: program.program_housings.map do |sample|
            { housing_type: sample.housing_type, included: sample.included }
          end,
          program_subjects: program.program_subjects.map(&:subject_area).compact.sort_by(&:name),
          publish_status: program.status,
          internal: internal,
          org_timezone: home_campus.try(:client_account_info)&.org_timezone,
          academic_notes: program.academic_notes,
          home_campus: home_campus&.org_name,
          pactivities: program.pactivities,
          pexcursions: program.pexcursions,
          padd_ons: program.padd_ons,
          pcourses: program.pcourses,
          program_contact: program_contact,
          housing_notes: program.housing_notes,
          location_notes: program.location_notes,
          host_organization: program.host_organization,
          host_organization_notes: program.host_organization_notes,
          activity_notes: program.activity_notes,
          organization_description: provider&.client_account_info&.description,
          provider: program.primary_client_account.org_name,
          program_review: program.program_review,
          program_administrators: program.program_managers.map do |pm|
            user = pm.user
            user_id = user.id
    
            {
              id: pm.id,
              email: user.email,
              name: user.preferred_name,
              program_contact: program.program_contact.user_id == user_id,
              program_id: pm.program_id,
              user_id: user_id
            }
          end,
          program_brochure_section: program_brochure_section
        }, status: 200
      end

      def get_org_authorized_program_settings
        return not_found unless program

        provider = program.primary_client_account

        render json: [
          AuthorizedProgramSettings: AuthorizedProgramSettingsPresenter.new(
            provider.client_account_info
          ).intro_text,
          ClientAccountApplication: provider.authorized_programs_caa,
          ClientAccountApplicationDeadline: provider.authorized_programs_application_deadline
        ], status: :created
      end

      def program
        @program = Program.includes(
          :primary_client_account,
          :program_ranges,
          :program_attachments,
          :program_types,
          :program_map,
          :program_highlight,
          :program_location_highlight,
          :program_locations,
          { program_amenities: :amenity },
          :program_eligibility,
          :program_scholarship_info,
          :program_languages,
          { program_subjects: :subject_area },
          program_housings: :housing_type
        ).find_by_id(params[:id])
      end

      def program_amenity_json(program_amenity)
        amenity = program_amenity.amenity

        {
          id: program_amenity.id,
          category: amenity.amenity_category_display_name,
          name: amenity.name,
          amenity_id: program_amenity.amenity_id
        }
      end

      def branding_theme
        ca_info = program.primary_client_account.client_account_info

        @branding_theme ||= {
          themes: {
            theme_color_dark: ca_info.theme_color_dark,
            theme_color_light: ca_info.theme_color_light,
            theme_color_accent: ca_info.theme_color_accent
          },
          logo: { theme_logo: ca_info.logo.url }
        }
      end
    end
  end
end
