module Api
  module Visitor
    class ApplicationsController < Api::Visitor::BaseController
      respond_to :json
    end
  end
end
