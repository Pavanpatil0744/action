# frozen_string_literal: true

class Api::Visitor::BaseController < ApplicationController
  def authenticate_user!; end

  def subdomain
    referrer = request.referrer

    return unless referrer

    URI.parse(referrer).host.split(".").first
  end
end
