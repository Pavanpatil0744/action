# frozen_string_literal: true

class Api::Visitor::EventsController < Api::Visitor::BaseController
  respond_to :json

  def get_event
    coordinates = (
      begin
        Geocoder.coordinates(event.location).present? ?
        Geocoder.coordinates(event.location) :
        Geocoder.coordinates("Boulder, CO 80306, US")
      rescue StandardError
        Geocoder.coordinates("Boulder, CO 80306, US")
      end
    )

    render json: event.as_json.merge!(
      background_photo: event.background_photo.url,
      coordinates: coordinates,
      background: [
        { large: event.background_photo.event_large.url },
        { medium: event.background_photo.event_medium.url },
        { small: event.background_photo.event_small.url },
        { xlarge: event.background_photo.event_xlarge.url }
      ]
    )
  end

  def create_event_traveler
    client_account = event.client_account
    email = user_params[:email].downcase
    event_traveler = event.event_travelers.find_or_create_by(email: email)
    user = client_account.travelers.find_by_email(email)

    event_traveler.update(
      confirmed: true,
      attended: event_traveler.attended?,
      first_name: user_params[:first_name],
      last_name: user_params[:last_name],
      user: user
    )

    SendGrid::SendEventRegistrationMailer.perform_async(client_account.logo.url, event_traveler.id)

    update_report_event_traveler_associations(event.id, event_traveler.id)

    render json: { event_traveler: event_traveler, status: :ok }
  end

  def same_day_registration
    client_account = event.client_account
    email = user_params[:email].downcase
    event_traveler = event.event_travelers.find_or_create_by(email: email)
    user = client_account.travelers.find_by_email(email)

    event_traveler.update(
      confirmed: true,
      attended: true,
      first_name: user_params[:first_name],
      last_name: user_params[:last_name],
      user: user
    )

    SendGrid::SendEventAttendanceMailer.perform_async(client_account.logo.url, event_traveler.id)

    update_report_event_traveler_associations(event.id, event_traveler.id)

    if event_traveler.errors && event_traveler.errors.full_messages.present?
      render json: { errors: event_traveler.errors }, status: :unprocessable_entity
    else
      render json: { event_traveler: event_traveler, status: :ok }
    end
  end

  private

  def user_params
    JSON.parse(params[:user], symbolize_names: true)
  end

  def event
    Event.find_by_id(params[:id])
  end

  def update_report_event_traveler_associations(event_id, event_traveler_id)
    ReportEvent.find_by_event_id(event_id)&.update(sync_required: true)
    ReportEventTraveler.find_by_event_traveler_id(event_traveler_id)&.update(sync_required: true)
    UpdateReportEvent.perform_in(10.seconds, event_id)
    UpdateReportEventTraveler.perform_in(10.seconds, event_traveler_id)
  end
end
