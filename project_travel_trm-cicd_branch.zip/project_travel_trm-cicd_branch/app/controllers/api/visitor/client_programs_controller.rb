# frozen_string_literal: true

class Api::Visitor::ClientProgramsController < Api::Visitor::BaseController
  def index
    render json: ::Visitor::ReportProgramSerializer.new(report_programs), status: :ok
  end

  private

  def report_programs
    @report_programs ||= ReportProgram.where(client_account_id: params[:client_account_id])
                                      .traveler_or_visitor_viewable
  end
end
