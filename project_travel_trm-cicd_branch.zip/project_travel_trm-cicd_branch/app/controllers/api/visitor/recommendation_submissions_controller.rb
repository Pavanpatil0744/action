# frozen_string_literal: true

class Api::Visitor::RecommendationSubmissionsController < Api::Visitor::BaseController
  before_action :find_recommendation, only: :update
  before_action :find_request, only: %i[show update]
  before_action :find_request_submission, only: :update
  before_action :find_recommendation_template, only: :show
  before_action :validate_file_params, only: %i[add_files remove_files]
  before_action :find_file_question, only: %i[add_files remove_files]
  before_action :find_file_submission, only: %i[add_files remove_files]
  before_action :find_response, only: :remove_files
  before_action :validate_uploaded_file, only: :remove_files
  before_action :validate_file_response_association, only: :remove_files
  before_action :validate_template_association, only: %i[add_files remove_files]

  def show
    if @request.submission
      return unprocessable if @request.cancelled_at

      render(json: SubmissionSerializer.new(@request.submission), status: :ok)
    else
      sent = SubmissionStatus.find_by(identifier: "sent")
      submission_type = SubmissionType.find_by(identifier: "recommendation")

      recommendation = Submission.create!(
        client_account: @recommendation_template.client_account,
        submission_status: sent,
        submission_type: submission_type,
        template: @recommendation_template
      )
      recommendation_id = recommendation.id

      @request.update(submission_id: recommendation_id, started_at: DateTime.current)

      update_report_submission_associations(recommendation_id)

      render(json: SubmissionSerializer.new(recommendation), status: :ok)
    end
  end

  def update
    completed_submission_status_id = SubmissionStatus.find_by_identifier("completed").id
    completed = submission_params[:submission_status_id] == completed_submission_status_id
    pre_save_status = @recommendation.status
    request_submission_id = @request_submission.id

    return bad_request(@recommendation) unless @recommendation.update(submission_params)

    log_submission_status_change if @recommendation.status != pre_save_status

    if @recommendation.completed? && completed
      @request.update(completed_at: DateTime.current)

      SendGrid::V2::Mailers::RecommendationSubmission.perform_async(
        request_submission_id,
        @request_submission.client_account.logo.url
      )
    end

    update_report_submission_associations(@recommendation.id)
    update_report_submission_associations(request_submission_id)

    render(
      json: SubmissionSerializer.new(
        @recommendation,
        params: { client_account_id: @recommendation.client_account_id }
      ),
      status: :ok
    )
  end

  def add_files
    responses = @file_submission.file_upload_responses
    response = responses.find_or_initialize_by(question_id: @file_question.id)

    uploaded_files_attributes.each do |file|
      response.uploaded_files.new(
        filename: file[:filename],
        s3_store: file[:s3_store]
      )
    end

    return bad_request(response) unless response.save

    render json: FileUploadResponseSerializer.new(response), status: :ok
  end

  def remove_files
    return bad_request(@response) unless @response.update(file_params)

    if @response.uploaded_files.empty?
      @response.destroy

      render json: {}, status: :ok
    else
      render json: FileUploadResponseSerializer.new(@response), status: :ok
    end
  end

  private

  def file_params
    params.require(:response).permit(
      :question_id,
      :submission_id,
      uploaded_files_attributes: %i[id _destroy filename s3_store]
    )
  end

  def submission_params
    params.require(:submission).permit(
      :deadline,
      :program_range_id,
      :submission_status_id,
      :template_id,
      :user_id,
      alternate_program_ranges_attributes: %i[id program_range_id ranking _destroy],
      date_responses_attributes: %i[id question_id value _destroy],
      dropdown_response_groupings_attributes: [
        :id,
        :question_id,
        :_destroy,
        { dropdown_responses_attributes: %i[id dropdown_question_option_id] }
      ],
      long_text_responses_attributes: %i[id question_id value _destroy],
      multiple_choice_response_groupings_attributes: [
        :id,
        :question_id,
        :_destroy,
        { multiple_choice_responses_attributes: %i[id multiple_choice_question_option_id] }
      ],
      short_text_responses_attributes: %i[id question_id value _destroy],
      signature_responses_attributes: %i[id question_id value _destroy],
      single_choice_responses_attributes: %i[id question_id value _destroy],
      star_rating_responses_attributes: %i[id star_rating_question_option_id question_id _destroy],
      submission_review_attributes: [
        :id,
        :notes,
        :rating,
        :_destroy,
        { uploaded_files_attributes: %i[id filename s3_store _destroy] }
      ]
    )
  end

  def find_file_question
    @file_question = Question.find_by_id(question_id)
    question_type = @file_question&.detailable_type

    return not_found unless @file_question && question_type == "FileUploadQuestion"
  end

  def find_file_submission
    @file_submission = Submission.find_by_id(submission_id)

    return not_found unless @file_submission
  end

  def find_recommendation
    @recommendation = Submission.find_by_id(params[:id])

    return not_found unless @recommendation
  end

  def find_recommendation_template
    @recommendation_template = @request.recommendation_template

    return not_found unless @recommendation_template
  end

  def find_request
    @request = RecommendationRequest.find_by_token(params[:token])

    return not_found unless @request&.recommendation_responses&.any?
  end

  def find_request_submission
    submission_id = @request.recommendation_responses.pluck(:submission_id).first
    @request_submission = Submission.find_by_id(submission_id)

    return not_found unless @request_submission
  end

  def find_response
    @response = @file_submission.file_upload_responses.find_by_question_id(@file_question.id)

    return not_found unless @response
  end

  def question_id
    file_params[:question_id]
  end

  def recommendation_template_id
    params[:recommendation_template_id]
  end

  def submission_id
    file_params[:submission_id]
  end

  def uploaded_files_attributes
    file_params[:uploaded_files_attributes]
  end

  def unprocessable
    render(
      json: { errors: ["Recommendation request previously cancelled"] },
      status: :unprocessable_entity
    )
  end

  def validate_file_params
    errors = []

    errors << "Question ID required" unless question_id
    errors << "Submission ID required" unless submission_id
    errors << "At least 1 uploaded file required" unless uploaded_files_attributes&.any?

    render json: { errors: errors }, status: 400 if errors.any?
  end

  def validate_file_response_association
    response_file_ids = @response.uploaded_files.pluck(:id)

    return not_found unless response_file_ids.include?(@file_id)
  end

  def validate_template_association
    return not_found unless @file_question.template_id == @file_submission.template_id
  end

  def validate_uploaded_file
    @file_id = uploaded_files_attributes.first[:id]

    render json: { errors: ["Uploaded file id is required"] }, status: 400 if @file_id.nil?
  end

  def log_submission_status_change
    @recommendation.submission_status_change_logs.create(status: @recommendation.status)
  end

  def update_report_submission_associations(submission_id)
    ReportSubmission.find_by_submission_id(submission_id)&.update(sync_required: true)
    UpdateReportSubmission.perform_in(10.seconds, submission_id)
  end
end
