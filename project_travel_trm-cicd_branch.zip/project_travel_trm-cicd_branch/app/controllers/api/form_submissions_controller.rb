# frozen_string_literal: true

class Api::FormSubmissionsController < Api::SubmissionsController
  def create
    return forbidden unless admin_user?

    created_forms = []
    failed_forms = []
    submissions = client_account.submissions

    params[:submissions].each do |submission|
      program_range_id = submission[:program_range_id]
      template_id = submission[:template_id]
      user_id = submission[:user_id]

      if submissions.find_by(program_range_id: program_range_id, template_id: template_id, user_id: user_id)
        failed_forms << submission
      else
        form = submissions.new(
          deadline: submission[:deadline],
          program_range_id: program_range_id,
          template_id: template_id,
          user_id: user_id
        )

        form.manually_added = true
        form.submission_status = SubmissionStatus.find_by_identifier("not_started")
        form.submission_type = SubmissionType.find_by_identifier("form")

        authorize!(:create, form)

        if form.save
          update_report_submission_associations(form)

          created_forms << form
        else
          failed_forms << submission
        end
      end

      SendGrid::V2::Mailers::NewFormNotification.perform_async(client_account_logo, user_id) if created_forms.any? && !client_account.automations_enabled?
    end

    response = SubmissionSerializer.new(
      created_forms,
      params: { client_account_id: client_account_id }
    ).to_hash

    response.merge!({ failures: failed_forms }) if failed_forms.any?

    if created_forms.empty? && failed_forms.any?
      render json: { message: "Unable to add; form already exists for term." }, status: :unprocessable_entity
    else
      render(json: response, status: :created)
    end
  end
end
