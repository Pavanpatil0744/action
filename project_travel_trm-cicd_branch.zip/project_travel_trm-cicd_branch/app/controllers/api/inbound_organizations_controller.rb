# frozen_string_literal: true

class Api::InboundOrganizationsController < Api::BaseController
  respond_to :json
  skip_before_action :authenticate_user!, only: :permission_groups
  before_action :verify_inbound_access, only: :show

  def show
    org_details = Inbound::Base.new(client_account_id).organization_details

    render json: { details: org_details }, status: :ok
  rescue Inbound::Errors::AuthenticationError
    render json: { error: "User is not authorized on inbound" }, status: :not_found
  rescue Inbound::Errors::OrganizationDetailsError
    render json: { error: "Fail to access organization details" }, status: :not_found
  end

  def permission_groups
    client_account = ClientAccount.find(params[:id])

    unless client_account.onboard_to_inbound
      return render(
        json: { error: 'Organization has not onboarded to inbound' },
        status: :forbidden
      )
    end
    permissions = Inbound::Base.new(params[:id]).permission_groups
    render json: { permissions: permissions }, status: :ok
  rescue Inbound::Errors::AuthenticationError
    render json: { error: "User is not authorized on inbound" }, status: :not_found
  rescue Inbound::Errors::OrganizationDetailsError
    render json: { error: "Fail to access details" }, status: :not_found
  end

  private

  def verify_inbound_access
    return if current_user.validate_inbound_permission?

    render json: { error: "Unauthorized" }, status: :unauthorized
  end
end
