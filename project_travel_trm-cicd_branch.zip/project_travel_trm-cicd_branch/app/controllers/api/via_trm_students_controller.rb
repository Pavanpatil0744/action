# frozen_string_literal: true

class Api::ViaTrmStudentsController < Api::BaseController
  skip_before_action :authenticate_user!

  before_action :find_via_trm_student, only: :show

  def show
    render json: ViaTrmStudentSerializer.new(@via_trm_student), status: :ok
  end

  private

  def find_via_trm_student
    @via_trm_student = ViaTrmStudent.find_by_email(params[:email])

    return not_found unless @via_trm_student
  end
end
