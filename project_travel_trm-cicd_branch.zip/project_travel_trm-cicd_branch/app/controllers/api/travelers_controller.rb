# frozen_string_literal: true

class Api::TravelersController < Api::BaseController
  def index
    render json: ::Reports::ReportTravelerSerializer.new(report_travelers), status: :ok
  end

  private

  def report_travelers
    admin_ids = client_account.users.without_role(:traveler).not_actively_applying.pluck(:id)

    if occasional_user?
      client_account.report_travelers.where(user_id: current_user.assigned_travelers.pluck(:id))
    else
      client_account.report_travelers
    end.where.not(user_id: admin_ids)
  end
end
