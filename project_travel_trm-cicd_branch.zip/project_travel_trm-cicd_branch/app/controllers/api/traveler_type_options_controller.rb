# frozen_string_literal: true

class Api::TravelerTypeOptionsController < Api::BaseController
  def index
    render json: TravelerInfo::TRAVELER_TYPE_OPTIONS, status: :ok
  end
end
