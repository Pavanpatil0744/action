# frozen_string_literal: true

class Api::ResidencyOptionsController < Api::BaseController
  def index
    render json: TravelerInfo::RESIDENCY_OPTIONS, status: :ok
  end
end
