# frozen_string_literal: true

class Api::ContinentsController < ApplicationController
  def index
    render json: ContinentSerializer.new(Continent.in_order).serialized_json, status: :ok
  end
end
