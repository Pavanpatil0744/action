# frozen_string_literal: true

class Api::FormTemplatesController < Api::BaseController
  before_action :authorize_admin
  before_action :find_template, only: %i[show update destroy duplicate]
  before_action :validate_params, only: %i[create update]

  def index
    render(
      json: FormTemplateSerializer.new(
        form_templates,
        params: { dash: template_params[:dash].to_s }
      ),
      status: :ok
    )
  end

  def show
    authorize!(:show, @template)

    render json: FormTemplateSerializer.new(@template), status: :ok
  end

  def create
    template = client_account.templates.new(name: template_name, template_type_id: template_type.id)

    authorize!(:create, template)

    if template.save
      render json: FormTemplateSerializer.new(template), status: :created
    else
      render json: { errors: template.errors }, status: :bad_request
    end
  end

  def update
    if @template.default
      render json: { message: "Default forms cannot be modified" }, status: :bad_request
    elsif @template.status == "archived"
      render json: { message: "Archived forms cannot be modified" }, status: :bad_request
    elsif template_status&.zero? && @template.status != "draft"
      render json: { message: "Forms cannot be reverted to draft status" }, status: :bad_request
    else
      authorize!(:update, @template)

      return bad_request(@template) unless @template.update(template_params)

      update_report_submission_associations(@template)

      render json: FormTemplateSerializer.new(@template), status: :ok
    end
  end

  def destroy
    authorize!(:destroy, @template)

    if @template.default
      render json: { message: "Default forms cannot be deleted" }, status: :bad_request
    elsif @template.status != "draft"
      render json: { message: "Only forms in draft status can be deleted" }, status: :bad_request
    elsif @template.destroy
      render json: {}, status: :no_content
    else
      render json: { errors: @template.errors }, status: :bad_request
    end
  end

  def available_for_traveler_terms
    all_templates = client_account.templates.form.published
    traveler = client_account.travelers.find(params[:user_id])
    applications = traveler.application_submissions
    forms = traveler.form_submissions
    form_terms = forms.pluck(:program_range_id).uniq

    term_templates = applications.map do |application|
      program_range = application.program_range
      program_range_attributes = program_range.serialized_attributes.except(:program_highlight)
      program_range_id = program_range.id
      form_term_ids = forms.where(program_range_id: program_range_id).pluck(:template_id)
      authorized = program_range.program.primary_client_account_id != client_account_id

      term_name = if authorized
                    client_account.suitcase_by_program_range(program_range)&.name
                  else
                    program_range.term_title
                  end

      {
        form_templates: if form_terms.include?(program_range_id)
                          all_templates.where.not(id: form_term_ids)
                        else
                          all_templates
                        end.map do |template|
                          { id: template.id, name: template.name }
                        end,
        program_range: program_range_attributes.merge({ term_name: term_name })
      }
    end

    render json: term_templates, status: :ok
  end

  def duplicate
    authorize!(:create, @template)

    unless duplicable
      return render json: {
        message: "Default Recommendation Form cannot be duplicated"
      }, status: :bad_request
    end

    dup_template = @template.duplicate

    render json: FormTemplateSerializer.new(dup_template), status: :created
  end

  def fields
    template_id = template_params[:id]

    if template_id.present?
      template = client_account.templates.find_by_id(template_id)

      return not_found unless template

      render json: FormTemplateFieldSerializer.new(template), status: :ok
    else
      render json: FormTemplateFieldSerializer.new(non_draft_templates), status: :ok
    end
  end

  def thin
    templates = form_templates
    templates = templates.order("#{params[:order_by]} #{params[:dir] || 'ASC'}") if params[:order_by].present?
    templates = templates.where(status: params[:template_status].split(',')) if params[:template_status].present?

    render(json: ThinFormTemplateSerializer.new(templates), status: :ok)
  end

  private

  def template_params
    params.permit(:dash, :id, :name, :status, :template_type)
  end

  def find_template
    @template = client_account.templates.find_by_id(template_params[:id])

    return not_found unless @template
  end

  def form_templates
    base_templates = client_account.templates.where(template_type: template_type)

    template_status.present? ? base_templates.where(status: template_status) : base_templates
  end

  def non_draft_templates
    client_account.templates.non_drafts.where(template_type: template_type)
  end

  def template_name
    template_params[:name]
  end

  def template_status
    template_params[:status]
  end

  def template_type
    if template_params[:id]
      @template.template_type
    else
      TemplateType.find_by(name: template_params[:template_type])
    end
  end

  def duplicable
    !(@template.default && @template.template_type.name == "Recommendation")
  end

  def duplicate_name
    templates = client_account.templates.where(name: template_name)
    template_ids = templates&.pluck(:id)
    original_template_ids = templates&.where&.not(original_template_id: nil)&.pluck(:id)

    if @template.nil? && template_ids.present?
      true
    elsif template_ids.none? || original_template_ids&.include?(@template&.id)
      false
    else
      !template_ids.include?(@template&.id)
    end
  end

  def validate_params
    errors = []

    errors << "Name can't be blank" unless template_name
    errors << "Template type can't be blank" unless template_type
    errors << "Form name must be unique, enter a new name and try again." if duplicate_name

    render json: { errors: errors }, status: 400 if errors.any?
  end

  def current_ability
    @current_ability ||= TemplateAbility.new(current_user, template_params)
  end

  def update_report_submission_associations(template)
    template.submissions&.each do |submission|
      submission_id = submission.id

      ReportSubmission.find_by_submission_id(submission_id)&.update(sync_required: true)
      UpdateReportSubmission.perform_in(10.seconds, submission_id)
    end
  end
end
