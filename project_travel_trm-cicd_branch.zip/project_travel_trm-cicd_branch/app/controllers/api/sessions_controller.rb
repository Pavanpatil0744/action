# frozen_string_literal: true

# class Api::SessionsController < Api::BaseController
#   def destroy
#     @user = User.find_by_id(params[:id])

#     Inbound::AuthToken.delete_token(@user.id)

#     render json: { message: 'Signed out' }, status: :ok
#   end
# end
