# frozen_string_literal: true

class Api::TpActivityTypesController < ApplicationController
  def index
    render json: TpActivityTypeSerializer.new(TpActivityType.in_order).serialized_json, status: :ok
  end
end
