# frozen_string_literal: true

class Api::SuitcasesController < Api::BaseController
  before_action :authorize_admin
  before_action :find_suitcase, only: :update

  def index
    render json: SuitcaseSerializer.new(suitcases.in_order), status: :ok
  end

  def create
    suitcase = client_account.suitcases.new(suitcase_params)

    return bad_request(suitcase) unless suitcase.save

    render json: SuitcaseSerializer.new(suitcase), status: :created
  end

  def update
    return bad_request(@suitcase) unless @suitcase.update(suitcase_params)

    program_ranges = @suitcase.program_ranges
    submissions = client_account.submissions.joins(:program_range)
                                .where(program_range_id: @suitcase.program_range_ids)

    @suitcase.programs.each do |program|
      UpdateReportProgram.perform_in(10.seconds, client_account_id, program.id)
    end

    program_ranges.each do |program_range|
      UpdateReportProgramRange.perform_in(10.seconds, client_account_id, program_range.id)
    end

    submissions.each do |submission|
      update_report_submission_associations(submission.id, submission.type)
      update_report_traveler_associations(submission.user_id)
    end

    SyncSuitcaseForms.perform_async(@suitcase.id)

    render json: SuitcaseSerializer.new(@suitcase), status: :ok
  end

  private

  def suitcase_params
    params.require(:suitcase).permit(
      :allow_alternates,
      :application_deadline,
      :application_template_id,
      :term_name_id,
      suitcase_form_groupings_attributes: [
        :id,
        :_destroy,
        :deadline,
        { suitcase_form_grouping_templates_attributes: %i[id _destroy form_template_id] }
      ]
    )
  end

  def find_suitcase
    @suitcase = suitcases.find_by(id: params[:id])

    return not_found unless @suitcase
  end

  def suitcases
    client_account.suitcases.includes(
      :application_template,
      :term_name,
      suitcase_form_groupings: [suitcase_form_grouping_templates: :form_template]
    )
  end

  def update_report_submission_associations(submission_id, submission_type)
    ReportSubmission.find_by_submission_id(submission_id)&.update(sync_required: true)
    UpdateReportSubmission.perform_in(10.seconds, submission_id)
    UpdateReportFormGrouping.perform_in(10.seconds, submission_id) if submission_type == "application"
  end

  def update_report_traveler_associations(traveler_id)
    ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
    UpdateReportTraveler.perform_in(10.seconds, traveler_id)
  end
end
