# frozen_string_literal: true

class Api::SafeCheckMessagesController < Api::BaseController
  before_action :find_safe_check_message, only: :show
  before_action :find_plans_users, only: :create

  def index
    render json: SafeCheckMessageSerializer.new(client_account.safe_check_messages)
                                           .serialized_json, status: :ok
  end

  def show
    render json: SafeCheckMessageSerializer.new(@safe_check_message).serialized_json, status: :ok
  end

  def create
    safe_check_message = client_account.safe_check_messages.new(safe_check_message_params)
    safe_check_message.client_user = current_user
    safe_check_message.sent_at = DateTime.current.utc

    return bad_request(safe_check_message) unless safe_check_message.save

    @plans_users.each do |plans_user|
      safe_check_enrollment_status = plans_user.user.safe_check_enrollment_status

      next unless safe_check_enrollment_status == "enrolled"

      SendSafeCheckMessage.call(plans_user: plans_user, safe_check_message: safe_check_message)
    end

    render json: SafeCheckMessageSerializer.new(safe_check_message)
                                           .serialized_json, status: :created
  end

  private

  def safe_check_message_params
    params.require(:safe_check_message).permit(
      :email_requested,
      :geolocation_requested,
      :group_lead,
      :safe_check_message_type_id
    )
  end

  def find_safe_check_message
    @safe_check_message = client_account.safe_check_messages.find_by(id: params[:id])

    return not_found unless @safe_check_message
  end

  def find_plans_users
    @plans_users = client_account.plans_users.includes(:user).where(id: params[:plans_user_ids])
  end
end
