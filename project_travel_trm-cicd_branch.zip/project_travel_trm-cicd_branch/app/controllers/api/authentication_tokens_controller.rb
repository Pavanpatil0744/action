# frozen_string_literal: true

# maybe?
class Api::AuthenticationTokensController < Api::BaseController
  def refresh_token
    if request.headers["HTTP_X_USER_TOKEN"]
      token = AuthenticationToken::TokenService.new(current_user).create_token
      AuthenticationToken::TokenService.new(current_user).delete_token(request.headers["HTTP_X_USER_TOKEN"])
      render json: { token: token }, status: :ok
    end
  end

  # def delete_token
  #   AuthenticationToken::TokenService.new(current_user).delete_token(params[:token])
  #   render json: { message: "Token deleted" }, status: :ok
  # end

  def poll_user_info
    if request.headers["HTTP_X_USER_TOKEN"]
      token = AuthenticationToken::TokenService.new(current_user).get_expiry_information(request.headers["HTTP_X_USER_TOKEN"])
      if token
        render json: { token: token }, status: :ok
      else
        render json: { message: "Token not found" }, status: :not_found
      end
    end
  end
end
