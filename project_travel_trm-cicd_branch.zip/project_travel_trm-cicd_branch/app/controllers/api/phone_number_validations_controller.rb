# frozen_string_literal: true

class Api::PhoneNumberValidationsController < Api::Traveler::BaseController
  def show
    validation = ValidateSafeCheckPhoneNumber.call(phone_number: params[:phone_number])

    unless validation.success?
      return render json: { error: "Invalid phone number" }, status: :bad_request
    end

    response = validation.response
    safe_check_phone_number = response.phone_number
    message_confirmation = SendSafeCheckMessageConfirmation.call(
      org_name: traveler.clients.first&.org_name,
      safe_check_phone_number: safe_check_phone_number
    )

    if message_confirmation.success?
      UpdateTravelerInfoSafeCheckFields.call(
        safe_check_enrollment_status: "enrolled",
        safe_check_phone_number: safe_check_phone_number,
        traveler: traveler
      )

      render json: {
        add_ons: response.add_ons,
        caller_name: response.caller_name,
        carrier: response.carrier,
        country_code: response.country_code,
        national_format: response.national_format,
        phone_number: safe_check_phone_number,
        url: response.url
      }, status: :ok
    else
      render json: { error: "Recipient is unsubscribed" }, status: :bad_request
    end
  end
end
