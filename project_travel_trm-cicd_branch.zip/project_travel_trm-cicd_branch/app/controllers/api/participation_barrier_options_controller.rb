# frozen_string_literal: true

class Api::ParticipationBarrierOptionsController < Api::BaseController
  def index
    render json: Advising::PARTICIPATION_BARRIER_OPTIONS, status: :ok
  end
end
