# frozen_string_literal: true

class Api::AutomationTypesController < Api::BaseController
  before_action :validate_admin_user, only: :index

  def index
    return forbidden unless admin_user?

    render(json: AutomationTypeSerializer.new(AutomationType.in_order).serialized_json, status: :ok)
  end

  private

  def validate_admin_user
    return forbidden unless admin_user?
  end
end
