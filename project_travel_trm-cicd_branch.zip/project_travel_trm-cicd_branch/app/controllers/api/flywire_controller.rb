# frozen_string_literal: true

class Api::FlywireController < Api::BaseController
  before_action :find_or_create_payment_response, only: :postback
  before_action :validate_payment_status, only: :postback

  def postback
    approved = flywire_params[:success]

    @payment_response.api_transaction = true
    @payment_response.attributes = { payment_status: payment_status("paid") } if approved
    @payment_response.save

    payment_log = create_payment_response_status_change_log(approved)

    PaymentResponseStatusChangeLogPayload.create(
      payload: params.to_json,
      payment_response_status_change_log: payment_log
    )

    render json: payment_log, status: :created
  end

  private

  def flywire_params
    params.permit(:amount, :nonce, :success, :txId)
  end

  def find_or_create_payment_response
    transaction_id = flywire_params[:nonce]
    flywire_question_id, submission_id, @payor_id = transaction_id.split("|").map(&:to_i)

    @payment_response = PaymentResponse.find_by(
      question: FlywireQuestion.find_by_id(flywire_question_id).question,
      submission_id: submission_id
    )

    return if @payment_response

    @payment_response = PaymentResponse.new(
      payment_status: payment_status("not_paid"),
      question: FlywireQuestion.find_by_id(flywire_question_id).question,
      submission_id: submission_id
    )
  end

  def create_payment_response_status_change_log(approved)
    payor = User.find_by_id(@payor_id)

    @payment_response.payment_response_status_change_logs.create(
      notes: "Flywire transaction",
      payment_status_id: @payment_response.payment_status_id,
      status: @payment_response.payment_status_identifier,
      transaction_id: flywire_params[:txId],
      transaction_response: approved ? "Successful" : "Failed",
      transaction_success: approved,
      user_id: payor&.id,
      user_email: payor&.email,
      user_first_name: payor&.first_name,
      user_last_name: payor&.last_name
    )
  end

  def payment_status(identifier)
    PaymentStatus.find_by_identifier(identifier)
  end

  def validate_payment_status
    return unless @payment_response.payment_status_identifier == "paid"

    render(
      json: { errors: ["Payment status is currently paid"] },
      status: :unprocessable_entity
    )
  end
end
