# frozen_string_literal: true

class Api::SubmissionContentsController < Api::BaseController
  def index
    render json: SubmissionContentSerializer.new(submissions), status: :ok
  end

  private

  def submissions
    client_account.trm_templates.where(type: params[:type])
  end
end
