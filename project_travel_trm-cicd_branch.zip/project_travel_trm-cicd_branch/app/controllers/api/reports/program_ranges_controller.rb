# frozen_string_literal: true

class Api::Reports::ProgramRangesController < Api::Reports::BaseController
  def index
    render json: ::Reports::ReportProgramRangeSerializer.new(report_program_ranges), status: :ok
  end

  private

  def report_program_ranges
    if occasional_user?
      client_account.report_program_ranges.where(
        program_range_id: current_user.assigned_program_ranges.pluck(:id)
      )
    else
      client_account.report_program_ranges
    end.includes(program: %i[program_highlight program_location_highlight])
  end
end
