# frozen_string_literal: true

class Api::Reports::BaseController < Api::BaseController; end
