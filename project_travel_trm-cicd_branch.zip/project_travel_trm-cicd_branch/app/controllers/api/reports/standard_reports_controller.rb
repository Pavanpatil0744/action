# frozen_string_literal: true

require "zip"

class Api::Reports::StandardReportsController < Api::Reports::BaseController
  def index
    return forbidden unless admin_user?

    standard_reports = StandardReport.where(user_id: current_user.id).order(created_at: :desc)
    render json: ::Reports::StandardReportSerializer.new(standard_reports), status: :ok
  end

  def notifications
    return forbidden unless admin_user?

    standard_report_notifications = StandardReport.where(user_id: current_user.id, notified: false)
                                                  .order(created_at: :desc)
                                                  .limit(3)
    render json: ::Reports::StandardReportSerializer.new(standard_report_notifications), status: :ok
  end

  def mark_as_read
    return forbidden unless admin_user?

    standard_report = StandardReport.find(params[:id])

    if standard_report.update_attributes(notified: true)
      render json: ::Reports::StandardReportSerializer.new(standard_report), status: :ok
    else
      render json: { message: "Something went wrong" }
    end
  end

  def mark_all_as_read
    return forbidden unless admin_user?

    standard_reports = current_user.standard_reports.where(notified: false)

    if standard_reports.update_all(notified: true)
      render json: { message: "All notifications are read", standard_report_notification_read: true }
    else
      render json: { message: "Something went wrong" }
    end
  end

  def destroy
    return forbidden unless admin_user?

    standard_report = StandardReport.find(params[:id])
    if standard_report.destroy
      render json: { message: "Report is deleted" }
    else
      render json: { message: "Something went wrong" }
    end
  end

  def update_standard_live_flag
    return forbidden unless admin_user?

    if current_user.update_attributes(standard_report_live: flag_params[:standard_report_live])
      render json: {
        message: "Standard Report Flag is updated",
        standard_report_live: current_user.standard_report_live
      }, status: :ok
    else
      render json: { message: "Something went wrong" }
    end
  end

  def standard_live_flag_info
    return forbidden unless admin_user?

    render json: {
      standard_report_live: current_user.standard_report_live
    }, status: :ok
  end

  def application_alternates
    @standard_report = StandardReport.create(
      user_id: current_user.id,
      status: 'pending',
      download_type: 'Application Alternates Report',
      filename: filename('application_alternates')
    )
    job_id = StandardReports::ApplicationAlternatesReportWorker.perform_async(
      @standard_report.id,
      params[:submission_ids],
      client_account_id
    )

    @standard_report.update(job_id: job_id)

    render json: ::Reports::StandardReportSerializer.new(@standard_report), status: :ok
  end

  def application_status_count
    @standard_report = StandardReport.create(
      user_id: current_user.id,
      status: 'pending',
      download_type: 'Application Counting',
      filename: filename('application_counting')
    )

    job_id = StandardReports::ApplicationStatusCountReportWorker.perform_async(
      @standard_report.id,
      params[:submission_ids],
      client_account_id
    )

    @standard_report.update(job_id: job_id)

    render json: ::Reports::StandardReportSerializer.new(@standard_report), status: :ok
  end

  def form_statuses
    @standard_report = StandardReport.create(
      user_id: current_user.id,
      status: 'pending',
      download_type: 'Form Status by Program Name and Term',
      filename: filename('form_statuses')
    )

    job_id = StandardReports::FormStatusesReportWorker.perform_async(
      @standard_report.id,
      params[:submission_ids],
      params[:report_by],
      client_account_id
    )

    @standard_report.update(job_id: job_id)

    render json: ::Reports::StandardReportSerializer.new(@standard_report), status: :ok
  end

  def participation
    @standard_report = StandardReport.create(
      user_id: current_user.id,
      status: 'pending',
      download_type: 'Participation Report',
      filename: filename('participation')
    )

    job_id = StandardReports::ParticipationReportWorker.perform_async(
      @standard_report.id,
      params[:submission_ids],
      client_account_id
    )

    @standard_report.update(job_id: job_id)

    render json: ::Reports::StandardReportSerializer.new(@standard_report), status: :ok
  end

  def traveler_information
    @standard_report = StandardReport.create(
      user_id: current_user.id,
      status: 'pending',
      download_type: 'Traveler Information',
      filename: filename('traveler_information')
    )
    job_id = StandardReports::TravelerInformationReportWorker.perform_async(
      @standard_report.id,
      params[:user_ids],
      client_account_id
    )

    @standard_report.update(job_id: job_id)

    render json: ::Reports::StandardReportSerializer.new(@standard_report), status: :ok
  end

  def application_content_by_application_template
    @standard_report = StandardReport.create(
      user_id: current_user.id,
      status: 'pending',
      download_type: 'Application Content by Application Template',
      filename: filename('content_by_template', 'Application')
    )

    job_id = StandardReports::ContentByTemplateReportWorker.perform_async(
      @standard_report.id,
      'application',
      params[:submission_ids],
      params[:report_by],
      client_account_id
    )

    @standard_report.update(job_id: job_id)

    render json: ::Reports::StandardReportSerializer.new(@standard_report), status: :ok
  end

  def form_content_by_form_template
    @standard_report = StandardReport.create(
      user_id: current_user.id,
      status: 'pending',
      download_type: 'Form Content by Form Template',
      filename: filename('content_by_template', 'Form')
    )

    job_id = StandardReports::ContentByTemplateReportWorker.perform_async(
      @standard_report.id,
      'form',
      params[:submission_ids],
      params[:report_by],
      client_account_id
    )

    @standard_report.update(job_id: job_id)

    render json: ::Reports::StandardReportSerializer.new(@standard_report), status: :ok
  end

  def application_content_by_program_name_and_term
    @standard_report = StandardReport.create(
      user_id: current_user.id,
      status: 'pending',
      download_type: 'Application Content by Program Name and Term',
      filename: filename('content_by_program_name_and_term', 'Application')
    )

    job_id = StandardReports::ContentByProgramNameAndTermReportWorker.perform_async(
      @standard_report.id,
      'application',
      params[:submission_ids],
      params[:report_by],
      client_account_id
    )

    @standard_report.update(job_id: job_id)

    render json: ::Reports::StandardReportSerializer.new(@standard_report), status: :ok
  end

  def form_content_by_program_name_and_term
    @standard_report = StandardReport.create(
      user_id: current_user.id,
      status: 'pending',
      download_type: 'Form Content by Program Name and Term',
      filename: filename('content_by_program_name_and_term', 'Form')
    )

    job_id = StandardReports::ContentByProgramNameAndTermReportWorker.perform_async(
      @standard_report.id,
      'form',
      params[:submission_ids],
      params[:report_by],
      client_account_id
    )

    @standard_report.update(job_id: job_id)

    render json: ::Reports::StandardReportSerializer.new(@standard_report), status: :ok
  end

  private

  def flag_params
    params.require(:standard_report).permit(:standard_report_live, :subject)
  end

  def filename(report_name, submission_type = nil)
    default_name, ext = default_filename_and_ext(report_name, submission_type)

    if params[:filename].present?
      params[:filename].ends_with?(ext) ? params[:filename] : "#{params[:filename]}.#{ext}"
    else
      default_name
    end
  end

  def default_filename_and_ext(report_name, submission_type)
    case report_name
    when 'participation'
      ["ViaTRM_Participation_Report_#{DateTime.now.strftime('%Y%m%d%H%M')}.csv", 'csv']
    when 'application_alternates'
      ["ViaTRM_Application_Alternates_Report_#{DateTime.now.strftime('%Y%m%d%H%M')}.csv", 'csv']
    when 'application_counting'
      ["ViaTRM_Application_Counting_#{DateTime.now.strftime('%Y%m%d%H%M')}.csv",'csv']
    when 'content_by_program_name_and_term'
      ["ViaTRM_#{submission_type}_Content_by_Program_Name_and_Term_#{DateTime.now.strftime('%Y%m%d%H%M')}.zip", 'zip']
    when 'content_by_template'
      ["ViaTRM_#{submission_type}_Content_by_#{submission_type}_Template_#{DateTime.now.strftime('%Y%m%d%H%M')}.zip", 'zip']
    when 'form_statuses'
      ["ViaTRM_Form_Status_by_Program_Name_and_Term_#{DateTime.now.strftime('%Y%m%d%H%M')}.zip", 'zip']
    when 'traveler_information'
      ["ViaTRM_Traveler_Information_Report_#{DateTime.now.strftime('%Y%m%d%H%M')}.csv", 'csv']
    end
  end
end
