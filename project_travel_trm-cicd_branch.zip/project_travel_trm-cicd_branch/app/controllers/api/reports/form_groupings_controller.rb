# frozen_string_literal: true

class Api::Reports::FormGroupingsController < Api::Reports::BaseController
  include QueryHandler

  def index
    return forbidden unless admin_user?

    return render(json: [], status: :ok) unless submissions.present?

    render json: query_to_json(report_form_groupings_query), status: :ok
  end

  private

  def current_ability
    @current_ability ||= SubmissionAbility.new(current_user)
  end

  def end_date
    @end_date ||= params[:end_date]
  end

  def end_date_present?
    end_date.present?
  end

  def report_form_groupings_query
    prepared_query(sql_statement, sql_variables)
  end

  def sql_statement
    if end_date_present? && occasional_user?
      REPORT_FORM_GROUPINGS_OCCASIONAL_USER_FILTERED_BY_END_DATE_SQL
    elsif end_date_present?
      REPORT_FORM_GROUPINGS_FILTERED_BY_END_DATE_SQL
    elsif occasional_user?
      REPORT_FORM_GROUPINGS_OCCASIONAL_USER_SQL
    else
      REPORT_FORM_GROUPINGS_SQL
    end
  end

  def sql_variables
    sql_variables = { CLIENT_ACCOUNT_ID: client_account_id }

    if occasional_user?
      submission_ids = submissions.map(&:id).join(", ")

      sql_variables.merge!({ SUBMISSION_IDS: submission_ids })
    end

    sql_variables.merge!({ END_DATE: end_date }) if end_date_present?

    sql_variables
  end

  def submissions
    @submissions ||= occasional_user? ? current_user.assigned_submissions : client_account.submissions
  end
end
