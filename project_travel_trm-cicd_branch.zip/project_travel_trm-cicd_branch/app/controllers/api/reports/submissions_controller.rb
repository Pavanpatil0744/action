# frozen_string_literal: true

class Api::Reports::SubmissionsController < Api::BaseController
  include QueryHandler

  before_action :validate_type, only: :index

  def index
    return forbidden unless admin_user?

    return render(json: [], status: :ok) unless submission_ids.present?

    render json: query_to_json(report_submissions_query), status: :ok
  end

  private

  def application_type?
    @application_type ||= type == "application"
  end

  def current_ability
    @current_ability ||= SubmissionAbility.new(current_user)
  end

  def end_date
    @end_date ||= params[:end_date]
  end

  def end_date_present?
    end_date.present?
  end

  def sql_statement
    if version_2? && end_date_present?
      VERSION_2_REPORT_SUBMISSIONS_FILTERED_BY_END_DATE_SQL
    elsif version_2?
      VERSION_2_REPORT_SUBMISSIONS_SQL
    elsif end_date_present? && template_id_present?
      REPORT_SUBMISSIONS_FILTERED_BY_END_DATE_AND_TEMPLATE_ID_SQL
    elsif end_date_present?
      REPORT_SUBMISSIONS_FILTERED_BY_END_DATE_SQL
    elsif template_id_present?
      REPORT_SUBMISSIONS_FILTERED_BY_TEMPLATE_ID_SQL
    else
      REPORT_SUBMISSIONS_SQL
    end
  end

  def sql_variables
    sql_variables = {
      CLIENT_ACCOUNT_ID: client_account_id,
      SUBMISSION_IDS: submission_ids.join(", ")
    }

    sql_variables.merge!({ END_DATE: end_date }) if end_date_present?
    sql_variables.merge!({ TEMPLATE_ID: template_id }) if template_id_present?

    sql_variables
  end

  def report_submissions_query
    prepared_query(sql_statement, sql_variables)
  end

  def submission_ids
    @submission_ids ||= if application_type? && occasional_user?
                          current_user.assigned_application_submissions
                        elsif application_type?
                          client_account.application_submissions
                        elsif occasional_user?
                          current_user.assigned_form_submissions
                        else
                          client_account.form_submissions
                        end.pluck(:id)
  end

  def template_id
    @template_id ||= params[:template_id]
  end

  def template_id_present?
    template_id.present?
  end

  def type
    @type ||= params[:type]
  end

  def validate_type
    return if type && %w[application form].include?(type)

    render(json: { message: "Type parameter is required" }, status: :bad_request)
  end

  def version
    @version ||= params[:version]
  end

  def version_2?
    version&.to_i == 2
  end
end
