# frozen_string_literal: true

class Api::SfsuHistoricRecordsController < Api::BaseController
  def index
    render json: SfsuHistoricRecordSerializer.new(sfsu_historic_records), status: :ok
  end

  private

  def sfsu_historic_records
    sfsu = ClientAccountInfo.find_by(subdomain: "sfstate").client_account

    client_account == sfsu && admin_user? ? SfsuHistoricRecord.all : []
  end
end
