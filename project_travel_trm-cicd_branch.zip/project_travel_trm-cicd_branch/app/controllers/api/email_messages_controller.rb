# frozen_string_literal: true

class Api::EmailMessagesController < Api::BaseController
  before_action :find_travelers

  def create
    attachment_count = params[:message][:attachment_count]&.to_i
    attachments = []
    message = Message.new(message_params)

    attachment_count.times do |index|
      attachments << params[:message]["attachment#{index}"]
    end

    message.assign_attributes(attachments: attachments)

    return bad_request(message) unless message.save

    @travelers.each do |traveler|
      SendMessage.call(admin: current_user, message: message, traveler: traveler)
    end

    SendGrid::SendEmailMessageMailer.perform_async(
      current_user.full_name_or_email,
      client_account.logo.url,
      message.body,
      message.subject,
      @travelers.ids
    )

    render json: MessageSerializer.new(message).serialized_json, status: :created
  end

  private

  def message_params
    params.require(:message).permit(:body, :subject)
  end

  def find_travelers
    @travelers = client_account.travelers
                               .joins(:plans_users)
                               .where(plans_users: { id: params[:plans_user_ids] })
                               .distinct
  end
end
