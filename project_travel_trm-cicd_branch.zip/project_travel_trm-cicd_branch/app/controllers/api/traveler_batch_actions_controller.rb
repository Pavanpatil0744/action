# frozen_string_literal: true

class Api::TravelerBatchActionsController < Api::BaseController
  before_action :authorize_admin

  def add_message_recipients
    travelers.each do |traveler|
      conversation = Conversation.conversation(traveler, client_account)

      recipients.each do |recipient|
        client_account.assigned_admins.find_or_create_by(client_user: recipient, traveler: traveler)

        next unless conversation && !conversation.is_participant?(recipient)

        conversation.add_participant(recipient)
      end

      update_report_traveler(traveler.id)
    end

    render json: { message: "Message recipients added" }, status: :created
  end

  def remove_message_recipients
    client_account.assigned_admins.where(client_user: recipients, traveler: travelers).destroy_all

    travelers.each do |traveler|
      update_report_traveler(traveler.id)

      conversation = Conversation.conversation(traveler, client_account)

      next unless conversation

      recipients.each { |recipient| conversation.receipts_for(recipient).delete_all }
    end

    render json: { message: "Message recipients removed" }, status: :ok
  end

  def send_event_invitations
    failures = 0
    invites = 0
    response = {}

    travelers.each do |traveler|
      if traveler.event_travelers.find_by(event: event)
        failures += 1
      else
        event_traveler = traveler.event_travelers.find_or_initialize_by(event: event)
        event_traveler.email = traveler.email
        event_traveler.first_name = traveler.first_name
        event_traveler.last_name = traveler.last_name

        if event_traveler.save
          SendGrid::SendEventInviteMailer.perform_async(client_account_logo, event_traveler.id)

          update_report_event_traveler_associations(event.id, event_traveler.id)

          invites += 1
        else
          failures += 1
        end
      end
    end

    response.merge!({ success: "#{invites} #{invites == 1 ? "#{alias_traveler} has" : "#{alias_travelers} have"} been invited." }) if invites.positive?
    response.merge!({ failure: "#{failures} #{failures == 1 ? alias_traveler : alias_travelers} unable to be invited." }) if failures.positive?

    render json: { message: response }, status: :created
  end

  def send_messages
    attachment_count = params[:message][:attachment_count].to_i
    attachments = []
    message = current_user.messages.new(message_params)

    attachment_count.times do |index|
      attachments << params[:message]["attachment#{index}"]
    end

    message.assign_attributes(attachments: attachments)

    return bad_request(message) unless message.save

    desire_travelers = travelers.with_role(:traveler)

    desire_travelers.each do |traveler|
      SendMessage.call(admin: current_user, message: message, traveler: traveler)
    end

    traveler_ids = desire_travelers.ids
    traveler_count = traveler_ids.count

    SendGrid::SendMessageFromAdminMailers.call(
      admin: current_user,
      message: message,
      traveler_ids: traveler_ids
    )

    messages = MessageSerializer.new(message).to_hash
    custom_alias = traveler_count == 1 ? traveler_alias : travelers_alias
    response = messages.merge(success: "Message sent to #{traveler_count} #{custom_alias}")

    render json: response, status: :created
  end

  def send_safe_check_enrollment_requests
    all_traveler_ids = travelers.pluck(:id)
    unenrolled_travelers = travelers.not_enrolled_in_safe_check
    unenrolled_traveler_ids = unenrolled_travelers.pluck(:id)
    enrolled_or_opted_out_traveler_ids = all_traveler_ids - unenrolled_traveler_ids

    SendGrid::SendSafeCheckEnrollmentRequestMailer.perform_async(
      client_account_logo,
      unenrolled_traveler_ids
    )

    render json: {
      failure: "#{enrolled_or_opted_out_traveler_ids.count} SafeCheck enrollment request(s) unable to send",
      success: "#{unenrolled_traveler_ids.count} SafeCheck enrollment request(s) sent"
    }, status: :created
  end

  def update_custom_fields
    custom_field = client_account.custom_fields.find_by(id: params[:custom_field_id])

    return not_found unless custom_field

    travelers.each do |traveler|
      custom_field_value = traveler.custom_field_texts.find_or_create_by(custom_field: custom_field)

      custom_field_value.update(text: params[:custom_field_value])

      traveler_id = traveler.id

      update_report_traveler(traveler_id)
      update_custom_field_reporting(traveler_id)
    end

    render json: { message: "Custom field values updated" }, status: :ok
  end

  private

  def message_params
    params.require(:message).permit(:body, :subject)
  end

  def alias_traveler
    client_account.client_account_info.alias_traveler.downcase
  end

  def alias_travelers
    client_account.client_account_info.alias_travelers.downcase
  end

  def event
    @event ||= client_account.events.find_by(id: params[:event_id])
  end

  def recipients
    @recipients ||= client_account.users.where(id: params[:message_recipient_ids])
  end

  def travelers
    traveler_ids = params[:traveler_ids].split(",")

    if occasional_user?
      current_user.assigned_travelers
    else
      client_account.travelers
    end.where(id: traveler_ids)
  end

  def update_custom_field_reporting(traveler_id)
    report_submissions = ReportSubmission.where(user_id: traveler_id)
    report_submissions.update_all(sync_required: true)

    report_submissions.each do |report_submission|
      UpdateReportSubmission.perform_in(10.seconds, report_submission.submission_id)
    end

    report_plan_users = ReportPlanUser.where(user_id: traveler_id)
    report_plan_users.update_all(sync_required: true)

    report_plan_users.each do |report_plan_user|
      UpdateReportPlanUser.perform_in(10.seconds, report_plan_user.plans_users_id)
    end
  end

  def update_report_event_traveler_associations(event_id, event_traveler_id)
    ReportEvent.find_by_event_id(event_id)&.update(sync_required: true)
    ReportEventTraveler.find_by_event_traveler_id(event_traveler_id)&.update(sync_required: true)
    UpdateReportEvent.perform_in(10.seconds, event_id)
    UpdateReportEventTraveler.perform_in(10.seconds, event_traveler_id)
  end

  def update_report_traveler(traveler_id)
    ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
    UpdateReportTraveler.perform_in(10.seconds, traveler_id)
  end
end
