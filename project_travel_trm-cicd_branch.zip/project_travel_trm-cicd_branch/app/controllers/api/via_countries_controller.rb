# frozen_string_literal: true

class Api::ViaCountriesController < ApplicationController
  def index
    render json: (Rails.cache.fetch("via_countries", expires_in: 12.hours) do
      ViaCountrySerializer.new(
        ViaCountry.includes(:continent).in_order
      ).serialized_json
    end), status: :ok
  end
end
