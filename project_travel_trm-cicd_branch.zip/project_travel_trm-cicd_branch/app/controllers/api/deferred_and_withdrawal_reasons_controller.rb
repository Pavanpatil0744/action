# frozen_string_literal: true

class Api::DeferredAndWithdrawalReasonsController < ApplicationController
  def index
    reasons = ::DeferredAndWithdrawalReason.all

    render json: DeferredAndWithdrawalReasonSerializer.new(reasons), status: :ok
  end
end