# frozen_string_literal: true

class Api::TravelerInfoQuestionsController < Api::BaseController
  before_action :find_template, only: :create
  before_action :ensure_required_params, only: :create

  def create
    ordered_questions = questions_params.sort_by { |k| k[:order].to_i }
    traveler_info_questions = []

    ordered_questions.each do |q|
      attrs = { label: q[:label], required: q[:required] }
      question_type_id = q[:question_type_id]
      sourceable_id = q[:sourceable_id]
      sourceable_type = q[:sourceable_type]

      traveler_info_question = if sourceable_type == "TravelerInfoField"
                                 create_tif_question(attrs, q, question_type_id)
                               else
                                 @template.short_text_questions.new(attrs)
                               end

      return bad_request(traveler_info_question) unless traveler_info_question.save

      associated_question = traveler_info_question.question

      associated_question.update(sourceable_id: sourceable_id, sourceable_type: sourceable_type)

      AddQuestionToTemplateLayout.call(question: associated_question, template: @template)

      traveler_info_questions << traveler_info_question
    end

    render json: build_response(traveler_info_questions), status: :created
  end

  private

  def questions_params
    params.permit(
      questions: %i[
        label
        order
        question_type_id
        required
        sourceable_id
        sourceable_type
      ]
    )[:questions]
  end

  def find_template
    @template = client_account.templates.find_by_id(params[:form_template_id])

    return not_found unless @template
  end

  def build_response(traveler_info_questions)
    q_count = traveler_info_questions.count
    template_layout = @template.template_layout

    TravelerInfoQuestionSerializer.new(
      traveler_info_questions
    ).to_hash.merge!(
      {
        message: if q_count == 1
                   "#{q_count} Traveler Info Question Created"
                 else
                   "#{q_count} Traveler Info Questions Created"
                 end,
        template_layout: {
          id: template_layout.id,
          layout: template_layout.layout
        }
      }
    )
  end

  def create_logic(question)
    option = question.dropdown_question_options
                     .find_by_name("Additional gender category/identity: please specify")
    other_text = TravelerInfoField.find_by_name("gender_identity_additional_text")

    question.update(
      {
        dropdown_question_logic_attributes: {
          child_question_attributes: {
            label: other_text.display_name,
            required: true,
            template_id: @template.id
          },
          child_question_type: "ShortTextQuestion",
          dropdown_question_option_id: option.id,
          trigger: "equals"
        }
      }
    )
  end

  def create_tif_question(attrs, question, question_type_id)
    multiselectable = %w[countries_of_citizenship pay_for_program]
    question_type = QuestionType.find(question_type_id)
    traveler_info_field = TravelerInfoField.find(question[:sourceable_id].to_i)

    case question_type.identifier
    when "date"
      @template.date_questions.new(attrs)
    when "dropdown"
      dq = @template.dropdown_questions.new
      field_name = traveler_info_field.name

      dq.multiselect = true if multiselectable.include?(field_name)

      options = dq.create_options(traveler_info_field)
      merge_attrs = attrs.merge!(dropdown_question_options_attributes: options)

      dq.update(merge_attrs)

      create_logic(dq) if field_name == "gender_identity_id"

      dq
    when "short_text"
      @template.short_text_questions.new(attrs)
    end
  end

  def ensure_required_params
    errors = 0

    questions_params.each do |q|
      required_attrs = [
        q[:order],
        q[:question_type_id],
        q[:sourceable_id],
        q[:sourceable_type]
      ]
      q_sources = [q[:sourceable_id].to_i, q[:sourceable_type]]
      t_sources = @template.questions.pluck(:sourceable_id, :sourceable_type)

      errors += 1 if required_attrs.any?(&:nil?) || t_sources.include?(q_sources)
    end

    return if errors.zero?

    render json: { message: "Failed to create questions" }, status: :bad_request
  end
end
