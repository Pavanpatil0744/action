# frozen_string_literal: true

module Api
  module ApplicationSubmissions
    # ApplicationSubmission base class controller
    class BaseController < Api::BaseController

      private

      def submission
        @submission ||= client_account.submissions.find(params[:application_submission_id])
      end

      def bad_request(model)
        render json: { errors: model.errors }, status: :bad_request
      end
    end
  end
end
