# frozen_string_literal: true

module Api
  module ApplicationSubmissions
    # controller for CRUD on SubmissionWithdrawalRequests
    class SubmissionWithdrawalRequestsController < Api::ApplicationSubmissions::BaseController
      before_action :authorize_admin, only: :update

      def create
        @withdrawal_request = submission.submission_withdrawal_requests.new(request_create_params)

        return bad_request(@withdrawal_request) unless @withdrawal_request.save

        log_submission_status_change
        update_report_submission_associations(submission)

        SendGrid::WithdrawRequest::SendRequestNotificationToAdminMailer.perform_async(@withdrawal_request.id)

        render json: ::ApplicationSubmissions::SubmissionWithdrawalRequestSerializer.new(@withdrawal_request), status: :created
      end

      def update
        @withdrawal_request = SubmissionWithdrawalRequest.find_by_id(params[:id])

        return bad_request(@withdrawal_request) unless @withdrawal_request.update(request_update_params)

        log_submission_status_change

        if @withdrawal_request.status == "accepted"
          update_submission
        else
          update_report_submission_associations(submission)
        end

        SendGrid::WithdrawRequest::SendWithdrawRequestToTravelerMailer.perform_async(@withdrawal_request.id)

        render json: ::ApplicationSubmissions::SubmissionWithdrawalRequestSerializer.new(@withdrawal_request), status: :ok
      end

      private

      def request_create_params
        params[:submission_withdrawal_request].permit(:reason)
      end

      def request_update_params
        params[:submission_withdrawal_request].permit(:status)
      end

      def update_submission
        submission.update(submission_status_id: SubmissionStatus.withdrawn&.id)

        submission.program_range.plans.each do |l|
          plan_user = l.plans_users.find_by_user_id(submission.user_id)

          if plan_user.present?
            plan_user.update_attribute(:removed, true)

            ReportPlanUser.find_by_plans_users_id(plan_user.id)&.update(sync_required: true)
            UpdateReportPlanUser.perform_in(10.seconds, plan_user.id)
          end

          Plan.update_traveler_count(l)
        end

        log_submission_status_change(true)

        SendGrid::V2::SendApplicationStatusChangeMailers.call(
          application: submission,
          client_account: client_account,
          drt_elaps_trigger: false
        )

        update_report_submission_associations(submission)
        update_report_traveler_associations(submission.user.id)
      end

      def log_submission_status_change(submission_log = false)
        if submission_log
          status = submission.status
          reasons = params[:application_submission][:reasons]
        else
          status = if @withdrawal_request.status == "accepted"
                     "Approved"
                   elsif @withdrawal_request.status == "rejected"
                     "Declined"
                   else
                     "pending"
                   end
          status = "request #{status}"
          reasons = [@withdrawal_request.reason]
        end

        log = submission.submission_status_change_logs.create(
          status: status,
          user_id: current_user.id,
          user_email: current_user.email,
          user_first_name: current_user.first_name || "",
          user_last_name: current_user.last_name || ""
        )

        log.add_reasons(reasons)
      end

      def update_report_submission_associations(submission)
        submissions_to_update = []
        submissions_to_update << submission
        submissions_to_update |= submission.corresponding_submissions

        submissions_to_update.each do |sub|
          sub_id = sub.id

          if sub.application?
            report_form_grouping = ReportFormGrouping.find_by_submission_id(sub_id)

            if sub.corresponding_forms.any?
              report_form_grouping&.update(sync_required: true)

              UpdateReportFormGrouping.perform_in(10.seconds, sub_id)
            else
              report_form_grouping&.destroy
            end
          end

          ReportSubmission.find_by_submission_id(sub_id)&.update(sync_required: true)
          UpdateReportSubmission.perform_in(10.seconds, sub_id)
        end

        program_id = submission.program_id

        ReportProgram.find_by_program_id(program_id)&.update(sync_required: true)
        UpdateReportProgram.perform_in(10.seconds, submission.client_account_id, program_id)
      end

      def update_report_traveler_associations(traveler_id)
        ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
        UpdateReportTraveler.perform_in(10.seconds, traveler_id)
      end
    end
  end
end
