# frozen_string_literal: true

class Api::RiskLine::BaseController < Api::BaseController; end
