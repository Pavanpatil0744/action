# frozen_string_literal: true

module Api
  module RiskLine
    # Travellers api
    class TravelersController < Api::RiskLine::BaseController
      skip_before_action :authenticate_user!, only: %i[update_traveler_response traveler_alert_info]

      def traveler_list
        alert = TrmRiskAlert.find_by_guid params[:alert_id]
        country = alert.trm_risk_country.iso_code.upcase
        output = []
        output << client_account.plans_users
                                .select("DISTINCT users.id AS user_id, users.email AS email,
                                  plans.id AS plan_id , users.first_name AS user_first_name,
                                  plans_users.group_lead as group_lead,
                                  users.last_name AS user_last_name, traveler_infos.student_id AS student_id,
                                  profiles.phone_number AS user_phone_number, plans.name AS plan_title,
                                  locations.formatted_address AS locations,
                                  profiles.avatar AS profile_image,
                                  traveler_infos.safe_check_phone_number AS safe_check_number,
                                  traveler_infos.preferred_first_name AS preferred_first_name,
                                  traveler_infos.preferred_last_name AS preferred_last_name")
                                .joins(user: [:profile, :traveler_info], plan: [:locations])
                                .where(
                                  "plans_users.removed = false AND locations.country_alpha2_code = ? AND (locations.start_date <= ? AND locations.end_date >= ?)",
                                  country,
                                  alert.end_date.to_date,
                                  alert.start_date.to_date
                                ) if %w[plan both].include? params[:plan_or_program]
        # output << client_account.submissions
        #                         .select("DISTINCT submissions.user_id AS user_id, users.first_name AS user_first_name, profiles.phone_number AS user_phone_number, users.last_name AS user_last_name, program_locations.formatted_address AS locations, programs.id AS programs_id, programs.title AS programs_title, profiles.avatar AS profile_image, traveler_infos.safe_check_phone_number AS safe_check_number")
        #                         .joins(:submission_status, :submission_type, program_range: [program: :program_locations], user: [profile: :traveler_info])
        #                         .where(
        #                           "submission_statuses.identifier = ? AND submission_types.identifier = ? AND program_locations.alpha2 = ? AND (program_ranges.start_date BETWEEN Date(?) AND Date(?) OR program_ranges.end_date BETWEEN Date(?) and Date(?))",
        #                           "committed",
        #                           "application",
        #                           country,
        #                           alert.start_date.to_date,
        #                           alert.end_date.to_date,
        #                           alert.start_date.to_date,
        #                           alert.end_date.to_date
        #                         ) if %w[program both].include? params[:plan_or_program]
        result = JSON.parse(output.flatten.to_json)
        output.flatten.select(&:profile_image).each do |l|
          result.select { |m| m["user_id"] == l.user_id }.first["profile_image"] = l.user.profile.avatar.url
        end
        traveler_info = TrmRiskTraveler.select(%i[id user_id check_in_status location_shared location_detail])
                                       .where(trm_risk_alert_id: alert.id, user_id: result.map { |m| m["user_id"] })
        output.flatten.each do |l|
          traveler_object = traveler_info.select { |m| m.user_id == l["user_id"] }.last
          selected_result = result.select { |m| m["user_id"] == l.user_id }.first
          selected_result["check_in_status"] = traveler_object&.check_in_status
          selected_result["location_detail"] = traveler_object&.location_detail
          selected_result["role"] = l.group_lead ? "Group Leader" : "Traveler"
        end
        render(
          json: result,
          status: :ok
        )
      end

      def update_traveler_response
        traveler = TrmRiskTraveler.find_by_uuid(params[:uuid])

        if traveler.update(traveler_params.merge!({ check_in_status_time: DateTime.now }))
          SendGrid::RiskLine::SendTravelerResponseToAdminMailer.perform_async(traveler.id) if traveler.help_required?
          render(
            json: ::RiskLine::TravelerResponseSerializer.new(traveler).serialized_json,
            status: :ok
          )
        else
          render json: { message: "Response not stored" }
        end
      end

      def traveler_alert_info
        traveler = TrmRiskTraveler.find_by_uuid(params[:uuid])
        user = traveler.user

        render json: { message: "Traveler not found" } unless traveler.present?

        trm_risk_alert = traveler.trm_risk_alert
        iso_code = trm_risk_alert.trm_risk_country&.iso_code&.upcase

        RisklineAlertViewLog.create(
          client_account: user.client,
          guid: trm_risk_alert.guid,
          trm_risk_alert: trm_risk_alert,
          user_id: traveler.user_id,
          user_email: user.email,
          user_first_name: user.first_name || "",
          user_last_name: user.last_name || ""
        )

        alert_note = trm_risk_alert.organization_note(user.client.id)

        if traveler
          render(
            json: {
              alert: trm_risk_alert,
              client_name: traveler.user.client&.org_name,
              country_flag_url: "https://via-country-flag-images.s3.us-west-2.amazonaws.com/#{iso_code.downcase}.png",
              emergency_numbers: trm_risk_alert.trm_risk_country&.emergency_numbers,
              traveler: traveler,
              alert_note: alert_note.present? ? { body: alert_note.body, trm_risk_alert_id: alert_note.trm_risk_alert_id } : nil
            },
            status: :ok
          )
        else
          render json: { message: "Alert not found" }
        end
      end

      def traveler_alerts
        alerts = TrmRiskAlert.includes(:trm_risk_travelers).where(trm_risk_travelers: { is_alert_sent: true, user: current_user })
        render(
          json: ::RiskLine::TravelerAlertInfoSerializer.new(alerts, { params: { current_user_id: current_user.id } }).serialized_json,
          status: :ok
        )
      end

      private

      def traveler_params
        params.require(:traveler).permit(
          :check_in_status,
          :location_shared,
          { location_detail: %i[latitude longitude] },
          :is_help_needed,
          :custom_message
        )
      end
    end
  end
end
