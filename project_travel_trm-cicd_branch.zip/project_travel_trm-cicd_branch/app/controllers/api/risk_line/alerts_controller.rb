# frozen_string_literal: true

module Api
  module RiskLine
    # Alerts api
    class AlertsController < Api::RiskLine::BaseController
      skip_before_action :authenticate_user!, only: %i[create update destroy]

      def index
        risk_level_ids = current_user&.trm_alert_config&.risk_level_ids
        risk_category_ids = current_user&.trm_alert_config&.risk_category_ids
        travelers_impacted = current_user&.trm_alert_config&.display_if_travelers_impacted
        alerts = current_user.trm_risk_alerts
                             .with_admin_alerts(client_account.id, current_user_id)
                             .by_include_exclude_criteria(current_user)
                             .with_travelers_impacted(current_user.id, travelers_impacted)
                             .by_risk_level(risk_level_ids)
                             .by_category(risk_category_ids)
                             .order(created_at: :desc)
                             .select('trm_risk_alerts.*, taa.travelers_impacted_count as travelers_count')
                             .limit(20)
        render(
          json: ::RiskLine::AlertSerializer.new(
            alerts, { params: { current_user_id: current_user.id } }
          ).serialized_json,
          status: :ok
        )
      end

      def mark_all_as_read
        alert_ids = TrmRiskAlert.where(guid: params[:alerts][:alert_ids]).pluck(:id)
        if alert_ids.any?
          current_user.trm_admin_alerts
                      .where(trm_risk_alert_id: alert_ids)
                      .update_all(read: true, read_timestamp: DateTime.now)
        end
        render json: { message: "Alerts are marked as read" }
      end

      def show
        trm_risk_alert = TrmRiskAlert
                         .with_admin_alerts(client_account_id, current_user_id)
                         .where(guid: params[:id])
                         .select('trm_risk_alerts.*, taa.travelers_impacted_count as travelers_count')
                         .first

        RisklineAlertViewLog.create(
          client_account: client_account,
          guid: trm_risk_alert.guid,
          trm_risk_alert: trm_risk_alert,
          user_id: current_user_id,
          user_email: current_user_email,
          user_first_name: current_user.first_name || "",
          user_last_name: current_user.last_name || ""
        )

        render(
          json: ::RiskLine::AlertSerializer.new(
            trm_risk_alert,
            { params: { current_user_id: current_user_id } }
          ).serialized_json,
          status: :ok
        )
      end

      def alert_history
        check_in_status = params[:check_in_status] ? JSON.parse(params[:check_in_status]) : []
        per_page = params[:per_page] || 10

        alerts = current_user.trm_risk_alerts
                             .with_associations(client_account.id, current_user.id)
                             .filter_records(params.slice(:category, :risk_level, :country))
                             .without_zero_travelers(current_user.id, params[:travelers_impacted])
                             .by_dates(params[:from], params[:to], client_account)
                             .by_check_in_status(check_in_status, client_account.id)
                             .search_by_title(params[:search])
                             .select('trm_risk_alerts.*, taa.travelers_impacted_count as travelers_count')
                             .order_data(params[:order_by], params[:dir])
                             .distinct

        alerts = alerts.where("NOT EXISTS (SELECT id FROM trm_risk_travelers WHERE trm_risk_travelers.trm_risk_alert_id = trm_risk_alerts.id and trm_risk_travelers.check_in_status <> 3)") if check_in_status.length == 1 && check_in_status.include?(3)
        alert_list = params[:all_data] == "1" ? alerts : alerts.paginate(page: params[:page], per_page: per_page)

        pagination = {
          current_page: params[:page].to_i,
          per_page: per_page,
          total_pages: params[:all_data] == "1" ? 0 : alert_list.total_pages
        }

        render(
          json: ::RiskLine::AlertSerializer.new(
            alert_list,
            {
              links: {},
              meta: {
                pagination: pagination,
                alert_count: alerts.count('trm_risk_alerts.id'),
                country_count: alerts.map(&:trm_risk_country_id).uniq.count
              },
              params: { current_user_id: current_user.id, show_traveler_response: true }
            }
          ).serialized_json,
          status: :ok
        )
      end

      # This method is to get alerts from riskline and this url will be provided to riskline
      def webhook
        render json: { message: "Alerts not created" } unless params["alert"]

        RisklineDataDump::AlertDump.new.call(params["alert"])
      end

      # Just creating end points for now will update def later
      def create
        render json: { message: "Alerts not created" } unless params["alert"]

        RisklineDataDump::AlertDump.new.call(params["alert"])
        render json: { params: params }, status: :ok
      end

      # Just creating end points for now will update def later
      def update
        render json: { params: params }, status: :ok
      end

      # Just creating end points for now will update def later
      def destroy
        render json: { params: params }, status: :ok
      end

      def send_alerts
        alert = TrmRiskAlert.find_by_guid(send_alerts_params[:alert_id])
        result = if send_alerts_params[:user_ids].any?
                   send_alerts_params[:user_ids].map { |l| OpenStruct.new(user_id: l["user_id"], plan_id: l["plan_id"], programs_id: l["program_id"]) }
                 else
                   TrmRiskAlert.travelers(alert, client_account)
                 end
        risk_traveler_ids = []
        result.each do |l|
          risk_traveler = TrmRiskTraveler.find_or_create_by(trm_risk_alert_id: alert.id, user_id: l.user_id, travel_plan_id: l.plan_id, program_id: l.programs_id, client_account_id: client_account.id)
          risk_traveler.update_attributes(is_alert_sent: true, alert_sent_time: DateTime.now)
          risk_traveler_ids << risk_traveler.id
        end

        SendGrid::RiskLine::SendRiskAlertToTravelerMailer.perform_async(risk_traveler_ids, client_account.id)
        render json: { message: "Alerts sent to users" }
      end

      def send_custom_message
        user_ids = JSON.parse(params[:message][:user_ids])
        attachments = params[:message][:attachment]
        ::RiskLine::SendRiskLineMessage.new.call(message_params, current_user, user_ids, attachments)
        render json: { message: "Message sent to travelers" }
      end

      private

      def message_params
        params.require(:message).permit(:body, :subject)
      end

      def send_alerts_params
        params[:send_alerts][:user_ids] ||= []
        params.require(:send_alerts).permit(:alert_id, user_ids: %i[user_id plan_id program_id])
      end
    end
  end
end
