# frozen_string_literal: true

module Api
  module RiskLine
    # Notes api
    class AlertNotesController < Api::RiskLine::BaseController
      before_action :find_note, only: %i[update destroy]

      def create
        return forbidden unless admin_user?

        alert_note = AlertNote.new(note_params)
        alert_note.user_id = current_user.id
        alert_note.client_account_id = client_account.id

        if alert_note.save
          render json: ::RiskLine::AlertNoteSerializer.new(alert_note), status: :ok
        else
          render json: { message: "Something went wrong" }
        end
      end

      def update
        return forbidden unless admin_user?

        if @alert_note.update(note_params)
          render json: ::RiskLine::AlertNoteSerializer.new(@alert_note), status: :ok
        else
          render json: { message: "Something went wrong" }
        end
      end

      def destroy
        return forbidden unless admin_user?

        if @alert_note.destroy
          render json: { message: "Note is deleted" }
        else
          render json: { message: "Something went wrong" }
        end
      end

      private

      def note_params
        params.require(:note).permit(:body, :trm_risk_alert_id)
      end

      def find_note
        @alert_note = AlertNote.find(params[:id])

        return not_found unless @alert_note
      end
    end
  end
end
