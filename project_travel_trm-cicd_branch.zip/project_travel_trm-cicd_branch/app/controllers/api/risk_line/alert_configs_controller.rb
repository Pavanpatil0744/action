# frozen_string_literal: true

module Api
  module RiskLine
    # Alert Config apis
    class AlertConfigsController < Api::RiskLine::BaseController
      def risk_levels
        render(
          json: ::RiskLine::RiskLevelSerializer.new(TrmRiskLevel.all).serialized_json,
          status: :ok
        )
      end

      def risk_types
        render(
          json: ::RiskLine::RiskTypeSerializer.new(TrmRiskCategory.all).serialized_json,
          status: :ok
        )
      end

      def create
        @alert_config = TrmAlertConfig.find_or_create_by(user_id: current_user.id)

        if @alert_config.update(config_params)
          render json: ::RiskLine::AlertConfigSerializer.new(@alert_config), status: :ok
        else
          render json: { message: "Something went wrong" }
        end
      end

      def alert_config
        @alert_config = TrmAlertConfig.find_by(user_id: current_user.id)

        if @alert_config
          render json: ::RiskLine::AlertConfigSerializer.new(@alert_config), status: :ok
        else
          render json: { message: "Something went wrong" }
        end
      end

      def countries
        render(
          json: Rails.cache.fetch("alert_countries", expires_in: 12.hours) do
            ::RiskLine::CountrySerializer.new(TrmRiskCountry.all.order(name: :asc)).serialized_json
          end,
          status: :ok
        )
      end

      private

      def config_params
        params[:alert_config][:risk_category_ids] ||= []
        params[:alert_config][:risk_level_ids] ||= []
        params[:alert_config][:countries] ||= []

        params.require(:alert_config).permit(
          :display_if_travelers_impacted,
          :send_alerts_filter_criteria,
          :exclude,
          :include,
          risk_category_ids: [],
          risk_level_ids: [],
          countries: []
        )
      end
    end
  end
end
