# frozen_string_literal: true

class Api::DashboardCardsController < Api::BaseController
  before_action :authorize_admin

  def index
    @cards = DashboardCard.by_client_account_status(client_account, current_user).order(:default_order)

    render(
      json: DashboardCardSerializer.new(
        @cards,
        params: {
          client_account: client_account,
          end_date: params[:end_date],
          user: current_user,
          org_details: organization_details
        }
      ),
      status: :ok
    )
  end

  private

  def organization_details
    return "" unless client_account.onboard_to_inbound

    Inbound::Base.new(client_account_id).organization_details
  rescue Inbound::Errors::AuthenticationError
    ""
  rescue Inbound::Errors::OrganizationDetailsError
    ""
  end
end
