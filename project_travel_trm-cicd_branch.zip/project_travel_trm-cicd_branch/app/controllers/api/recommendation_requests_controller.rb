# frozen_string_literal: true

class Api::RecommendationRequestsController < Api::BaseController
  before_action :find_request, only: %i[cancel_request resend_request]
  before_action :find_question, only: %i[cancel_request resend_request]
  before_action :find_submission, only: %i[cancel_request resend_request]
  before_action :authorize_actions, if: :admin_role?
  before_action :validate_assignment, only: %i[cancel_request resend_request], if: :occasional_user?
  before_action :find_template, only: %i[cancel_request resend_request]
  before_action :validate_client_account, only: %i[cancel_request resend_request]
  before_action :validate_user_submission, only: %i[cancel_request resend_request], if: :traveler_user?
  before_action :validate_template_association, only: %i[cancel_request resend_request]

  def cancel_request
    authorize!(:update, @submission) if admin_user?

    @request.update(
      cancelled_at: DateTime.current,
      user_id: requestee_user&.id,
      user_first_name: requestee_user&.first_name,
      user_last_name: requestee_user&.last_name
    )

    SendGrid::V2::Mailers::RecommendationCancellation.perform_async(
      client_account_logo,
      @request.id,
      @submission.user.full_name_or_email
    )

    update_report_submission_associations(@submission)

    render json: RecommendationRequestSerializer.new(@request), status: :ok
  end

  def resend_request
    authorize!(:update, @submission) if admin_user?

    @request.update(
      sent_at: DateTime.current,
      user_id: requestee_user&.id,
      user_first_name: requestee_user&.first_name,
      user_last_name: requestee_user&.last_name
    )

    SendGrid::V2::Mailers::RecommendationReminder.perform_async(
      client_account_logo,
      @request.id,
      @submission.user.full_name_or_email
    )

    update_report_submission_associations(@submission)

    render json: RecommendationRequestSerializer.new(@request), status: :ok
  end

  private

  def find_question
    @response = @request.recommendation_responses&.first
    @question = @response.question
    question_type = @question&.detailable_type

    return not_found unless @question && question_type == "RecommendationQuestion"
  end

  def find_request
    @request = RecommendationRequest.find_by_id(params[:id])

    return not_found unless @request
  end

  def find_submission
    submissions = client_account.submissions
    @submission = submissions.find_by_id(@response.submission_id)

    return not_found unless @submission
  end

  def find_template
    @template = @question.template

    return not_found unless @template
  end

  def authorize_actions
    authorize_admin unless current_user.submissions.find_by_id(@submission.id)
  end

  def requestee_user
    User.find_by(email: @request.user_email)
  end

  def validate_assignment
    assigned_travelers = current_user.assigned_travelers

    assigned = assigned_travelers.find_by_id(@submission.user_id)

    render json: { message: "Unauthorized" }, status: :unauthorized unless assigned
  end

  def validate_client_account
    validated = if admin_user?
                  client_account_id == @submission.client_account_id
                else
                  client_account_id == @template.client_account_id
                end

    render json: { message: "Unauthorized" }, status: :unauthorized unless validated
  end

  def validate_template_association
    return not_found unless @question.template_id == @submission.template_id
  end

  def validate_user_submission
    return not_found unless current_user_id == @submission.user_id
  end

  def current_ability
    @current_ability ||= SubmissionAbility.new(current_user)
  end

  def update_report_submission_associations(submission)
    submission_id = submission.id

    ReportSubmission.find_by_submission_id(submission_id)&.update(sync_required: true)
    UpdateReportSubmission.perform_in(10.seconds, submission_id)
  end
end
