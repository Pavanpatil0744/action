# frozen_string_literal: true

class Api::SendGridMailerTypesController < Api::BaseController
  def index
    render json: SendGridMailerTypeSerializer.new(SendGridMailerType.all), status: :ok
  end
end
