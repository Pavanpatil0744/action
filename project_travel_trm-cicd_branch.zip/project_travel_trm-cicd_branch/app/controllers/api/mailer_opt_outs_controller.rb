# frozen_string_literal: true

class Api::MailerOptOutsController < ApplicationController
  before_action :find_mailer_opt_out, only: :create

  def index
    render json: MailerOptOutSerializer.new(current_user.mailer_opt_outs.active)
                                       .serialized_json, status: :ok
  end

  def create
    if @mailer_opt_out&.update(mailer_opt_out_params)

      render json: MailerOptOutSerializer.new(@mailer_opt_out).serialized_json, status: :created
    else
      mailer_opt_out = current_user.mailer_opt_outs.new(mailer_opt_out_params)
      mailer_opt_out.save

      render json: MailerOptOutSerializer.new(mailer_opt_out).serialized_json, status: :created
    end
  end

  private

  def find_mailer_opt_out
    @mailer_opt_out = current_user.mailer_opt_outs.active.find_by(
      send_grid_mailer_type_id: mailer_opt_out_params[:send_grid_mailer_type_id]
    )
  end

  def mailer_opt_out_params
    params.require(:mailer_opt_out).permit(:archived, :send_grid_mailer_type_id)
  end
end
