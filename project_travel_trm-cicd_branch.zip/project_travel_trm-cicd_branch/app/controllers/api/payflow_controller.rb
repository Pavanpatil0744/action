# frozen_string_literal: true

class Api::PayflowController < Api::BaseController
  skip_before_action :authenticate_user!

  before_action :find_or_create_payment_response, only: :postback
  before_action :find_submission, only: :create
  before_action :find_question, only: :create

  def create
    cost = @pf_question.cost ? format("%5.2f", @pf_question.cost).strip : "0.00"
    token_id = SecureRandom.uuid

    require "payflow_pro/#{client_subdomain}" rescue require "payflow_pro"

    token_params = {
      payment_amount: cost,
      postback_link: return_link,
      token_id: token_id,
      tracking_id: "#{@pf_question.id}|#{@submission.id}|#{params[:user_id]}"
    }

    response = authorize_transaction(token_endpoint, token_params)

    render html: redirect_html(response), status: :moved_permanently
  end

  def postback
    approved = payflow_params[:RESULT].to_s == "0"

    @payment_response.api_transaction = true
    @payment_response.attributes = { payment_status: payment_status("paid") } if approved
    @payment_response.save

    payment_log = create_payment_response_status_change_log(approved)

    PaymentResponseStatusChangeLogPayload.create(
      payload: params.to_json,
      payment_response_status_change_log: payment_log
    )

    render html: confirm_html(approved), status: :created
  end

  private

  def payflow_params
    params.permit(:PNREF, :RESPMSG, :RESULT, :USER1)
  end

  def find_or_create_payment_response
    transaction_id = payflow_params[:USER1]
    pf_question_id, submission_id, @payor_id = transaction_id.split("|", 3)

    @payment_response = PaymentResponse.find_by(
      question: PayflowQuestion.find_by_id(pf_question_id).question,
      submission_id: submission_id
    )

    return if @payment_response

    @payment_response = PaymentResponse.new(
      payment_status: payment_status("not_paid"),
      question: PayflowQuestion.find_by_id(pf_question_id).question,
      submission_id: submission_id
    )
  end

  def find_question
    template = @submission.template
    @pf_question = template.payflow_questions.find_by_id(params[:question_id])

    return not_found unless @pf_question
  end

  def find_submission
    @submission = Submission.find_by_id(params[:submission_id])

    return not_found unless @submission
  end

  def authorize_transaction(token_endpoint, token_params)
    klassname = "PayflowPro::#{client_subdomain.gsub('-', '_').camelize}"
    payflow = Object.const_get(klassname).new

    response = payflow.authorize_transaction(token_endpoint, token_params)

    response.body.split("&").map { |str| str.split("=") }.to_h
  end

  def client_subdomain
    @submission.client_account.client_account_info.subdomain
  end

  def confirm_html(approved)
    content = approved ? <<~EHTML
      <html>
        <head>
          <style>
            h3 {text-align: center;}
            p {text-align: center;}
            div {text-align: center;}
          </style>
        </head>
        <body>
          <br>
          <h3>Transaction Complete</h3>
          <p>Your payment has been processed.</p>
          <p>Return to your application or form and refresh the page to update your transaction information and payment status.</p>
          <div>
            <button type="button" onclick="javascript:window.close()">Close</button>
          </div>
        </body>
      </html>
    EHTML
    : <<~EHTML
      <html>
        <head>
          <style>
            h3 {text-align: center;}
            p {text-align: center;}
            div {text-align: center;}
          </style>
        </head>
        <body>
          <br><br>
          <h3>Credit Card Processing Failure</h3>
          <p>Due to the reason indicated below, there was an issue processing your payment and your fees have not been paid.</p>
          <p><b>Reason: </b>#{payflow_params[:RESPMSG]}</p>
          <p>If you'd like to attempt again, return to your Via TRM application or form and click Make a Payment to re-start the payment process.</p>
          <p>If you think you've reached this message in error, reach out to your bank or credit card provider for more information.</p><br>
          <div>
            <button type="button" onclick="javascript:window.close()">Close</button>
          </div>
        </body>
      </html>
    EHTML

    content.html_safe
  end

  def payment_endpoint
    if %w[viatrm via-university].include?(client_subdomain)
      "https://pilot-payflowlink.paypal.com/"
    else
      "https://payflowlink.paypal.com/"
    end
  end

  def create_payment_response_status_change_log(approved)
    payor = User.find_by_id(@payor_id)

    @payment_response.payment_response_status_change_logs.create(
      notes: "Payflow transaction",
      payment_status_id: @payment_response.payment_status_id,
      status: @payment_response.payment_status_identifier,
      transaction_id: payflow_params[:PNREF],
      transaction_response: payflow_params[:RESPMSG].capitalize,
      transaction_success: approved,
      user_id: payor&.id,
      user_email: payor&.email,
      user_first_name: payor&.first_name,
      user_last_name: payor&.last_name
    )
  end

  def payment_status(identifier)
    PaymentStatus.find_by_identifier(identifier)
  end

  def redirect_html(response)
    content = <<~EHTML
      <html>
        <head>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js">
          </script>
        </head>
        <body>
          <p>Please wait. Transfering you to the payment processor...</p>
          <form id="payflow" name="payflow" action="#{payment_endpoint}" method="POST">
            <input type="hidden" name="SECURETOKEN" value=#{response['SECURETOKEN']} />
            <input type="hidden" name="SECURETOKENID" value=#{response['SECURETOKENID']} />
          </form>
          <script type="text/javascript">
            $(document).ready(function () {
              setTimeout(function () {
                $("#payflow").submit();
              }, 0);
            });
          </script>
        </body>
      </html>
    EHTML

    content.html_safe
  end

  def return_link
    subdomain = Rails.configuration.front_end_uri.to_s
    protocol = subdomain == "localhost:3000/" ? "http" : "https"
    domain = subdomain == "localhost:3000/" ? "localhost:3090/" : "api.#{subdomain}"

    "#{protocol}://#{domain}api/payflow/postback"
  end

  def token_endpoint
    if %w[viatrm via-university].include?(client_subdomain)
      "https://pilot-payflowpro.paypal.com/"
    else
      "https://payflowpro.paypal.com/"
    end
  end
end
