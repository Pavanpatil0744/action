# frozen_string_literal: true

class Api::EventTravelerBatchActionsController < Api::BaseController
  def send_messages
    attachment_count = params[:message][:attachment_count].to_i
    attachments = []
    message = Message.new(message_params)

    attachment_count.times do |index|
      attachments << params[:message]["attachment#{index}"]
    end

    message.assign_attributes(attachments: attachments)

    return bad_request(message) unless message.save

    travelers = client_account.travelers.where(id: event_travelers.pluck(:user_id))
                              .with_role(:traveler)

    travelers.each do |traveler|
      SendMessage.call(admin: current_user, message: message, traveler: traveler)
    end

    SendGrid::SendMessageFromAdminMailers.call(
      admin: current_user,
      message: message,
      traveler_ids: travelers.ids
    )

    render json: MessageSerializer.new(message).serialized_json, status: :created
  end

  private

  def message_params
    params.require(:message).permit(:body, :subject)
  end

  def event_travelers
    if occasional_user?
      current_user.assigned_event_travelers
    else
      client_account.event_travelers
    end.where(id: params[:event_traveler_ids]).includes(:user)
  end
end
