# frozen_string_literal: true

class Api::CybersourceController < Api::BaseController
  skip_before_action :authenticate_user!

  before_action :find_submission, only: :create
  before_action :find_question, only: :create
  before_action :find_user, only: :create

  def create
    render html: redirect_html, status: :moved_permanently
  end

  def return_path
    key = params["key"]
    transaction_id = params["transactionId"]
    transaction_details = payment_service.retrieve_transaction_details(key, transaction_id)
    decision = transaction_details["decision"]
    success = decision == "ACCEPT"
    external_id = transaction_details["usersubmissionid"]
    question_id, submission_id, user_id = external_id.split("|", 3)
    question = Question.find_by_id(question_id)
    payment_response = PaymentResponse.find_or_initialize_by(
      question: question,
      submission_id: submission_id
    )
    user = User.find_by_id(user_id)

    payment_response.api_transaction = true
    payment_response.payment_status = success ? payment_status("paid") : payment_status("not_paid")
    payment_response.save

    payment_log = payment_response.payment_response_status_change_logs.create(
      notes: "Cybersource transaction",
      payment_status_id: payment_response.payment_status_id,
      status: payment_response.payment_status_identifier,
      transaction_id: transaction_details["transactionsignature"],
      transaction_response: decision,
      transaction_success: success,
      user_id: user&.id,
      user_email: user&.email,
      user_first_name: user&.first_name,
      user_last_name: user&.last_name
    )

    payment_log.create_payment_response_status_change_log_payload(payload: transaction_details)
    payment_service.confirm_transaction(key, transaction_id)

    render html: confirmation_html(success), status: :created
  end

  private

  def confirmation_html(success)
    content = success ? <<~EHTML
      <html>
        <head>
          <style>
            h3 {text-align: center;}
            p {text-align: center;}
            div {text-align: center;}
          </style>
        </head>
        <body>
          <br>
          <h3>Transaction Complete</h3>
          <p>Your payment has been processed.</p>
          <p>Return to your application or form and refresh the page to update your transaction information and payment status.</p>
          <div>
            <button type="button" onclick="javascript:window.close()">Close</button>
          </div>
        </body>
      </html>
    EHTML
    : <<~EHTML
      <html>
        <head>
          <style>
            h3 {text-align: center;}
            p {text-align: center;}
            div {text-align: center;}
          </style>
        </head>
        <body>
          <br><br>
          <h3>Credit Card Processing Failure</h3>
          <p>There was an issue processing your payment, and your fees have not been paid.</p>
          <p>If you'd like to attempt again, return to your Via TRM application or form and click 'Make a Payment' to re-start the payment process.</p>
          <p>If you think you've reached this message in error, reach out to your bank or credit card provider for more information.</p><br>
          <div>
            <button type="button" onclick="javascript:window.close()">Close</button>
          </div>
        </body>
      </html>
    EHTML

    content.html_safe
  end

  def find_question
    @question = @submission.template.cybersource_questions.find_by_id(params[:question_id])

    not_found unless @question
  end

  def find_submission
    @submission = Submission.find_by_id(params[:submission_id])

    not_found unless @submission
  end

  def find_user
    @user = User.find_by_id(params[:user_id])

    not_found unless @user
  end

  def form_html
    form_variables = {
      amt: @question.cost ? format("%5.2f", @question.cost).strip : "0.00",
      descriptor: "PIC_VIATRM",
      email: @user.email,
      externalID: "#{@question.question_id}|#{@submission.id}|#{@user.id}",
      firstName: @user.profile_first_name,
      lastName: @user.profile_last_name,
      returnPath: "#{request.protocol}#{request.host}/api/cybersource/return_path"
    }

    form_variables.collect { |k, v| "<input type='hidden' name='#{k}' value='#{v}'/>" }.join("\n")
  end

  def payment_gateway_url
    "#{ENV['GVSU_PAYMENT_BASE_URL']}/tools/paymentprocessor/payment.htm"
  end

  def payment_service
    @payment_service ||= GvsuPaymentService.new
  end

  def payment_status(identifier)
    PaymentStatus.find_by_identifier(identifier)
  end

  def redirect_html
    content = <<~EHTML
      <html>
        <head>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        </head>
        <body>
          <p>Please wait. Transfering you to payment processor...</p>
          <form id="cybersource" name="cybersource" action="#{payment_gateway_url}" method="POST">
            #{form_html}
          </form>
          <script type="text/javascript">
            $(document).ready(function () {
              setTimeout(function () {
                $("#cybersource").submit();
              }, 0);
            });
          </script>
        </body>
      </html>
    EHTML

    content.html_safe
  end
end
