# frozen_string_literal: true

class Api::ProgramBatchActionsController < Api::BaseController
  def update
    return unauthorized unless internal

    failures = []
    updated_programs = []

    programs.each do |program|
      if program.update(program_params)
        update_all_report_program_associations(program)

        updated_programs << program
      else
        failures << program.title
      end
    end

    render json: build_response(updated_programs, failures), status: :ok
  end

  def add_program_ranges
    return unauthorized unless internal

    failures = []
    updated_programs = []
    program_ranges = programs.map { |program| program.program_ranges.new(program_range_params) }

    program_ranges.each do |program_range|
      if program_range.save
        update_all_report_program_associations(program_range.program)

        updated_programs << program_range.program
      else
        failures << {
          title: program_range.program_title,
          errors: program_range.errors.full_messages
        }
      end
    end

    render json: build_response(updated_programs, failures), status: :created
  end

  def authorize_programs
    if internal
      return render json: { message: "Unable to authorize internal programs" }, status: :bad_request
    end

    failures = []
    authorized_program_range_ids = []
    updated_programs = []

    programs.each do |program|
      program_id = program.id

      if client_account.programs.exists?(id: program_id)
        failures << program.title
      else
        updated_programs << program

        program_range_ids = program.program_range_ids
        authorized_program_range_ids += program_range_ids

        client_account.client_account_programs.create(program_id: program_id)
        client_account_info.add_authorized_program_ranges(program_range_ids)
      end
    end

    update_client_specific_report_program_associations(
      programs.map(&:id),
      authorized_program_range_ids
    )

    render json: build_response(updated_programs, failures), status: :ok
  end

  def deauthorize_programs
    if internal
      return render json: {
        message: "Unable to deauthorize internal programs"
      }, status: :bad_request
    end

    failures = []
    deauthorized_program_range_ids = []
    updated_programs = []

    programs.each do |program|
      program_id = program.id
      client_account_program = client_account.client_account_programs
                                             .find_by(program_id: program_id)

      if client_account_program
        updated_programs << program

        program_range_ids = program.program_range_ids
        deauthorized_program_range_ids += program_range_ids

        client_account_info.remove_authorized_program_ranges(program_range_ids)
        client_account_program.destroy
      else
        failures << program.title
      end
    end

    update_client_specific_report_program_associations(
      programs.map(&:id),
      deauthorized_program_range_ids
    )

    render json: build_response(updated_programs, failures), status: :ok
  end

  def add_edit_program_brochure_section
    failures = []
    updated_programs = []
    section_title = params[:program_brochure_section][:title]
    section_description = params[:program_brochure_section][:description]

    programs =
      if occasional_user?
        current_user.assigned_program
      else
        client_account.programs
      end.where(id: params[:program_ids])

    programs.each do |program|
      brochure_section = program.program_brochure_sections.find_or_initialize_by(program_id: program.id, client_account_id: client_account_id)

      brochure_section.title = section_title
      brochure_section.description = section_description

      if brochure_section.save
        ReportProgram.find_by(client_account_id: client_account_id, program_id: program.id)
                     &.update(sync_required: true)
        UpdateReportProgram.perform_in(10.seconds, client_account_id, program.id)
        updated_programs << program.id
      else
        failure << program.id
      end
    end

    render json: { updated: updated_programs, failure: failures }, status: :ok
  end

  def delete_program_brochure_section
    failures = []
    updated_programs = []

    programs =
      if occasional_user?
        current_user.assigned_program
      else
        Program.all
      end.where(id: params[:program_ids])

    programs.each do |program|
      if program.program_brochure_sections.where(client_account_id: client_account_id).first&.destroy
        ReportProgram.find_by(client_account_id: client_account_id, program_id: program.id)
                     &.update(sync_required: true)
        UpdateReportProgram.perform_in(10.seconds, client_account_id, program.id)
        updated_programs << program.id
      else
        failures << program.id
      end
    end

    render json: { updated: updated_programs, failure: failures }, status: :ok
  end

  private

  def program_params
    params.require(:program).permit(:status)
  end

  def program_range_params
    params.require(:program_range).permit(
      :cost_embedded_url,
      :cost_notes,
      :currency_code,
      :end_date,
      :high_cost_cents,
      :low_cost_cents,
      :max_course_credits,
      :min_course_credits,
      :name,
      :start_date,
      :term_name_id,
      :use_exact_dates,
      :weeks,
      taggables_attributes: :tag_id
    )
  end

  def internal
    @internal ||= params[:source] == "internal"
  end

  def programs
    @programs ||= if internal && occasional_user?
                    current_user.assigned_programs
                  elsif internal
                    client_account.internal_programs
                  elsif client_account.enrollment? && !occasional_user?
                    if params[:source] == "authorized"
                      client_account.authorized_programs
                    else
                      Program.all_authorizable
                    end
                  else
                    Program.none
                  end.where(id: params[:program_ids]).includes(
                    :primary_client_account,
                    :program_amenities,
                    :program_eligibility,
                    :program_review,
                    :program_scholarship_info,
                    :subject_areas,
                    program_languages: :language,
                    program_locations: :via_country,
                    program_ranges: :tags,
                    included_program_housings: :housing_type,
                    included_program_type_connections: :program_type,
                    program_contact: [user: %i[profile traveler_info]],
                    program_managers: [user: %i[profile traveler_info]]
                  )
  end

  def build_response(updated_programs, failures)
    ProgramSerializer.new(
      updated_programs,
      params: { client_account_id: client_account_id, source: params[:source] }
    ).to_hash.merge!({ failures: failures })
  end

  def update_all_report_program_associations(program)
    program_id = program.id

    ReportProgram.where(program_id: program_id).update_all(sync_required: true)
    ReportProgramRange.where(program_range_id: program.program_range_ids)
                      .update_all(sync_required: true)

    UpdateAllReportProgramAssociations.perform_async(program_id)
  end

  def update_client_specific_report_program_associations(program_ids, program_range_ids)
    ReportProgram.where(client_account_id: client_account_id, program_id: program_ids)
                 .update_all(sync_required: true)
    ReportProgramRange.where(
      client_account_id: client_account_id,
      program_range_id: program_range_ids
    ).update_all(sync_required: true)

    UpdateClientSpecificReportProgramAssociations.perform_async(
      client_account_id,
      program_ids,
      program_range_ids
    )
  end
end
