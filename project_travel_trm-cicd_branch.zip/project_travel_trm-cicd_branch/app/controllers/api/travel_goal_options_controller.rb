# frozen_string_literal: true

class Api::TravelGoalOptionsController < Api::BaseController
  def index
    render json: TravelGoal::TRAVEL_GOAL_OPTIONS, status: :ok
  end
end
