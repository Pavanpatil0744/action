# frozen_string_literal: true

class Api::Traveler::BaseController < ApplicationController
  before_action :authenticate_user!

  def custom_aliases
    ca_info = client.client_account_info

    {
      alias_enrollment: ca_info.alias_enrollment,
      alias_favorite: ca_info.alias_favorite,
      alias_favorites: ca_info.alias_favorites,
      alias_program: ca_info.alias_program,
      alias_programs: ca_info.alias_programs,
      alias_traveler: ca_info.alias_traveler,
      alias_travelers: ca_info.alias_travelers,
      alias_traveling: ca_info.alias_traveling,
      alias_unfavorite: ca_info.alias_unfavorite
    }
  end

  private

  def traveler
    @traveler ||= current_user
  end

  def client_account
    account_check

    @client_account ||= if current_user
                          current_user&.clients&.first
                        else
                          ClientAccount.find(
                            ClientAccountInfo.find_by(subdomain: derived_subdomain)
                                             .client_account_id
                          )
                        end
  end

  def client
    account_check

    @client ||= if current_user
                  current_user&.clients&.first
                else
                  ClientAccount.find(
                    ClientAccountInfo.find_by(subdomain: derived_subdomain).client_account_id
                  )
                end
  end

  def account_check
    return if current_user.nil?

    if current_user.clients.empty? && current_user.client_account
      ClientTraveler.find_or_create_by(
        user_id: current_user.id,
        client_account_id: current_user.client_account.id
      )
    elsif current_user.clients.empty? && current_user.client_account.nil?
      derived_client_account = ClientAccount.find(
        ClientAccountInfo.find_by(subdomain: derived_subdomain).client_account_id
      )

      ClientTraveler.find_or_create_by(
        user_id: current_user.id,
        client_account_id: derived_client_account.id
      )
    else
      return
    end
  end

  def derived_subdomain
    host = URI.parse(request.env["HTTP_ORIGIN"]).host

    host.split(".").first
  end

  def derived_domain
    front_end_uri = Rails.configuration.front_end_uri
    subdomain = client.client_account_info.subdomain

    "#{subdomain}.#{front_end_uri}"
  end

  def bad_request(model)
    render json: { errors: model.errors.full_messages }, status: :bad_request
  end

  def not_found
    render json: { message: "Resource not found" }, status: :not_found
  end

  def unauthorized
    render json: { message: "Please log in to continue" }, status: :unauthorized
  end
end
