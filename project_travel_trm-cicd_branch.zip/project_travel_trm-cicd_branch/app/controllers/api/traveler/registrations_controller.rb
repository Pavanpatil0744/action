# frozen_string_literal: true

class Api::Traveler::RegistrationsController < Devise::RegistrationsController
  DEFAULT_SIGNUP_SOURCE_DATA = { signup_source: "Self Registration" }.freeze

  before_action :check_client_account_state, :ensure_params_exist, only: :create

  def create
    new_user = User.new(user_params)

    if new_user.save
      new_user.add_role(:traveler)
      new_user.clients << client_account

      Traveler::Builder.new(new_user, signup_source_data).execute

      complete_invitation_for(new_user)
      sign_in(new_user)
      sync_events(new_user)

      SendGrid::SendNewAccountCreationMailers.call(
        client_account: client_account,
        traveler: new_user
      )

      traveler_id = new_user.id

      ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
      UpdateReportTraveler.perform_in(10.seconds, traveler_id)

      render json: {
        data: {
          client_feature_list: client_account.client_feature_list.attributes.except(
            "id",
            "client_account_id",
            "created_at",
            "updated_at"
          ),
          user: new_user
        },
        message: "Sign up successful",
        is_success: true
      }, status: :created
    else
      render json: {
        errors: new_user.errors.full_messages,
        is_success: false,
        data: {}
      }, status: :bad_request
    end
  end

  private

  def user_params
    params.require(:user).permit(:email, :password, :password_confirmation, :client_account_id)
  end

  def ensure_params_exist
    return if params[:user].present?

    render json: {
      message: "Missing parameters",
      is_success: false,
      data: {}
    }, status: :bad_request
  end

  def check_client_account_state
    return if client_account.active?

    render json: { error: "Client account is inactive" }, status: :bad_request
  end

  def client_account
    @client_account ||= ClientAccount.find(user_params[:client_account_id])
  end

  def complete_invitation_for(traveler)
    Traveler::CompleteInvitation.new(traveler, client_account.id, signup_source_data).execute
  end

  def signup_source_data
    @signup_source_data ||=
      begin
        Crypto::Secrets.new(Rails.application.secrets.secret_key_base)
                       .decrypt(source)
      rescue Crypto::InvalidPayload
        DEFAULT_SIGNUP_SOURCE_DATA
      end
  end

  def source
    params[:source]
  end

  def sync_events(user)
    EventTraveler.joins(:event)
                 .where("events.client_account_id = ? ", client_account.id)
                 .where(email: user.email, user_id: ["", nil])
                 .update_all(user_id: user.id)
  rescue StandardError => e
    puts e
  end
end
