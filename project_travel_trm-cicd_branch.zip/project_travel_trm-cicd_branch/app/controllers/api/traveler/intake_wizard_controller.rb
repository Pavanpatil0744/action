# frozen_string_literal: true

class Api::Traveler::IntakeWizardController < Api::Traveler::BaseController
  after_action :update_report_traveler, only: %i[
    update_advising
    update_financial_info
    update_passport
    update_preferred_program_countries
    update_preferred_program_housing
    update_program_length
    update_program_term
    update_program_type
    update_program_preference
    update_program_priorities
    update_program_support
    update_subject_areas
    update_travel_experience
    update_travel_goal
    update_traveler_info
    update_traveler_profile
    update_user_languages
  ]

  respond_to :json

  def get_intake
    profile = traveler.profile
    traveler_info = traveler.traveler_info
    advising = traveler_info.advising
    financial_info = traveler_info.financial_info
    receives_federal_financial_aid = financial_info&.receives_federal_financial_aid
    readonly = Integrations::ReadOnlyFieldFinder
               .find_read_only_fields_for(profile) + Integrations::ReadOnlyFieldFinder
               .find_read_only_fields_for(traveler_info)
    travel_certainty = traveler_info&.read_attribute("travel_certainty")
    travel_goal = traveler_info.travel_goal
    traveler_experience = traveler_info.travel_experience

    advisings = if advising
                  {
                    academic_credit: advising.academic_credit,
                    cost: advising.cost,
                    dietary_issues: advising.dietary_issues,
                    discrimination_identity_concern: advising.discrimination_identity_concern,
                    health_safety_issue: advising.health_safety_issue,
                    housing: advising.housing,
                    missing_out_at_home: advising.missing_out_at_home,
                    no_questions_concerns: advising.no_questions_concerns,
                    not_knowing_anyone: advising.not_knowing_anyone,
                    not_sure: advising.not_sure,
                    other: advising.other,
                    other_concern_question_text: advising.other_concern_question_text,
                    people_left_behind: advising.people_left_behind,
                    picking_a_program: advising.picking_a_program,
                    planning_time: advising.planning_time,
                    program_acceptance: advising.program_acceptance,
                    unsupportive_parent: advising.unsupportive_parent
                  }
                end

    funding_sources = if financial_info
                        {
                          financial_aid: financial_info.financial_aid,
                          fundraising_crowdfunding: financial_info.fundraising_crowdfunding,
                          job: financial_info.job,
                          not_sure: financial_info.not_sure,
                          other: financial_info.other,
                          other_financial_aid_text: financial_info.other_financial_aid_text,
                          parent_donor: financial_info.parent_donor,
                          personal_savings: financial_info.personal_savings,
                          scholarship_grant: financial_info.scholarship_grant
                        }
                      end

    passport = if traveler_info&.passport
                 {
                   status: traveler_info.passport.status,
                   alpha2: traveler_info.passport.alpha2
                 }
               end

    travel_experience = if traveler_experience&.has_left_home_country
                          {
                            africa: traveler_experience.africa,
                            antarctica: traveler_experience.antarctica,
                            asia: traveler_experience.asia,
                            australia: traveler_experience.australia,
                            europe: traveler_experience.europe,
                            has_left_home_country: "yes",
                            north_america: traveler_experience.north_america,
                            south_america: traveler_experience.south_america
                          }
                        elsif traveler_experience
                          { has_left_home_country: "no" }
                        end

    travel_goals = if travel_goal
                     {
                       become_independent: travel_goal.become_independent,
                       family_heritage: travel_goal.family_heritage,
                       have_adventure: travel_goal.have_adventure,
                       improve_job_prospects: travel_goal.improve_job_prospects,
                       learn_language: travel_goal.learn_language,
                       learn_new_skills: travel_goal.learn_new_skills,
                       leave_home: travel_goal.leave_home,
                       meet_people: travel_goal.meet_people,
                       new_places: travel_goal.new_places,
                       not_sure: travel_goal.not_sure,
                       see_friends: travel_goal.see_friends,
                       study_or_research: travel_goal.study_or_research,
                       other: travel_goal.other,
                       other_goal_text: travel_goal.other_goal_text
                     }
                   end

    respond_with(profile, traveler_info) do |format|
      format.json do
        render json: {
          advising: advisings,
          countries_of_citizenship: traveler_info.countries_of_citizenship,
          first_name: profile.first_name,
          financial_info: funding_sources,
          last_name: profile.last_name,
          passport: passport,
          readonly: readonly,
          receives_federal_financial_aid: receives_federal_financial_aid,
          school_name: traveler_info.school_name,
          signup_date: traveler.created_at,
          signup_source: traveler.signup_source,
          sso_traveler: SsoAuthentication.exists?(
            client_account_id: client.id,
            user_id: current_user.id
          ),
          travel_goals: travel_goals,
          travel_experience: travel_experience,
          travel_certainty: travel_certainty,
          traveler_type: traveler_info.traveler_type,
          primary_major: traveler_info.primary_major,
          primary_minor: traveler_info.primary_minor,
          honors_status: traveler_info.honors_status,
          pronoun: traveler_info.pronoun,
          year_in_school: traveler_info.year_in_school,
          grad_year: traveler_info.grad_year,
          cumulative_gpa: traveler_info.cumulative_gpa,
          veteran_status: traveler_info.veteran_status,
          first_generation_status: traveler_info.first_generation_status,
          intake_questions: IntakeQuestion.where(client_account_id: client.id).order(:order)
        }, status: :ok
      end
    end
  end

  def get_program_preferences
    traveler_info = traveler.traveler_info
    program_preference = ProgramPreference.find_or_create_by(traveler_info_id: traveler_info.id)
    preferred_support_level = PreferredSupportLevel.find_or_create_by(
      program_preference_id: program_preference.id
    )

    priority_names = {
      1 => "Subject Areas",
      2 => "Housing",
      3 => "Timing",
      5 => "Location",
      6 => "Language",
      7 => "Program Type"
    }

    program_types = program_preference.preferred_program_types.pluck(:program_type_id)
    other_program_type_text = program_preference.preferred_program_types
                                                .where("program_types.name = ?", "Other")
                                                .joins(:program_type)
                                                .pluck(:other_program_type_text).last
    program_length = {
      minimum_duration_weeks: program_preference.minimum_duration_weeks,
      maximum_duration_weeks: program_preference.maximum_duration_weeks
    }
    program_terms = program_preference.traveler_terms
    level_of_support = preferred_support_level.support_level
    language_immersion = program_preference.language_immersion
    user_languages = program_preference.user_languages.pluck(:iso_639_3)
    program_countries = program_preference.preferred_program_countries.pluck(:alpha2)
    program_housing = program_preference.preferred_program_housings.pluck(:housing_type_id)
                                        .reject { |h| h.to_s.empty? }
    other_program_housing_text = program_preference.preferred_program_housings
                                                   .where("housing_types.name = ?", "Other")
                                                   .joins(:housing_type)
                                                   .pluck(:other_program_housing_text).last
    subject_areas = program_preference.preferred_program_subject_areas.map(&:subject_area).compact
                                      .map(&:name)
    preferred_priorities = program_preference.preferred_program_priorities.joins(:priority)
                                             .where.not(priorities: { name: "Level of support" })
                                             .select(:priority_id, :ranking).order("ranking")

    priorities = preferred_priorities.map do |priority|
      {
        id: priority.priority_id,
        text: priority_names[priority.priority_id],
        value: priority.ranking
      }
    end

    respond_with(
      program_types,
      other_program_type_text,
      program_length,
      program_terms,
      level_of_support,
      user_languages,
      program_countries,
      program_housing,
      subject_areas,
      priorities
    ) do |format|
      format.json do
        render json: {
          program_types: program_types,
          other_program_type_text: other_program_type_text,
          program_length: program_length,
          program_terms: program_terms,
          level_of_support: level_of_support,
          language_immersion: language_immersion,
          user_languages: user_languages,
          program_countries: program_countries,
          program_housing: program_housing,
          other_program_housing_text: other_program_housing_text,
          subject_areas: subject_areas,
          priorities: priorities,
          housing_types: HousingType.all.map { |ht| { id: ht.id, name: ht.name } },
          all_program_types: ProgramType.all.map { |pt| { id: pt.id, name: pt.name, order: pt.order } }
        }, status: :ok
      end
    end
  end

  def update_traveler_profile
    profile = traveler.profile

    respond_with(profile) do |format|
      if profile.update(profile_params) &&
         traveler.update(
           first_name: profile_params[:first_name],
           last_name: profile_params[:last_name]
          )
        format.json { render json: [profile: profile, status: 200] }
      else
        format.json { render json: [errors: profile.errors, status: 400] }
      end
    end
  end

  def update_traveler_info
    traveler_info = traveler.traveler_info

    respond_with(traveler_info) do |format|
      if traveler_info.update(traveler_info_params)
        format.json { render json: [traveler_info: traveler_info, status: 200] }
      else
        format.json { render json: [errors: traveler_info.errors, status: 400] }
      end
    end
  end

  def update_advising
    advising = Advising.find_or_create_by(traveler_info: traveler.traveler_info)

    respond_with(advising) do |format|
      if advising.update(advising_params)
        format.json { render json: [advising: advising, status: 200] }
      else
        format.json { render json: [errors: advising.errors, status: 400] }
      end
    end
  end

  def update_financial_info
    financial_info = FinancialInfo.find_or_create_by(traveler_info: traveler.traveler_info)

    respond_with(financial_info) do |format|
      if financial_info.update(financial_info_params)
        format.json { render json: [financial_info: financial_info, status: 200] }
      else
        format.json { render json: [errors: financial_info.errors, status: 400] }
      end
    end
  end

  def update_travel_goal
    travel_goal = TravelGoal.find_or_create_by(traveler_info: traveler.traveler_info)

    respond_with(travel_goal) do |format|
      if travel_goal.update(travel_goal_params)
        format.json { render json: [travel_goal: travel_goal, status: 200] }
      else
        format.json { render json: [errors: travel_goal.errors, status: 400] }
      end
    end
  end

  def update_travel_experience
    travel_experience = TravelExperience.find_or_create_by(traveler_info: traveler.traveler_info)

    respond_with travel_experience do |format|
      if travel_experience.update(travel_experience_params)
        format.json { render json: [travel_experience: travel_experience, status: 200] }
      else
        format.json { render json: [errors: travel_experience.errors, status: 400] }
      end
    end
  end

  def update_program_type
    program_preference = ProgramPreference.find_or_create_by(traveler_info: traveler.traveler_info)
    old_program_types = program_preference.preferred_program_types.pluck(:id)
    program_types = []

    params[:program_types]&.each do |program_type|
      program_types << if program_type == 11
                         program_preference.preferred_program_types.new(
                           program_type_id: program_type,
                           other_program_type_text: params[:other_program_type_text]
                         )
                       else
                         program_preference.preferred_program_types.new(
                           program_type_id: program_type
                         )
                       end
    end

    respond_with(program_types) do |format|
      if program_types.each(&:save!)
        PreferredProgramType.delete(old_program_types)

        format.json { render json: [program_types: program_types, status: 200] }
      else
        format.json { render json: [errors: program_types.errors, status: 400] }
      end
    end
  end

  def update_program_preference
    program_preference = traveler.traveler_info.program_preference

    respond_with(program_preference) do |format|
      if program_preference.update(program_preference_params)
        format.json { render json: [program_preference: program_preference, status: 200] }
      else
        format.json { render json: [errors: program_preference.errors, status: 400] }
      end
    end
  end

  def update_user_languages
    traveler_info = traveler.traveler_info
    program_preference = traveler.traveler_info.program_preference
    old_user_languages = program_preference.user_languages.pluck(:id)
    user_languages = []

    params[:user_languages]&.each do |language|
      user_languages << program_preference.user_languages.new(
        traveler_info: traveler_info,
        iso_639_3: language
      )
    end

    respond_with(user_languages) do |format|
      if user_languages.each(&:save!) &&
         program_preference.update(language_immersion: params[:language_immersion])

        UserLanguage.delete(old_user_languages)

        format.json { render json: [user_languages: user_languages, status: 200] }
      else
        format.json { render json: [errors: user_languages.errors, status: 400] }
      end
    end
  end

  def update_passport
    passport = traveler.traveler_info.passport

    respond_with(passport) do |format|
      if passport.update(passport_params)
        format.json { render json: [passport: passport, status: 200] }
      else
        format.json { render json: [errors: passport.errors, status: 400] }
      end
    end
  end

  def update_program_length
    program_preference = traveler.traveler_info.program_preference

    respond_with(program_preference) do |format|
      if program_preference.update(program_length_params)
        format.json { render json: [program_preference: program_preference, status: 200] }
      else
        format.json { render json: [errors: program_preference.errors, status: 400] }
      end
    end
  end

  def update_preferred_program_countries
    program_preference = traveler.traveler_info.program_preference
    old_program_countries = program_preference.preferred_program_countries.pluck(:id)
    program_countries = []

    params[:program_countries]&.each do |alpha2|
      program_countries << program_preference.preferred_program_countries.new(alpha2: alpha2)
    end

    respond_with(program_countries) do |format|
      if program_countries.each(&:save!)
        PreferredProgramCountry.delete(old_program_countries)

        format.json { render json: [program_countries: program_countries, status: 200] }
      else
        format.json { render json: [errors: program_countries.errors, status: 400] }
      end
    end
  end

  def update_preferred_program_housing
    program_preference = traveler.traveler_info.program_preference
    old_program_housings = program_preference.preferred_program_housings.pluck(:id)
    program_housing = []

    params[:program_housing]&.each do |housing|
      program_housing << if housing == 6
                           program_preference.preferred_program_housings.new(
                             housing_type_id: housing,
                             other_program_housing_text: params[:other_program_housing_text]
                            )
                         else
                           program_preference.preferred_program_housings.new(
                             housing_type_id: housing
                           )
                         end
    end

    respond_with(program_housing) do |format|
      if program_housing.each(&:save!)
        PreferredProgramHousing.delete(old_program_housings)

        format.json { render json: [program_housing: program_housing, status: 200] }
      else
        format.json { render json: [errors: program_housing.errors, status: 400] }
      end
    end
  end

  def update_subject_areas
    program_preference = traveler.traveler_info.program_preference
    old_subject_areas = traveler.traveler_info.program_preference.preferred_program_subject_areas
                                .pluck(:id)
    subject_areas = []

    params[:subject_areas]&.each do |subject|
      subject_area = SubjectArea.find_by(name: subject)

      subject_areas << program_preference.preferred_program_subject_areas.new(
        subject_area: subject_area
      )
    end

    respond_with(subject_areas) do |format|
      if subject_areas.each(&:save!)
        PreferredProgramSubjectArea.delete(old_subject_areas)

        format.json { render json: [subject_areas: subject_areas, status: 200] }
      else
        format.json { render json: [errors: subject_areas.errors, status: 400] }
      end
    end
  end

  def update_program_priorities
    program_preference = traveler.traveler_info.program_preference
    old_program_priorities = program_preference.preferred_program_priorities.pluck(:id)
    preferred_program_priorities = []

    params[:preferred_program_priorities]&.each do |priority|
      preferred_program_priorities << program_preference.preferred_program_priorities.new(
        priority_id: priority["priority_id"],
        ranking: priority["ranking"]
      )
    end

    current_user.update_tracking if current_user && client_account

    respond_with(preferred_program_priorities) do |format|
      if preferred_program_priorities.each(&:save!)
        PreferredProgramPriority.delete(old_program_priorities)

        format.json do
          render json: [preferred_program_priorities: preferred_program_priorities, status: 200]
        end
      else
        format.json { render json: [errors: preferred_program_priorities.errors, status: 400] }
      end
    end
  end

  def update_program_support
    program_preference = traveler.traveler_info.program_preference
    preferred_support_level = program_preference.preferred_support_level

    respond_with(preferred_support_level) do |format|
      if preferred_support_level.update(program_support_params)
        format.json { render json: [preferred_support_level: preferred_support_level, status: 200] }
      else
        format.json { render json: [errors: preferred_support_level.errors, status: 400] }
      end
    end
  end

  def update_program_term
    program_preference = traveler.traveler_info.program_preference
    old_traveler_terms = traveler.traveler_info.program_preference.traveler_terms.pluck(:id)
    traveler_terms = []

    params[:traveler_terms]&.each do |term|
      traveler_terms << program_preference.traveler_terms.new(
        end_date: term["end_date"],
        start_date: term["start_date"]
      )
    end

    respond_with(traveler_terms) do |format|
      if traveler_terms.each(&:save!)
        TravelerTerm.delete(old_traveler_terms)

        format.json { render json: [traveler_terms: traveler_terms, status: 200] }
      else
        format.json { render json: [errors: traveler_terms.errors, status: 400] }
      end
    end
  end

  private

  def profile_params
    params[:profile].permit(:first_name, :last_name)
  end

  def traveler_info_params
    params[:traveler_info].permit(
      :home_institution,
      :intake_complete,
      :program_favorite_disclaimer_accepted,
      :program_match_complete,
      :school_name,
      :traveler_type,
      :travel_certainty,
      :primary_major,
      :primary_minor,
      :honors_status,
      :pronoun,
      :year_in_school,
      :grad_year,
      :cumulative_gpa,
      :veteran_status,
      :first_generation_status,
      countries_of_citizenship: []
    )
  end

  def advising_params
    params[:advising].permit(
      :academic_credit,
      :cost,
      :dietary_issues,
      :discrimination_identity_concern,
      :health_safety_issue,
      :housing,
      :missing_out_at_home,
      :no_questions_concerns,
      :not_knowing_anyone,
      :not_sure,
      :other,
      :other_concern_question_text,
      :people_left_behind,
      :picking_a_program,
      :planning_time,
      :program_acceptance,
      :unsupportive_parent
    )
  end

  def financial_info_params
    params[:financial_info].permit(
      :other_financial_aid_text,
      :personal_savings,
      :scholarship_grant,
      :parent_donor,
      :job,
      :fundraising_crowdfunding,
      :other,
      :financial_aid,
      :receives_federal_financial_aid,
      :not_sure
    )
  end

  def travel_goal_params
    params[:travel_goal].permit(
      :become_independent,
      :family_heritage,
      :have_adventure,
      :improve_job_prospects,
      :learn_language,
      :learn_new_skills,
      :leave_home,
      :meet_people,
      :new_places,
      :not_sure,
      :other,
      :other_goal_text,
      :see_friends,
      :study_or_research
    )
  end

  def travel_experience_params
    params[:travel_experience].permit(
      :africa,
      :antarctica,
      :asia,
      :australia,
      :europe,
      :has_left_home_country,
      :north_america,
      :south_america
    )
  end

  def program_preference_params
    params[:program_preference].permit(:language_immersion)
  end

  def passport_params
    params[:passport].permit(:alpha2, :status)
  end

  def program_length_params
    params[:program_length].permit(:maximum_duration_weeks, :minimum_duration_weeks)
  end

  def program_support_params
    params[:program_support].permit(:support_level)
  end

  def update_report_traveler
    traveler_id = traveler.id

    ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
    UpdateReportTraveler.perform_in(10.seconds, traveler_id)
  end
end
