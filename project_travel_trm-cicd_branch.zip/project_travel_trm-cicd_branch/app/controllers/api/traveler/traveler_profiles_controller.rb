# frozen_string_literal: true

require "date"

class Api::Traveler::TravelerProfilesController < Api::Traveler::BaseController
  respond_to :json

  before_action :set_values
  before_action :set_messages, only: %i[get_messages add_message check_message]

  def show
    render json: [
      custom_fields: custom_fields_information,
      info: @traveler_info,
      profile: @profile,
      passport_status: @passport,
      readonly: @readonly_fields,
      traveler_email: traveler.email
    ], status: :ok
  end

  def update
    custom_field_params = params[:custom_fields].compact

    update_custom_fields(custom_field_params) unless custom_field_params.empty?

    @passport.update(passport_params) unless passport_params.empty?
    @profile.update(profile_params) unless profile_params.empty?
    @traveler_info.update(traveler_profile_params) unless traveler_profile_params.empty?

    errors = @profile.errors.messages.merge(
      @traveler_info.errors.messages,
      @passport.errors.messages
    )
    traveler_id = traveler.id

    ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
    UpdateReportTraveler.perform_in(10.seconds, traveler_id)

    update_report_plan_user
    update_custom_field_reporting(traveler_id)

    respond_with(@traveler_info) do |format|
      if errors.empty?
        format.json do
          render json: [
            custom_fields: custom_fields_information,
            info: @traveler_info,
            profile: @profile,
            passport_status: @passport,
            readonly: @readonly_fields,
            status: 200
          ]
        end
      else
        format.json { render json: [errors, { status: 400 }] }
      end
    end
  end

  def update_custom_fields(custom_field_params)
    custom_field_params.each do |custom_field_id, custom_field_text|
      cft = traveler.custom_field_texts.find_or_initialize_by(custom_field_id: custom_field_id)
      custom_field = cft.custom_field

      next if custom_field.nil? || custom_field.private?

      cft.text = custom_field_text
      cft.save
    end
  end

  def get_traveler_details
    @events = traveler.events.includes(:event_travelers).all
    events = []

    @events.each do |event|
      sample = EventPresenter.new(event)
      event = event.as_json.merge(public_url: "#{derived_domain}visitor/events/#{event.id}")

      event[:attended] = if sample.attended_travelers.present? &&
                            sample.attended_travelers.map(&:user_id).include?(traveler.id)

                           "Attended"
                         else
                           "Not Attended"
                         end

      event[:registered] = if sample.registered_travelers.present? &&
                              sample.registered_travelers.map(&:user_id).include?(traveler.id)

                             "Registered"
                           else
                             "Not Registered"
                           end

      events << event
    end

    events&.uniq!

    program_rankings = Alguru.new(traveler, client.id).run rescue []

    program_ids = traveler.program_favorites.pluck(:program_id)
    favorite_programs = Program.where(id: program_ids).where(status: Program.statuses[:published])

    favorite_programs_json = []

    favorite_programs.each do |fp|
      background_photo_url = if fp.program_images.any?
                               fp.primary_program_image.original
                             else
                               fp.background_photo.url
                             end

      favorite_programs_json << fp.as_json.merge!(
        background_photo: background_photo_url,
        percent: traveler.traveler_info.program_matches,
        match_rank: (
          begin
            program_rankings.find { |rank| rank[fp.id] rescue false }[fp.id]
          rescue
            0
          end
        )
      )
    end

    sorted_favorite_programs = favorite_programs_json.sort_by do |program|
      program[:match_rank]
    end.reverse rescue favorite_programs

    render json: {
      events: events,
      applications: [],
      favorite_programs: sorted_favorite_programs,
      forms: []
    }, status: :ok
  end

  def get_traveler_preference
    program_preference = @traveler_info.program_preference || ProgramPreference.new
    priority_names = {
      1 => "Subject Areas",
      2 => "Housing",
      3 => "Timing",
      5 => "Location",
      6 => "Language",
      7 => "Program Type"
    }

    language_immersion = program_preference.language_immersion
    maximum_duration_weeks = program_preference.maximum_duration_weeks
    minimum_duration_weeks = program_preference.minimum_duration_weeks
    program_terms = program_preference.traveler_terms.pluck(:start_date, :end_date)
    program_types = program_preference.preferred_program_types.pluck(:program_type_id).compact

    user_languages = program_preference.user_languages.pluck(:iso_639_3).map do |ul|
      LanguageList::LanguageInfo.find(ul).name rescue ul
    end

    program_countries = program_preference.preferred_program_countries.pluck(:alpha2).reject do |h|
      h.to_s.empty?
    end

    program_housing = program_preference.preferred_program_housings.pluck(:housing_type_id)
    subject_areas = program_preference.preferred_program_subject_areas.includes(:subject_area)
                                      .map(&:subject_area).compact.map(&:name)
    preferred_priorities = program_preference.preferred_program_priorities.joins(:priority)
                                             .where.not(priorities: { name: "Level of support" })
                                             .select(:priority_id, :ranking).order("ranking")
    other_program_housing = program_preference.preferred_program_housings
                                              .pluck(:other_program_housing_text).compact

    priorities = preferred_priorities.map do |priority|
      {
        text: priority_names[priority.priority_id],
        ranking: priority.ranking,
        priority_id: priority.priority_id
      }
    end

    traveler_experience = @traveler_info.travel_experience
    financial_info = @traveler_info.financial_info
    travel_goal = @traveler_info.travel_goal

    travel_certainty = TravelerInfo::TRAVELER_CERTAINTIES[@traveler_info.travel_certainty.to_sym] if @traveler_info.travel_certainty

    travel_experience = if @traveler_info.travel_experience&.has_left_home_country
                          {
                            africa: traveler_experience.africa,
                            antarctica: traveler_experience.antarctica,
                            asia: traveler_experience.asia,
                            australia: traveler_experience.australia,
                            europe: traveler_experience.europe,
                            north_america: traveler_experience.north_america,
                            south_america: traveler_experience.south_america
                          }
                        end

    if financial_info
      funding_sources = {
        financial_aid: financial_info.financial_aid,
        fundraising_or_crowdfunding: financial_info.fundraising_crowdfunding,
        job: financial_info.job,
        not_sure: financial_info.not_sure,
        other: financial_info.other,
        parent_donor: financial_info.parent_donor,
        personal_savings: financial_info.personal_savings,
        scholarship_grant: financial_info.scholarship_grant
      }
    end

    financial_aid = case financial_info&.receives_federal_financial_aid
                    when "yes"
                      "Yes"
                    when "no"
                      "No"
                    when "not_sure"
                      "Not Sure"
                    else
                      ""
                    end

    render json: {
      program_types: program_types.map do |id|
        (ProgramType.find(id) rescue nil)&.name.eql?("Other") ?
          "Other (#{program_preference.preferred_program_types
                                      .find_by_program_type_id(id)
                                      .other_program_type_text})" :
        (ProgramType.find(id) rescue nil)&.name
      end.sort,
      minimum_duration_weeks: minimum_duration_weeks,
      maximum_duration_weeks: maximum_duration_weeks,
      program_terms: program_terms,
      language_immersion: language_immersion,
      user_languages: user_languages,
      program_countries: program_countries,
      program_housing: program_housing.map { |id| (HousingType.find(id) rescue nil)&.name },
      subject_areas: subject_areas,
      priorities: priorities,
      advising: @traveler_info.advising,
      financial_info: funding_sources,
      financial_aid: financial_aid,
      travel_goal: travel_goal,
      travel_experience: travel_experience,
      travel_certainty: travel_certainty,
      other_program_housing: other_program_housing,
      signup_date: traveler&.created_at,
      signup_source: traveler&.profile&.signup_source,
      percent: @traveler_info.program_matches
    }, status: :ok
  end

  def get_messages
    receipts = @receipts.map do |receipt|
      {
        subject: receipt.message.subject,
        body: receipt.message.body,
        attachments: receipt.message.attachments.map do |attach|
          { url: attach.url, name: attach.file.filename, size: attach&.file.size
        }
        end,
        created_at: receipt.message.created_at,
        message_id: receipt.id,
        receiver_id: receipt.receiver_id,
        receiver_type: receipt.receiver_type,
        notification_id: receipt.notification_id,
        is_read: receipt.is_read,
        trashed: receipt.trashed,
        deleted: receipt.deleted,
        author: receipt&.notification&.sender&.name || "Deleted Admin User",
        sender: receipt&.notification&.sender || "Deleted Admin User",
        sender_avatar: (
          begin
            receipt.notification.sender.profile.avatar.url
          rescue StandardError
            "default_avatar"
          end
        )
      }
    end

    traveler_assigned_admins = @assigned_admins.map do |admin|
      admin_user = admin.client_user

      next unless admin_user

      {
        name: admin_user.name,
        admin_id: admin_user.id,
        avatar: (
          begin
            admin_user.profile.avatar.url
          rescue StandardError
            "default_avatar"
          end
        ),
        rest: admin_user
      }
    end

    available_admins = client&.admin_users&.includes(:profile) || []
    assigned_admin_ids = @assigned_admins.pluck(:client_user_id)

    traveler_available_admins = available_admins.reject { |a| assigned_admin_ids.include?(a.id) }
                                                .map do |admin_user|
      next unless admin_user

      {
        name: admin_user.name,
        admin_id: admin_user.id,
        avatar: (
          begin
            admin_user.profile.avatar.url
          rescue StandardError
            "default_avatar"
          end
        ),
        rest: admin_user
      }
    end

    render json: {
      assigned_admins: traveler_assigned_admins.compact,
      available_admins: traveler_available_admins.compact,
      current_user_avatar: (
        begin
          current_user.profile.avatar.url
        rescue StandardError
          "default_avatar"
        end
      ),
      messages: receipts
    }, status: :ok
  end

  def get_header
    traveler = @user
    traveler_applications = traveler.application_submissions.includes(program_range: :program)
    events = traveler.event_travelers

    apps = traveler_applications.map do |app|
      {
        title: app.program_range.program&.title,
        start_date: app.program_range.start_date,
        end_date: app.program_range.end_date,
        program: app.program_range.program,
        program_range: app.program_range,
        status: app.status
      }
    end

    render json: [
      FirstName: traveler.profile.first_name,
      LastName: traveler.profile.last_name,
      Email: traveler.email,
      PreferredFirstName: @traveler_info.preferred_first_name,
      PreferredLastName: @traveler_info.preferred_last_name,
      Avatar: traveler.profile.avatar.url,
      Events: {
        registered_total: events.count(&:confirmed),
        attended_total: events.count(&:attended)
      },
      ChevronStatuses: (
        begin
          tracking_steps = traveler.client_travelers.flat_map do |ct|
            ct.tracking_steps.map(&:step)
          end

          tracking_steps.map { |t| t.gsub("_", " ") }
        rescue
          []
        end
      ),
      LastLogin: traveler.last_sign_in_at,
      TotalProgramFavorites: traveler.program_favorites.count,
      Applications: apps
    ], status: :created
  end

  def add_message
    @conversation = nil unless @conversation.present?

    attachment_count = params[:message][:attachment_count].to_i
    attachments = []
    message = Message.new(body: message_params[:body], subject: message_params[:subject])

    attachment_count.times do |index|
      attachments << params[:message]["attachment#{index}"]
    end

    message.assign_attributes(attachments: attachments)

    if message.save
      message_body = message.body
      message_subject = message.subject

      if @conversation
        Conversation.traveler_reply(@conversation, traveler, message)

        admin_ids = @conversation.participants.find_all { |p| p.is_a?(User) && p.admin_role? }
                                 .map(&:id)

        SendGrid::SendMessageFromTravelerToAdminMailer.perform_async(
          admin_ids,
          client.logo.url,
          message_body,
          message_subject,
          traveler.id,
          traveler.full_name_or_email
        )
      else
        @conversation = traveler.send_message(
          @default_message_recipients,
          message_body,
          message_subject,
          false,
          message.attachments.map(&:file)
        ).notification.conversation

        assigned_admins = client.assigned_admins.assignments_for(traveler)

        assigned_admins.each { |aa| @conversation.add_participant(aa.client_user) }

        @conversation.add_participant(client)

        @default_message_recipients.each do |dmr|
          client.assigned_admins.find_or_create_by(client_user: dmr, traveler: traveler)
        end

        SendGrid::SendMessageFromTravelerToAdminMailer.perform_async(
          @default_message_recipients.pluck(:id),
          client.logo.url,
          message_body,
          message_subject,
          traveler.id,
          traveler.full_name_or_email
        )
      end

      @receipts = @conversation.receipts_for(traveler) if @receipts.empty?

      receipt = @receipts.map do |r|
        {
          subject: r.message.subject,
          body: r.message.body,
          attachments: r.message.attachments,
          created_at: r.message.created_at,
          message_id: r.id,
          receiver_id: r.receiver_id,
          receiver_type: r.receiver_type,
          notification_id: r.notification_id,
          is_read: r.is_read,
          trashed: r.trashed,
          deleted: r.deleted,
          author: r.notification.sender.name,
          sender: r.notification.sender
        }
      end.first

      r = @receipts.find_by(id: receipt[:message_id])

      r.update_attribute(:is_read, false) if r&.is_read

      render json: { receipt: receipt, status: 200 }, status: :ok
    else
      render json: message.errors, status: :bad_request
    end
  end

  def check_message
    message = @receipts.find_by(id: params[:message_id])

    return unless message

    if message.is_read == false
      message.update_attribute(:is_read, true)

      render json: message, status: :ok
    else
      render json: message, status: :created
    end
  end

  private

  def form_deadline(trm_template_id, form_grouping_ids)
    ProgramRangeTrmTemplate.submitted_forms(trm_template_id, form_grouping_ids).first.form_grouping
                           .deadline
  end

  def set_messages
    @conversation = Conversation.conversation(traveler, client) rescue nil

    @receipts = if @conversation
                  @conversation.receipts_for(traveler).includes(:notification, message: :sender)
                               .order(created_at: :desc)
                else
                  Mailboxer::Receipt.none
                end

    @assigned_admins = client.assigned_admin_profiles_by_traveler(traveler.id) rescue []
  end

  def set_values
    logger.info("current_user is: #{current_user.email}")

    @default_message_recipients = client_account.default_message_recipients
    @profile = traveler.profile
    @traveler_info = traveler.traveler_info
    @passport = if @traveler_info.passport.nil?
                  @traveler_info.create_passport
                else
                  @traveler_info.passport
                end

    @readonly_fields = Integrations::ReadOnlyFieldFinder.new.find_locked_fields_for(traveler)
  end

  def form_finder
    @form_finder ||= Traveler::Forms::Finder.new(@user, client_account)
  end

  def updater
    Traveler::ProfileDetailsUpdate.new(@traveler_info)
  end

  def message_params
    params.require(:message).permit(:subject, :body, :attachments)
  end

  def traveler_profile_params
    tp_params = params[:traveler_profile]
    tp_params = tp_params.each do |k, v|
      tp_params[k] = v.strip if %w[preferred_first_name preferred_last_name].include?(k)
    end

    ActionController::Parameters.new(tp_params).permit(
      Traveler::TravelerInfoParams::PERMITTED - @readonly_fields
    )
  end

  def profile_params
    profile_params = params[:profile]
    profile_params = profile_params.each { |k, v| profile_params[k] = v.strip }

    ActionController::Parameters.new(profile_params).permit(
      Traveler::ProfileParams::PERMITTED - @readonly_fields
    )
  end

  def passport_params
    params[:passport].permit(Traveler::PassportParams::PERMITTED - @readonly_fields)
  end

  def custom_fields_information
    custom_fields = client.custom_fields.traveler_viewable
    synced_fields = client.custom_integration_fields.traveler_viewable
    combined_fields = (custom_fields + synced_fields).sort_by(&:title)

    serialized_custom_fields = combined_fields.map do |custom_field|
      synced_custom_field = custom_field.instance_of?(CustomIntegrationField)

      {
        id: custom_field.id,
        answer: if synced_custom_field
                  @traveler_info.custom_fields[custom_field.name] if @traveler_info.custom_fields
                else
                  custom_field.custom_field_texts.find_by(traveler_id: traveler.id)&.text
                end,
        integration_field: synced_custom_field,
        title: custom_field.title
      }
    end
    serialized_custom_fields
  end

  def update_custom_field_reporting(traveler_id)
    report_submissions = ReportSubmission.where(user_id: traveler_id)
    report_submissions.update_all(sync_required: true)

    report_submissions.each do |report_submission|
      UpdateReportSubmission.perform_in(10.seconds, report_submission.submission_id)
    end

    report_plan_users = ReportPlanUser.where(user_id: traveler_id)
    report_plan_users.update_all(sync_required: true)

    report_plan_users.each do |report_plan_user|
      UpdateReportPlanUser.perform_in(10.seconds, report_plan_user.plans_users_id)
    end
  end

  def update_report_plan_user
    plans_users = PlansUser.where(user_id: traveler.id)

    plans_users.each do |plan_user|
      ReportPlanUser.find_by_plans_users_id(plan_user.id)&.update(sync_required: true)
      UpdateReportPlanUser.perform_in(10.seconds, plan_user.id)
    end
  end
end
