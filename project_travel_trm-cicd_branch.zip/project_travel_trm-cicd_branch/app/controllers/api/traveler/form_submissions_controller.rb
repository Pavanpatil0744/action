# frozen_string_literal: true

class Api::Traveler::FormSubmissionsController < Api::Traveler::BaseController
  respond_to :json
  before_action :verify_submission

  def show
    if submission.user_id == current_user.id
      render json: {
        submission: submission,
        program_name: submission.program_range.program.title
      }
    else
      render json: {
        error: :form_submission_does_not_belong_to_traveler
      }, status: :not_acceptable
    end
  end

  def update
    result = ::FormSubmissions::Service.new.update(submission.id, current_user, params)

    if result.success?
      render json: submission
    else
      render json: { errors: result }, status: :unprocessable_entity
    end
  end

  private

  def submission
    @submission ||= FormSubmission.find(params[:id])
  end

  def verify_submission
    render json: { error: :could_not_find_form_submission }, status: :not_acceptable unless submission
  end
end
