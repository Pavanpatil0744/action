class Api::Traveler::DashboardController < Api::Traveler::BaseController
  respond_to :json

  def header
    traveler = User.find(params[:id])
    client_account = ClientAccountInfo.find_by(id: 4).client_account
    info = traveler.traveler_info
    traveler_applications = traveler.traveler_applications
    events = traveler.event_travelers
    apps = traveler_applications.map do |app|
      { title: app.client_account_application.name,
        start_date: app.program_range.start_date,
        status: app.tapp_status }
    end
    form_finder = Traveler::Forms::Finder.new(traveler, client_account)

    render json: [
      FirstName: traveler.profile.first_name,
      LastName: traveler.profile.last_name,
      PreferredFirstName: info.preferred_first_name,
      PreferredLastName: info.preferred_last_name,
      Avatar: traveler.profile.avatar,
      Events: { registered_total: events.count(&:confirmed), attended_total: events.count(&:attended) },
      ChevronStatuses: traveler.client_travelers.map { |ct| ct.tracking_steps.map(&:step) }.flatten,
      LastLogin: traveler.last_sign_in_at,
      TotalProgramFavorites: traveler.program_favorites.count,
      Applications: apps,
      TotalForms: form_finder.forms.count,
      CompletedForms: form_finder.form_submissions(&:completed).count,
      TotalPayments: traveler_applications.map { |tapp| tapp.tapp_payments.count }.sum,
      CompletedPayments: traveler_applications.map { |tapp| tapp.tapp_payments.select(&:paid?) }.sum
    ], status: :created
  end
end
