# frozen_string_literal: true

class Api::Traveler::UsersController < Api::Traveler::BaseController
  # after_action :update_auth_token_expiration, only: :get_current_user

  def get_current_user
    client_info = client_account.client_account_info
    client_sso_configuration = client_account.sso_configuration
    profile = traveler.profile
    traveler_info = traveler.traveler_info

    render json: {
      admin_access: traveler.admin_role?,
      tag_agreement: traveler.tap_agreement,
      admin_role: traveler.admin_role?,
      admin_sign_in: traveler.admin_sign_in,
      allow_traveler_deferral: client.allow_traveler_deferral,
      allow_traveler_sign_up: client.allow_traveler_sign_up,
      avatar: traveler&.profile&.avatar&.url,
      branding_theme: get_theme,
      client_account_state: client_account.state.description,
      client_account_name: client_account.org_name,
      client_account_safe_check_custom_text: client_info&.safe_check_custom_text,
      client_feature_list: client_account.client_feature_list.attributes.except(
        "id",
        "client_account_id",
        "created_at",
        "updated_at"
      ),
      custom_aliases: custom_aliases,
      freemium: client.free? ? true : false,
      intake_complete: traveler_info.intake_complete,
      logout_url: client_sso_configuration ? client_sso_configuration.logout_url : "",
      org_timezone: client_info ? client_info.org_timezone : "US/Mountain",
      other_admin_limit: client_account.other_admin_limit,
      permissions: [],
      profile_info: { first_name: profile&.first_name, avatar: traveler&.profile&.avatar&.url },
      program_favorite_disclaimer_accepted: traveler_info.program_favorite_disclaimer_accepted,
      program_match_complete: traveler_info.program_match_complete,
      role: current_user.role_name,
      safe_check_enrollment_status: traveler_info&.safe_check_enrollment_status,
      safe_check_phone_number: traveler_info&.safe_check_phone_number,
      show_intake: client_info.show_intake,
      enable_active_term_name_filtering: client.client_account_info.enable_active_term_name_filtering,
      show_program_match: client_info.show_program_match,
      super_user_limit: client_account.super_user_limit,
      use_custom_aliases: client_info.use_custom_aliases,
      user: traveler
    }, status: :ok, methods: %i[client_user_role? is_traveler?]
  end

  def traveler_header
    if traveler
      render json: {
        email: traveler.email,
        name: traveler.name,
        first_name: traveler.profile.first_name,
        last_name: traveler.profile.last_name,
        avatar: traveler&.profile&.avatar,
        inactive: traveler.inactive
      }
    else
      render json: { error: "User with ID #{params[:id]} not found." }
    end
  end

  def update_user_info
    profile = traveler.profile
    traveler_info = traveler.traveler_info

    avatar = if params[:profile][:avatar] != ""
               params[:profile][:avatar]
             else
               profile.avatar
             end

    profile.assign_attributes(profile_params)
    traveler.assign_attributes(avatar: avatar)

    traveler_info.assign_attributes(title: params['traveler_info']['title']) if params['traveler_info'].present?

    if profile.save! && traveler.save! && traveler_info.save!
      update_report_traveler(traveler.id)
      update_report_plan_user(traveler.id)

      render json: { profile: profile, status: 200 }
    else
      render json: profile.errors, status: :unprocessable_entity
    end
  end

  def activate_inactivate
    traveler.update_attribute(:inactive, params[:user][:inactive])

    update_report_traveler(traveler.id)
    update_report_plan_user(traveler.id)

    render json: :ok, status: 200
  end

  def new_messages
    unread = traveler.mailbox.conversations(read: false, mailbox_type: "inbox").order(:updated_at).limit(100)
    unread_messages = []

    unread.includes(receipts: %i[message notification]).each do |c|
      receipt = c.receipts_for(traveler).order(created_at: :desc)
                 .select { |r| r.is_read == false }.first

      next unless receipt

      sender = receipt.notification.sender

      next unless sender

      unread_messages << {
        attachments: receipt.message.attachments.map do |attachment|
          { url: attachment.url, name: attachment.file.filename }
        end,
        author: sender.name,
        body: Sanitize.clean(receipt.message.body),
        created_at: receipt.message.created_at,
        created_at_date: receipt.message.created_at.to_date,
        deleted: receipt.deleted,
        is_read: receipt.is_read,
        message_id: receipt.id,
        notification_id: receipt.notification_id,
        receiver_id: receipt.receiver_id,
        receiver_type: receipt.receiver_type,
        sender: sender,
        sender_avatar_url: sender.profile.avatar.url,
        subject: receipt.message.subject,
        trashed: receipt.trashed
      }
    end

    render json: unread_messages, status: :ok
  end

  def mark_as_read
    unread = traveler.mailbox.inbox.order(:updated_at).select { |c| c.is_unread?(traveler) }
    receipts = []

    unread.each { |c| receipts << c.receipts_for(traveler).order(created_at: :desc) }

    receipt = receipts.flatten.select { |r| r.id == params[:message_id] }.first

    receipt.update_attribute(:is_read, true) if receipt.is_read == false

    unread_messages = []

    unread.each do |c|
      unread_messages << c.receipts_for(traveler).order(created_at: :desc)
                          .select { |r| r.is_read == false }
                          .map do |r|
        {
          attachments: r.message.attachments.map do |attachment|
            { url: attachment.url, name: attachment.file.filename }
          end,
          author: r.notification.sender.name,
          body: Sanitize.clean(r.message.body),
          created_at: r.message.created_at,
          created_at_date: r.message.created_at.to_date,
          deleted: r.deleted,
          is_read: r.is_read,
          message_id: r.id,
          notification_id: r.notification_id,
          receiver_id: r.receiver_id,
          receiver_type: r.receiver_type,
          sender: r.notification.sender,
          subject: r.message.subject,
          trashed: r.trashed
        }
      end
    end

    render json: unread_messages, status: :ok
  rescue StandardError => e
    render json: e, status: :unprocessable_entity
  end

  def mark_all_as_read
    unread = traveler.mailbox.inbox.order(:updated_at).select { |c| c.is_unread?(traveler) }
    receipts = []

    unread.each { |c| receipts << c.receipts_for(traveler).order(created_at: :desc) }
    Mailboxer::Receipt.where(id: receipts.flatten.map(&:id), is_read: false).update_all(is_read: true)
    render json: { message: "All messages are marked as read" }, status: :ok
  rescue StandardError => e
    render json: e, status: :unprocessable_entity
  end

  def update_last_visited_product
    unless %w(via_abroad via_international via_contracts).include? last_visited_product_params[:last_visited_product]
      render json: { message: "Invalid input", type: "error" } and return
    end
    if current_user.update(last_visited_product_params)
      render json: {
        message: "Last visited product updated",
        type: "success"
      }, status: :ok
    else
      render json: { message: "Last visited product not updated", type: "error" }
    end
  end

  private

  def get_theme
    if client_account
      ca_info = client_account.client_account_info

      {
        themes: {
          theme_color_accent: ca_info.theme_color_accent,
          theme_color_dark: ca_info.theme_color_dark,
          theme_color_light: ca_info.theme_color_light
        },
        logo: {
          theme_logo: ca_info.logo.url
        }
      }
    elsif traveler.client_account
      ca_info = traveler.client_account.client_account_info

      {
        themes: {
          theme_color_accent: ca_info.theme_color_accent,
          theme_color_dark: ca_info.theme_color_dark,
          theme_color_light: ca_info.theme_color_light
        },
        logo: {
          theme_logo: ca_info.logo.url
        }
      }
    else
      {
        themes: {
          theme_color_accent: "#DD602A",
          theme_color_dark: "#00277C",
          theme_color_light: "#65A5E0"
        },
        logo: {
          theme_logo: "/uploads/client_account_info/logo/62/client_logo.jpg"
        }
      }
    end
  end

  def profile_params
    profile_params = params[:profile]
    profile_params = profile_params.each { |k, v| profile_params[k] = v.strip }
    readonly_fields = Integrations::ReadOnlyFieldFinder.new.find_locked_fields_for(traveler)

    ActionController::Parameters.new(profile_params).permit(
      Traveler::ProfileParams::PERMITTED - readonly_fields
    )
  end

  def update_report_traveler(traveler_id)
    ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
    UpdateReportTraveler.perform_in(10.seconds, traveler_id)
  end

  def update_report_plan_user(user_id)
    plans_users = PlansUser.where(user_id: user_id)

    plans_users.each do |plan_user|
      ReportPlanUser.find_by_plans_users_id(plan_user.id)&.update(sync_required: true)
      UpdateReportPlanUser.perform_in(10.seconds, plan_user.id)
    end
  end

  def last_visited_product_params
    params.require(:user).permit(:last_visited_product)
  end

  # def update_auth_token_expiration
  #   return unless request.headers["HTTP_X_USER_TOKEN"].present?

  #   auth_token = VtAuthenticationToken.find_by(
  #     user_id: current_user.id,
  #     token: request.headers["HTTP_X_USER_TOKEN"]
  #   )

  #   AuthenticationToken::TokenService.new(current_user).update_auth_token_expiration(auth_token)
  # end
end
