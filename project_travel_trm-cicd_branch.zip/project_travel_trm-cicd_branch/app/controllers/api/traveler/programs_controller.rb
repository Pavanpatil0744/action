# frozen_string_literal: true

class Api::Traveler::ProgramsController < Api::Traveler::BaseController
  respond_to :json

  def programs
    traveler = client.travelers.find(params[:id])
    client_id = client.id
    client_info = client.client_account_info

    blocksize = 500
    n = params[:block].to_i
    offset = n * blocksize

    programs = if client_info&.allow_authorized_programs?
                 authorized_program_ids =
                   client.client_account_programs.joins(:program)
                         .where.not(programs: { primary_client_account_id: client.id })
                         .where(programs: { is_authorizable: true, status: 1 })
                         .pluck("DISTINCT programs.id")

                 Program.includes(
                   :primary_client_account,
                   { program_contact: :user },
                   :program_highlight,
                   :program_housings,
                   :program_languages,
                   :program_locations,
                   :program_ranges,
                   :program_supports,
                   :subject_areas
                  ).internal_programs(client_id).or(id: authorized_program_ids)
               else
                 Program.includes(
                   :primary_client_account,
                   { program_contact: :user },
                   :program_highlight,
                   :program_housings,
                   :program_languages,
                   :program_locations,
                   :program_ranges,
                   :program_supports,
                   :subject_areas
                 ).internal_programs(client_id)
               end

    favorites = traveler.favorite_programs.pluck(:id).compact
    empty_array = []

    program_match_percentages

    programs_with_associations =
      programs.distinct.order(id: :desc).limit(blocksize).offset(offset).map do |program|
        program_ranges = program.program_ranges.in_the_future.order(:start_date).as_json

        if program.primary_client_account_id != client.id
          program_ranges.each do |program_range|
            pr = client.program_ranges.find(program_range["id"])
            suitcase = client.suitcase_by_program_range(pr)

            program_range.merge!(
              {
                "alternate" => suitcase&.allow_alternates,
                "alternate_all_programs" => suitcase&.allow_alternates,
                "deadline" => suitcase&.application_deadline,
                "decision_release_date" => nil,
                "name" => suitcase&.name,
                "provider_deadline" => pr.deadline,
                "provider_term_name" => pr.term_title,
                "term_name_id" => suitcase&.term_name_id
              }
            )
          end
        else
          program_ranges.each do |program_range|
            pr = client.program_ranges.find(program_range["id"])

            program_range.merge!({ "name" => pr.term_title })
          end
        end

        program_contact = program.program_contact&.user if program.primary_client_account == client

        if program_contact
          program_contact_name = "#{program_contact.first_name} #{program_contact.last_name}"
          program_contact_name = program_contact.email if program_contact_name.blank?
        end

        program.attributes.merge(
          background_photo: program.background_url,
          subject_areas: program.subject_areas.pluck(:name).compact,
          program_ranges: program_ranges,
          start_date: program_ranges.min_by { |pr| pr["start_date"] },
          end_date: program_ranges.max_by { |pr| pr["end_date"] },
          program_length: program_ranges.map { |pr| pr["weeks"] }.compact,
          program_contact: program_contact_name,
          program_locations: program.program_locations_array,
          program_languages: program.program_languages.pluck(:iso_639_3).compact,
          housing_types: HousingType.where(id: program.program_housings.where(included: true)
                                    .pluck(:housing_type_id).compact).pluck(:name).compact,
          school: program.primary_client_account.org_name,
          program_types: program.program_types.map(&:name).compact,
          provider: program.primary_client_account.org_name,
          program_supports: program.program_supports.pluck(:support_level_id).compact,
          description: program.program_highlight&.text,
          percent: (
            begin
              traveler.traveler_info.program_preference.preferred_program_priorities.empty? ?
                0 :
              @program_match_percentages.find { |pr| pr[program.id] }[program.id]
            rescue StandardError => e
              puts "Error in program_match_percentages, defaulting to 0 value: #{e.message}."

              0
            end
          ),
          included_length: program.program_supports.included.count
        )
      end

    respond_with(programs_with_associations, favorites) do |format|
      format.json do
        render json: {
          programs: programs_with_associations,
          favorites: favorites,
          percent_match: empty_array,
          administrators: empty_array,
          all_program_types: ProgramType.all.map { |pt| { id: pt.id, name: pt.name, order: pt.order } },
          housing_types: HousingType.pluck(:name),
          status: 200
        }
      end
    end
  end

  def show
    program_ranges = program.program_ranges.in_the_future.order(:start_date)

    ranges = program_ranges.map do |range|
      { application: range.client_account_application, range: range }
    end

    render json: [
      program,
      programTypes: program.program_types.map(&:name).compact,
      programMap: program.program_map.included,
      Provider: ProgramPresenter.new(program, client).connections_list,
      ProgramHighlight: program.program_highlight,
      ProgramLocation: program.program_location_highlight,
      Locations: program.program_locations_array,
      Coordinates: [
        program.program_locations.in_order.map { |l| { data: { lat: l.lat, lon: l.lng } } }
      ],
      ProgramRanges: program_ranges,
      Ranges: ranges,
      ProgramActivity: program.program_activities,
      ProgramAmenities: program.program_amenities.map { |sample| sample.amenity.name },
      ProgramAmenitiesIncluded: program.program_amenities.included.map do |sample|
        sample.amenity.name
      end,
      ProgramAmenitiesExcluded: program.program_amenities.excluded.map do |sample|
        sample.amenity.name
      end,
      ProgramCourses: program.program_courses,
      ProgramReview: program.program_review,
      ProgramSupport: program.program_supports.pluck(:support_level).compact,
      ProgramSupportIncluded: program.program_supports.included.pluck(:support_level).compact,
      ProgramSupportExcluded: program.program_supports.excluded.pluck(:support_level).compact,
      ProgramEligibility: program.program_eligibility,
      ProgramScholarship: program.program_scholarship_info,
      ProgramLanguages: program.languages,
      ProgramHousing: program.program_housings.map do |sample|
        { housing_type: sample.housing_type, included: sample.included }
      end,
      ProgramSubjects: program.program_subjects.pluck(:subject_area).compact,
      ProgramActivities: program.program_activities,
      ProgramExcursions: program.program_excursions,
      ProgramFavorite: program.program_favorites.find_by(user: traveler),
      Authorized: program.primary_client_account_id != client.id
    ], status: :created
  end

  def get_program_hash
    return not_found unless program

    authorized = program.primary_client_account_id != client.id
    program_ranges = program.program_ranges.in_the_future.order(:start_date).as_json

    program_ranges.each do |program_range|
      pr = client.program_ranges.find(program_range["id"])

      next unless pr

      if authorized
        suitcase = client.suitcase_by_program_range(pr)

        program_range.merge!(
          {
            "alternate" => suitcase&.allow_alternates,
            "alternate_all_programs" => suitcase&.allow_alternates,
            "deadline" => suitcase&.application_deadline,
            "decision_release_date" => nil,
            "name" => suitcase&.name,
            "provider_deadline" => pr.deadline,
            "provider_term_name" => pr.term_title,
            "term_name_id" => suitcase&.term_name_id
          }
        )
      else
        program_range.merge!({ "name" => pr.term_title })
      end

      application_timeframe_violation = if traveler.application_exists?(pr)
                                          false
                                        else
                                          traveler.application_timeframe_violation?(pr)
                                        end

      program_range.merge!(
        { "application_timeframe_violation" => application_timeframe_violation }
      )
    end

    ranges = program_ranges.map do |range|
      pr = client.program_ranges.find(range["id"])

      template = if authorized
                   client.suitcase_application_template_by_program_range(pr)
                 else
                   pr.application_template
                 end

      application_timeframe_violation = if traveler.application_exists?(pr)
                                          false
                                        else
                                          traveler.application_timeframe_violation?(pr)
                                        end

      {
        application: template,
        application_timeframe_violation: application_timeframe_violation,
        range: range
      }
    end

    serialized_program = program.as_json

    if program.program_images.any?
      serialized_background_photo = program.serialized_primary_program_image

      serialized_program.merge!({ background_photo: serialized_background_photo })
    end

    render json: {
      program: serialized_program,
      program_attachments: program.program_attachments.in_order,
      program_types: program.program_types.sort_by(&:order).map(&:name),
      program_map: program.program_map.included,
      provider: program.primary_client_account&.org_name,
      program_highlight: program.program_highlight,
      program_location: program.program_location_highlight,
      locations: program.program_locations_array_of_objects,
      coordinates: [
        program.program_locations.in_order.map { |l| { data: { lat: l.lat, lon: l.lng } } }
      ],
      program_ranges: program_ranges,
      ranges: ranges,
      program_activity: program.program_activities,
      program_amenities: program.displayable_amenities,
      program_amenities_with_id: (
        program.program_amenities.included + program.program_amenities.excluded
      ).sort.map { |paie| program_amenity_json(paie) },
      program_amenities_included: program.program_amenities.included.map do |sample|
        sample.amenity.name
      end,
      program_amenities_excluded: program.program_amenities.excluded.map do |sample|
        sample.amenity.name
      end,
      program_courses: program.program_courses,
      program_review: program.program_review || ProgramReview.new,
      program_support: program.program_supports.map(&:support_level).compact,
      program_support_included: program.program_supports.included.map(&:support_level).compact,
      program_support_excluded: program.program_supports.excluded.map(&:support_level).compact,
      program_eligibility: program.program_eligibility,
      program_scholarship: program.program_scholarship_info,
      program_languages: program.languages,
      program_housing: program.program_housings.map do |sample|
        { housing_type: sample.housing_type, included: sample.included }
      end,
      program_subjects: program.program_subjects.map(&:subject_area).compact.sort_by(&:name),
      program_activities: program.program_activities,
      program_excursions: program.program_excursions,
      program_favorite: program.program_favorites.find_by(user: traveler),
      publish_status: program.status,
      authorized: authorized,
      internal_program: program.primary_client_account.id == client.id,
      program_opportunities: program.program_opportunities.map do |add_on|
        { id: add_on.id, info: add_on.info }
      end,
      organization_description: (
        begin
          authorized ?
            ClientAccountInfo.find_by_client_account_id(program.primary_client_account_id)
                             .description :
          client.client_account_info.description
        rescue
          nil
        end
      ),
      program_locations: program.program_locations.in_order.map do |pl|
        {
          id: pl.id,
          alpha2: pl.alpha2,
          city: pl.city,
          lat: pl.lat,
          lng: pl.lng,
          continent: pl.continent,
          country_common_name: pl.country_common_name,
          county_or_region: pl.county_or_region,
          formatted_address: pl.formatted_address,
          google_place_id: pl.google_place_id,
          image_url: pl.image_url,
          locality: pl.location,
          program_id: pl.program_id,
          postal_code: pl.postal_code,
          postal_code_suffix: pl.postal_code_suffix,
          state_or_province: pl.state_or_province,
          state_or_province_code: pl.state_or_province_code,
          street: pl.street,
          street_number: pl.street_number,
          time_zone: pl.time_zone,
          time_zone_offset: pl.time_zone_offset
        }
      end,
      program_administrators: program.program_managers.map do |pm|
        user = pm.user
        user_id = user.id

        {
          id: pm.id,
          email: user.email,
          name: user.preferred_name,
          program_contact: program.program_contact.user_id == user_id,
          program_id: pm.program_id,
          user_id: user_id
        }
      end,
      pactivities: program.pactivities,
      pexcursions: program.pexcursions,
      padd_ons: program.padd_ons,
      pcourses: program.pcourses,
      alternate_setting: client.alternate_setting,
      academic_notes: program.academic_notes,
      activity_notes: program.activity_notes,
      host_organization: program.host_organization,
      host_organization_notes: program.host_organization_notes,
      housing_notes: program.housing_notes,
      location_notes: program.location_notes,
      home_campus: client.org_name,
      program_brochure_section: program.program_brochure_sections.where(client_account_id: client.id).select('id, title, description').first || {}
    }, status: :created
  end

  def program_brochure_details
    return not_found unless program

    authorized = program.primary_client_account_id != client.id
    program_ranges = program.program_ranges.in_the_future.order(:start_date).as_json
    ranges = []

    program_ranges.each do |program_range|
      pr = client.program_ranges.find(program_range["id"])

      next unless pr

      if authorized
        suitcase = client.suitcase_by_program_range(pr)

        program_range.merge!(
          {
            "deadline" => suitcase&.application_deadline,
            "name" => suitcase&.name,
            "term_name_id" => suitcase&.term_name_id
          }
        )

        template = client.suitcase_application_template_by_program_range(pr)
      else
        program_range.merge!({ "name" => pr.term_title })
        template = pr.application_template
      end

      application_timeframe_violation = if traveler.application_exists?(pr)
                                          false
                                        else
                                          traveler.application_timeframe_violation?(pr)
                                        end

      program_range.merge!(
        { "application_timeframe_violation" => application_timeframe_violation }
      )

      ranges << {
        application: template,
        application_timeframe_violation: application_timeframe_violation,
        range: program_range
      }
    end

    program_user = program.program_contact&.user

    if program_user.present?
      program_contact = {
        id: program_user&.id,
        first_name: program_user&.first_name,
        last_name: program_user&.last_name,
        email: program_user&.email
      }
    end

    serialized_program = program.as_json

    ppi = program.primary_program_image

    serialized_program.merge!({
      background_photo: ppi&.background,
      program_list_img_url: ppi&.list
    })

    render json: {
      program: serialized_program,
      program_attachments: program.program_attachments.in_order,
      program_types: program.program_types.sort_by(&:order).map(&:name),
      program_map: program.program_map&.included,
      program_highlight: program.program_highlight,
      program_location: program.program_location_highlight,
      locations: program.program_locations,
      coordinates: [
        program.program_locations.in_order.map { |l| { data: { lat: l.lat, lon: l.lng } } }
      ],
      ranges: ranges,
      program_amenities_included: program.program_amenities.included.map do |sample|
        sample.amenity.name
      end,
      program_amenities_excluded: program.program_amenities.excluded.map do |sample|
        sample.amenity.name
      end,
      program_eligibility: program.program_eligibility,
      program_scholarship: program.program_scholarship_info,
      program_languages: program.languages,
      program_housing: program.program_housings.map do |sample|
        { housing_type: sample.housing_type, included: sample.included }
      end,
      program_subjects: program.program_subjects.map(&:subject_area).compact.sort_by(&:name),
      publish_status: program.status,
      authorized: authorized,
      internal_program: program.primary_client_account.id == client.id,
      org_timezone: client.try(:client_account_info)&.org_timezone,
      organization_description: (
        begin
          authorized ?
            ClientAccountInfo.find_by_client_account_id(program.primary_client_account_id)
                             .description :
          client.client_account_info.description
        rescue
          nil
        end
      ),
      academic_notes: program.academic_notes,
      alternate_setting: client.alternate_setting,
      home_campus: client.org_name,
      pactivities: program.pactivities,
      pexcursions: program.pexcursions,
      padd_ons: program.padd_ons,
      pcourses: program.pcourses,
      program_contact: program_contact,
      housing_notes: program.housing_notes,
      location_notes: program.location_notes,
      host_organization: program.host_organization,
      host_organization_notes: program.host_organization_notes,
      activity_notes: program.activity_notes,
      provider: program.primary_client_account.org_name,
      program_review: program.program_review || ProgramReview.new,
      program_favorite: program.program_favorites.find_by(user: traveler),
      program_administrators: program.program_managers.map do |pm|
        user = pm.user
        user_id = user.id

        {
          id: pm.id,
          email: user.email,
          name: user.preferred_name,
          program_contact: program.program_contact.user_id == user_id,
          program_id: pm.program_id,
          user_id: user_id
        }
      end,
      program_brochure_section: program.program_brochure_sections.where(client_account_id: client.id).select('id, title, description').first || {}
    }, status: 200
  end

  def get_favorite
    program = client.programs.find(params[:program_id])

    render json: traveler.favorite_programs.include?(program), status: :created
  end

  def get_favorite_all
    render json: traveler.favorite_programs.pluck(:id), status: :created
  end

  def create_favorite
    program = Program.find(params[:favorite_id])
    favorite = traveler.program_favorites.new(program_id: params[:favorite_id])

    successful_save = begin
                        favorite.save
                      rescue ActiveRecord::RecordNotUnique
                        false
                      end

    if successful_save
      traveler.update_tracking

      send_authorized_favorite_program_mailers(params[:favorite_id])
      track_activity(0, program)

      update_report_traveler(traveler.id)

      render json: {
        favorites: traveler.favorite_programs.pluck(:id).compact,
        is_success: true,
        messages: "Program Favorited"
      }, status: :ok
    else
      render json: {
        is_success: false,
        messages: "Favorite Failed"
      }, status: :unprocessable_entity
    end
  end

  def delete_favorite
    favorite = traveler.program_favorites.find_by(program_id: params[:favorite_id])

    if favorite&.destroy
      update_report_traveler(traveler.id)

      render json: {
        favorites: traveler.favorite_programs.pluck(:id).compact,
        is_success: true,
        messages: "Program Favorite Destroyed"
      }, status: :ok
    else
      render json: {
        is_success: false,
        messages: "Unable to find and destroy favorite"
      }, status: :unprocessable_entity
    end
  end

  def favorite_program
    program_id = program.id
    favorite = traveler.program_favorites.find_or_initialize_by(program_id: program_id)

    favorite.new_record? ? favorite.save : favorite.destroy

    traveler.update_tracking

    track_activity(0, program)

    update_report_traveler(traveler.id)

    render json: { favorite: traveler.program_favorites.exists?(program_id: program_id) }
  end

  def get_traveler_percent_match_one
    if traveler&.traveler_info
      render json: traveler.traveler_info.program_matches, status: :created
    else
      render json: [], status: :ok
    end
  end

  def get_program_contacts
    contacts = ProgramContact.where(program_id: params[:id])
    contact_info = if contacts
                     contacts.map do |e|
                       {
                         info: User.where(id: e.user_id).map do |cc|
                           {
                             id: cc.id,
                             email: cc.email,
                             avatar: (cc.profile.avatar.url rescue "default_avatar")
                           }
                         end << Profile.where(user_id: e.user_id).map do |pp|
                           {
                             first_name: pp.first_name,
                             last_name: pp.last_name,
                             phone_number: pp.phone_number
                           }
                         end << e.client_user_info&.job_title
                       }
                     end
                   else
                     Role.includes(:users).where(default_message_recipient: true)
                   end

    render json: contact_info, status: :created
  end

  def get_program_opportunity
    program_opportunity = ProgramOpportunity.where(program_id: params[:id]).select(:id, :info)

    render json: program_opportunity, status: :created
  end

  def get_program_stats
    background_photo = if program.program_images.any?
                         program.serialized_primary_program_image
                       else
                         program.background_photo
                       end

    render json: [
      BackgroundPhoto: background_photo,
      ProgramLocationCity: program_location.city,
      ProgramLocationAlpha2: program_location.alpha2,
      ProgramType: ProgramTypeConnection.find_by(program: program, included: true)&.program_type,
      ProgramRanges: program.program_ranges,
      SubjectArea: program.program_subjects.select(&:included?)
    ], status: :created
  end

  def get_program_amenities_included
    render json: [program.program_amenities.included.map { |pa| pa.amenity.name }], status: :created
  end

  def get_program_amenities_excluded
    render json: [program.program_amenities.excluded.map { |pa| pa.amenity.name }], status: :created
  end

  def get_program_about
    render json: [
      LanguageImmersion: program.language_immersion,
      ProgramLanguage: ProgramLanguage.where(program: program).pluck(:iso_639_3).compact,
      HousingTypes: ProgramHousing.where(program: program).included.map do |ph|
        ph.housing_type.name
      end,
      ProgramCourses: ProgramCourse.where(program: program).pluck(:name).compact,
      ProgramActivities: ProgramActivity.where(program: program).pluck(:info).compact,
      ProgramExcursion: ProgramExcursion.where(program: program).pluck(:info).compact,
      SupportLevels: ProgramSupport.where(program: program).included.map do |ps|
        ps.support_level.name
      end,
      ProgramOpportunities: ProgramOpportunity.where(program: program).select do |po|
        po.info.present?
      end.map(&:info)
    ], status: :created
  end

  def get_program_eligibility
    render json: [EligibilityInfo: program.program_eligibility.eligibility_info], status: :created
  end

  def get_program_map
    program_map = program.program_map

    render json: [
      ProgramMapIncluded?: program_map.included?,
      ProgramMapAddress: program_map.address
    ], status: :created
  end

  def get_org_authorized_program_settings
    render json: [
      suitcases: SuitcaseSerializer.new(client.suitcases)
    ], status: :created
  end

  def request_to_apply
    contacts = []
    message = Message.new(
      subject: "Student has requested to apply to #{program.title} but no term is currently available.",
      body: ""
    )
    program_contact = program.program_contact&.user
    program_provider = ClientAccount.find(program.primary_client_account_id)

    contacts << program_contact if program_contact&.active?

    if contacts.empty?
      program_provider.default_message_recipients.each do |message_recipient|
        contacts << message_recipient
      end
    end

    if message.save
      conversation = Conversation.conversation(traveler, client)
      message_body = message.body
      message_subject = message.subject

      if program_provider.id == client.id
        if conversation
          contacts.each do |contact|
            conversation.add_participant(contact) unless conversation.is_participant?(contact)
          end

          Conversation.traveler_reply(conversation, traveler, message)
        else
          conversation = traveler.send_message(
            contacts,
            message_body,
            message_subject
          ).notification.conversation

          client.assigned_admins.assignments_for(traveler).each do |aa|
            conversation.add_participant(aa.client_user)
          end

          conversation.add_participant(client)
        end

        contacts.each do |contact|
          client.assigned_admins.find_or_create_by(client_user: contact, traveler: traveler)
        end

        SendGrid::SendInternalRequestToApplyMailer.perform_async(
          contacts.map(&:id),
          client.logo.url,
          program.title,
          traveler.id,
          traveler.email,
          traveler.full_name_or_email
        )
      else
        if conversation
          Conversation.traveler_reply(conversation, traveler, message)
        else
          default_message_recipients = client.default_message_recipients

          conversation = traveler.send_message(
            default_message_recipients,
            message_body,
            message_subject
          ).notification.conversation

          client.assigned_admins.assignments_for(traveler).each do |aa|
            conversation.add_participant(aa.client_user)
          end

          conversation.add_participant(client)

          default_message_recipients.each do |dmr|
            client.assigned_admins.find_or_create_by(client_user: dmr, traveler: traveler)
          end
        end

        if program_provider.active?
          SendGrid::SendAuthorizedRequestToApplyMailers.call(
            client_account: client,
            contacts: contacts,
            program: program,
            traveler: traveler
          )
        end


      end

      track_activity(2, program)
      render json: { code: 200 }, status: :ok
    else
      render json: { code: 400 }, status: :bad_request
    end
  end

  def ask_question
    contacts = []
    message = Message.new(
      subject: "Question from #{traveler.name} about #{program.title}",
      body: params[:question]
    )
    message_body = message.body
    program_contact = program.program_contact&.user
    program_provider = ClientAccount.find(program.primary_client_account_id)

    contacts << program_contact if program_contact&.active?

    if contacts.empty?
      program_provider.default_message_recipients.each do |message_recipient|
        contacts << message_recipient
      end
    end

    if message.save
      conversation = Conversation.conversation(traveler, client)
      message_body = message.body
      message_subject = message.subject

      if program_provider.id == client.id
        if conversation
          contacts.each do |contact|
            conversation.add_participant(contact) unless conversation.is_participant?(contact)
          end

          Conversation.traveler_reply(conversation, traveler, message)
        else
          conversation = traveler.send_message(
            contacts,
            message_body,
            message_subject
          ).notification.conversation

          client.assigned_admins.assignments_for(traveler).each do |aa|
            conversation.add_participant(aa.client_user)
          end

          conversation.add_participant(client)
        end

        contacts.each do |contact|
          client.assigned_admins.find_or_create_by(client_user: contact, traveler: traveler)
        end

        SendGrid::SendInternalProgramQuestionMailer.perform_async(
          contacts.map(&:id),
          client.logo.url,
          message_body,
          program.title,
          traveler.id,
          traveler.email,
          traveler.full_name_or_email
        )
      else
        if conversation
          Conversation.traveler_reply(conversation, traveler, message)
        else
          default_message_recipients = client.default_message_recipients

          conversation = traveler.send_message(
            default_message_recipients,
            message_body,
            message_subject
          ).notification.conversation

          client.assigned_admins.assignments_for(traveler).each do |aa|
            conversation.add_participant(aa.client_user)
          end

          conversation.add_participant(client)

          default_message_recipients.each do |dmr|
            client.assigned_admins.find_or_create_by(client_user: dmr, traveler: traveler)
          end
        end

        if program_provider.active?
          SendGrid::SendAuthorizedProgramQuestionMailers.call(
            client_account: client,
            contacts: contacts,
            message_body: message_body,
            program: program,
            traveler: traveler
          )
        end
      end

      track_activity(1, program, message_body)

      render json: message.as_json.merge!(code: 200), status: :created
    else
      render json: message.errors.as_json.merge!(code: 400), status: :bad_request
    end
  end

  private

  def program
    @program ||= client.programs.includes(
      :program_activities,
      { program_amenities: :amenity },
      :program_courses,
      :program_excursions,
      { program_housings: :housing_type },
      :program_languages,
      :program_opportunities,
      { program_ranges: :trm_application_template },
      { program_subjects: :subject_area },
      { program_supports: :support_level }
    ).find_by_id(params[:id])
  end

  def program_match_percentages
    @program_match_percentages ||= Traveler::AlguruMatchUpdate.new(traveler.traveler_info, client).execute
  end

  def program_amenity_json(program_amenity)
    amenity = program_amenity.amenity

    {
      id: program_amenity.id,
      category: amenity.amenity_category_display_name,
      name: amenity.name,
      amenity_id: program_amenity.amenity_id
    }
  end

  def update_report_traveler(traveler_id)
    ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
    UpdateReportTraveler.perform_in(10.seconds, traveler_id)
  end

  def contacts(program)
    return @contacts if @contacts.present?

    program_contact = program.program_contact&.user
    program_provider = ClientAccount.find(program.primary_client_account_id)

    @contacts = []
    @contacts << program_contact if program_contact&.active?

    if @contacts.empty?
      program_provider.default_message_recipients.each do |message_recipient|
        @contacts << message_recipient
      end
    end

    @contacts
  end

  def send_authorized_favorite_program_mailers(program_id)
    program = Program.find_by_id(program_id)

    return if program.internal?(client_account) || !program.primary_client_account.active?

    SendGrid::SendAuthorizedFavoriteProgramMailers.call(
      contacts: contacts(program),
      program: program,
      traveler: traveler,
      client_account: client_account
    )
  end

  def track_activity(action, program, message_body = nil)
    action_time = Time.now.utc
    program_countries = program.via_countries.compact.map(&:name).join(", ")

    ViaConnectAction.create(
      action_date: action_time.to_date,
      action_time: action_time,
      action: action,
      message: message_body,
      user_id: traveler.id,
      user_preferred_first_name: traveler.preferred_first_name,
      user_first_name: traveler.first_name,
      user_last_name: traveler.last_name,
      user_email: traveler.email,
      home_campus: client_account.org_name,
      program_name: program.title,
      program_provider: program.primary_client_account.org_name,
      source: "Via TRM",
      internal: program.internal?(client_account),
      program_id: program.id,
      program_countries: program_countries,
      student_id: traveler.student_id
    )
  end
end
