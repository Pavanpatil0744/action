# frozen_string_literal: true

class Api::TrackingStepOptionsController < Api::BaseController
  def index
    render json: submission_tracking_steps, status: :ok
  end

  private

  def submission_tracking_steps
    SubmissionTrackingStep.in_order.pluck(:name).reject { |step| step == "Transferred" }
  end
end
