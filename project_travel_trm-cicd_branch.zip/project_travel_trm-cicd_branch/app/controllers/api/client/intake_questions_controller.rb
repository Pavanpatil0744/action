# frozen_string_literal: true

class Api::Client::IntakeQuestionsController < Api::Client::BaseController
  def index
    intake_questions = IntakeQuestion.where(client_account_id: client.id).order(:order)

    render(
      json: { show_intake: client.show_intake, intake_questions: IntakeQuestionSerializer.new(intake_questions) },
      status: :ok
    )
  end

  def update_setting
    client.client_account_info.update(show_intake: params[:show_intake])

    params[:intake_questions].each do |question|
      intake_question = IntakeQuestion.find_by_id(question[:id])

      next unless intake_question

      intake_question.update(
        name: question[:name],
        enabled: question[:enabled],
        required: question[:required],
        order: question[:order]
      )
    end

    render json: { message: 'Settings updated successfully'}, status: :ok
  end
end
