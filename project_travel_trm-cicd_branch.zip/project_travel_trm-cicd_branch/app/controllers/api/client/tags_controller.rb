# frozen_string_literal: true

class Api::Client::TagsController < Api::Client::BaseController
  def index
    tags = client.tags.program_range_tags
    tags = tags.not_archived unless ['true', true].include?(params[:all])
    tags = natural_sort(tags)

    render json: tags.map { |tag| response_object(tag) }
  end

  def create
    tags = client.tags.create(tag_params[:tags])

    success = []
    failure = []

    tags.each do |tag|
      object = response_object(tag)

      if tag.errors.blank?
        success << object
      else
        failure << object.merge!(errors: tag.errors.full_messages)
      end
    end

    render json: { tags: { success: success, failure: failure } }
  end

  def update
    success = []
    failure = []

    tag = client.tags.program_range_tags.find(params[:id])
    tag.update(update_params)
    object = response_object(tag)

    program_ids = tag.program_ids | tag.alternate_program_ids
    program_range_ids = tag.alternate_program_range_ids | tag.alternate_program_ids

    update_client_specific_report_program_associations(program_ids, program_range_ids)

    if tag.errors.blank?
      success << object
    else
      failure << object.merge!(errors: tag.errors.full_messages)
    end

    render json: object
  end

  def archived
    tags = client.tags.program_range_tags.archived

    render json: tags.map { |tag| response_object(tag) }
  end

  def get_available_tags
    tags = client.tags.program_range_tags.not_archived
    pagination = { active_page: params[:page].to_i, per_page: 10, total: tags.count }

    render json: {
      tags: natural_sort(tags).map { |tag| response_object(tag) },
      pagination: pagination
    }, status: :ok
  end

  def paginated_tags
    tags = client.tags.program_range_tags.not_archived
    pagination = { active_page: params[:page].to_i, per_page: 10, total: tags.count }
    paginated_tags = tags.paginate(page: params[:page], per_page: 10)

    render json: { pagination: pagination, tags: paginated_tags.map { |tag| response_object(tag) } }
  end

  def batch_add_tags
    programs = client.programs.find(batch_add_tags_params[:program_ids])
    tags = client.tags.program_range_tags.not_archived.where(id: batch_add_tags_params[:tag_ids])

    programs.each do |program|
      ranges = if batch_add_tags_params[:apply_filter]
                 program.program_ranges.in_range(batch_add_tags_params[:filters])
               else
                 program.program_ranges
               end

      ranges.each do |range|
        tags.each do |tag|
          Taggable.find_or_create_by(program_range_id: range.id, tag_id: tag.id)
        end
      end

      update_client_specific_report_program_associations([program.id], ranges.map(&:id))
    end

    render json: { success: "Great! Your selected terms have been updated." }, status: :ok
  rescue
    render json: {
      error: "The Terms you selected were not updated. Try again or contact support@via-trm.com"
    }, status: :bad_request
  end

  private

  def natural_sort(tags)
    tags.sort_by { |e| e.name.split(/(\d+)/).map { |a| a =~ /\d+/ ? a.to_i : a } }
  end

  def tag_params
    unless params[:taggable].blank?
      params[:taggable][:tags].each do |param|
        param.merge!(client_account_id: client.id, tag_type: "ProgramRange")
      end
    end

    params.require(:taggable).permit(tags: %i[client_account_id name tag_type])
  end

  def update_params
    params.require(:tag).permit(:archive, :name)
  end

  def response_object(tag)
    {
      id: tag.id,
      archive: tag.archive,
      name: tag.name
    }
  end

  def term
    client.program_ranges.find_by_id(params[:program_range_id])
  end

  def batch_add_tags_params
    params.require(:program).permit(
      :apply_filter,
      program_ids: [],
      tag_ids: [],
      filters: %i[
        end_month1
        end_month2
        end_year1
        end_year2
        start_month1
        start_month2
        start_year1
        start_year2
      ]
    )
  end

  def update_client_specific_report_program_associations(program_ids, program_range_ids)
    client_account_id = client.id

    ReportProgram.where(client_account_id: client_account_id, program_id: program_ids)
                 .update_all(sync_required: true)
    ReportProgramRange.where(
      client_account_id: client_account_id,
      program_range_id: program_range_ids
    ).update_all(sync_required: true)

    UpdateClientSpecificReportProgramAssociations.perform_async(
      client_account_id,
      program_ids,
      program_range_ids
    )
  end
end
