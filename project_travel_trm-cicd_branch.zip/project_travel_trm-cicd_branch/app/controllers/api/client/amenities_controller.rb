# frozen_string_literal: true

class Api::Client::AmenitiesController < Api::Client::BaseController
  respond_to :json

  def index
    authorize(:program, :create?)

    @amenities = Amenity.order(:name).map { |am| { amenity_id: am.id, name: am.name } }

    render json: @amenities, status: :ok
  end
end
