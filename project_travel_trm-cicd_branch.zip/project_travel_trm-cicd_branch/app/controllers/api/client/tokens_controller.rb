# frozen_string_literal: true

class Api::Client::TokensController < Api::Client::BaseController
  def index
    tokens = Token.all

    if params[:tokenable_type].present?
      tokens = tokens.joins(:tokenables)
                     .order('tokenables.order')
                     .where('tokenables.tokenable_type = ?', params[:tokenable_type])
                     .where('tokenables.tokenable_id = ?', tokenable_id)
    end

    render json: TokenSerializer.new(tokens,
                                     params: {
                                       tokenable_type: params[:tokenable_type],
                                       tokenable_id: tokenable_id
                                     })
                                .serialized_json, status: :ok
  end

  def tokenable_id
    return params[:tokenable_id] if params[:tokenable_id].present?

    @tokenable_id ||=
      case params[:tokenable_type]
      when 'TemplateType'
        TemplateType.find_by_name(params[:tokenable_name])&.id
      when 'AutomationType'
        AutomationType.find_by_display_name(params[:tokenable_name])&.id
      end
  end
end