# frozen_string_literal: true

class Api::Client::MessagesController < Api::Client::BaseController
  def create
    authorize(:traveler_information, :view_and_send_messages?)

    attachment_count = params[:message][:attachment_count].to_i
    attachments = []
    message = Message.new(message_params)

    attachment_count.times do |index|
      attachments << params[:message]["attachment#{index}"]
    end

    message.assign_attributes(attachments: attachments)

    if message.save
      traveler_ids = params[:traveler_ids].split(",").uniq

      traveler_ids.each do |traveler_id|
        MessagingWorker.perform_async(traveler_id.to_i, client.id, current_user.id, message.id)
      end

      SendGrid::SendMessageFromAdminMailers.call(
        admin: current_user,
        message: message,
        traveler_ids: traveler_ids
      )

      render json: {
        message: message,
        status: 201,
        success: "Message sent to #{traveler_ids.count} traveler(s)."
      }
    else
      render json: message.errors, status: :bad_request
    end
  end

  private

  def message_params
    params.require(:message).permit(:subject, :body).merge(user: @user)
  end
end
