# frozen_string_literal: true

class Api::Client::SessionsController < ApplicationController
  before_action :sign_in_params, only: :create
  before_action :load_user, only: :create

  def new
    client_account = ClientAccount.find_by(id: params[:id])

    render json: {
      org_name: client_account.org_name,
      logo: client_account.client_account_info.logo,
      description: client_account.client_account_info.description
    }, status: :created
  end

  def all_organizations
    client_accounts = ClientAccount.active.where.not(org_name: nil).order(:org_name)

    org_info = client_accounts.map do |client_account|
      {
        id: client_account.id,
        allow_traveler_sign_up: client_account.allow_traveler_sign_up,
        hidden: client_account.hidden,
        org_name: client_account.org_name,
        status: client_account.status,
        subdomain: client_account.subdomain
      }
    end

    render json: org_info, status: :created
  end

  def current_org
    client_account = ClientAccountInfo.find_by(subdomain: subdomain)&.client_account

    if client_account
      alternate_settings = client_account.alternate_setting
      client_account_info = client_account.client_account_info
      custom_aliases = {
        alias_enrollment: client_account_info.alias_enrollment,
        alias_favorite: client_account_info.alias_favorite,
        alias_favorites: client_account_info.alias_favorites,
        alias_program: client_account_info.alias_program,
        alias_programs: client_account_info.alias_programs,
        alias_traveler: client_account_info.alias_traveler,
        alias_travelers: client_account_info.alias_travelers,
        alias_traveling: client_account_info.alias_traveling,
        alias_unfavorite: client_account_info.alias_unfavorite
      }

      render json: {
        id: client_account.id,
        allow_traveler_sign_up: client_account.allow_traveler_sign_up,
        allow_traveler_deferral: client_account.allow_traveler_deferral,
        alternate_settings: {
          accept_alternates: alternate_settings&.accept_alternates,
          brochure_instruction: alternate_settings&.brochure_instruction,
          maximum_alternates: alternate_settings&.maximum_alternates,
          minimum_alternates: alternate_settings&.minimum_alternates,
          ranking_instruction: alternate_settings&.ranking_instruction
        },
        branding_theme: branding_theme(client_account_info),
        client_feature_list: client_account.client_feature_list.attributes.except(
          "id",
          "client_account_id",
          "created_at",
          "updated_at"
        ),
        custom_aliases: custom_aliases,
        info: client_account_info,
        org_name: client_account.org_name,
        sso_url: sign_in_redirect_url,
        status: client_account.status,
        use_custom_aliases: client_account.client_account_info.use_custom_aliases
      }, status: :created
    else
      render json: { error: "Organization not found." }, status: :not_found
    end
  end

  def create
    if @user.valid_password?(sign_in_params[:password])
      client_account = ClientAccount.find_by(id: @user.client_account_id) ||
                       ClientTraveler.find_by(user_id: @user.id).client_account

      sign_in("user", @user)
      # create_sign_in_log

      # token = AuthenticationToken::TokenService.new(@user).create_token

      render json: {
        messages: "Signed In Successfully",
        is_success: true,
        data: {
          id: @user.id,
          admin_access: @user.admin_role?,
          admin_sign_in: @user.admin_sign_in,
          allow_traveler_login: (
            begin
              @user.only_has_role?("traveler")
            rescue StandardError
              false
            end
          ),
          avatar: @user.avatar,
          branding_theme: branding_theme(client_account.client_account_info),
          client_account: client_account,
          via_abroad: @user.via_abroad,
          via_international: @user.via_international,
          via_contracts: @user.via_contracts,
          last_visited_product: @user.last_visited_product,
          client_feature_list: client_account.client_feature_list.attributes.except(
            "id",
            "client_account_id",
            "created_at",
            "updated_at"
          ),
          client_id: @user.client_account_id,
          subdomain: client_account.subdomain,
          tap_agreement: @user.tap_agreement,
          token: @user.authentication_token,
          # authentication_token: token.token,
          # expires_at: token.expires_at,
          user: @user.email
        }
      }, status: :ok
    else
      render json: {
        messages: "Signed In Failed - Unauthorized",
        is_success: false,
        data: {}
      }, status: :unauthorized
    end
  end

  # maybe?
  def destroy
    AuthenticationToken::TokenService.new(current_user).delete_token(request.headers["HTTP_X_USER_TOKEN"])
    head(:ok)
    render json: { messages: "Signed Out", data: {} }
  end

  private

  def sign_in_params
    params.require(:sign_in).permit(:email, :password)
  end

  def load_user
    @user = User.find_for_database_authentication(email: sign_in_params[:email])

    return @user if @user

    render json: {
      messages: "Signed In Failed - Unauthorized",
      is_success: false,
      data: {}
    }, status: :unauthorized
  end

  def branding_theme(ca_info)
    begin
      @branding_theme ||= {
        themes: {
          theme_color_dark: ca_info.theme_color_dark,
          theme_color_light: ca_info.theme_color_light,
          theme_color_accent: ca_info.theme_color_accent
        },
        logo: {
          theme_logo: ca_info.logo.url
        }
      }
     rescue StandardError
       {}
    end
  end

  def logout_url
    @logout_url ||= Sso::Slo::LogoutUrl.new(current_user, subdomain).execute
  end

  def sign_in_redirect_url
    client = ClientAccountInfo.find_by_subdomain(subdomain).client_account if subdomain.present?

    if client && SsoConfiguration.where(client_account_id: client.id).present?
      sso_sign_in_url(subdomain: subdomain)
    else
      ""
    end
  end

  def subdomain
    @subdomain ||= params[:subdomain]
  end

  def create_sign_in_log
    SignInLog.create(
      sign_in_type: 'standard',
      user_id: current_user.id,
      client_account_id: current_user.client&.id
    )
  end
end
