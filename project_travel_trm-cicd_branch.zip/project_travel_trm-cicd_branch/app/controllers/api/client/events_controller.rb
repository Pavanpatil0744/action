# frozen_string_literal: true

class Api::Client::EventsController < Api::Client::BaseController
  respond_to :json

  def index
    events = client.events.order(start: :desc).map do |event|
      {
        id: event.id,
        background_photo: event.background_photo.event_background.url,
        deleted: event.cancelled,
        ending: event.ending,
        location: event.location,
        name: event.name,
        start: event.start,
        timezone: event.timezone
      }
    end

    render json: events, status: :ok
  end

  def show
    authorize(:event, :view_events?)

    return not_found unless event

    render json: event.as_json.merge(
      {
        public_url: "#{derived_domain}visitor/events/#{event.id}",
        same_day_signup_url: "#{derived_domain}visitor/events/#{event.id}/same-day-signup",
        background_photo: event.background_photo.url,
        background: [
          { large: event.background_photo.event_large.url },
          { medium: event.background_photo.event_medium.url },
          { small: event.background_photo.event_small.url },
          { xlarge: event.background_photo.event_xlarge.url }
        ]
      }
    ), status: :ok
  end

  def create
    authorize(:event, :create?)

    client_time_zone = client.client_account_info.org_timezone

    Time.use_zone(client_time_zone) do
      event = client.events.new(event_params)

      if event.save
        UpdateReportEvent.perform_in(10.seconds, event.id)

        render json: event, status: :ok
      else
        render json: { errors: event.errors }, status: :bad_request
      end
    end
  end

  def update
    authorize(:event, :edit?)

    event_time_zone = if event.timezone.blank?
                        client.client_account_info.org_timezone
                      else
                        event.timezone
                      end

    Time.use_zone(event_time_zone) do
      if event.update(event_params)
        update_report_event_associations(event)

        render json: event, status: :ok
      else
        render json: { errors: event.errors }, status: :bad_request
      end
    end
  end

  def destroy
    if event.update(cancelled: true)
      SendGrid::SendEventCancellationMailer.perform_async(
        client.logo.url,
        event.event_travelers.pluck(:id)
      )

      update_report_event_associations(event)

      render json: event, status: :ok
    else
      render json: { errors: event.errors }, status: :bad_request
    end
  end

  def reactivate_event
    if event.update(cancelled: false)
      update_report_event_associations(event)

      render json: event, status: :ok
    else
      render json: { errors: event.errors }, status: :bad_request
    end
  end

  def delete_event
    if event.destroy
      update_report_event_associations(event)

      render json: event, status: :ok
    else
      render json: { error: "Unable to delete event." }, status: :bad_request
    end
  end

  def register_travelers
    travelers = params[:traveler_ids]
    event_travelers = []

    travelers.each do |traveler|
      event_travelers << event.event_travelers.find_or_create_by(user_id: traveler.id)
    end

    update_report_event_associations(event)

    render json: event_travelers, status: :ok
  end

  def get_event_travelers
    render json: event.event_travelers.order(:first_name, :last_name), status: :ok
  end

  def create_event_traveler
    email = event_traveler_params[:email].downcase

    if event.event_travelers.find_by(email: email)
      render json: {
        message: "#{alias_traveler} has already been invited",
        type: "error"
      }, status: :bad_request
    else
      event_traveler = event.event_travelers.create(email: email)
      user_id = User.find_by(email: email)&.id

      event_traveler.update(
        confirmed: false,
        first_name: event_traveler_params[:first_name],
        last_name: event_traveler_params[:last_name],
        user_id: user_id
      )

      if event_traveler.save
        update_report_event_traveler_associations(event.id, event_traveler.id)

        row = {
          email: event_traveler.email,
          first_name: event_traveler.first_name,
          last_name: event_traveler.last_name
        }

        if existing_user?(row)
          invite_user_to_event(row, client, event)
        else
          invite_new_user(row, client, event)
        end

        render json: {
          event_traveler: event_traveler,
          message: "#{alias_traveler} has been invited to the event",
          type: "success"
        }, status: :created
      else
        render json: { errors: event_traveler.errors }, status: :bad_request
      end
    end
  end

  def same_day_registration
    email = params[:user][:email].downcase
    event_traveler = event.event_travelers.find_or_create_by(email: email)
    user = client.travelers.find_by_email(event_traveler.email)

    event_traveler.update(
      attended: true,
      confirmed: true,
      first_name: params[:user][:first_name],
      last_name: params[:user][:last_name],
      user: user
    )

    SendGrid::SendEventAttendanceMailer.perform_async(client.logo.url, event_traveler.id)

    update_report_event_traveler_associations(event.id, event_traveler.id)

    if event_traveler.errors && event_traveler.errors.full_messages.present?
      render json: { errors: event_traveler.errors }, status: :bad_request
    else
      render json: { event_traveler: event_traveler }, status: :ok
    end
  end

  def update_event_traveler
    attended = params[:attended]
    event_traveler = EventTraveler.find(params[:event_traveler_id])

    event_traveler.update(attended: attended)

    if attended
      SendGrid::SendEventAttendanceMailer.perform_async(client.logo.url, event_traveler.id)
    end

    update_report_event_traveler_associations(event.id, event_traveler.id)

    render json: event_traveler, status: :ok
  end

  def update_event_travelers
    attended = event_travelers_params[:attended]
    event_travelers = EventTraveler.where(id: event_travelers_params[:traveler_ids])

    event_travelers.update_all(attended: attended)

    if attended
      event_travelers.each do |l|
        SendGrid::SendEventAttendanceMailer.perform_async(client.logo.url, l.id)
      end
    end
    event_travelers.each do |l|
      update_report_event_traveler_associations(l.event_id, l.id)
    end

    render json: event_travelers, status: :ok
  end

  def delete_event_traveler
    event_traveler = event.event_travelers.find(params[:event_traveler_id])

    event_traveler.destroy

    update_report_event_traveler_associations(event.id, event_traveler.id)

    render json: {}, status: :ok
  end

  def delete_event_travelers
    event_travelers = event.event_travelers.where(id: params[:event_traveler_ids])

    event_travelers.destroy_all
    event_travelers.each do |l|
      update_report_event_traveler_associations(l.event_id, l.id)
    end

    render json: { message: "Event travelers deleted" }, status: :ok
  end

  def download_csv
    authorize(:client_account, :download_csv?)

    return not_found unless event

    respond_to do |format|
      format.csv do
        send_data(
          csv,
          type: "text/csv; charset=iso-8859-1; header=present",
          disposition: "attachment; filename=event-report.csv"
        )
      end
    end
  end

  def duplicate_event
    dup_event = client.events.new(
      description: event.description,
      ending: event.ending,
      location: event.location,
      name: "Copy of #{event.name}",
      start: event.start,
      timezone: client.client_account_info.org_timezone
    )

    if event.background_photo.present?
      dup_event.background_photo = event.background_photo
    end

    if dup_event.save(validate: false)
      update_report_event_associations(dup_event)

      render json: dup_event.id, status: :ok
    else
      render json: dup_event.errors, status: :bad_request
    end
  end

  def invite_event_travelers
    rows = params[:file].split("\n").drop(1).map do |row|
      row = row.split(",")

      next unless row[0] && row[1] && row[2]

      { email: row[0].delete('"'), first_name: row[1].delete('"'), last_name: row[2].delete('"') }
    end

    if rows.empty? || rows == [nil] || rows.uniq == [{ email: "", first_name: "", last_name: "\r" }]
      return render json: {
        alert: "Please upload one or more #{alias_traveler.downcase} invitation CSV files."
      }, status: :bad_request
    else
      existing = 0
      invalid = 0
      invites = 0

      rows.each do |row|
        next if row == { email: "", first_name: "", last_name: "\r" } || row.nil?

        email = row[:email].downcase

        if !email.match?(Devise.email_regexp)
          invalid += 1
        elsif event.event_travelers.find_by(email: email)
          existing += 1
        elsif event_invite(row).valid?
          invite_user(row, client, event)

          invites += 1
        else
          logger.info("Failed to invite #{row[:email]}: #{row[:first_name]} #{row[:last_name]}")

          invalid += 1
        end
      end
    end

    update_report_event_associations(event)

    reason = []
    reason << "#{alias_traveler.downcase} are already added to this event" if existing.positive?
    reason << "First name, Last name, and/or Email address is missing" if invalid.positive?
    render json: {
      notice: {
        total_success: invites,
        total_failed: existing + invalid,
        reason: reason
      }
    }, status: :ok
  end

  def upload_attendees
    rows = params[:file].split("\n").drop(1).map do |row|
      row = row.split(",")

      next unless row[0] && row[1] && row[2]

      { email: row[0].delete('"'), first_name: row[1].delete('"'), last_name: row[2].delete('"') }
    end

    if rows.empty? || rows == [nil] || rows.uniq == [{ email: "", first_name: "", last_name: "\r" }]
      render json: {
        alert: "Please upload one or more #{alias_traveler.downcase} attendees CSV files."
      }, status: :bad_request
    else
      attendees = 0
      existing = 0
      invalid = 0

      rows.each do |row|
        next if row == { email: "", first_name: "", last_name: "\r" } || row.nil?

        email = row[:email].downcase

        if !email.match?(Devise.email_regexp)
          invalid += 1
        elsif event.event_travelers.find_by(email: email) &&
              event.event_travelers.find_by(email: email)[:attended] == true

          existing += 1
        elsif event_invite(row).valid?
          upload_attendee(row, event, client)

          attendees += 1
        else
          logger.info("Failed to upload attendee #{row[:email]}: #{row[:first_name]} #{row[:last_name]}")

          invalid += 1
        end
      end

      update_report_event_associations(event)
      reason = []
      reason << "#{alias_traveler.downcase} are already added to this event" if existing.positive?
      reason << "First name, Last name, and/or Email address is missing" if invalid.positive?
      render json: {
        notice: {
          total_success: attendees,
          total_failed: existing + invalid,
          reason: reason
        }
      }, status: :ok
    end
  end

  def registered_and_attended
    render json: { csv: CSV.parse(generate_csv(event.event_travelers)) }, status: :ok
  end

  private

  def alias_traveler
    client.client_account_info.alias_traveler
  end

  def alias_travelers
    client.client_account_info.alias_travelers
  end

  def upload_attendee(row, event, client)
    email = row[:email].downcase
    event_traveler = event.event_travelers.find_or_create_by(email: email)
    user = client.travelers.find_by_email(email)

    event_traveler.update(
      attended: true,
      confirmed: true,
      first_name: row[:first_name],
      last_name: row[:last_name],
      user: user
    )

    update_report_event_traveler_associations(event.id, event_traveler.id)

    SendGrid::SendEventAttendanceMailer.perform_async(client.logo.url, event_traveler.id)
  end

  def event
    @event ||= client.events.find(params[:id])
  end

  def event_params
    params.require(:event).permit(
      :background_photo,
      :description,
      :ending,
      :location,
      :name,
      :start,
      :timezone
    )
  end

  def event_traveler_params
    params[:user].permit(:attended, :confirmed, :email, :first_name, :last_name)
  end

  def event_travelers_params
    params[:event_travelers].permit(
      :attended,
      traveler_ids: []
    )
  end

  def csv
    @csv ||= Client::Events::EventCSVGenerator.generate(event)
  end

  def invite_user(row, client, event)
    if existing_user?(row)
      invite_user_to_event(row, client, event)
    else
      invite_new_user(row, client, event)
    end
  end

  def existing_user?(row)
    user_from(row).present?
  end

  def invite_user_to_event(row, client, event)
    user = user_from(row)

    send_event_invitation_email(user, client, event)
    register_for_event(user, event, row)
  end

  def send_event_invitation_email(user, client, event)
    event_traveler = event.event_travelers.find_or_create_by(email: user.email)

    SendGrid::SendEventInviteMailer.perform_async(client.logo.url, event_traveler.id)
  end

  def register_for_event(_user, event, row)
    event_traveler = event.event_travelers.find_or_create_by(email: row[:email].downcase)

    event_traveler.update(first_name: row[:first_name], last_name: row[:last_name])

    mark_attended(event_traveler)
  end

  def invite_new_user(row, client, event)
    inviter(row, client, event).execute

    event_traveler = event.event_travelers.find_or_create_by(email: row[:email].downcase)

    mark_attended(event_traveler)
  end

  def mark_attended(event_traveler)
    event_traveler.update(attended: true) if params[:attended]
  end

  def user_from(row)
    User.find_by(email: row[:email].downcase)
  end

  def inviter(invite_data, client, event)
    Client::EventInviter.new(
      Rails.application.secrets.secret_key_base,
      client,
      invite_data[:email].downcase,
      invite_data[:first_name],
      invite_data[:last_name],
      event.id,
      { invited_from_csv: true }
    )
  end

  def event_invite(invite_data)
    Validators::Client::OnsiteInvitations::Invite.new(invite_data)
  end

  def generate_csv(event_travelers)
    attributes = %w[email first_name last_name registered attended]

    CSV.generate(headers: true) do |csv|
      csv << attributes.map(&:titleize)

      event_travelers.each do |event_traveler|
        csv << attributes.map do |attr|
          event_traveler.send(attr).blank? ? "--" : event_traveler.send(attr).strip
        end
      end
    end
  end

  def update_report_event_associations(event)
    event_id = event.id

    ReportEvent.find_by_event_id(event_id)&.update(sync_required: true)
    UpdateReportEvent.perform_in(10.seconds, event_id)

    event.event_travelers.each do |event_traveler|
      event_traveler_id = event_traveler.id

      ReportEventTraveler.find_by_event_traveler_id(event_traveler_id)&.update(sync_required: true)
      UpdateReportEventTraveler.perform_in(10.seconds, event_traveler_id)
    end
  end

  def update_report_event_traveler_associations(event_id, event_traveler_id)
    ReportEvent.find_by_event_id(event_id)&.update(sync_required: true)
    ReportEventTraveler.find_by_event_traveler_id(event_traveler_id)&.update(sync_required: true)
    UpdateReportEvent.perform_in(10.seconds, event_id)
    UpdateReportEventTraveler.perform_in(10.seconds, event_traveler_id)
  end
end
