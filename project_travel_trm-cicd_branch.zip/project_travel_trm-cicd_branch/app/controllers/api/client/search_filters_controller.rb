# frozen_string_literal: true

class Api::Client::SearchFiltersController < Api::Client::BaseController
  before_action :find_search_filter, only: %i[update destroy]

  def index
    search_filters = SearchFilter.for_user(current_user).with_filter_type(params[:filter_type])

    render json: SearchFilterSerializer.new(search_filters).serialized_json, status: :ok
  end

  def create
    search_filter = current_user.search_filters.new(search_filter_params)
    search_filter.client_account = client

    return bad_request(search_filter) unless search_filter.save

    render json: SearchFilterSerializer.new(search_filter).serialized_json, status: :created
  end

  def update
    return bad_request(search_filter) unless @search_filter.update(search_filter_params)

    render json: SearchFilterSerializer.new(@search_filter).serialized_json, status: :ok
  end

  def destroy
    @search_filter.destroy

    render json: {}, status: :no_content
  end

  private

  def search_filter_params
    params.require(:search_filter).permit(:filter, :filter_type, :name, :shared)
  end

  def find_search_filter
    @search_filter = current_user.search_filters.find_by(id: params[:id])

    return not_found unless @search_filter
  end
end
