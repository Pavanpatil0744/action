# frozen_string_literal: true

require "resources/data/phone_country_codes"
require "resources/data/relationships"
require "resources/data/ethnicities"
require "resources/data/college_faculty"
require "resources/data/races"

class Api::Client::TravelerProfilesController < Api::Client::BaseController
  respond_to :json

  before_action :validate_traveler
  before_action :set_notes, except: :insights
  before_action :set_admins, except: %i[get_current_user insights]
  before_action :set_messages, only: %i[
    add_message
    check_message
    get_messages
    update_assigned_admins
  ]
  before_action :set_profile_objects, only: %i[get_traveler_preference show update]
  # after_action :update_auth_token_expiration, only: :get_current_user

  def get_current_user
    render json: {
      admin_access: current_user.admin_role?,
      admin_sign_in: current_user.admin_sign_in,
      allow_traveler_deferral: client.allow_traveler_deferral,
      allow_traveler_sign_up: client.allow_traveler_sign_up,
      avatar: current_user&.profile&.avatar&.url,
      branding_theme: branding_theme,
      client_account_state: client.state.description,
      client_feature_list: client.client_feature_list.attributes.except(
        "id",
        "client_account_id",
        "created_at",
        "updated_at"
      ),
      custom_aliases: custom_aliases,
      freemium: client.free? ? true : false,
      lead: client.lead? ? true : false,
      logout_url: client.sso_configuration.nil? ? "" : client.sso_configuration&.logout_url,
      org_timezone: client.client_account_info.org_timezone,
      other_admin_limit: client.other_admin_limit,
      permissions: user_permissions,
      profile_info: {
        first_name: current_user.profile&.first_name,
        avatar: current_user.profile&.avatar&.url
      },
      role: current_user.role_name,
      show_intake: client.show_intake,
      show_program_match: client.show_program_match,
      super_user_limit: client.super_user_limit,
      enable_active_term_name_filtering: client.client_account_info.enable_active_term_name_filtering,
      use_custom_aliases: client.client_account_info.use_custom_aliases,
      user: current_user,
      standard_report_notification_read: current_user.standard_reports.where(notified: false).count == 0 ? true : false
    }, status: :ok, methods: %i[is_traveler? client_user_role?]
  end

  def show
    authorize(:traveler_information, :view_traveler?)
    authorize!(:manage, @traveler)

    traveler_info = @traveler.traveler_info
    passport = @traveler_info.passport
    profile = @traveler.profile
    serialized_custom_fields = []

    client.custom_fields.active.each do |custom_field|
      serialized_custom_fields << {
        id: custom_field.id,
        answer: custom_field.custom_field_texts.find_by(traveler_id: @traveler.id)&.text,
        integration_field: false,
        title: custom_field.title
      }
    end

    @traveler.custom_fields&.each do |custom_field, answer|
      serialized_custom_fields << {
        id: nil,
        answer: answer,
        integration_field: true,
        title: custom_field.titleize
      }
    end

    respond_with(info, passport) do |format|
      format.json do
        render json: [
          custom_fields: serialized_custom_fields,
          info: traveler_info,
          passport_status: passport,
          profile: profile,
          readonly: @readonly_fields,
          traveler_email: @traveler.email
        ], status: :ok
      end
    end
  end

  def update
    authorize(:traveler_information, :edit_traveler_profile?)
    authorize!(:manage, @traveler)

    custom_fields = params[:custom_fields].compact

    unless custom_fields.empty?
      custom_fields_with_text = check_and_update_custom_fields(custom_fields, @traveler.id)
    end

    if custom_fields_with_text.nil?
      custom_fields_with_text = handle_custom_fields_when_sent_over_empty(custom_fields)
    end

    @passport.update(passport_params) unless passport_params.empty?

    @profile.update(profile_params) unless profile_params.empty?

    @traveler_info.update(traveler_profile_params) unless traveler_profile_params.empty?

    errors = @profile.errors.messages.merge(
      @traveler_info.errors.messages,
      @passport.errors.messages
    )

    respond_with(@traveler_info) do |format|
      if errors.empty?
        update_report_traveler_associations(@traveler)

        format.json do
          render json: [
            info: @traveler_info,
            profile: @profile,
            passport_status: @passport.status,
            custom_fields: custom_fields_with_text,
            readonly: @readonly_fields,
            traveler_email: @traveler.email,
            status: 200
          ]
        end
      else
        format.json { render json: [@traveler_info.errors, { status: 400 }] }
      end
    end
  end

  def destroy
    authorize(:traveler_information, :inactivate_traveler?)
    authorize!(:manage, @traveler)

    if (current_user == @traveler) || @traveler.admin_role?
      render json: {
        error: "Unable to delete #{custom_aliases[:alias_traveler].downcase}"
      }, status: :forbidden
    elsif @traveler.destroy
      TravelerDeletionHistory.create(
        admin_email: current_user.email,
        admin_first_name: current_user.first_name || "",
        admin_id: current_user.id.to_s,
        admin_last_name: current_user.last_name || "",
        traveler_email: @traveler.email
      )

      render json: { message: "#{custom_aliases[:alias_traveler]} deleted" }, status: :ok
    else
      render json: { error: @traveler.errors }, status: :unprocessable_entity
    end
  end

  def check_and_update_custom_fields(compact_fields, traveler_id)
    custom_fields = []

    compact_fields.keys.map do |field_id|
      custom_field = CustomField.find(field_id)

      if custom_field&.custom_field_texts&.find_by(traveler_id: traveler_id)

        cf = custom_field.custom_field_texts.find_by(traveler_id: traveler_id)

        cf.assign_attributes(text: params[:custom_fields][field_id])

        field = cf
      else
        field = CustomFieldText.new(
          custom_field_id: custom_field.id,
          traveler_id: traveler_id,
          text: params[:custom_fields][field_id]
        )
      end

      custom_fields << field
    end

    begin
      custom_fields.each(&:save)
    rescue StandardError
      true
    end

    custom_fields = CustomField.where(client_account_id: client.id).includes(:custom_field_texts)

    custom_fields_with_text = custom_fields.map do |custom_field|
      custom_field.attributes.merge(
        "answer" => custom_field.custom_field_texts.find_by(traveler_id: traveler_id)&.text
      )
    end

    custom_fields_with_text
  end

  def handle_custom_fields_when_sent_over_empty(compact_fields)
    compact_fields.keys.map { |_| { field_id: "" } }
  end

  def get_traveler_details
    authorize(:traveler_information, :view_traveler?)
    authorize!(:manage, @traveler)

    traveler_events = client.events.includes(:event_travelers)
                            .where(event_travelers: { user_id: @traveler.id })
    events = []

    traveler_events.each do |event|
      sample = EventPresenter.new(event)
      event = event.as_json.merge(public_url: "#{derived_domain}visitor/events/#{event.id}")

      event[:attended] = if sample.attended_travelers.present? &&
                            sample.attended_travelers.map(&:user_id).include?(@traveler.id)

                           "Attended"
                         else
                           "Not Attended"
                         end

      event[:registered] = if sample.registered_travelers.present? &&
                              sample.registered_travelers.map(&:user_id).include?(@traveler.id)

                             "Registered"
                           else
                             "Not Registered"
                           end

      events << event
    end

    events&.uniq!

    program_rankings = Alguru.new(@traveler, client.id).run

    favorite_ids = @traveler.program_favorites.pluck(:program_id)
    favorite_programs = client.report_programs.traveler_or_visitor_viewable.where(program_id: favorite_ids)

    favorite_programs_json = []

    favorite_programs.each do |fp|
      fp = fp.program

      background_photo_url = if fp.program_images.any?
                               fp.primary_program_image.original
                             else
                               fp.background_photo.url
                             end
      report_program = fp.report_programs.first

      favorite_programs_json << fp.as_json.merge!(
        background_photo: background_photo_url,
        locations: report_program.locations,
        match_rank: (
          begin
            program_rankings.find { |rank| rank[fp.id] rescue false }[fp.id]
          rescue
            0
          end
        ),
        percent: @traveler.traveler_info.program_matches,
        terms: report_program.program_terms,
        types: report_program.types
      )
    end

    sorted_favorite_programs = favorite_programs_json.sort_by do |program|
      program[:match_rank]
    end.reverse rescue favorite_programs

    render json: {
      events: events,
      applications: [],
      favorite_programs: sorted_favorite_programs,
      forms: []
    }, status: :ok
  end

  def get_header
    authorize(:traveler_information, :view_traveler?)
    authorize!(:manage, @traveler)

    traveler_applications = @traveler.application_submissions.includes(program_range: :program)
    events = @traveler.event_travelers

    apps = traveler_applications.map do |app|
      {
        end_date: app.program_range.end_date,
        id: app.id,
        program: app.program_range.program,
        program_range: app.program_range,
        start_date: app.program_range.start_date,
        status: app.status,
        title: app.program_range.program&.title
      }
    end

    form_finder = Traveler::Forms::Finder.new(@traveler, client)
    applications = @traveler.application_submissions
    step_ids = applications.pluck(:submission_tracking_step_id).uniq

    render json: [
      Applications: apps,
      Avatar: @traveler.profile.avatar.url,
      ChevronStatuses: SubmissionTrackingStep.where(id: step_ids).in_order.pluck(:identifier),
      CompletedForms: form_finder.form_submissions(&:completed),
      Email: @traveler.email,
      Events: {
        registered_total: @traveler.event_travelers.where(
          confirmed: true,
          event_id: events.map(&:id)
        ).map(&:event_id).uniq.count,
        attended_total: @traveler.event_travelers.where(
          attended: true,
          event_id: events.map(&:id)
        ).map(&:event_id).uniq.count
      },
      FirstName: @traveler.profile.first_name,
      LastLogin: @traveler.last_sign_in_at,
      LastName: @traveler.profile.last_name,
      PreferredFirstName: @traveler.preferred_first_name,
      PreferredLastName: @traveler.preferred_last_name,
      SsoUser: @traveler.sso_authentications.any?,
      TotalForms: form_finder.form_submissions(&:all),
      TotalProgramFavorites: @traveler.program_favorites.count
    ], status: :created
  end

  def get_notes
    authorize(:traveler_information, :view_and_create_notes?)

    render json: NoteSerializer.new(@notes.order_by_updated_at).serialized_json, status: :ok
  end

  def add_note
    authorize(:traveler_information, :view_and_create_notes?)

    note = client.notes.new(note_params)
    note.user_id = @traveler.id
    note.author_id = current_user.id

    attachment_count = params[:note][:attachment_count].to_i
    attachments = []

    attachment_count.times do |index|
      attachments << params[:note]["attachment#{index}"]
    end

    note.assign_attributes(attachments: attachments)

    if note.save
      render json: NoteSerializer.new(note).serialized_json, status: :created
    else
      render json: note.errors, status: :failure
    end
  end

  def update_note
    authorize(:traveler_information, :edit_note?)

    note = client.notes.find_by(id: note_params[:id])

    if note&.update(body: note_params[:body], subject: note_params[:subject])
      render json: NoteSerializer.new(note).serialized_json, status: :ok
    else
      render json: { error: "Unable to update Note" }, status: :failure
    end
  end

  def delete_note
    authorize(:traveler_information, :delete_note?)

    note = client.notes.find_by(id: note_params[:id])

    if note&.destroy
      render json: { message: "Note successfully deleted" }, status: :ok
    else
      render json: { error: "Unable to delete Note" }, status: :failure
    end
  end

  def get_traveler_preference
    authorize(:traveler_information, :view_program_preferences?)
    authorize!(:manage, @traveler)

    traveler_info = @traveler.traveler_info
    program_preference = traveler_info.program_preference || ProgramPreference.new

    priority_names = {
      1 => "Subject Areas",
      2 => "Housing",
      3 => "Timing",
      5 => "Location",
      6 => "Language",
      7 => "Program Type"
    }

    program_types = program_preference.preferred_program_types.pluck(:program_type_id).compact
    minimum_duration_weeks = program_preference.minimum_duration_weeks
    maximum_duration_weeks = program_preference.maximum_duration_weeks

    program_terms = program_preference.traveler_terms.map do |tt|
      [tt.start_date, tt.end_date].compact
    end

    # level_of_support = program_preference.preferred_support_level&.support_level
    language_immersion = program_preference&.language_immersion&.humanize

    user_languages = program_preference.user_languages.pluck(:iso_639_3).map do |ul|
      LanguageList::LanguageInfo.find(ul).name rescue ul
    end

    program_countries = program_preference.preferred_program_countries.pluck(:alpha2)
    program_housing = program_preference.preferred_program_housings.pluck(:housing_type_id)
    subject_areas = program_preference.preferred_program_subject_areas.includes(:subject_area)
                                      .map(&:subject_area).compact.map(&:name)
    preferred_priorities = program_preference.preferred_program_priorities.joins(:priority)
                                             .where.not(priorities: { name: "Level of support" })
                                             .select(:priority_id, :ranking).order("ranking")
    other_program_housing = program_preference.preferred_program_housings
                                              .pluck(:other_program_housing_text).compact

    priorities = preferred_priorities.map do |tt|
      next unless tt.ranking.is_a?(Integer) && tt.ranking.positive?

      {
        text: priority_names[tt.priority_id],
        ranking: tt.ranking,
        priority_id: tt.priority_id
      }
    end.compact

    traveler_experience = traveler_info.travel_experience
    financial_info = traveler_info.financial_info
    travel_goal = traveler_info.travel_goal

    travel_certainty = if traveler_info.travel_certainty
                         TravelerInfo::TRAVELER_CERTAINTIES[traveler_info.travel_certainty.to_sym]
                       end

    travel_experience = if traveler_info.travel_experience&.has_left_home_country
                          {
                            africa: traveler_experience.africa,
                            antarctica: traveler_experience.antarctica,
                            asia: traveler_experience.asia,
                            australia: traveler_experience.australia,
                            europe: traveler_experience.europe,
                            north_america: traveler_experience.north_america,
                            south_america: traveler_experience.south_america
                          }
                        end

    funding_sources = if financial_info.present?
                        {
                          financial_aid: financial_info.financial_aid,
                          fundraising_or_crowdfunding: financial_info.fundraising_crowdfunding,
                          job: financial_info.job,
                          not_sure: financial_info.not_sure,
                          other: financial_info.other,
                          parent_donor: financial_info.parent_donor,
                          personal_savings: financial_info.personal_savings,
                          scholarship_grant: financial_info.scholarship_grant
                        }
                      else
                        {}
                      end

    financial_aid = case financial_info&.receives_federal_financial_aid
                    when "yes"
                      "Yes"
                    when "no"
                      "No"
                    when "not_sure"
                      "Not Sure"
                    else
                      "Not Provided"
                    end

    respond_with(
      program_types,
      minimum_duration_weeks,
      maximum_duration_weeks,
      program_terms,
      user_languages,
      program_countries,
      program_housing,
      subject_areas,
      priorities
    ) do |format|
      format.json do
        render json: {
          program_types: program_types.map do |id|
            (ProgramType.find(id) rescue nil)&.name.eql?("Other") ?
              "Other (#{program_preference.preferred_program_types
                                          .find_by_program_type_id(id)
                                          .other_program_type_text})" :
            (ProgramType.find(id) rescue nil)&.name
          end.sort,
          minimum_duration_weeks: minimum_duration_weeks,
          maximum_duration_weeks: maximum_duration_weeks,
          program_terms: program_terms.compact,
          language_immersion: language_immersion,
          user_languages: user_languages,
          program_countries: program_countries.compact,
          program_housing: program_housing.map { |id| (HousingType.find(id) rescue nil)&.name },
          subject_areas: subject_areas,
          priorities: priorities,
          advising: traveler_info.advising,
          financial_info: funding_sources,
          financial_aid: financial_aid,
          travel_goal: travel_goal,
          travel_experience: travel_experience,
          travel_certainty: travel_certainty,
          other_program_housing: other_program_housing,
          signup_date: @traveler.created_at,
          signup_source: @traveler.profile.signup_source
        }, status: :ok
      end
    end
  end

  def get_messages
    receipts = @receipts.map do |receipt|
      {
        subject: receipt.message.subject,
        body: receipt.message.body,
        attachments: receipt.message.attachments.map do |attach|
          {
            url: attach.url,
            name: attach.file.filename
          }
        end,
        created_at: receipt.message.created_at,
        message_id: receipt.id,
        receiver_id: receipt.receiver_id,
        receiver_type: receipt.receiver_type,
        notification_id: receipt.notification_id,
        is_read: receipt.is_read,
        trashed: receipt.trashed,
        deleted: receipt.deleted,
        author: receipt&.notification&.sender&.name || "Deleted Admin User",
        sender: receipt&.notification&.sender || "Deleted Admin User",
        sender_avatar: (
          begin
            receipt.notification.sender.profile.avatar.url
          rescue StandardError
            "default_avatar"
          end
        ),
        allow_mark_read: current_user.id != receipt&.notification&.sender&.id
      }
    end

    traveler_assigned_admins = @assigned_admins.map do |admin|
      admin_user = admin.client_user

      next unless admin_user

      {
        name: admin_user.name,
        admin_id: admin_user.id,
        avatar: (
          begin
            admin_user.profile.avatar.url
          rescue StandardError
            "default_avatar"
          end
        ),
        rest: admin_user
      }
    end

    available_admins = client&.admin_users&.includes(:profile) || []
    assigned_admin_ids = @assigned_admins.pluck(:client_user_id)

    traveler_available_admins = available_admins.reject { |a| assigned_admin_ids.include?(a.id) }
                                                .map do |admin_user|
      next unless admin_user

      {
        name: admin_user.name,
        admin_id: admin_user.id,
        avatar: (
          begin
            admin_user.profile.avatar.url
          rescue StandardError
            "default_avatar"
          end
        ),
        rest: admin_user
      }
    end

    render json: {
      assigned_admins: traveler_assigned_admins.compact,
      available_admins: traveler_available_admins.compact,
      messages: receipts,
      current_user_avatar: (
        begin
          current_user.profile.avatar.url
        rescue StandardError
          "default_avatar"
        end
      )
    }, status: :ok
  end

  def update_assigned_admins
    new_admin_ids = params[:assigned_admin_ids]&.map(&:to_i) || []
    traveler_id = @traveler.id
    old_admin_ids = client.assigned_admins.where(traveler_id: traveler_id).pluck(:client_user_id)
    added_admin_users = client.users.where(id: new_admin_ids - old_admin_ids)
    removed_admin_users = client.users.where(id: old_admin_ids - new_admin_ids)

    client.assigned_admins.where(
      client_user_id: removed_admin_users,
      traveler_id: traveler_id
    ).destroy_all

    added_admin_users.each do |user|
      client.assigned_admins.find_or_create_by(client_user: user, traveler_id: traveler_id)
    end

    if @conversation
      removed_admin_users.each { |user| @conversation.receipts_for(user).delete_all }

      added_admin_users.each do |user|
        @conversation.add_participant(user) unless @conversation.is_participant?(user)
      end
    end

    new_admin_users = client.users.where(id: new_admin_ids)

    update_report_traveler_associations(@traveler)

    render json: new_admin_users.map { |user|
      {
        name: user.name,
        admin_id: user.id,
        avatar: (
          begin
            user.profile.avatar.url
          rescue StandardError
            "default_avatar"
          end
        ),
        rest: user
      }
    }, status: :ok
  end

  def get_assigned_admins
    render json: @assigned_admins.map { |admin|
      next unless @admins.find_by(id: admin)

      {
        name: @admins.find_by(id: admin).name,
        admin_id: admin,
        avatar: (
          begin
            @admins.find_by(id: admin).profile.avatar.url
          rescue StandardError
            "default_avatar"
          end
        ),
        rest: @admins.find_by(id: admin)
      }
    }.compact, status: :ok
  end

  def get_admins
    available_admins = @admins.reject { |a| @assigned_admins.include?(a.id) }

    render json: available_admins.map { |admin|
      {
        name: @admins.find_by(id: admin).name,
        admin_id: admin,
        avatar: (
          begin
            @admins.find_by(id: admin).profile.avatar.url
          rescue StandardError
            "default_avatar"
          end
        ),
        rest: @admins.find_by(id: admin)
      }
    }, status: :ok
  end

  def add_message
    authorize(:traveler_information, :view_and_send_messages?)

    message = Message.new(body: message_params[:body], subject: message_params[:subject])

    attachments = []
    attachment_count = params[:message][:attachment_count].to_i

    attachment_count.times do |index|
      attachments << params[:message]["attachment#{index}"]
    end

    message.assign_attributes(attachments: attachments)

    if message.save
      Conversation.client_reply(@traveler, current_user, client, @conversation, message)

      SendGrid::SendMessageFromAdminMailers.call(
        admin: current_user,
        message: message,
        traveler_ids: [@traveler.id]
      )

      receipt = @receipts.map do |r|
        {
          subject: r.message.subject,
          body: r.message.body,
          attachments: r.message.attachments,
          created_at: r.message.created_at,
          message_id: r.id,
          receiver_id: r.receiver_id,
          receiver_type: r.receiver_type,
          notification_id: r.notification_id,
          is_read: r.is_read,
          trashed: r.trashed,
          deleted: r.deleted,
          author: r&.notification&.sender&.name,
          sender: r&.notification&.sender
        }
      end.first

      render json: { receipt: receipt, status: 200 }, status: :ok
    else
      render json: message.errors, status: :bad_request
    end
  end

  def check_message
    authorize :traveler_information, :view_and_send_messages?

    message = @receipts.find_by(id: params[:message_id])

    return unless message

    if message.is_read == false
      message.update_attribute(:is_read, true)

      render json: message, status: :ok
    else
      render json: message, status: :created
    end
  end

  def update_tracking_step
    if @traveler.update_tracking
      render json: @traveler, status: :ok
    else
      render json: @traveler.errors, status: :unauthorized
    end
  end

  def sync_user
    sso_authentication = @traveler.sso_authentications.first

    IntegrationAtLoginWorker.perform_async(sso_authentication.id) if sso_authentication

    render json: { notice: "Sync requested" }, status: 202
  end

  def insights
    authorize(:traveler_information, :view_traveler?)

    render json: TravelerProfileInsightsSerializer.new(@traveler), status: :ok
  end

  private

  def branding_theme
    ca_info = client.client_account_info

    @branding_theme ||= {
      themes: {
        theme_color_dark: ca_info.theme_color_dark,
        theme_color_light: ca_info.theme_color_light,
        theme_color_accent: ca_info.theme_color_accent
      },
      logo: {
        theme_logo: ca_info.logo.url
      }
    }
  rescue StandardError
    {}
  end

  def user_permissions
    permissions = default_permissions

    if client&.client_account_info
      role_name = current_user.role_name.to_sym

      client.client_account_info.role_settings.each do |role_grouping, settings|
        settings.each do |setting, roles|
          permissions[role_grouping] << setting.to_s if roles[role_name] == true
        end
      end
    end

    permissions.merge({ current_user_roles: current_user.roles.pluck(:name) })
  end

  def default_permissions
    {
      "organization_settings": [],
      "user_settings": [],
      "program_settings": [],
      "report_settings": [],
      "events_settings": [],
      "travel_plans_settings": [],
      "traveler_information_settings": [],
      "application_templates_settings": [],
      "traveler_applications_and_forms_settings": [],
      "form_template_settings": [],
      "recommendation_template_settings": [],
      "risk_alerts_settings": [],
      "automation_settings": []
    }
  end

  def set_profile_objects
    @traveler_info = @traveler.traveler_info
    @profile = @traveler.profile
    @passport = if @traveler_info.passport.nil?
                  @traveler_info.create_passport
                else
                  @traveler_info.passport
                end
    @codes = PhoneCountryCodes::ALL
    @ethnicities = Ethnicities::ALL
    @college_faculty = CollegeFaculty::ALL
    @races = Races::ALL
    @relationships = Relationships::ALL
    @readonly_fields = Integrations::ReadOnlyFieldFinder.new.find_locked_fields_for(@traveler)
  end

  def set_notes
    @notes = Note.includes(:author).where(client_account_id: client.id, user_id: @traveler.id)
  end

  def set_admins
    @admins = client.users.without_role(:traveler).where(archived: false).includes(:profile)
    @assigned_admins = client.assigned_admin_profiles_by_traveler(@traveler.id)
  end

  def set_messages
    @conversation = Conversation.conversation(@traveler, client)

    @receipts = if @conversation
                  @conversation.receipts_for(@traveler)
                               .includes(:notification, :receiver, message: :sender)
                               .order(created_at: :desc)
                else
                  Mailboxer::Receipt.none
                end
  end

  def validate_traveler
    @traveler = User.includes(:traveler_info, :submissions).find_by(id: params[:id])
  end

  def traveler_profile_params
    tp_params = params[:traveler_profile]
    tp_params = tp_params.each do |k, v|
      tp_params[k] = v.strip if %w[preferred_first_name preferred_last_name].include?(k)
    end

    ActionController::Parameters.new(tp_params).permit(
      Traveler::TravelerInfoParams::PERMITTED - @readonly_fields
    )
  end

  def profile_params
    profile_params = params[:profile]
    profile_params = profile_params.each { |k, v| profile_params[k] = v.strip }

    ActionController::Parameters.new(profile_params).permit(
      Traveler::ProfileParams::PERMITTED - @readonly_fields
    )
  end

  def passport_params
    params[:passport].permit(Traveler::PassportParams::PERMITTED - @readonly_fields)
  end

  def note_params
    params.require(:note).permit(:subject, :body)
  end

  def message_params
    params.require(:message).permit(:subject, :body, :attachments, { attachments: [] })
  end

  def update_report_traveler_associations(traveler)
    traveler_id = traveler.id

    ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
    UpdateReportTraveler.perform_in(10.seconds, traveler_id)

    report_submissions = ReportSubmission.where(user_id: traveler_id)

    report_submissions.update_all(sync_required: true)

    report_submissions.each do |report_submission|
      UpdateReportSubmission.perform_in(10.seconds, report_submission.submission_id)
    end

    report_plan_users = ReportPlanUser.where(user_id: traveler_id)

    report_plan_users.update_all(sync_required: true)

    report_plan_users.each do |report_plan_user|
      UpdateReportPlanUser.perform_in(10.seconds, report_plan_user.plans_users_id)
    end
  end

  # def update_auth_token_expiration
  #   return unless request.headers["HTTP_X_USER_TOKEN"].present?

  #   auth_token = VtAuthenticationToken.find_by(
  #     user_id: current_user.id,
  #     token: request.headers["HTTP_X_USER_TOKEN"]
  #   )

  #   AuthenticationToken::TokenService.new(current_user).update_auth_token_expiration(auth_token)
  # end
end
