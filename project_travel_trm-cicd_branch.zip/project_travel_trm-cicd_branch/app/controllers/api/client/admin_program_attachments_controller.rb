# frozen_string_literal: true

class Api::Client::AdminProgramAttachmentsController < Api::Client::BaseController
  before_action :find_attachment, only: %i[update destroy]

  def create
    attachment = AdminProgramAttachment.new(attachment_params)

    return bad_request(attachment) unless attachment.save(attachment_params)

    render json: AdminProgramAttachmentSerializer.new(attachment), status: :created
  end

  def update
    return bad_request(@attachment) unless @attachment.update(attachment_params)

    render json: AdminProgramAttachmentSerializer.new(@attachment), status: :ok
  end

  def destroy
    @attachment.destroy

    render json: {}, status: :no_content
  end

  private

  def find_attachment
    @attachment = AdminProgramAttachment.find_by(id: attachment_params[:id])

    return not_found unless @attachment
  end

  def attachment_params
    params.require(:admin_program_attachment).permit(:file, :id, :program_id, :title)
  end
end
