class Api::Client::TravelPlansController < Api::Client::BaseController
  respond_to :json

  def index
    authorize :travel_plans, :access_travel_registration?
    travel_plans = current_user.client_account.travel_plans

    render json: travel_plans, status: :ok
  end

  # GET travel_plan
  def show
    authorize :travel_plans, :access_travel_registration?
    travel_plan = TravelPlan.find(params[:id])
    travelers = []
    travel_plan.traveler_plan_logistics.map(&:profile).map do |profile|
      travelers << {
        id: profile.id,
        email: profile.email,
        first_name: profile.first_name,
        last_name: profile.last_name,
        avatar: profile.avatar.url
      }
    end

    if travel_plan
      render json: {travel_plan: travel_plan, travelers: travelers}, status: :ok
    else
      render json: travel_plan.errors, status: :bad_request
    end
  end

  def travel_plan_logistics
    authorize :program, :show?
    travel_plan = TravelPlan.find(params[:id])

    arrival_logistics = gather_logistics(travel_plan, "Arrival")
    onsite_logistics = gather_logistics(travel_plan, "Onsite")
    return_logistics = gather_logistics(travel_plan, "Return")

    respond_with arrival_logistics, onsite_logistics, return_logistics do |format|
      format.json { render json: {:arrival => arrival_logistics.as_json, :onsite => onsite_logistics.as_json, :return => return_logistics.as_json}, status: :ok }
    end
  end

  def add_housing_logistic
    authorize :program, :edit?
    travel_plan = TravelPlan.find(params[:id])

    housing_logistic = HousingLogistic.new(housing_logistic_params.merge(travel_plan_id: travel_plan_id))

    if housing_logistic.save
      render json: event, status: :created
    else
      render json: { errors: event.errors }, status: :unprocessable_entity
    end
  end

  private

  def gather_logistics(travel_plan, logistic_type)
    housing_logistics = []
    transportation_logistics = []
    activity_logistics = []

    travel_plan.housing_logistics.where(logistic_type: logistic_type).map do |housing_logistic|
      logistic = {logistic: housing_logistic, travelers: [], type: "housing"}
      housing_logistic.traveler_plan_logistics.map(&:profile).map do |profile|
        logistic[:travelers] << {id: profile.id, email: profile.email, first_name: profile.first_name, last_name: profile.last_name}
      end
      housing_logistics << logistic
    end

    travel_plan.transportation_logistics.where(logistic_type: logistic_type).map do |transportation_logistic|
      logistic = {logistic: transportation_logistic, travelers: [], type: "transportation", segments: []}
      transportation_logistic.traveler_plan_logistics.map(&:profile).map do |profile|
        logistic[:travelers] << {id: profile.id, email: profile.email, first_name: profile.first_name, last_name: profile.last_name}
      end
      logistic[:segments] = transportation_logistic.transportation_segments.order(departure_date: :asc, departure_time: :asc)
      transportation_logistics << logistic
    end

    travel_plan.activity_logistics.where(logistic_type: logistic_type).map do |activity_logistic|
      logistic = {logistic: activity_logistic, travelers: [], type: "activity"}
      activity_logistic.traveler_plan_logistics.map(&:profile).map do |profile|
        logistic[:travelers] << {id: profile.id, email: profile.email, first_name: profile.first_name, last_name: profile.last_name}
      end
      activity_logistics << logistic
    end

    (housing_logistics + activity_logistics + transportation_logistics).sort_by { |logistic| logistic[:departure_date] }
  end

  def housing_logistic_params
    params.require(:housing_logistic).permit(:name, :logistic_type, :housing_type, :arrival_date, :departure_date, :travel_plan_id, :country_code, :phone_number, :email, :confirmation_number, :arrival_time, :departure_time, :time_zone, :lat, :long, :address)
  end
end
