# frozen_string_literal: true

class Api::Client::ProgramsController < Api::Client::BaseController
  include Api::Client::ProgramsHelper

  before_action :admin_query

  respond_to :json

  def index
    render json: {
      programs: client.programs.select(:id, :title),
      all_program_types: ProgramType.all.map { |pt| { id: pt.id, name: pt.name, order: pt.order } }
    }, status: 200
  end

  def get_program
    authorize(:program, :show?)

    if program
      authorized = program.primary_client_account_id != client.id
      program_ranges = program.program_ranges.order(:start_date).as_json

      program_ranges.each do |program_range|
        pr = client.program_ranges.find(program_range["id"])

        next unless authorized

        suitcase = client.suitcase_by_program_range(pr)

        program_range.merge!(
          {
            "alternate" => suitcase&.allow_alternates,
            "alternate_all_programs" => suitcase&.allow_alternates,
            "deadline" => suitcase&.application_deadline,
            "decision_release_date" => nil,
            "name" => suitcase&.name,
            "provider_deadline" => pr.deadline,
            "provider_term_name" => pr.term_title,
            "term_name_id" => suitcase&.term_name_id
          }
        )
      end

      ranges = program_ranges.map do |range|
        pr = client.program_ranges.find(range["id"])

        template = if authorized
                     client.suitcase_application_template_by_program_range(pr)
                   else
                     pr.application_template
                   end

        { application: template, range: range }
      end

      program_admins = program.program_managers
                              .select { |manager| manager.user if manager.user.present? }
                              .map do |manager|
        {
          id: manager.user_id,
          name: manager.user.name,
          first_name: manager.user.profile.first_name,
          last_name: manager.user.profile.last_name,
          role: manager.user.client_user_info&.job_title,
          program_con: program.program_contact.user.name,
          contact: program.program_contact.user.name == manager.user.name
        }
      end

      client_apps = client.client_account_applications.published

      client_forms = Form.published_for(client).map do |form|
        { id: form.id, name: form.name, grouping: form.form_groupings }
      end

      program_settings = program_ranges.map do |range|
        pr = client.program_ranges.find(range["id"])

        forms = pr.program_range_form_groupings.map do |grouping|
          {
            deadline: grouping.deadline,
            form: grouping.form_templates,
            form_grouping_templates: grouping.program_range_form_grouping_templates
          }
        end

        {
          applications: pr.client_account_application,
          availableApplications: client.client_account_applications.published,
          range: range,
          forms: forms,
          availableForms: Form.published_for(client).map { |form| { id: form.id, name: form.name } }
        }
      end

      administrators = []

      unless @admin_query.empty?
        @admin_query.map do |user|
          begin
            administrators << {
              id: user.id,
              name: user.name,
              first_name: user.profile.first_name,
              last_name: user.profile.last_name,
              role: user.client_user_info&.job_title,
              program_con: program.program_contact.user.name,
              contact: program.program_contact.user.name == user.name
            }
          rescue StandardError
            # Just ignore anyone who fails for right now.
          end
        end
      end

      serialized_program = program.as_json

      if program.program_images.any?
        serialized_background_photo = program.serialized_primary_program_image

        serialized_program.merge!({ background_photo: serialized_background_photo })
      end

      render json: [
        serialized_program,
        programTypes: program.program_types.map(&:name),
        programMap: program.program_map.included,
        programMapId: program.program_map.id,
        ProgramHighlight: program.program_highlight,
        ProgramLocation: program.program_location_highlight,
        Locations: program.program_locations_array_of_objects,
        Coordinates: [
          program.program_locations.in_order.map { |l| { data: { lat: l.lat, lon: l.lng } } }
        ],
        ProgramRanges: program_ranges,
        Ranges: ranges,
        ProgramSettings: program_settings,
        ProgramActivity: program.program_activities,
        ProgramAmenities: program.program_amenities.map { |sample| sample.amenity.name },
        ProgramAmenitiesIncluded: program.program_amenities.included.map do |sample|
          sample.amenity.name
        end,
        ProgramAmenitiesExcluded: program.program_amenities.excluded.map do |sample|
          sample.amenity.name
        end,
        ProgramCourses: program.program_courses,
        ProgramReview: program.program_review,
        ProgramEligibility: program.program_eligibility,
        ProgramScholarship: program.program_scholarship_info,
        ProgramLanguages: program.languages,
        ProgramHousing: program.program_housings.map do |sample|
          { housing_type: sample.housing_type, included: sample.included }
        end,
        ProgramSubjects: program.program_subjects.map(&:subject_area).compact.sort_by(&:name),
        ProgramActivities: program.program_activities,
        ProgramExcursions: program.program_excursions,
        programAdmins: administrators,
        ProgramManagers: program_admins,
        PublishStatus: program.status,
        ClientApps: client_apps,
        ClientForms: client_forms,
        Authorized: authorized,
        ProgramLanguageCodes: program.language_codes,
        ProgramOpportunities: program.program_opportunities.map do |add_on|
          { id: add_on.id, info: add_on.info }
        end,
        ProgramDisplayableAmenities: program.displayable_amenities,
        ProgramAmenitiesWithId: program.program_amenities.map { |pa| program_amenity_json(pa) },
        ProgramAmenitiesIncludedWithId: program.program_amenities.included.map do |pai|
          program_amenity_json(pai)
        end,
        ProgramAmenitiesExcludedWithId: program.program_amenities.excluded.map do |pae|
          program_amenity_json(pae)
        end,
        ProgramDisplayableAmenitiesWithId: (
          program.program_amenities.included + program.program_amenities.excluded
        ).sort.map { |paie| program_amenity_json(paie) },
        authorized: authorized,
        internal_program: program.primary_client_account.id == client.id,
        program_type_connections: program.program_type_connections.map do |ptc|
          { id: ptc.id, program_type_id: ptc.program_type_id }
        end,
        pactivities: program.pactivities,
        pexcursions: program.pexcursions,
        padd_ons: program.padd_ons,
        pcourses: program.pcourses,
        lat: program.primary_location&.lat,
        lng: program.primary_location&.lng
      ], status: 201
    else
      render json: [{}, { authorized: false, internal_program: false }], status: 201
    end
  end

  def get_org_authorized_program_settings
    render json: [
      AuthorizedProgramSettings: AuthorizedProgramSettingsPresenter.new(client.client_account_info)
                                                                   .intro_text,
      suitcases: SuitcaseSerializer.new(client.suitcases.in_order)
    ], status: :created
  end

  def get_program_hash
    authorize(:program, :show?)

    return not_found unless program

    authorizable = program.primary_client_account_id != client.id
    authorized = authorizable && client.programs.include?(program)
    program_ranges = if params["settings"]
                       client.programs
                             .includes(program_ranges: { program_range_form_groupings: :form_templates })
                             .find(program.id).program_ranges.order(:start_date).as_json
                     else
                       program.program_ranges.where("start_date > ?", Date.today).order(:start_date)
                              .as_json
                     end

    program_ranges.each do |program_range|
      pr = client.program_ranges.find_by(id: program_range["id"])

      next unless pr

      if authorizable
        suitcase = client.suitcase_by_program_range(pr)

        program_range.merge!(
          {
            "alternate" => suitcase&.allow_alternates,
            "alternate_all_programs" => suitcase&.allow_alternates,
            "deadline" => suitcase&.application_deadline,
            "decision_release_date" => nil,
            "name" => suitcase&.name,
            "provider_deadline" => pr.deadline,
            "provider_term_name" => pr.term_title,
            "term_name_id" => suitcase&.term_name_id
          }
        )
      else
        program_range.merge!({ "name" => pr.term_title })
      end
    end

    ranges = program_ranges.map.with_index do |range, index|
      pr = client.program_ranges.find_by(id: range["id"])

      next unless pr

      template = if authorizable
                   client.suitcase_application_template_by_program_range(pr)
                 else
                   pr.application_template
                 end

      { application: template, dummyId: index, range: range }
    end

    program_admins = program.program_managers
                            .select { |manager| manager.user if manager.user.present? }
                            .map do |manager|
      {
        id: manager.user_id,
        name: manager.user.name,
        first_name: manager.user.profile.first_name,
        last_name: manager.user.profile.last_name,
        email: available_email(manager.user),
        role: manager.user.client_user_info&.job_title,
        program_con: program.program_contact&.user&.name,
        contact: program.program_contact&.user&.name == manager.user.name,
        program_contact: program.program_contact,
        record_id: manager.id,
        db_roles: manager.user_roles
      }
    end

    client_apps = client.templates.application.published.order(:name)

    client_available_forms = client.templates.form.published.order(updated_at: :desc)

    client_forms = client_available_forms.map do |form|
      {
        id: form.id,
        title: form.name,
        grouping: form.program_range_form_groupings
      }
    end

    program_settings = program_ranges.map do |range|
      pr = client.program_ranges.find_by(id: range["id"])

      next unless pr

      {
        application_count: pr.application_submissions.count,
        applications: pr.application_template,
        availableApplications: client.templates.application.published.order(:name),
        range: range,
        form_count: pr.form_submissions.count,
        forms: pr.program_range_form_groupings.map do |grouping|
                 {
                   id: grouping.id,
                   deadline: grouping.deadline,
                   form: grouping.form_templates,
                   form_grouping_templates: grouping.program_range_form_grouping_templates
                 }
               end,
        availableForms: client_available_forms.map { |form| { id: form.id, title: form.name } },
        termTags: pr.taggables.includes(:client_tag).order(id: :desc).map do |taggable|
          {
            id: taggable.tag_id,
            name: taggable.name,
            taggable_id: taggable.id,
            archive: taggable.archive
          }
        end,
        termAlternateTags: pr.term_alternate_tags,
        alternateProgramCount: alternate_programs_count(pr.id, pr.term_alternate_tag_ids)
      }
    end

    administrators = []
    client_administrators = []

    unless @admin_query.empty?
      @admin_query.map do |user|
        begin
          administrators << {
            id: user.id,
            name: user.name,
            first_name: user.profile.first_name,
            last_name: user.profile.last_name,
            email: available_email(user),
            role: user.client_user_info&.job_title,
            program_con: program.program_contact.user.name,
            contact: program.program_contact.user.name == user.name,
            program_contact: program.program_contact,
            db_roles: user.user_roles
          }
          client_administrators << {
            first_name: user.profile.first_name,
            last_name: user.profile.last_name,
            role: !user.roles.where_not_traveler.empty? ?
              user.roles.where_not_traveler&.first&.name :
              ""
          }
        rescue StandardError
          # Just ignore anyone who fails for right now.
        end
      end
    end

    serialized_program = program.as_json

    if program.program_images.any?
      serialized_background_photo = program.serialized_primary_program_image

      serialized_program.merge!({ background_photo: serialized_background_photo })
    end

    occasional_user_assigned = current_user.has_role?(:occasional_user) &&
                               current_user.assigned_programs.include?(program)

    render json: {
      admin_program_attachments: program.admin_program_attachments.in_order,
      client_admins: client_administrators,
      program: serialized_program,
      program_attachments: program.program_attachments.in_order,
      program_types: program.program_types.sort_by(&:order).map(&:name),
      program_map: program.program_map&.included,
      program_highlight: program.program_highlight,
      program_location: program.program_location_highlight,
      locations: program.program_locations_array_of_objects,
      coordinates: [
        program.program_locations.in_order.map { |l| { data: { lat: l.lat, lon: l.lng } } }
      ],
      program_ranges: program_ranges,
      ranges: ranges,
      program_settings: program_settings,
      program_activity: program.program_activities,
      program_amenities: program.program_amenities.map { |sample| sample.amenity.name },
      program_amenities_included: program.program_amenities.included.map do |sample|
        sample.amenity.name
      end,
      program_amenities_excluded: program.program_amenities.excluded.map do |sample|
        sample.amenity.name
      end,
      program_courses: program.program_courses,
      program_review: program.program_review,
      program_eligibility: program.program_eligibility,
      program_scholarship: program.program_scholarship_info,
      program_languages: program.languages,
      program_housing: program.program_housings.map do |sample|
        { housing_type: sample.housing_type, included: sample.included }
      end,
      program_subjects: program.program_subjects.map(&:subject_area).compact.sort_by(&:name),
      program_activities: program.program_activities,
      program_excursions: program.program_excursions,
      program_admins: administrators,
      program_managers: program_admins,
      publish_status: program.status,
      client_apps: client_apps,
      client_forms: client_forms.sort_by { |cf| cf[:title].downcase },
      authorized: authorized,
      internal_program: program.primary_client_account.id == client.id,
      program_language_codes: program.language_codes,
      program_opportunities: program.program_opportunities.map do |add_on|
        { id: add_on.id, info: add_on.info }
      end,
      program_displayable_amenities: program.displayable_amenities,
      program_amenities_with_id: program.program_amenities.map { |pa| program_amenity_json(pa) },
      program_amenities_included_with_id: program.program_amenities.included.map do |pai|
        program_amenity_json(pai)
      end,
      program_amenities_excluded_with_id: program.program_amenities.excluded.map do |pae|
        program_amenity_json(pae)
      end,
      program_displayable_amenities_with_id: (
        program.program_amenities.included + program.program_amenities.excluded
      ).sort.map { |paie| program_amenity_json(paie) },
      is_owner: program.owned_by?(client),
      has_future_term: program.program_ranges.where("start_date > ? ", Date.today).length >= 1,
      provider: program.primary_client_account.org_name,
      organization_description: (
        begin
          if authorized
            ClientAccountInfo.find_by_client_account_id(program.primary_client_account_id)
                             .description
          else
            client.client_account_info.description
          end
        rescue
          nil
        end
      ),
      program_locations: program.program_locations.in_order.map do |pl|
        {
          id: pl.id,
          alpha2: pl.alpha2,
          city: pl.city,
          lat: pl.lat,
          lng: pl.lng,
          continent: pl.continent,
          country_common_name: pl.country_common_name,
          county_or_region: pl.county_or_region,
          formatted_address: pl.formatted_address,
          google_place_id: pl.google_place_id,
          image_url: pl.image_url,
          locality: pl.location,
          program_id: pl.program_id,
          postal_code: pl.postal_code,
          postal_code_suffix: pl.postal_code_suffix,
          state_or_province: pl.state_or_province,
          state_or_province_code: pl.state_or_province_code,
          street: pl.street,
          street_number: pl.street_number,
          time_zone: pl.time_zone,
          time_zone_offset: pl.time_zone_offset
        }
      end,
      program_administrators: program.program_managers.map do |pm|
        user = pm.user
        user_id = user.id

        {
          id: pm.id,
          email: user.email,
          name: user.preferred_name,
          program_contact: program.program_contact&.user_id == user_id,
          program_id: pm.program_id,
          user_id: user_id
        }
      end,
      pactivities: program.pactivities,
      pexcursions: program.pexcursions,
      padd_ons: program.padd_ons,
      pcourses: program.pcourses,
      org_timezone: client.try(:client_account_info)&.org_timezone,
      lat: program.primary_location&.lat,
      lng: program.primary_location&.lng,
      academic_notes: program.academic_notes,
      activity_notes: program.activity_notes,
      host_organization: program.host_organization,
      host_organization_notes: program.host_organization_notes,
      housing_notes: program.housing_notes,
      location_notes: program.location_notes,
      notes: program.notes,
      home_campus: client.org_name,
      occasional_user_assigned: occasional_user_assigned,
      program_brochure_section: program.program_brochure_sections.where(client_account_id: client.id).select('id, title, description').first || {}
    }, status: 201
  end

  def program_brochure_details
    authorize(:program, :show?)

    return not_found unless program

    authorizable = program.primary_client_account_id != client.id
    authorized = authorizable && client.programs.include?(program)
    program_ranges =
      if params["settings"]
        client.programs
              .includes(program_ranges: { program_range_form_groupings: :form_templates })
              .find(program.id).program_ranges.order(:start_date).as_json
      else
        program.program_ranges.where("start_date > ?", Date.today).order(:start_date)
              .as_json
      end

    ranges = []

    program_ranges.each_with_index do |program_range, index|
      pr = client.program_ranges.find_by(id: program_range["id"])

      next unless pr

      if authorizable
        suitcase = client.suitcase_by_program_range(pr)

        program_range.merge!(
          {
            "deadline" => suitcase&.application_deadline,
            "name" => suitcase&.name,
            "term_name_id" => suitcase&.term_name_id
          }
        )

        template = client.suitcase_application_template_by_program_range(pr)
      else
        program_range.merge!({ "name" => pr.term_title })
        template = pr.application_template
      end

      ranges << { application: template, dummyId: index, range: program_range }
    end

    program_contact = @admin_query.where(id: program.program_contact.user_id).select('id, first_name, last_name, email')

    serialized_program = program.as_json

    ppi = program.primary_program_image

    serialized_program.merge!({
      background_photo: ppi&.background,
      program_list_img_url: ppi&.list
    })

    render json: {
      program: serialized_program,
      program_attachments: program.program_attachments.in_order,
      program_types: program.program_types.sort_by(&:order).map(&:name),
      program_map: program.program_map&.included,
      program_highlight: program.program_highlight,
      program_location: program.program_location_highlight,
      locations: program.program_locations,
      coordinates: [
        program.program_locations.in_order.map { |l| { data: { lat: l.lat, lon: l.lng } } }
      ],
      ranges: ranges,
      program_amenities_included: program.program_amenities.included.map do |sample|
        sample.amenity.name
      end,
      program_amenities_excluded: program.program_amenities.excluded.map do |sample|
        sample.amenity.name
      end,
      program_eligibility: program.program_eligibility,
      program_scholarship: program.program_scholarship_info,
      program_languages: program.languages,
      program_housing: program.program_housings.map do |sample|
        { housing_type: sample.housing_type, included: sample.included }
      end,
      program_subjects: program.program_subjects.map(&:subject_area).compact.sort_by(&:name),
      publish_status: program.status,
      authorized: authorized,
      internal_program: program.primary_client_account.id == client.id,
      org_timezone: client.try(:client_account_info)&.org_timezone,
      organization_description: (
        begin
          if authorized
            ClientAccountInfo.find_by_client_account_id(program.primary_client_account_id)
                             .description
          else
            client.client_account_info.description
          end
        rescue
          nil
        end
      ),
      academic_notes: program.academic_notes,
      home_campus: client.org_name,
      pactivities: program.pactivities,
      pexcursions: program.pexcursions,
      padd_ons: program.padd_ons,
      pcourses: program.pcourses,
      program_contact: program_contact,
      housing_notes: program.housing_notes,
      location_notes: program.location_notes,
      host_organization: program.host_organization,
      host_organization_notes: program.host_organization_notes,
      activity_notes: program.activity_notes,
      provider: program.primary_client_account.org_name,
      program_review: program.program_review,
      program_administrators: program.program_managers.map do |pm|
        user = pm.user
        user_id = user.id

        {
          id: pm.id,
          email: user.email,
          name: user.preferred_name,
          program_contact: program.program_contact.user_id == user_id,
          program_id: pm.program_id,
          user_id: user_id
        }
      end,
      program_brochure_section: program.program_brochure_sections.where(client_account_id: client.id).select('id, title, description').first || {}
    }, status: 201
  end

  def thin
    programs = if params[:unauthorize_programs].present? && ['true', true].include?(params[:unauthorize_programs])
                 Program.where(id: ProgramRange.where(id: client.submissions.pluck(:program_range_id).uniq).pluck(:program_id).uniq)
               else
                 client.programs
               end

    if params[:source].present?
      programs = case params[:source]
                 when 'internal'
                   programs.internal(client)
                 when 'authorized'
                   programs.authorized(client)
                 when 'unauthorized'
                   authorizable_programs =
                     if params[:org_id].present?
                       Program.authorizable(params[:org_id])
                     else
                       Program.all_authorizable
                     end

                   authorizable_programs.where("id NOT IN (?)", programs.pluck(:id))
                 end
    end

    client_programs = client.programs
    programs = programs&.map { |l|
      {
        id: l.id,
        title: l.title,
        internal_authorize: l.internal?(client),
        status: l.status,
        unauthorize: client_programs.where(id: l.id).empty?
      }
    }

    if params[:automation_id].present?
      automation = Automation.find(params[:automation_id])
      automation_program_ids = automation.automation_triggers
                                         .joins(:automation_precondition, :automation_conditions)
                                         .where(
                                           automation_preconditions: {
                                             identifier: %w[application_program_is form_program_is]
                                           }
                                         ).pluck("automation_conditions.display_name")

      if automation_program_ids
        program_ids = programs.pluck(:id)

        Program.where(id: automation_program_ids.map(&:to_i)).each do |program|
          next if program_ids.include?(program.id)

          programs << {
            id: program.id,
            title: program.title,
            internal_authorize: false,
            status: program.status,
            unauthorize: true
          }
        end
      end
    end

    render json: { programs: programs&.sort_by { |program| program[:title] } }, status: 200
  end

  def program_settings
    authorize(:program, :show?)

    program = client.programs.find(params[:id])
    program_ranges = program.program_ranges.select(&:start_date)
                            .sort_by(&:start_date) + program.program_ranges.reject(&:start_date)
    program_admins = program.program_managers
                            .select { |manager| manager.user if manager.user.present? }
                            .map do |manager|
      {
        id: manager.user_id,
        name: manager.user.name,
        first_name: manager.user.profile.first_name,
        last_name: manager.user.profile.last_name,
        role: manager.user.client_user_info&.job_title,
        program_con: program.program_contact.user.name,
        contact: program.program_contact.user.name == manager.user.name
      }
    end

    administrators = []

    unless @admin_query.empty?
      @admin_query.map do |user|
        begin
          administrators << {
            id: user.id,
            name: user.name,
            first_name: user.profile.first_name,
            last_name: user.profile.last_name,
            role: user.client_user_info&.job_title,
            program_con: program.program_contact.user.name,
            contact: program.program_contact.user.name == user.name
          }
        rescue StandardError
          # Just ignore anyone who fails for right now.
        end
      end
    end

    program_settings = program_ranges.map do |range|
      {
        title: program.title,
        authorized: program.primary_client_account_id != client.id,
        applications: range.application_template,
        availableApplications: client.client_account_applications.published,
        range: range,
        forms: range.program_range_form_groupings.map do |grouping|
                 {
                   deadline: grouping.deadline,
                   form: grouping.form_templates,
                   form_grouping_templates: grouping.program_range_form_grouping_templates
                 }
               end,
        availableForms: Form.published_for(client).map { |form| { id: form.id, name: form.name } },
        programManagers: program_admins,
        programAdmins: administrators
      }
    end

    render json: program_settings, status: 200
  end

  def get_authorized_programs
    user = User.find(params[:id])
    user_client_account = user.client_account
    programs = user_client_account.programs.limit(10).filter do |p|
      p.primary_client_account_id != user_client_account.id
    end

    render json: programs, status: 201
  end

  def unauthorized_programs
    user = User.find(params[:id])
    user_client_account = user.client_account

    client_account = ClientAccount.where(org_name: params[:org_name])
    programs = Program.where(primary_client_account: client_account, is_authorizable: true)
                      .includes(
                        :subject_areas,
                        :program_ranges,
                        :program_locations,
                        :program_languages,
                        :program_contact,
                        :primary_client_account
                      )

    programs_with_associations = programs.map do |program|
      program.attributes.merge(
        "background_photo": program.result_url,
        "subject_areas": program.subject_areas.pluck(:name),
        "program_ranges": program.program_ranges,
        "start_date": program.program_ranges.minimum(:start_date),
        "end_date": program.program_ranges.maximum(:end_date),
        "program_length": program.program_ranges.pluck(:weeks),
        "program_locations": program.program_locations_array,
        "program_languages": program.program_languages.pluck(:iso_639_3),
        "housing_types": HousingType.where(
          id: program.program_housings.where(included: true).pluck(:housing_type_id)
        ).pluck(:name),
        "school": program.primary_client_account.org_name,
        "program_types": program.program_types.map(&:name),
        "authorized": !program.client_account_programs.where(client_account_id: user_client_account)
                              .empty?
        )
    end

    respond_with(programs_with_associations) do |format|
      format.json do
        render json: {
          programs: programs_with_associations,
          housing_types: HousingType.all.pluck(:name),
          status: 200
        }
      end
    end
  end

  def authorize_programs
    authorize(:program, :authorize?)

    program_ids = params[:program_ids]
    authorized_program_range_ids = []

    program_ids.map do |program_id|
      authorized_program = client.client_account_programs.find_or_initialize_by(
        program_id: program_id
      )

      next unless authorized_program.new_record?

      authorized_program.save

      program = authorized_program.program
      authorized_program_range_ids += program.program_range_ids

      add_authorized_program_range_ids_to_info(program)
    end

    update_client_specific_report_program_associations(program_ids, authorized_program_range_ids)

    render json: { programs: program_ids, code: 200 }, status: 200
  end

  def authorize_program
    authorize(:program, :authorize?)

    program_id = params[:id]
    authorized_program = client.client_account_programs.find_or_initialize_by(
      program_id: program_id
    )

    unless authorized_program.new_record?
      return render json: { authorized_program: authorized_program, code: 200 }, status: 200
    end

    if authorized_program.save
      program = authorized_program.program

      add_authorized_program_range_ids_to_info(program)

      update_client_specific_report_program_associations([program_id], program.program_range_ids)

      render json: { authorized_program: authorized_program, code: 200 }, status: 200
    else
      render json: { errors: authorized_program.errors, status: 400 }
    end
  end

  def deauthorize_program
    authorize(:program, :authorize?)

    program_id = params[:id]
    program = Program.find(program_id)

    if program.internal?(client)
      return render json: {
        message: "Unable to deauthorize internal program"
      }, status: :bad_request
    end

    client_account_program = client.client_account_programs.find_by(program_id: program_id)

    if client_account_program
      deauthorized_program_range_ids = client_account_program.program.program_range_ids

      remove_authorized_program_ranges_from_info(deauthorized_program_range_ids)

      client_account_program.destroy

      update_client_specific_report_program_associations(
        [program_id],
        deauthorized_program_range_ids
      )

      render json: { deauthorize_program: client_account_program, code: 200 }, status: 200
    else
      render json: { errors: client_account_program.errors, status: 400 }
    end
  end

  def toggle_authorization
    authorize(:program, :authorize?)

    program = client.programs.find(params[:id])
    program.is_authorizable = params[:checked]
    program.external_program_url = params[:external_program_url]
    program.skip_range_validation = true

    if program.save
      update_all_report_program_associations(program)

      render json: { program: program, code: 200 }, status: 200
    else
      render json: { errors: program.errors, status: 400 }
    end
  end

  def deauthorize_programs
    program_ids = params[:program_ids]
    deauthorized_program_range_ids = []
    dedauthorized_program_ids = []

    program_ids&.map do |program_id|
      program = Program.find_by_id(program_id)

      next if program.internal?(client)

      client_account_program = client.client_account_programs.find_by(program_id: program_id)

      if client_account_program
        deauthorized_program_range_ids += client_account_program.program.program_range_ids

        client_account_program.destroy

        dedauthorized_program_ids << program_id
      end
    end

    remove_authorized_program_ranges_from_info(deauthorized_program_range_ids)
    update_client_specific_report_program_associations(program_ids, deauthorized_program_range_ids)

    render json: { program_ids: dedauthorized_program_ids, status: 200 }, status: 200
  end

  def providers
    auth_programs_primary_accounts_ids = Program.where(is_authorizable: true, status: 1)
                                                .pluck(:primary_client_account_id).uniq
    accounts_with_auth_programs = ClientAccount.where(id: auth_programs_primary_accounts_ids)
                                               .pluck(:org_name)

    render json: { providers: accounts_with_auth_programs }, status: 200
  end

  def new
    subject_areas = SubjectArea.where(included: true)
                               .select("DISTINCT ON (name) *")
                               .order(:name)
    amenities = []

    Amenities::DETAILS.map { |n| amenities << n[1] }

    housing_types = HousingType.all.map { |ht| { id: ht.id, name: ht.name } }
    program_types = ProgramType.all.map { |pt| { id: pt.id, name: pt.name } }

    render json: [subject_areas, amenities, housing_types, program_types], status: 201
  end

  def create
    authorize(:program, :create?)

    new_program = Program.new(program_params)

    new_program.build_program_contact(user: @user)
    new_program.build_program_eligibility unless new_program.program_eligibility
    new_program.build_program_highlight unless new_program.program_highlight
    new_program.build_program_location_highlight unless new_program.program_location_highlight
    new_program.build_program_map unless new_program.program_map
    new_program.build_program_review unless new_program.program_review
    new_program.build_program_scholarship_info unless new_program.program_scholarship_info
    new_program.program_activities.build unless new_program.program_activities.any?
    new_program.program_courses.build unless new_program.program_courses.any?
    new_program.program_excursions.build unless new_program.program_excursions.any?
    new_program.program_images.build(client_account_id: client.id, primary: true)
    new_program.program_managers.build(user: @user)
    new_program.program_opportunities.build unless new_program.program_opportunities.any?

    new_program.is_authorizable = true

    if new_program.title.present?
      new_program.save(validate: false)

      client.programs << new_program

      update_client_specific_report_program_associations([new_program.id], [])

      render json: new_program, status: 201
    else
      new_program.errors.add(:title, "Please enter a #{t :program} title.")

      render json: { program: new_program, errors: new_program.errors, status: 400 }
    end
  end

  def update_program_settings
    authorize(:program, :create?)

    program.skip_range_validation = program.skip_language_validation = program.skip_subject_validation = program.skip_location_validation = program.skip_type_validation = true

    program_ranges_attributes = params[:program][:program_ranges_attributes]

    if program.update_attributes(update_program_settings_params)
      if program_ranges_attributes
        range_ids = program_ranges_attributes.map { |range| range[:id] }.compact

        range_ids.each { |id| SyncProgramRangeForms.perform_async(id) } if range_ids.any?
      end

      update_all_report_program_associations(program)

      render json: { message: 'Updated successfully' }, status: 201
    else
      render json: { errors: program.errors, status: 400 }
    end
  end

  def cancel_program_range
    program_range = client.program_ranges.find_by(id: program_range_params[:id])

    return render json: {}, status: :not_found unless program_range

    pr_applications = program_range.application_submissions
    pr_forms = program_range.form_submissions

    if (pr_applications.count + pr_forms.count).zero?
      program_range.destroy
      update_all_report_program_associations(program_range.program)

      render json: {}, status: :no_content
    else
      program_range.update(status: 1)

      update_all_report_program_associations(program_range.program)

      render json: ProgramRangeSerializer.new(
        program_range,
        params: { client_account: client, time_zone: client.org_timezone }
      ), status: :ok
    end
  end

  def restore_program_range
    program_range = client.program_ranges.find_by(id: program_range_params[:id])

    return render json: {}, status: :not_found unless program_range

    pr_applications = program_range.application_submissions
    pr_forms = program_range.form_submissions

    if (pr_applications.count + pr_forms.count).zero? && program_range.deleted?
      program_range.restore
      # update_all_report_program_associations(program_range.program)

      render json: {}, status: :no_content
    else
      program_range.update(status: 0)

      # update_all_report_program_associations(program_range.program)

      render json: ProgramRangeSerializer.new(
        program_range,
        params: { client_account: client, time_zone: client.org_timezone }
      ), status: :ok
    end
  end

  def update
    authorize(:program, :create?)

    program.skip_range_validation = true

    program.program_types_included = program_params[:program_type_connections_attributes].map do |c|
      c[1]["included"]
    end.include?(true)

    params[:program][:program_amenities_attributes].each do |attr|
      attr.last.merge!(
        id: program.program_amenities.map do |pa|
          pa.id if pa.amenity_id == attr.last[:amenity_id]
        end.compact.first
      )
    end

    params[:program][:program_housings_attributes].each do |attr|
      attr.last.merge!(
        id: program.program_housings.map do |ph|
          ph.id if ph.housing_type_id == attr.last[:housing_type_id]
        end.compact.first
      )
    end

    program.program_courses.build unless program.program_courses.any?
    program.program_activities.build unless program.program_activities.any?
    program.program_excursions.build unless program.program_excursions.any?
    program.program_opportunities.build unless program.program_opportunities.any?
    program.build_program_contact(user: @user) unless program.program_contact
    program.build_program_eligibility unless program.program_eligibility
    program.build_program_highlight unless program.program_highlight
    program.build_program_location_highlight unless program.program_location_highlight
    program.build_program_map unless program.program_map
    program.build_program_review unless program.program_review
    program.build_program_scholarship_info unless program.program_scholarship_info

    primary_program_image = program.program_images.primary
    uploaded_background = program_params[:background_photo]

    primary_program_image.update(s3_store: uploaded_background) if uploaded_background

    if program.status == "draft"
      program.assign_attributes(program_params)
      program.update_attribute(:subject_area_ids, []) if program_params[:subject_area_ids].nil?

      if program.save(validate: false)
        render json: { program: program, status: 201 }
      else
        render json: {
          program: program,
          errors: program.errors,
          status: program.errors.blank? ? 201 : 400
        }
      end
    else
      program.program_highlight.update_attribute(:text, "<p> </p>") if params[:program][:program_highlight_attributes][:text] == ""
      program.program_location_highlight.update_attribute(:text, "<p> </p>") if params[:program][:program_location_highlight_attributes][:text] == ""
      program.program_scholarship_info.update_attribute(:scholarship_info, "") if params[:program][:program_scholarship_info_attributes][:scholarship_info] == ""

      program.update_attributes(program_params)
      program.update_attribute(:subject_area_ids, []) if program_params[:subject_area_ids].nil?

      update_all_report_program_associations(program)

      render json: {
        program: program,
        errors: program.errors,
        status: program.errors.blank? ? 201 : 400
      }
    end
  end

  def update_lat_lng
    authorize(:program, :create?)

    program_location = program.primary_location

    if program_location
      program_location.lat = params[:lat]
      program_location.lng = params[:lng]

      program_location.save(validate: false)

      update_all_report_program_associations(program)
    end

    render json: {}, status: :ok
  end

  def destroy
    authorize(:program, :create?)

    if program.draft? && program.destroy
      update_all_report_program_associations(program)

      render json: {}, status: :no_content
    else
      render json: { error: "Only drafts may be destroyed" }, status: :bad_request
    end
  end

  def program_params
    params["program"]["primary_client_account_id"] = current_user.client_account_id

    params.require(:program).permit(
      :academic_notes,
      :activity_notes,
      :background_photo,
      :external_application_url,
      :host_organization,
      :host_organization_notes,
      :housing_notes,
      :institution_only,
      :language_immersion,
      :location_notes,
      :pactivities,
      :padd_ons,
      :pexcursions,
      :pcourses,
      :primary_client_account_id,
      :title,
      program_locations_attributes: %i[id alpha2 city lat lng _destroy],
      program_type_connections_attributes: %i[id program_type_id included _destroy],
      program_housings_attributes: %i[id housing_type_id included _destroy],
      subject_area_ids: [],
      program_custom_supports_attributes: %i[id custom_support_id included _destroy],
      program_amenities_attributes: %i[id amenity_id included excluded _destroy],
      program_map_attributes: %i[id included address _destroy],
      program_contact_attributes: %i[id user_id _destroy],
      program_highlight_attributes: %i[id text _destroy],
      program_review_attributes: %i[id review_text reviewer_name reviewer_details _destroy],
      program_location_highlight_attributes: %i[id text _destroy],
      program_courses_attributes: %i[id name _destroy],
      program_activities_attributes: %i[id info _destroy],
      program_excursions_attributes: %i[id info _destroy],
      program_opportunities_attributes: %i[id info _destroy],
      program_eligibility_attributes: %i[id eligibility_info _destroy],
      program_ranges_attributes: [
        :id,
        :cost_notes,
        :currency_code,
        :_destroy,
        :end_date,
        :high_cost,
        :low_cost,
        :max_course_credits,
        :min_course_credits,
        :name,
        :start_date,
        :term_name_id,
        :use_exact_dates,
        :weeks,
        "deadline(1i)",
        "deadline(2i)",
        "deadline(3i)",
        {
          caa_program_range_attributes: [:client_account_application_id]
        },
        {
          form_groupings_attributes: [
            {
              form_ids: []
            },
            :deadline,
            :_destroy,
            :id
          ]
        }
      ],
      program_languages_attributes: %i[id iso_639_3 _destroy],
      program_scholarship_info_attributes: %i[id scholarship_info _destroy],
      program_managers_attributes: %i[id user_id _destroy]
    )
  end

  def program_range_params
    params.require(:program_range).permit(:id)
  end

  def toggle_program_publish
    program.status = program.status == "published" ? 3 : 1

    if (program.published? && program.save) ||
       (program.unpublished? && program.save(validate: false))
      update_all_report_program_associations(program)

      render json: { status: program.status }, status: 201
    else
      render json: { errors: program.errors, status: 400 }
    end
  end

  def publish_program
    program.update_attributes(status: 1)

    update_all_report_program_associations(program)

    render json: {
      program: program,
      errors: program.errors,
      status: program.errors.blank? ? 201 : 400
    }
  end

  def add_program_admins
    program_ids = params[:programs]
    programs = client.programs.where(id: program_ids)
    user_id = params[:user_id]

    if params[:type] == "contact"
      programs.each { |program| program.program_contact.update(user_id: user_id) }
    else
      programs.each { |program| program.program_managers.find_or_create_by(user_id: user_id) }
    end

    programs.each do |program|
      update_all_report_program_associations(program)
    end

    respond_with(programs) do |format|
      format.json { render json: { programs: programs, status: 200 } }
    end
  end

  def add_program_ranges
    program_ids = params[:programs]
    programs = client.programs.where(id: program_ids)

    programs.each do |program|
      program.program_ranges.create(
        start_date: params[:start_date],
        end_date: params[:end_date],
        weeks: params[:weeks],
        use_exact_dates: params[:use_exact_dates]
      )

      update_all_report_program_associations(program)
    end

    respond_with(programs) do |format|
      format.json { render json: { programs: programs, status: 200 } }
    end
  end

  def publish_programs
    authorize(:program, :publish?)

    program_ids = params[:programs]
    programs = client.programs.where(id: program_ids)

    respond_with(programs) do |format|
      if programs.update_all(status: 1)
        programs.each do |program|
          update_all_report_program_associations(program)
        end

        format.json { render json: { programs: programs, status: 200 } }
      else
        format.json { render json: { errors: programs.errors, status: 400 } }
      end
    end
  end

  def publish_programs_loudly
    authorize(:program, :publish?)

    errors = {}
    published = []
    programs = client.programs.where(id: params[:programs])

    programs.each do |p|
      errors[p.id.to_s] = p.title unless p.update(status: 1)

      update_all_report_program_associations(p)

      published.push(p.id) if client.programs.find(p.id).published?
    end

    if errors.blank?
      message = "Success! Your Programs were published."
      code = 200
    else
      code = 400
      message = "There was an error publishing your programs"
    end

    render json: { errors: errors, code: code, published_id: published, message: message }
  end

  def archive_programs_loudly
    authorize(:program, :archive?)

    errors = {}
    code = 400
    programs = client.programs.where(id: params[:programs])

    programs.each do |p|
      errors[p.id.to_s] = p.title unless p.update(status: 4)

      update_all_report_program_associations(p)
    end

    code = 200 if errors.blank?

    render json: { errors: errors, code: code }
  end

  def archive_programs
    authorize(:program, :archive?)

    programs = client.programs.where(id: params[:programs])

    programs.each do |p|
      p.update_column(:status, 2)

      update_all_report_program_associations(p)
    end

    render json: :ok
  end

  def destroy_programs
    program_ids = params[:programs]
    draft_count = program_ids.size
    draft_wording = program_ids.size > 1 ? "Drafts were" : "Draft was"

    client.programs.where(id: program_ids).destroy_all

    render json: {
      code: 200,
      message: "#{draft_count} #{draft_wording} successfully deleted."
    }
  end

  def unpublish_programs
    authorize(:program, :unpublish?)

    program_ids = params[:programs]
    programs = client.programs.where(id: program_ids)

    respond_with(programs) do |format|
      if programs.update_all(status: 3)
        programs.each do |program|
          update_all_report_program_associations(program)
        end

        format.json { render json: { programs: programs, status: 200 } }
      else
        format.json { render json: { errors: programs.errors, status: 400 } }
      end
    end
  end

  def get_program_map
    program_map = program.program_map

    render json: [
      ProgramMapIncluded: program_map.included,
      ProgramMapAddress: program_map.address
    ], status: 201
  end

  def get_program_organizations
    programs = Program.all_for(client).includes(:primary_client_account)

    render json: programs.pluck(:org_name).uniq, status: 201
  end

  def get_program_locations
    programs = Program.all_for(client)

    locations = programs.map do |program|
      program.program_locations.in_order.pluck(:city, :alpha2)
    end

    render json: locations.uniq, status: 201
  end

  def duplicate
    authorize(:program, :duplicate?)

    duplicate_program = program.amoeba_dup
    duplicate_program.status = "draft"
    duplicate_program.title = "Copy of #{program.title}"

    duplicate_program.remove_background_photo!

    duplicate_program.build_program_contact(user: current_user)
    duplicate_program.program_images.build(client_account_id: client_id, primary: true)
    duplicate_program.program_managers.build(user: current_user)

    if duplicate_program.save(validate: false)
      ClientAccountProgram.where(program_id: duplicate_program.id)
                          .where.not(client_account_id: client_id).destroy_all

      duplicate_attachments(duplicate_program, program)

      update_client_specific_report_program_associations(
        [duplicate_program.id],
        duplicate_program.program_range_ids
      )

      render json: duplicate_program, status: :created
    else
      render json: {
        program: duplicate_program,
        errors: duplicate_program.errors
      }, status: :bad_request
    end
  end

  def inactive
    authorize(:program, :unpublish?)

    program_id = params[:id]
    program = client.programs.find(program_id)

    program.inactive_at = Time.current
    program.inactive_by = current_user.name
    program.status = "inactive"

    program.save(validate: false)

    update_all_report_program_associations(program)

    render json: { msg: "#{(t :program).capitalize} was changed to inactive." }, status: :ok
  end

  def alternate_programs_count(program_range_id = nil, term_tag_ids = [])
    program_count = params[:program_count]

    if program_count
      parsed = JSON.parse(program_count)
      program_range_id = parsed["program"]["program_range_id"]
      term_tag_ids = parsed["program"]["term_ids"]
    end

    matching_program_range_ids = []
    term_tag_ids = term_tag_ids.sort

    unless term_tag_ids.empty?
      ProgramRange.internal_alternates(client, program_range_id).each do |pr|
        next unless pr.tags.not_archived.ids.sort == term_tag_ids

        matching_program_range_ids << pr.id
      end
    end

    matching_program_range_count = matching_program_range_ids.length

    if program_count
      render json: {
        alternateProgramsCount: matching_program_range_count,
        programRangeId: program_range_id
      }, status: 200
    else
      matching_program_range_count
    end
  end

  private

  def program
    @program ||= Program.includes(program_amenities: :amenity)
                        .includes(program_housings: :housing_type)
                        .includes(program_subjects: :subject_area)
                        .includes(
                          :program_ranges,
                          :program_activities,
                          :program_courses,
                          :program_excursions,
                          :program_languages,
                          :program_opportunities,
                          program_contact: :user
                        ).find_by_id(params[:id])
  end

  def duplicate_attachments(dup_program, base_program)
    base_program.program_attachments.each do |base_file|
      dup_file = dup_program.program_attachments.find_by_title(base_file.title)

      begin
        CopyCarrierwaveFile::CopyFileService.new(base_file, dup_file, :file).set_file
      rescue CopyCarrierwaveFile::CopyFileService::NoFileForOriginalResource
        dup_file.destroy

        next
      end

      dup_file.save
    end
  end

  def add_authorized_program_range_ids_to_info(program)
    client_account_info = client.client_account_info

    program.program_ranges.each do |program_range|
      client_account_info.add_authorized_program_range(program_range.id)
    end

    client_account_info.save
  end

  def remove_authorized_program_ranges_from_info(program_range_ids)
    client_account_info = client.client_account_info
    current_ids = client_account_info.authorized_programs_ranges_ids
    client_account_info.authorized_programs_ranges_ids = (current_ids - program_range_ids)

    client_account_info.save
  end

  def admin_query
    @admin_query ||= client.users.where(archived: false).joins(:users_roles)
                           .where.not("users_roles.role_id = 3").includes(:profile)
                           .includes(:client_user_info)
  end

  def program_amenity_json(program_amenity)
    amenity = program_amenity.amenity

    {
      id: program_amenity.id,
      category: amenity.amenity_category_display_name,
      name: amenity.name,
      amenity_id: program_amenity.amenity_id
    }
  end

  def update_program_settings_params
    params.require(:program).permit(
      :external_application_url,
      :notes,
      :status,
      program_contact_attributes: %i[id user_id _destroy],
      program_managers_attributes: %i[id user_id _destroy],
      program_ranges_attributes: [
        :id,
        :alternate,
        :alternate_all_programs,
        :application_template_id,
        :cost_embedded_url,
        :cost_notes,
        :currency_code,
        :deadline,
        :decision_release_date,
        :decision_release_timezone,
        :end_date,
        :high_cost_cents,
        :low_cost_cents,
        :max_course_credits,
        :min_course_credits,
        :name,
        :start_date,
        :term_name_id,
        :use_exact_dates,
        :weeks,
        { caa_program_range_attributes: [:client_account_application_id] },
        {
          form_groupings_attributes: [
            :_destroy,
            :id,
            :deadline,
            { form_ids: [] }
          ]
        },
        { other_tags_attributes: %i[id tag_id _destroy] },
        { program_range_form_groupings_attributes: [
          :id,
          :deadline,
          :_destroy,
          { program_range_form_grouping_templates_attributes: %i[id form_template_id _destroy] }
        ] },
        { taggables_attributes: %i[id tag_id _destroy] }
      ]
    )
  end

  def update_all_report_program_associations(program)
    program_id = program.id

    ReportProgram.where(program_id: program_id).update_all(sync_required: true)
    ReportProgramRange.where(program_range_id: program.program_range_ids)
                      .update_all(sync_required: true)

    UpdateAllReportProgramAssociations.perform_async(program_id)
  end

  def update_client_specific_report_program_associations(program_ids, program_range_ids)
    client_account_id = client.id

    ReportProgram.where(client_account_id: client_account_id, program_id: program_ids)
                 .update_all(sync_required: true)
    ReportProgramRange.where(
      client_account_id: client_account_id,
      program_range_id: program_range_ids
    ).update_all(sync_required: true)

    UpdateClientSpecificReportProgramAssociations.perform_async(
      client_account_id,
      program_ids,
      program_range_ids
    )
  end
end
