# frozen_string_literal: true

class Api::Client::ClientAccountController < Api::Client::BaseController
  def show
    admins = client.users.includes(:profile, :roles).active.where.not(roles: { name: "traveler" })
    client_account_info = client.client_account_info
    address = client_account_info.address
    org_name = client.org_name
    travelers = TravelerInvitation.pending_invitations_for(client)
    request_to_withdraw_setting = client.request_to_withdraw_setting

    admins_with_associations =
      admins.map do |admin|
        profile = admin.profile
        roles = admin.roles

        {
          id: admin.id,
          avatar: profile.avatar.url,
          created_at: admin.created_at,
          email: admin.email,
          first_name: profile.first_name,
          invited: admin.invited?,
          last_name: profile.last_name,
          recipient: admin.default_message_recipient?,
          role: !roles.where_not_traveler.empty? ? roles.where_not_traveler&.first&.name : "",
          via_international: admin.via_international,
          via_contracts: admin.via_contracts,
          via_global: admin.via_abroad,
          via_travel: admin.client_account.client_feature_list.travel_plans && admin.client_account.client_account_info.role_settings[:travel_plans_settings][:access_travel_plans][:support_user]
        }
      rescue StandardError
        # If there is something goofy, just move on with life.
      end.reject(&:nil?)

    render(
      json: { org_name: org_name,
              client_account: client_account_info,
              address: address,
              available_forms: published_form_templates,
              admins: admins_with_associations,
              travelers: travelers,
              request_to_withdraw_setting: request_to_withdraw_setting },
      status: :ok
    )
  end

  def update
    authorize(:client_account, :update?)

    address = client_account_info.address

    client_account_info.assign_attributes(client_account_info_params)
    address.assign_attributes(address_params)

    settings = client.request_to_withdraw_setting

    if params[:request_to_withdraw_setting]
      settings.assign_attributes(request_to_withdraw_setting_params)
    end

    if client_account_info.save && address.save && settings.save
      render json: {
        success: "Your account information has been updated.",
        status: 200
      }, status: :ok
    else
      render json: {
        error: "Unable to update account information",
        status: 400
      }, status: :bad_request
    end
  end

  def update_safe_check_custom_text
    authorize(:client_account, :update?)

    client_account_info.safe_check_custom_text = client_account_info_params[:safe_check_custom_text]

    if client_account_info.save
      render json: { success: "SafeCheck custom text updated" }
    else
      render json: { error: "Unable to update SafeCheck custom text" }
    end
  end

  def update_notifications
    return unless @user.update(inactive: params[:inactive])

    render json: { error: "Unable to update account information", status: 400 }
  end

  def get_custom_fields
    custom_fields = client.custom_fields

    if custom_fields
      render json: custom_fields, status: :created
    else
      render json: custom_fields.errors, status: :unauthorized
    end
  end

  def update_custom_fields
    authorize(:client_account, :update_custom_fields?)

    create_or_update_custom_fields
    get_custom_fields
  end

  def show_role_settings
    render json: {
      current_settings: ClientAccountRoleSettings.settings(client),
      editable_settings: ClientAccountRoleSettings::EDITABLE_SETTINGS
    }
  end

  def update_role_settings
    authorize(:client_account, :update_role_settings?)

    success = params[:client_account_info] ?
      "Permissions Updated" :
      "Permissions reset to default successfully"

    return unless ClientAccountRoleSettings.save_settings(client, params[:client_account_info])

    render json: {
      current_settings: ClientAccountRoleSettings.settings(client),
      editable_settings: ClientAccountRoleSettings::EDITABLE_SETTINGS,
      success: success
    }
  end

  def default_role_settings
    authorize(:client_account, :default_role_settings?)

    ClientAccountRoleSettings.default_client_settings(client)

    render json: { success: "Permissions set to default values" }
  end

  def get_authorized_program_settings
    applications = client.application_templates.published
    available_forms = client.form_templates.published

    render json: {
      account: client.client_account_info,
      forms: available_forms,
      applications: applications,
      authorized_program_ranges: SuitcaseSerializer.new(client.suitcases)
    }, status: :created
  end

  def update_user_account_info
    profile = @user.profile
    profile.override_readonly_fields = true
    client_user_info = @user.client_user_info

    profile_params.each do |key, value|
      next if key =~ /avatar/

      profile.__send__("#{key.intern}=", value&.strip || "")
    end

    profile.avatar = profile_params["avatar"] if profile_params["avatar"] != ""

    if profile.save && client_user_info.update(client_user_info_params)
      @user.assigned_programs.pluck(:id).each do |program_id|
        UpdateAllReportProgramAssociations.perform_async(program_id)
      end

      update_report_plan_user(@user.id)

      render json: @user.as_json.merge(
        title: client_user_info.title,
        job_title: client_user_info.job_title,
        suffix: client_user_info.suffix,
        department: client_user_info.department,
        first_name: profile.first_name,
        last_name: profile.last_name,
        status: 200
      ), status: 200
    else
      render json: @user.errors, status: :unprocessable_entity
    end
  end

  def update_authorized_program_settings
    authorize(:program, :authorize?)

    applications = client.application_templates.published
    available_forms = client.form_templates.published
    client_account_info = client.client_account_info
    current_form_ids = if client_account_info.authorized_programs_allow
                         client_account_info.authorized_programs_form_ids || []
                       else
                         []
                       end

    requested_form_ids = authorized_program_params["client_account_info_attributes"]["authorized_programs_form_ids"] || []
    added_form_ids = requested_form_ids - current_form_ids
    deleted_form_ids = current_form_ids - requested_form_ids

    client.assign_attributes(authorized_program_params)

    if client_account_info.authorized_programs_allow
      form_deadline = client_account_info.authorized_programs_form_deadline

      if added_form_ids.present?
        program_range_ids = FormGrouping.where(
          program_range_id: client_account_info.authorized_programs_ranges_ids,
          grouping_type: FormGrouping::AUTHORIZED_PROGRAM,
          client_account_id: client.id
        ).pluck(:program_range_id)
        program_ranges = ProgramRange.where(id: program_range_ids)

        program_ranges.each do |program_range|
          Traveler::Applications::UpdateFormGrouping.update_form_grouping(
            client,
            program_range,
            form_deadline,
            added_form_ids
          )
        end

        AttachFormsForAuthorizedPrograms.perform_async(client.id)
      elsif deleted_form_ids.present?
        DetachFormsForAuthorizedPrograms.perform_async(client.id, deleted_form_ids)
      end
    end

    if client.save
      render json: {
        account: client_account_info,
        forms: published_form_templates,
        applications: published_application_templates,
        status: 201
      }
    else
      render json: { error: "Unable to update program settings", status: 400 }
    end
  end

  def get_admins
    admins = client.users.without_role(:traveler).where(archived: false).includes(:profile)
                   .map { |admin| { name: admin.name, admin_id: admin.id } }

    render json: admins, status: :ok
  end

  def get_archived_admins
    archived_admins = client.users.where(archived: true).joins(:users_roles)
                            .where.not("users_roles.role_id = 3").includes(:profile)
                            .map { |admin| { name: admin.name, admin_id: admin.id } }

    render json: { admins: archived_admins }, status: :ok
  end

  def get_college_or_faculty_options
    options = client.travelers.joins(:traveler_info).where
                    .not(traveler_infos: { places_of_study: nil }).pluck("DISTINCT places_of_study")
                    .sort.flatten.uniq

    render json: options, status: :created
  end

  def users
    admins = client.users.includes(:profile, :roles).where(via_international: true).active.where.not(roles: { name: "traveler" })
    caf = client.client_account_info
    client_info = {
      client_account_id: caf.client_account_id,
      subdomain: caf.subdomain
    }

    travelers =
      client.travelers.with_role(:traveler).includes(:profile, :roles).where(via_international: true).map do |traveler|
        profile = traveler.profile

        {
          id: traveler.id,
          avatar: profile.avatar.url,
          created_at: traveler.created_at,
          email: traveler.email,
          first_name: profile.first_name,
          inbound_permission: traveler.inbound_permission,
          invited: false,
          last_name: profile.last_name,
          role: 'traveler',
          recipient: '',
          via_international: traveler.via_international,
          via_contracts: traveler.via_contracts
        }
      end

    admins_with_associations =
      admins.map do |admin|
        profile = admin.profile
        roles = admin.roles

        {
          id: admin.id,
          avatar: profile.avatar.url,
          created_at: admin.created_at,
          email: admin.email,
          first_name: profile.first_name,
          inbound_permission: admin.inbound_permission,
          invited: admin.invited?,
          last_name: profile.last_name,
          recipient: admin.default_message_recipient?,
          role: !roles.where_not_traveler.empty? ? roles.where_not_traveler&.first&.name : "",
          via_international: admin.via_international,
          via_contracts: admin.via_contracts,
          via_global: admin.via_abroad,
          via_travel: admin.client_account.client_feature_list.travel_plans && admin.client_account.client_account_info.role_settings[:travel_plans_settings][:access_travel_plans][:support_user]
        }
      end

    render(
      json: { org_name: client.org_name,
              client_account: client_info,
              admins: admins_with_associations,
              travelers: travelers },
      status: :ok
    )
  end

  private

  def client_account_info
    @client_account_info ||= client.client_account_info
  end

  def create_or_update_custom_fields
    if params["custom_fields"]
      CustomFields::Updater.create_custom_fields(params["custom_fields"], client.id)
    end

    if params["saved_custom_fields"]
      CustomFields::Updater.update_custom_fields(params["saved_custom_fields"])
    end

    if params["deleted_custom_fields"]
      CustomFields::Updater.delete_custom_fields(params["deleted_custom_fields"])
    end
  end

  def profile_params
    params.require(:profile).permit(:avatar, :first_name, :last_name)
  end

  def client_user_info_params
    @client_user_info_params ||= params.require(:client_user_info).permit(:job_title, :title, :suffix, :department)
  end

  def published_application_templates
    @published_application_templates ||= client.application_templates.published
  end

  def published_form_templates
    @published_form_templates ||= client.form_templates.published
  end

  def update_params_modifications
    subdomain = client_account_info.subdomain

    if subdomain.blank?
      params[:client_account][:client_account_info_attributes][:subdomain].downcase
    else
      params[:client_account][:client_account_info_attributes][:subdomain] = subdomain
    end

    params[:client_account][:org_name] = client.org_name if client.org_name.present?
  end

  def authorized_program_params
    params.require(:client_account).permit(
      :org_name,
      client_account_info_attributes: [
        :id,
        :authorized_programs_allow,
        :authorized_programs_application_deadline,
        :authorized_programs_form_deadline,
        :authorized_programs_intro_text,
        :authorized_programs_mailer_text,
        :client_account_id,
        :department,
        :description,
        :logo,
        :phone_country_code,
        :phone_number,
        :subdomain,
        { authorized_programs_form_ids: [] },
        { address_attributes: %i[id street secondary_street city state zip country] }
      ]
    )
  end

  def client_account_info_params
    params.require(:client_account_info).permit(
      :alias_enrollment,
      :alias_favorite,
      :alias_favorites,
      :alias_program,
      :alias_programs,
      :alias_traveler,
      :alias_travelers,
      :alias_traveling,
      :alias_unfavorite,
      :allow_traveler_deferral,
      :allow_traveler_sign_up,
      :department,
      :description,
      :limit_applications_by_timeframe,
      :logo,
      :org_timezone,
      :phone_country_code,
      :phone_number,
      :safe_check_custom_text,
      :show_intake,
      :show_program_match,
      :theme_code,
      :theme_color_accent,
      :theme_color_dark,
      :theme_color_light,
      :use_custom_aliases,
      :enable_active_term_name_filtering,
      :show_sign_in_instruction,
      :sign_in_instruction
    )
  end

  def address_params
    params.require(:address).permit(:city, :country, :secondary_street, :state, :street, :zip)
  end

  def request_to_withdraw_setting_params
    params[:request_to_withdraw_setting][:active] = params[:request_to_withdraw_setting][:active] == "true"
    setting_params = params.require(:request_to_withdraw_setting).permit(:active, :instruction, :application_statuses)
    setting_params[:application_statuses] = JSON.parse(setting_params[:application_statuses])
    setting_params
  end

  def update_report_plan_user(user_id)
    plans_users = PlansUser.where(user_id: user_id)

    plans_users.each do |plan_user|
      ReportPlanUser.find_by_plans_users_id(plan_user.id)&.update(sync_required: true)
      UpdateReportPlanUser.perform_in(10.seconds, plan_user.id)
    end
  end
end
