# frozen_string_literal: true

class Api::Client::TravelerInvitationsController < Api::Client::BaseController
  respond_to :json

  def pending_invitations
    render json: TravelerInvitation.pending_invitations_for(client)
                                   .as_json(only: %i[email first_name last_name]), status: :ok
  end

  def invite_single
    authorize(:traveler_information, :invite_traveler?)

    if traveler_invite.valid?
      Client::TravelerInviter.new(traveler_invitation_params, @user, client).invite

      render json: {
        message: "New #{alias_traveler.downcase} #{traveler_email} has been invited",
        status: 200
      }, status: :ok
    else
      render json: {
        message: "An account already exists for #{traveler_email}",
        status: 400
      }, status: :bad_request
    end
  end

  def batch_invite
    rows = params[:file].split("\n").drop(1).map do |row|
      row = row.split(",")

      { email: row[0].strip, first_name: row[1].strip, last_name: row[2].strip }
    end

    if rows.empty?
      render json: {
        alert: "Please upload one or more #{alias_traveler.downcase} invitation CSV files",
        status: 400
      }, status: :bad_request
    else
      success_count = 0

      rows.each do |row|
        next unless batch_traveler_invite(row).valid?

        Client::TravelerInviter.new(row, current_user, client).invite

        success_count += 1
      end

      render json: {
        message: "#{success_count} of #{rows.count} #{alias_traveler} invitation(s) sent (invitations were not sent to #{alias_travelers} with existing invitations)",
        status: 200
      }, status: :ok
    end
  end

  def resend_invitation
    authorize(:traveler_information, :invite_traveler?)

    if existing_invite
      Client::TravelerInviter.new(traveler_invitation_params, @user, client).reinvite

      render json: { status: 200 }
    else
      render json: { error: "Unable to find existing invite" }
    end
  end

  def cancel_invitation
    authorize(:traveler_information, :invite_traveler?)

    if existing_invite&.destroy
      render json: {
        success: "Invite to #{alias_traveler.downcase} has been cancelled.",
        code: 200,
        user_email: existing_invite.email
      }
    else
      render json: { error: "Unable to find existing invite" }
    end
  end

  private

  def alias_traveler
    client.client_account_info.alias_traveler
  end

  def alias_travelers
    client.client_account_info.alias_travelers
  end

  def traveler_invitation_params
    params.require(:traveler_invitation).permit(:email, :first_name, :last_name)
  end

  def batch_traveler_invite(row)
    Validators::Client::TravelerInvitations::Invite.new(row)
  end

  def traveler_invite
    @traveler_invite ||=
      Validators::Client::TravelerInvitations::Invite.new(traveler_invitation_params)
  end

  def existing_invite
    @existing_invite ||= TravelerInvitation.find_by("LOWER(email) = ? ", traveler_email)
  end

  def traveler_email
    traveler_invitation_params[:email].downcase
  end

  def upload_invite_params
    params.require(:user).permit(uploads_attributes: %i[file id _destroy])
          .deep_merge(uploads_attributes: { "0" => { upload_type: :invite } })
  end
end
