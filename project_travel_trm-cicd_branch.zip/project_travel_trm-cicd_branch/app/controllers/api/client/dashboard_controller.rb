# frozen_string_literal: true

class Api::Client::DashboardController < Api::Client::BaseController
  include QueryHandler

  def traveler_tracker
    data = {
      traveler_counts: traveler_counts,
      geo_data: geo_location_data
    }

    render json: { data: data }, status: :ok
  end

  def program_distribution_data
    data = {
      internal_programs: internal_programs_count,
      authorized_programs: authorized_programs_count
    }

    render json: { data: data }, status: :ok
  end

  def terms_deporting_data
    date = Date.current
    upcoming_terms = program_ranges
                     .joins(:program)
                     .where("program_ranges.start_date::DATE BETWEEN ? AND ?", date, date.advance(days: 90))
                     .order("program_ranges.start_date")
                     .select("programs.id as program_id, programs.title as program_title,
                      program_ranges.id as term_id, program_ranges.start_date")

    program_range_ids = upcoming_terms.map(&:term_id)
    started_id = SubmissionStatus.find_by_identifier("started").id
    not_started_id = SubmissionStatus.find_by_identifier("not_started").id

    form_submissions = client.form_submissions.where(program_range_id: program_range_ids)
    program_terms = []
    upcoming_terms.each do |term|
      program_terms << {
        program_id: term.program_id,
        term_id: term.term_id,
        name: term.program.title,
        background_image: term.program.primary_program_image&.small,
        start_date: term.start_date,
        incomplete_forms: form_submissions.where(program_range_id: term.term_id)
                                          .where(
                                            submission_status_id: [started_id,
                                                                   not_started_id]
                                          ).count
       }
    end

    data = {
      forms_started: form_submissions.where(submission_status_id: started_id).count,
      forms_not_started: form_submissions.where(submission_status_id: not_started_id).count,
      program_terms: program_terms
    }

    render json: { data: data }, status: :ok
  end

  def upcoming_application_deadlines_data
    date = Date.current
    upcoming_terms = program_ranges
                     .joins(:program)
                     .where("program_ranges.deadline::DATE BETWEEN ? AND ?", date, date.advance(days: 90))
                     .order('program_ranges.deadline')
                     .select("programs.id as program_id, programs.title as program_title,
                      program_ranges.deadline, program_ranges.id,
                      program_ranges.name as title, program_ranges.start_date")

    incomplete_status_id = SubmissionStatus.find_by_identifier('incomplete').id

    data = []
    upcoming_terms.each do |term|
      data << {
        program_id: term.program_id,
        term_id: term.id,
        program_name: term.program_title,
        term_name: term.title,
        background_image: term.program.primary_program_image&.small,
        start_date: term.start_date,
        deadline: term.deadline,
        incomplete_app: client.application_submissions.where(submission_status_id: incomplete_status_id, program_range_id: term.id).count
      }
    end

    render json: { data: data }, status: :ok
  end

  def application_started_data
    start_date = params[:start_date] || Date.current.advance(days: -30)
    end_date = params[:end_date] || Date.current

    data = ViaConnectAction.where(home_campus: client.org_name, action: 3)
                           .where("CAST(via_connect_actions.created_at AT TIME ZONE 'UTC' AT TIME ZONE ? AS TEXT)::DATE BETWEEN ? AND ?", client.org_timezone, start_date, end_date)

    if current_user.is_occasional_user?
      user_email = current_user.assigned_travelers.pluck(:email)
      data = data.where(user_email: user_email).group("via_connect_actions.created_at::DATE").count
    else
      data = data.group("via_connect_actions.created_at::DATE").count
    end

    render json: { data: data }, status: :ok
  end

  def most_favorite_programs
    start_date = params[:start_date] || Date.current.advance(days: -30)
    end_date = params[:end_date] || Date.current

    data = ViaConnectAction
           .where("program_provider = ?  AND action = 0 AND
                  CAST(created_at AT TIME ZONE 'UTC' AT TIME ZONE ? AS TEXT)::DATE BETWEEN ? AND ?",
                  client.org_name,
                  client.org_timezone,
                  start_date,
                  end_date)

    data =
      if current_user.is_occasional_user?
        emails = current_user.assigned_travelers.pluck(:email)
        data.where(user_email: emails)
      else
        data
      end.select("program_id, program_name, count('program_name') as favorite_count")
         .group('program_id, program_name')
         .order("favorite_count DESC")
         .limit(10)

    render json: { data: data }, status: :ok
  end

  def top_participation_barriers
    start_date = params[:start_date] || Date.current.advance(days: -30)
    end_date = params[:end_date] || Date.current

    advisings = if current_user.is_occasional_user?
                  client.report_travelers.where(user_id: current_user.assigned_travelers.pluck(:id))
                else
                  client.report_travelers
                end.where("CAST(sign_up_date_raw AT TIME ZONE 'UTC' AT TIME ZONE ? AS TEXT)::DATE BETWEEN ? AND ?", client.org_timezone, start_date, end_date)
                .pluck(:participation_barriers)

    data = {}
    advisings.each do |advising|
      keys = advising.split('; ')
      keys.each do |key|
        data[key] ||= 0
        data[key] += 1
      end
    end

    data = data.sort_by { |_k, v| -v }

    render json: { data: data }, status: :ok
  end

  private

  def geo_location_data
    application_submissions
      .joins(:submission_tracking_step).joins(
        "left join program_ranges ON program_ranges.id = submissions.program_range_id
        left join programs ON programs.id = program_ranges.program_id
        left join program_locations ON program_locations.program_id = programs.id
        left join via_countries ON program_locations.alpha2 = via_countries.alpha2_code"
      ).where("submission_tracking_steps.identifier = 'on_site'")
      .select("submissions.user_id, programs.id, via_countries.name country_name")
      .group("submissions.user_id, programs.id, via_countries.name")
      .map(&:country_name)
      .inject(Hash.new(0)) { |total, e| total[e] += 1 ; total }
      .sort_by { |_k, v| -v }
  end

  def traveler_counts
    {
      interested_count: traveler_count('Interested', admin_ids),
      applying_count: traveler_count('Applying'),
      pre_departure_count: traveler_count('Pre-departure'),
      on_site_count: traveler_count('On-site')
    }
  end

  def traveler_count(tracking_step, skip_ids = [])
    if current_user.is_occasional_user?
      client.report_travelers.where(user_id: current_user.assigned_travelers.pluck(:id))
    else
      client.report_travelers
    end.where("tracking_steps LIKE ?", "%#{tracking_step}%")
       .where.not(user_id: skip_ids)
       .size
  end

  def internal_programs_count
    programs = ReportProgram.where(client_account_id: client.id, status: 'Published', internal_authorized: 'Internal')

    count =
      if current_user.is_occasional_user?
        programs.where(id: current_user.assigned_programs.pluck(:id)).count
      else
        programs.count
      end

    [count, calculate_percentage(count)]
  end

  def authorized_programs_count
    programs = ReportProgram.where(client_account_id: client.id, status: 'Published', currently_authorized: true)

    count =
      if current_user.is_occasional_user?
        programs.where(id: current_user.assigned_programs.pluck(:id)).count
      else
        programs.count
      end

    [count, calculate_percentage(count)]
  end

  def published_programs_count
    @published_programs_count ||=
      if current_user.is_occasional_user?
        ReportProgram.where(client_account_id: client.id, status: 'Published')
                     .where(id: current_user.assigned_programs.pluck(:id)).count
      else
        ReportProgram.where(client_account_id: client.id, status: 'Published').count
      end
  end

  def calculate_percentage(count)
    total = published_programs_count
    (count.to_f / total * 100).round(2)
  end

  def program_ranges
    @program_ranges ||=
      if current_user.is_occasional_user?
        current_user.assigned_program_ranges
      else
        client.program_ranges
      end
  end

  def application_submissions
    if current_user.is_occasional_user?
      current_user.assigned_application_submissions
    else
      client.application_submissions
    end
  end

  def admin_ids
    ActiveRecord::Base.connection.execute(
      prepared_query(ADMIN_IDS_SQL, { CLIENT_ACCOUNT_ID: client.id })
    ).values.flatten
  end

end
