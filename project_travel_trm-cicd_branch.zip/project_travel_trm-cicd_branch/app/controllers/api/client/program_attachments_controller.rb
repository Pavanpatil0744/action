class Api::Client::ProgramAttachmentsController < Api::Client::BaseController
  before_action :find_program_attachment, only: %i[update destroy]

  def create
    program_attachment = ProgramAttachment.new(program_attachment_params)

    return bad_request(program_attachment) unless program_attachment.save(program_attachment_params)

    render json: ProgramAttachmentSerializer.new(program_attachment), status: :created
  end

  def update
    unless @program_attachment.update(program_attachment_params)
      return bad_request(@program_attachment)
    end

    render json: ProgramAttachmentSerializer.new(@program_attachment), status: :ok
  end

  def destroy
    @program_attachment.destroy

    render json: {}, status: :no_content
  end

  private

  def find_program_attachment
    @program_attachment = ProgramAttachment.find_by(id: program_attachment_params[:id])

    return not_found unless @program_attachment
  end

  def program_attachment_params
    params.require(:program_attachment).permit(:id, :file, :title, :program_id)
  end
end
