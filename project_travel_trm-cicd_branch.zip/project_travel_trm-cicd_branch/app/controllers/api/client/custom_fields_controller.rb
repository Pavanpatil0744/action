# frozen_string_literal: true

require "custom_fields/updater"

class Api::Client::CustomFieldsController < Api::Client::BaseController
  def update_travelers
    traveler_ids = params[:traveler_ids] || []

    ReportTraveler.where(user_id: traveler_ids).update_all(sync_required: true)

    traveler_ids.each do |traveler_id|
      CustomFields::Updater.update_or_create_custom_field_texts_for_traveler(
        traveler_id,
        filtered_params
      )

      UpdateReportTraveler.perform_in(10.seconds, traveler_id)
    end

    render json: { success: "Successfuly Updated", status: 200 }
  end

  def filtered_params
    saved_custom_fields = params[:saved_custom_fields] || []

    saved_custom_fields.reject { |s| s["value"].blank? }
  end
end
