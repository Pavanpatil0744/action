# frozen_string_literal: true

require "sanitize"

class Api::Client::UsersController < Api::Client::BaseController
  respond_to :json

  before_action :check_new_user_role, only: :create
  before_action :check_user_limits, only: :create

  def create
    authorize(:user, :invite_admin_users?)

    new_user = User.new(user_params)
    client_logo = client.logo.url
    email = new_user.email.downcase
    existing_user = User.find_by_email(email)
    existing_user_id = existing_user&.id
    role = params[:role]
    other_admin_limit = client.other_admin_limit
    super_user_limit = client.super_user_limit

    if Role.admin_value(current_user.roles.first.name) < Role.admin_value(role)
      render json: {
        message: "You are not allowed to create a user with a higher role than your role.",
        type: "error"
      }, status: :bad_request
    elsif role == "super_user" && client.super_users.count + 1 > super_user_limit
      render json: {
        message: "Your account is limited to #{super_user_limit} Super User(s).",
        type: "error"
      }, status: :bad_request
    elsif client.other_admins.count + 1 > other_admin_limit
      render json: {
        message: "Your account is limited to #{other_admin_limit} Other Admin User(s).",
        type: "error"
      }, status: :bad_request
    elsif existing_user&.admin_role? && existing_user&.archived?
      existing_user.remove_client_roles
      existing_user.add_role(role.to_sym)
      existing_user.update(archived: false)

      SendGrid::SendAdminUnarchivedMailer.perform_async(existing_user_id, client_logo)
      SyncHubspotUser.perform_in(10.seconds, existing_user_id)

      render json: { message: "User #{email} was unarchived", type: "success" }, status: :ok
    elsif existing_user&.admin_role?
      render json: {
        message: "An account already exists for this email address",
        type: "error"
      }, status: :bad_request
    elsif existing_user
      existing_user.remove_role(:traveler)
      existing_user.add_role(role.to_sym)
      existing_user.update(admin_sign_in: true, client_account_id: client.id)
      existing_user.create_client_user_info if existing_user.client_user_info.nil?

      SendGrid::SendTravelerUpgradedMailer.perform_async(existing_user_id, client_logo)
      SyncHubspotUser.perform_in(10.seconds, existing_user_id)

      render json: {
        message: "User #{email} was upgraded to #{role.titleize}",
        type: "success"
      }, status: :ok
    else
      TravelerInvitation.find_by("LOWER(email) = ?", email)&.destroy

      new_user.invite_client_user(client, role)

      new_user_id = new_user.id

      SendGrid::SendAdminInvitationMailer.perform_async(new_user_id, client_logo)
      SyncHubspotUser.perform_in(10.seconds, new_user_id)

      render json: {
        message: "New user #{email} was invited",
        type: "success",
        user: response_user(new_user)
      }, status: :created
    end
  end

  def update_roles
    authorize(:user, :adjust_role_settings?)

    return if roles_params.empty?

    errors = []
    role_updates = roles_params
    role_values = role_updates.values

    if role_updates.values.count("super_user") < 1
      errors.push("There must be at least one super user.")
    end

    if role_values.count("super_user") > client.super_user_limit
      errors.push("Your account is limited to #{client.super_user_limit} super user(s).")
    end

    if role_values.reject { |role| role == "super_user" }.count > client.other_admin_limit
      errors.push("Your account is limited to #{client.other_admin_limit} non super admin(s).")
    end

    if errors.empty?
      role_updates.each_pair do |user_id, role|
        user = User.find(user_id.to_i)

        next if current_user == user || user.roles.include?(Role.find_by(name: role))

        if Role.admin_value(current_user.roles.first.name) < Role.admin_value(role)
          errors.push("You are not allowed to change a user to a higher role than your role.")
        else
          user.remove_client_roles if user.client_user_role?
          user.add_role(role.to_sym)
        end
      end
    end

    if errors.empty?
      render json: { status: 200 }
    else
      render json: { error: errors, status: 400 }
    end
  end

  def update_recipients
    return render json: { status: 400 } if params[:recipients].blank?

    users = client.users.active

    users.map do |user|
      if params[:recipients].include?(user.id)
        user.assign_attributes(default_message_recipient: true)
      else
        user.assign_attributes(default_message_recipient: false)
      end
    end

    if users.each(&:save)
      render json: { status: 200 }
    else
      render json: { status: 400 }
    end
  end

  def cancel_invitation
    authorize(:traveler_information, :invite_traveler?)

    invitation = client.traveler_invitations.find(params[:id])
    email = invitation.email
    user = client.travelers.find_by(email: email)

    if !user.invited?
      render json: { alert: "The user has already accepted the invitation, unable to cancel." }
    elsif user.destroy
      render json: { success: "Invitation to #{email} was cancelled." }
    else
      render json: { error: "Unable to cancel invitation." }
    end
  end

  def cancel_admin_invitation
    authorize(:user, :invite_admin_users?)

    user = client.users.find_by(id: params[:id])

    if !user.invited?
      render json: { alert: "The user has already accepted the invitation, unable to cancel." }
    elsif user.destroy
      render json: { user_id: user.id }
    else
      render json: { error: "Unable to cancel invitation." }
    end
  end

  def resend_invitation
    authorize(:user, :invite_admin_users?)

    user = client.users.find_by(id: params[:id])
    new_email = params[:new_email]

    if new_email.present? && (user.email != new_email)
      existing_user = User.find_by_email(params[:new_email])

      return render(
        json: {
          message: "An account already exists for this email address",
          type: "error"
        },
        status: :bad_request
      ) if existing_user.present?

      user.skip_reconfirmation!
      user.assign_attributes(email: params[:new_email])
      user.save
      user.sso_authentications.destroy_all
    end

    unless user&.invited?
      return render json: { alert: "The user has already accepted the invitation, unable to resend." }
    end

    user.set_reset_password_token

    SendGrid::SendAdminInvitationMailer.perform_async(user.id, client.logo.url)

    render json: { status: 200 }
  end

  def user_roles
    users = client.users.where(archived: false).includes(:roles).map do |user|
      { user.email => user.roles.first.name }
    end

    render json: users
  end

  def authorized_for
    role_id = params[:role_id].to_sym

    if User.find(params[:id]).authorized_for?(params[:role_id])
      render json: { authorizations: { role_id => true } }
    else
      render json: { authorizations: { role_id => false } }
    end
  end

  def archive_user
    user_to_archive = User.find(params[:id])
    current_user = User.find_by(email: params[:user_email])

    unless authorize_user_archive?(user_to_archive, current_user)
      return render json: {
        message: "You cannot archive a user with a higher role than yourself.",
        type: "error",
        user_id: user_to_archive.id
      }
    end

    if user_to_archive.default_message_recipient?
      return render json: {
        message: "Please remove the user as a default message recipient before archiving.",
        type: "error",
        user_id: user_to_archive.id
      }
    end

    remove_user_from_conversations(user_to_archive)
    update_program_associations(user_to_archive)

    if user_to_archive && !user_to_archive.invited?
      if user_to_archive.update(archived: true)
        render json: {
          message: "User #{user_to_archive.email} has been archived.",
          type: "success",
          user_id: user_to_archive.id
        }
      else
        render json: {
          message: "User #{user_to_archive.email} can't be archived. Errors: #{user_to_archive.errors}",
          type: "error",
          user_id: user_to_archive.id
        }
      end
    elsif user_to_archive.invited?
      user_to_archive.destroy
      render json: {
        message: "The user had not accepted their invite, invite cancelled.",
        type: "success",
        user_id: user_to_archive.id
      }
    else
      render json: {
        message: "User #{user_to_archive.email} not found.",
        type: "error",
        user_id: user_to_archive.id
      }
    end
  end

  def client_user_header
    user = User.find(params[:id])

    if user
      render json: {
        avatar: user.profile.avatar,
        email: user.email,
        inactive: user.inactive,
        first_name: user.profile.first_name,
        last_name: user.profile.last_name,
        name: user.name,
        role: user.admin_role.name,
        title: user.client_user_info.title,
        job_title: user.client_user_info.job_title,
        suffix: user.client_user_info.suffix,
        department: user.client_user_info.department
      }
    else
      render json: { error: "User #{user.email} not found." }
    end
  end

  def new_client_messages
    user = client.users.find(params[:id])
    unread = user.mailbox.conversations(read: false, mailbox_type: "inbox").order(:updated_at)
                 .limit(100)
    unread_messages = []

    unread.includes(receipts: %i[message notification]).each do |c|
      receipt = c.receipts_for(user).order(created_at: :desc)
                 .select { |r| r.is_read == false && r.notification&.sender&.is_traveler? }.first

      next unless receipt

      sender = receipt.notification.sender

      next unless sender

      unread_messages << {
        attachments: receipt.message.attachments.map do |attachment|
          { url: attachment.url, name: attachment.file.filename }
        end,
        author: sender.name,
        body: Sanitize.clean(receipt.message.body),
        created_at: receipt.message.created_at,
        created_at_date: receipt.message.created_at.to_date,
        deleted: receipt.deleted,
        is_read: receipt.is_read,
        message_id: receipt.id,
        notification_id: receipt.notification_id,
        receiver_id: receipt.receiver_id,
        receiver_type: receipt.receiver_type,
        sender: sender,
        sender_avatar_url: sender.profile.avatar.url,
        sender_is_traveler: sender.is_traveler?,
        subject: receipt.message.subject,
        trashed: receipt.trashed
      }
    end

    render json: unread_messages, status: :ok
  end

  def mark_as_read
    user = client.users.find(params[:user_id])
    unread = user.mailbox.inbox.order(:updated_at).select { |c| c.is_unread?(user) }
    receipts = []

    unread.each { |c| receipts << c.receipts_for(user).order(created_at: :desc) }

    receipt = receipts.flatten.select { |r| r.id == params[:message_id] }.first

    receipt.update_attribute(:is_read, true) if receipt.is_read == false

    unread_messages = []

    unread.each do |c|
      unread_messages << c.receipts_for(user).order(created_at: :desc)
                          .select { |r| r.is_read == false && r.notification.sender.is_traveler? }
                          .map do |r|
        {
          attachments: r.message.attachments.map do |attachment|
            { url: attachment.url, name: attachment.file.filename }
          end,
          author: r.notification.sender.name,
          body: Sanitize.clean(r.message.body),
          created_at: r.message.created_at,
          created_at_date: r.message.created_at.to_date,
          deleted: r.deleted,
          is_read: r.is_read,
          message_id: r.id,
          notification_id: r.notification_id,
          receiver_id: r.receiver_id,
          receiver_type: r.receiver_type,
          sender: r.notification.sender,
          sender_is_traveler: r.notification.sender.is_traveler?,
          subject: r.message.subject,
          trashed: r.trashed
        }
      end
    end

    render json: unread_messages, status: :ok
  rescue StandardError => e
    render json: e, status: :unprocessable_entity
  end

  def destroy
    archived_user = client.users.find_by_id(params[:id])
    assumed_user = client.users.find_by_id(params[:assumed_user_id])

    if !authorize_user_archive?(archived_user, current_user)
      return render json: {
        message: "You cannot remove admin permissions from a user with a higher role than yourself.",
        type: "error"
      }
    elsif !archived_user
      return render json: {
        message: "Please choose a user.",
        type: "error"
      }
    elsif !assumed_user
      return render json: {
        message: "Please choose a user to assume the user's responsibilities.",
        type: "error"
      }
    elsif Role.admin_value(assumed_user.roles.first.name) <
          Role.admin_value(archived_user.roles.first.name)

      return render json: {
        message: "Please choose a user with a role greater than or equal to the user.",
        type: "error"
      }
    end

    archived_user.update(admin_sign_in: false)
    archived_user.remove_client_roles
    archived_user.add_role(:traveler)

    if archived_user.default_message_recipient?
      assumed_user.update(default_message_recipient: true)
      archived_user.update(default_message_recipient: false)
    end

    transfer_user_conversations(archived_user, assumed_user)
    transfer_plan_ownership(archived_user, assumed_user)
    transfer_program_associations(archived_user, assumed_user)
    archived_user.search_filters.update_all(user_id: assumed_user.id)

    archived_user_id = archived_user.id

    ReportTraveler.find_by_user_id(archived_user_id)&.update(sync_required: true)
    UpdateReportTraveler.perform_in(10.seconds, archived_user_id)

    render json: {
      message: "Admin permissions removed from user #{archived_user.email}.",
      type: "success"
    }
  end

  def update_last_visited_product
    unless %w(via_abroad via_international via_contracts).include? last_visited_product_params[:last_visited_product]
      render json: { message: "Invalid input", type: "error" } and return
    end
    if current_user.update(last_visited_product_params)
      render json: {
        message: "Last visited product updated",
        type: "success"
      }, status: :ok
    else
      render json: { message: "Last visited product not updated", type: "error" }
    end
  end

  private

  def user_params
    params.require(:user).permit(:email, :first_name, :last_name, :via_international, :inbound_permission)
  end

  def last_visited_product_params
    params.require(:user).permit(:last_visited_product)
  end

  def email
    user_params[:email]
  end

  def roles_params
    params.require(:roles).permit(client.users.where(archived: false).pluck(:id).map(&:to_s))
  end

  def set_messages
    @conversation = Conversation.conversation(@traveler, client)

    @receipts = if @conversation
                  @conversation.receipts_for(client).order(:created_at)
                else
                  []
                end
  end

  def check_user_limits
    role = params[:role]

    client.reload

    if total_non_super_admins >= client.other_admin_limit ||
       (role == "super_user" && client.users.where(archived: false).with_role(role)
                                       .size >= client.send("#{role}_limit".to_sym))
      return
    end
  end

  def check_new_user_role
    role = params[:role]

    return if Role.admin_value(current_user.roles.first.name) < Role.admin_value(role)
  end

  def total_non_super_admins
    Role.all.reject { |role| role.name == "traveler" || role.name == "super_user" }
        .sum do |admin_role|
      client.users.where(archived: false).with_role(admin_role.name).count
    end
  end

  def response_user(user)
    {
      id: user.id,
      avatar: user.avatar.url,
      email: user.email,
      first_name: user.profile.first_name,
      invited: user.invited?,
      last_name: user.profile.last_name,
      recipient: user.default_message_recipient,
      role: !user.roles.where_not_traveler.empty? ? user.roles.where_not_traveler&.first&.name : ""
    }
  end

  def authorize_user_archive?(user_to_archive, current_user)
    user_to_archive_role_value = Role.admin_value(user_to_archive.roles.first.name)
    current_user_role_value = Role.admin_value(current_user.roles.first.name)

    current_user_role_value >= user_to_archive_role_value
  end

  def transfer_user_conversations(archived_user, assumed_user)
    archived_assigned_admins = archived_user.assigned_admins
    traveler_ids = []

    archived_assigned_admins.each do |assigned_admin|
      traveler = assigned_admin.traveler

      next unless traveler

      traveler_ids |= [traveler.id]

      client.assigned_admins.find_or_create_by(client_user: assumed_user, traveler: traveler)
    end

    archived_assigned_admins.destroy_all
    archived_user.receipts.delete_all

    ReportTraveler.where(user_id: traveler_ids).each do |rt|
      UpdateReportTraveler.perform_in(10.seconds, rt.user_id)
    end
  end

  def transfer_plan_ownership(archived_user, assumed_user)
    archived_user.owned_plans.each do |plan|
      plan.update(owner_id: assumed_user.id)
      report_plan = ReportPlan.find_by_plan_id(plan.id)

      report_plan.update(sync_required: true)
      UpdateReportPlan.perform_in(10.seconds, plan.id)
    end
  end

  def transfer_program_associations(archived_user, assumed_user)
    archived_program_contacts = archived_user.program_contacts
    archived_program_managers = archived_user.program_managers
    program_ids = []
    program_range_ids = []

    archived_program_contacts.each do |program_contact|
      program = program_contact.program

      next unless program

      program_ids |= [program.id]
      program_range_ids |= [program.program_range_ids]

      ProgramContact.find_or_create_by(program: program, user: assumed_user)
      ProgramManager.find_or_create_by(program: program, user: assumed_user)
    end

    archived_program_managers.each do |program_manager|
      program = program_manager.program

      next unless program

      program_ids |= [program.id]
      program_range_ids |= [program.program_range_ids]

      ProgramManager.find_or_create_by(program: program, user: assumed_user)
    end

    archived_program_contacts.destroy_all
    archived_program_managers.destroy_all

    ReportProgram.where(program_id: program_ids).each do |rp|
      UpdateReportProgram.perform_in(10.seconds, rp.client_account_id, rp.program_id)
    end

    ReportProgramRange.where(program_range_id: program_range_ids).each do |rpr|
      UpdateReportProgramRange.perform_in(10.seconds, rpr.client_account_id, rpr.program_range_id)
    end
  end

  def remove_user_from_conversations(user)
    user.assigned_admins.destroy_all
    user.receipts.delete_all
  end

  def update_program_associations(user)
    default_message_recipient = client.default_message_recipients.first
    programs = Program.where(id: user.program_contacts.pluck(:program_id))

    programs.each do |program|
      ProgramContact.create(program: program, user: default_message_recipient)
      ProgramManager.find_or_create_by(program: program, user: default_message_recipient)
    end

    user.program_contacts.destroy_all
    user.program_managers.destroy_all
  end
end
