# frozen_string_literal: true

class Api::Client::ProgramBrochureSectionsController < Api::Client::BaseController
  before_action :find_program, only: :create

  def create
    program_brochure_section = @program.program_brochure_sections.find_or_initialize_by(client_account_id: client_id)
    program_brochure_section.assign_attributes(program_brochure_section_params)

    if program_brochure_section.save
      update_report_program(@program.id)

      render(
        json: {
          program_brochure_section: ProgramBrochureSectionSerializer.new(program_brochure_section)
        },
        status: :ok
      )
    else
      render json: { errors: program_brochure_section.errors }, status: :bad_request
    end
  end

  def destroy
    program_brochure_section = ProgramBrochureSection.find_by_id(params[:id])

    if program_brochure_section&.destroy
      program = program_brochure_section.program
      update_report_program(program.id)

      render json: { message: "Deleted brochure section" }, status: :ok
    else
      render(
        json: { errors: program_brochure_section&.errors || "Program brochure section not found" },
        status: :bad_request
      )
    end
  end

  private

  def find_program
    @program = Program.find(params[:program_id])
  end

  def program_brochure_section_params
    params.require(:program_brochure_section).permit(:title, :description)
  end

  def update_report_program(program_id)
    ReportProgram.find_by(client_account_id: client_id, program_id: program_id)
                 &.update(sync_required: true)

    UpdateReportProgram.perform_in(10.seconds, client_id, program_id)
  end
end