# frozen_string_literal: true

require "base64"
require "zip"

class Api::Client::CsvReportingController < Api::Client::BaseController
  respond_to :json

  def index
    reports_list = reports.select { |r| r.fetch(:enabled, true) }
                          .map do |r|
      label = r.fetch(:label, nil) || r[:report].titleize

      {
        value: r[:report],
        label: label,
        type: r[:type] || "csv",
        prefix: r[:prefix] || ["ViaTRM"].concat(label.split).join("_")
      }
    end

    render json: reports_list
  end

  def generate
    authorize :client_account, :download_csv?

    report = reports.select { |r| r&.fetch(:report) == params[:reportType] }.first
    report_origin = define_report_origin(params)

    if report&.fetch(:source)
      source, method = report[:source].split("#") + ["csv_report"]
      results = source.classify.constantize.public_send(
        method.to_sym, client, params, report_origin
      )
    end

    case report&.fetch(:type, "csv")
    when "csv"
      render json: { csv: results, status: :ok }
    when "zip"

      zip = Zip::OutputStream.write_buffer do |zio|
        results.each do |(filename, content)|
          zio.put_next_entry(filename)
          zio.write content
        end
      end

      render json: { zip: Base64.strict_encode64(zip.string), status: :ok }
    else
      render json: { error: "Unknown file type '#{report&.fetch(:type)}'", status: 500 }
    end
  end

  private

  def reports
    common_report = [
      {
        report: "traveler_information",
        source: "traveler_info",
        type: "csv",
        enabled: true
      }
    ]

    return common_report + application_reports + form_reports if params[:report_type].blank?

    common_report + (params[:report_type].downcase == 'application' ? application_reports : form_reports)
  end

  def application_reports
    [
      {
        report: "application_counting",
        source: "trm_submission_application#csv_report_application_counts",
        enabled: true
      },
      {
        report: "application_alternates_report",
        label: "Application Alternates Report",
        source: "application_alternates_report",
        type: "csv",
        enabled: true
      },
      {
        report: "application_content_by_application_template",
        label: "Application Content by Application Template",
        type: "zip",
        enabled: true
      },
      {
        report: "application_content_by_program_name_and_term",
        label: "Application Content by Program Name and Term",
        type: "zip",
        enabled: true
      },
      {
        report: "participation_report",
        label: "Participation Report",
        source: "trm_submission_application#participation_report_csv",
        type: "csv",
        enabled: true
      }
    ]
  end

  def form_reports
    [
      {
        report: "form_status_by_program_name_and_term",
        label: "Form Status by Program Name and Term",
        source: "trm_submission_form#csv_report_form_status",
        type: "zip",
        enabled: true
      },
      {
        report: "form_content_by_form_template",
        label: "Form Content by Form Template",
        type: "zip",
        enabled: true
      },
      {
        report: "form_content_by_program_name_and_term",
        label: "Form Content by Program Name and Term",
        type: "zip",
        enabled: true
      }
    ]
  end

  def define_report_origin(params)
    return :travelers if params[:origin] == "travelers"
    return :applications if params[:origin] == "applications"
  end
end
