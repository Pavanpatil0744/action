# frozen_string_literal: true

class Api::Client::BaseController < ApplicationController
  before_action :authenticate_user!
  before_action :check_user_auth
  before_action :authorize_client

  acts_as_token_authentication_handler_for User

  def authorize_client; end

  def custom_aliases
    ca_info = @client.client_account_info

    {
      alias_enrollment: ca_info.alias_enrollment,
      alias_favorite: ca_info.alias_favorite,
      alias_favorites: ca_info.alias_favorites,
      alias_program: ca_info.alias_program,
      alias_programs: ca_info.alias_programs,
      alias_traveler: ca_info.alias_traveler,
      alias_travelers: ca_info.alias_travelers,
      alias_traveling: ca_info.alias_traveling,
      alias_unfavorite: ca_info.alias_unfavorite
    }
  end

  def validate_subdomain
    client_subdomain = current_user&.client_account&.client_account_info&.subdomain

    return unless subdomain.present? && subdomain != client_subdomain

    sign_out(:user)

    redirect_to(root_path, alert: "You attempted to login under the wrong subdomain.") && return
  end

  def prevent_free_accounts
    return unless client.free?

    redirect_to(
      search_client_programs_path(q: { status: "draft" }),
      alert: "The requested feature is only available for paid accounts."
    ) && return
  end

  def allow_enrollment_accounts
    return if client.in_enrollment?

    redirect_to(
      search_client_programs_path(q: { status: "draft" }),
      alert: "The requested feature is only available for #{t :enrollment} accounts."
    ) && return
  end

  def available_forms
    @available_forms ||= Form.published_for(client)
  end

  def check_user_auth
    if current_user.nil?
      render json: { message: "User not signed in" }, status: :unauthorized
    elsif !admin_user?
      render json: { message: "User not authorized to access client side" }, status: :forbidden
    end
  end

  def user_not_authorized
    render json: {
      message: "You do not have permission to perform this operation."
    }, status: :unauthorized
  end

  def bad_request(model)
    render json: { errors: model.errors }, status: :bad_request
  end

  def not_found
    render json: { message: "Resource not found" }, status: :not_found
  end

  private

  def admin_user?
    @admin_user || current_user.admin_sign_in?
  end

  def client
    @client ||= current_user.client_account || current_user.client
  end

  def client_id
    @client_id ||= client.id
  end

  def derived_domain
    front_end_uri = Rails.configuration.front_end_uri
    subdomain = client.client_account_info.subdomain

    "#{subdomain}.#{front_end_uri}"
  end

  def occasional_user?
    @occasional_user ||= admin_user? && current_user.is_occasional_user?
  end
end
