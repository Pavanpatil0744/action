# frozen_string_literal: true

class Api::Client::AdminsController < Api::Client::BaseController
  def index
    render json: AdminSerializer.new(admins).serialized_json, status: :ok
  end

  private

  def admins
    client.users.includes(:roles, :profile, :traveler_info).with_any_role(
      :super_user,
      :power_user,
      :support_user,
      :occasional_user
    ).sort_by { |admin| admin.full_name_or_email.downcase }
  end
end
