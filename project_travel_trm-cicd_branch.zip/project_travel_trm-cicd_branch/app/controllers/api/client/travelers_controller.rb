# frozen_string_literal: true

require "sanitize"

class Api::Client::TravelersController < Api::Client::BaseController
  respond_to :json

  def batch_create
    travelers = []
    failures = []

    all_travelers = traveler_params['travelers']
    if all_travelers.count > 200
      return render json: { error: "Limit exceeded, Only 200 travelers can be created at a time" }, status: 404
    end

    all_travelers.first(200).each do |traveler|
      unless required_data_present?(traveler)
        failures << {
          email: traveler['email'],
          first_name: traveler['first_name'],
          last_name: traveler['last_name'],
          error: 'Required data missing'
        }
        next
      end

      existing_user = ::User.find_by("lower(email) = ?", traveler['email'].downcase)
      traveler_client = ClientAccount.find_by_id(traveler['client_id'])

      if existing_user.present? && traveler_client != existing_user.client
        failures << {
          email: existing_user.email,
          first_name: existing_user.first_name,
          last_name: existing_user.last_name,
          error: 'Email address already in use with another organization'
        }
        next
      end

      password = SecureRandom.base64(15)
      password = Devise.friendly_token until password.match?(%r{^(?=.*[A-Z])(?=.*[!"#$%&'()*+,-./:;<=>?@\[\\\]^_`{|}~]).{8,}$})

      user = existing_user || CreateTraveler.call(
          client_account: traveler_client,
          email: traveler['email'],
          first_name: traveler['first_name'],
          last_name: traveler['last_name'],
          password: password,
          sign_up_source: 'Via International Invitation',
        ).traveler

      user.via_international = true
      user.inbound_permission = traveler['inbound_permission']
      user.save

      client_account_logo = traveler_client.logo.url

      SendGrid::SendTravelerNewAccountCreationMailer.perform_async(client_account_logo, user.id)

      if existing_user.present?
        failures << {
          email: existing_user.email,
          first_name: existing_user.first_name,
          last_name: existing_user.last_name,
          error: 'User with this email address already exist'
        }
      else
        travelers << user
      end
    end

    response = { travelers: travelers.map { |t| { id: t.id, first_name: t.first_name, last_name: t.last_name, email: t.email }}}

    if failures.any?
      response[:failures] = failures
    end

    render json: response, status: :ok
  end

  def traveler_activities
    actions =
      if current_user.is_occasional_user?
        emails = current_user.assigned_travelers.pluck(:email)

        ViaConnectAction.where(home_campus: client.org_name, user_email: emails)
      else
        ViaConnectAction.where(home_campus: client.org_name)
      end

    render json: ViaConnectActionSerializer.new(actions, params: { timezone: client.org_timezone }).serialized_json, status: :ok
  end

  private

  def traveler_params
    params.require(:travelers)
    params.permit(travelers: [:first_name, :last_name, :email, :client_id, :inbound_permission])
  end

  def required_data_present?(traveler)
    traveler['first_name'].present? &&
      traveler['last_name'].present? &&
      traveler['email'].present? &&
      traveler['client_id'] &&
      traveler['inbound_permission']
  end
end