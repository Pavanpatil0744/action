# frozen_string_literal: true

class Api::Client::AlternateSettingsController < Api::Client::BaseController
  def create
    settings = client.build_alternate_setting(alternate_settings_params)

    if settings.save
      render json: {
        alternate_setting: settings,
        success_msg: "Success! Your changes to Program Alternates Settings have been saved",
        status: :OK
      }
    else
      render json: {
        errors: settings.errors.full_messages,
        error_msg: "Changes to your Program Alternates Settings have not been saved. Try again or contact support@via-trm.com",
        status: :bad_request
      }
    end
  end

  def update
    settings = client.alternate_setting

    if settings.update_attributes(alternate_settings_params)
      render json: {
        alternate_setting: settings,
        success_msg: "Success! Your changes to Program Alternates Settings have been saved",
        status: :OK
      }
    else
      render json: {
        errors: settings.errors.full_messages,
        error_msg: "Changes to your Program Alternates Settings have not been saved. Try again or contact support@via-trm.com",
        status: :bad_request
      }
    end
  end

  def show
    render json: { alternate_setting: client.alternate_setting }
  end

  private

  def alternate_settings_params
    params.require(:alternate_setting).permit(
      :accept_alternates,
      :minimum_alternates,
      :maximum_alternates,
      :ranking_instruction,
      :brochure_instruction
   )
  end
end
