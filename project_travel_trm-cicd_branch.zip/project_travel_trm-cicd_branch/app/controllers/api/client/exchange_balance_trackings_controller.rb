# frozen_string_literal: true

class Api::Client::ExchangeBalanceTrackingsController < Api::Client::BaseController
  respond_to :json

  def index
    contracts = ExchangeBalanceTracking.contracts(client_id)

    render(
      json: { contracts: contracts },
      status: :ok
    )
  rescue Inbound::Errors::ContractsError
    render json: { error: "Something went wrong" }, status: :unprocessable_entity
  end

  def update
    exchange_balance_tracking = ExchangeBalanceTracking.find_or_create_by(contract_guid: params[:id])

    if exchange_balance_tracking.update(exchange_balance_tracking_params)
      render json: ExchangeBalanceTrackingSerializer.new(exchange_balance_tracking).serialized_json, status: :ok
    else
      render json: { error: "Update Error" }, status: :unprocessable_entity
    end
  end

  def balance_values
    balance_values = Inbound::ExchangeBalance.new(client_id).balance_values(params[:id], params[:org_guid])

    render(
      json: balance_values,
      status: :ok
    )
  rescue Inbound::Errors::ContractsError
    render json: { Error: "Fail to fetch balance values" }, status: :bad_request
  end

  private

  def exchange_balance_tracking_params
    params[:exchange_balance_tracking]
      .permit(:stop_adding_removing_on_contract_expiry,
              :traveler_balance_value, :org_guid,
              { add_application_statuses: [], remove_application_statuses: [], program_ids: [] })
  end
end