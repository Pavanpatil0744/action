# frozen_string_literal: true

class Api::SafeCheckMessageReceiptsController < Api::BaseController
  skip_before_action :authenticate_user!

  before_action :find_safe_check_message_receipt_by_receipt_uuid, only: %i[show update resend]
  before_action :find_safe_check_message_receipt_by_message_sid, only: :twilio_callback

  def show
    render json: SafeCheckMessageReceiptSerializer.new(@safe_check_message_receipt)
                                                  .serialized_json, status: :ok
  end

  def update
    @safe_check_message_receipt.responded_at = DateTime.current.utc

    unless @safe_check_message_receipt.update(safe_check_message_receipt_params)
      return bad_request(@safe_check_message_receipt)
    end

    render json: SafeCheckMessageReceiptSerializer.new(@safe_check_message_receipt)
                                                  .serialized_json, status: :ok
  end

  def resend
    enrollment_status = @safe_check_message_receipt.user.safe_check_enrollment_status

    if enrollment_status == "enrolled"
      ResendSafeCheckMessage.call(safe_check_message_receipt: @safe_check_message_receipt)

      render json: SafeCheckMessageReceiptSerializer.new(@safe_check_message_receipt)
                                                    .serialized_json, status: :created
    else
      render json: { error: "Traveler is no longer enrolled in SafeCheck" }, status: :bad_request
    end
  end

  def twilio_callback
    utc_timestamp = DateTime.current.utc
    from = params[:From]
    status = params[:SmsStatus]

    @safe_check_message_receipt.sent_from = from

    if status == "sent"
      @safe_check_message_receipt.sent_at = utc_timestamp
    elsif status == "delivered"
      @safe_check_message_receipt.delivered_at = utc_timestamp
    end

    @safe_check_message_receipt.save

    render xml: {}, status: :ok
  end

  private

  def safe_check_message_receipt_params
    params.require(:safe_check_message_receipt).permit(
      :comment,
      :confirmed,
      safe_check_message_location_attributes: %i[
        country_alpha2_code
        country_common_name
        county_or_region
        formatted_address
        google_place_id
        lat
        locality
        lng
        postal_code
        postal_code_suffix
        state_or_province
        state_or_province_code
        street
        street_number
        time_zone
        time_zone_offset
      ]
    )
  end

  def find_safe_check_message_receipt_by_receipt_uuid
    @safe_check_message_receipt = SafeCheckMessageReceipt.find_by(receipt_uuid: params[:id])

    return not_found unless @safe_check_message_receipt
  end

  def find_safe_check_message_receipt_by_message_sid
    @safe_check_message_receipt = SafeCheckMessageReceipt.find_by(message_sid: params[:SmsSid])

    return not_found unless @safe_check_message_receipt
  end
end
