class Api::AnnouncementsController < ApplicationController
  respond_to :json

  GLOBAL_KEY = ["global"].freeze

  def get
    user_key = "user:#{current_user.id}"
    client_ids = []

    client_ids << current_user.client_account.id if current_user.client_account

    if current_user.client_travelers.any?
      current_user.client_travelers.each { |ct| client_ids << ct.client_account_id }
    end

    client_keys = client_ids.collect { |id| "client:#{id}" }
    aggregated_keys = GLOBAL_KEY + client_keys
    keys = [user_key] + aggregated_keys

    current_user.roles.collect(&:name).each do |role|
      aggregated_keys.each { |_| keys << "#{_}:#{role}" }
    end

    now = Time.now.utc.strftime("%Y-%m-%d %H:%M:%S")
    where = <<~ESQL
      enabled = true
      AND start_time < '#{now}'
      AND end_time > '#{now}'
      AND (
    ESQL

    where << keys.collect { |_| " parameters -> 'keys' @> '[\"#{_}\"]'\n" }.join(" OR\n")

    where << ")"

    sql = <<~ESQL
      SELECT JSON_BUILD_OBJECT('announcements', (
        SELECT JSON_AGG(announcements_values) FROM (
          SELECT body, klass, weight FROM announcements
            WHERE #{where}
        ) announcements_values
      ))
    ESQL

    formatted_json = ActiveRecord::Base.connection.execute(sql)

    render json: formatted_json[0]["json_build_object"]
  rescue
    render json: { announcements: nil }
  end
end
