# frozen_string_literal: true

class Api::ProgramPaymentOptionsController < Api::BaseController
  def index
    render json: FinancialInfo::PROGRAM_PAYMENT_OPTIONS, status: :ok
  end
end
