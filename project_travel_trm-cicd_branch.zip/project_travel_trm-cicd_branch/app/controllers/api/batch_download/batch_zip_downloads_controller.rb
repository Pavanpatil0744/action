# frozen_string_literal: true

class Api::BatchDownload::BatchZipDownloadsController < Api::BaseController
  def create
    type = batch_download_params[:type]
    files_downlodable = batch_download_params[:upload_files]

    @standard_report = StandardReport.create(
      user_id: current_user.id,
      status: 'pending',
      download_type: "#{type.capitalize} PDF by Program Name and Term",
      filename: "#{type}_PDF_Batch.zip"
    )

    job_id = BatchDownloadFiles.perform_async(
      @standard_report.id,
      batch_download_params[:submission_ids],
      files_downlodable,
      client_account_id
    )

    @standard_report.update(job_id: job_id)

    render json: ::Reports::StandardReportSerializer.new(@standard_report), status: :ok
  end

  private

  def batch_download_params
    params.require(:batch_download).permit(:response_downloadable, :upload_files, :type, submission_ids: [])
  end
end