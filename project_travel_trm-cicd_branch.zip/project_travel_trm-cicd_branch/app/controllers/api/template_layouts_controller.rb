# frozen_string_literal: true

class Api::TemplateLayoutsController < Api::BaseController
  before_action :find_template_layout, only: :update

  def update
    return bad_request(@template_layout) unless @template_layout.update(template_layout_params)

    render json: TemplateLayoutSerializer.new(@template_layout), status: :ok
  end

  private

  def template_layout_params
    params.require(:template_layout).permit(layout: [:id, { position: [] }])
  end

  def find_template_layout
    @template_layout = client_account.template_layouts.find_by(id: params[:id])

    return not_found unless @template_layout
  end
end
