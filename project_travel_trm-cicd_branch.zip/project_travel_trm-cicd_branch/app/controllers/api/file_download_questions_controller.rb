# frozen_string_literal: true

class Api::FileDownloadQuestionsController < Api::BaseController
  before_action :authorize_admin
  before_action :validate_file_presence, only: :create
  before_action :find_template, only: %i[create update destroy]
  before_action :find_question, only: %i[update destroy]
  before_action :validate_file_upload_count, only: :update
  before_action :validate_file_id, only: :update

  def create
    authorize!(:update, @template)

    fdq = @template.file_download_questions.new(fdq_params)

    return bad_request(fdq) unless fdq.save

    AddQuestionToTemplateLayout.call(question: fdq.question, template: @template)

    update_report_submission_associations(@template)

    render(
      json: FileDownloadQuestionSerializer.new(fdq, params: { action: params[:action] }),
      status: :created
    )
  end

  def update
    authorize!(:update, @template)

    return bad_request(@question) unless @question.update(fdq_params)

    update_report_submission_associations(@template)

    render json: FileDownloadQuestionSerializer.new(@question), status: :ok
  end

  def destroy
    authorize!(:update, @template)

    question_id = @question.question_id
    template_layout = @template.template_layout

    if @question.destroy
      RemoveQuestionFromTemplateLayout.call(
        question_id: question_id,
        template_layout: template_layout
      )

      update_report_submission_associations(@template)

      render json: { template_layout: template_layout }, status: :ok
    else
      render json: { errors: @question.errors }, status: :bad_request
    end
  end

  private

  def fdq_params
    params.require(:question).permit(
      :admin_only,
      :instructions,
      :label,
      uploaded_files_attributes: %i[id _destroy filename s3_store]
    )
  end

  def file_attributes
    fdq_params[:uploaded_files_attributes]
  end

  def find_template
    @template = client_account.templates.find_by_id(params[:form_template_id])

    return not_found unless @template
  end

  def find_question
    @question = @template.file_download_questions.find_by_id(params[:id])

    return not_found unless @question
  end

  def validate_file_id
    file_ids = []

    file_attributes.each do |file|
      next unless file["id"].present?

      file_ids << file["id"].to_i unless @question.uploaded_files.find_by_id(file["id"])
    end

    return unless file_ids.present?

    render json: {
      errors: ["Unable to find UploadedFile ID(s): #{file_ids.join(', ')}"]
    }, status: :not_found
  end

  def validate_file_presence
    return if file_attributes.present?

    render json: {
      errors: ["At least 1 uploaded file required"]
    }, status: :bad_request
  end

  def validate_file_upload_count
    return if file_attributes.any? { |attributes| attributes["id"].blank? }

    files = @question.uploaded_files
    file_count = files.count
    file_ids = files.pluck(:id)

    file_attributes.each do |file|
      file_count -= 1 if file_ids.include?(file[:id]&.to_i) && file[:_destroy]
    end

    return unless file_count.zero?

    render json: {
      errors: ["At least 1 uploaded file required"]
    }, status: :bad_request
  end

  def current_ability
    @current_ability ||= TemplateAbility.new(current_user, params)
  end

  def update_report_submission_associations(template)
    template.submissions&.each do |submission|
      submission_id = submission.id

      ReportSubmission.find_by_submission_id(submission_id)&.update(sync_required: true)
      UpdateReportSubmission.perform_in(10.seconds, submission_id)
    end
  end
end
