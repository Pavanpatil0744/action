# frozen_string_literal: true

class Api::SafeCheckMessageTypesController < Api::BaseController
  def index
    render json: SafeCheckMessageTypeSerializer.new(SafeCheckMessageType.in_order)
                                               .serialized_json, status: :ok
  end
end
