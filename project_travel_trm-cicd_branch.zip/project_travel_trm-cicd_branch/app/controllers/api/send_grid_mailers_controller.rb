# frozen_string_literal: true

class Api::SendGridMailersController < Api::BaseController
  include QueryHandler

  def index
    render json: SendGridMailerMajorCategorySerializer.new(
      send_grid_mailer_major_categories,
      params: { admin: admin_user?, status: client_account.status }
    ), status: :ok
  end

  def automation_mailers_history
    render json: query_to_json(history_query), status: :ok
  end

  def form_mailers_history
    render json: query_to_json(history_query), status: :ok
  end

  private

  def send_grid_mailer_major_categories
    categories = []
    categories << "Account" if admin_user?
    categories << "Via Global" if via_global?
    categories << "Via Travel" if via_travel?
    categories << "General" if traveler_user?

    SendGridMailerMajorCategory.where(display_name: categories).in_order
  end

  def sql_variables
    {
      CLIENT_ACCOUNT_ID: client_account_id,
      AUTOMATION_ID: params[:automation_id]
    }
  end

  def sql_statement
    if params[:action] == "automation_mailers_history"
      AUTOMATION_MAILER_HISTORY
    else
      FORM_MAILER_HISTORY
    end
  end

  def history_query
    prepared_query(sql_statement, sql_variables)
  end
end
