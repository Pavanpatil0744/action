# frozen_string_literal: true

class Api::PasswordsController < ApplicationController
  respond_to :json

  def forgot
    return render json: { error: "Email not present" } if params[:email].blank?

    email = params[:email]
    user = User.find_by(email: email.downcase)

    if user.present? && user.confirmed_at?
      user.set_reset_password_token

      admin_role = user.admin_role?
      client_account = admin_role ? user.client_account : user.clients.first

      SendGrid::SendPasswordResetMailer.perform_async(admin_role, client_account.logo.url, user.id)

      render json: { status: "ok" }, status: :ok
    else
      render json: {
        error: "Email address not found. Please check and try again."
      }, status: :not_found
    end
  end

  def reset
    password = params[:password]
    token = params[:token].to_s
    user = User.find_by(reset_password_token: token)

    if user.present? && user.password_token_valid?
      if user.update(password: password)
        if user.sign_in_count.zero? && user.admin_role? && (user.client.onboard_to_inbound)
          Inbound::VerifyInboundUsersWorker.new.perform(user.id, user.client.id)
        end

        render json: { status: "ok" }, status: :ok
      else
        render json: { errors: user.errors.full_messages }, status: :unprocessable_entity
      end
    else
      render json: {
        errors: ["The email link seems to be invalid. Try requesting for a new one."]
      }, status: :not_found
    end
  end

  def update
    password = params[:password]

    if password.blank?
      return render json: { error: "Password not present" }, status: :unprocessable_entity
    end

    unless current_user.valid_password?(params[:current_password])
      return render json: { error: "Please enter current password." }, status: :unprocessable_entity
    end
    @user = current_user || User.find_by_reset_password_token(params[:reset_token])

    if @user.update(password: password)
      render json: { status: "Password Updated" }, status: :ok
    else
      render json: { errors: @user.errors.full_messages }, status: :unprocessable_entity
    end
  end

  def user
    user = User.find_by(reset_password_token: params["reset_token"])

    if user
      render json: {
        user: user.as_json.merge(reset_password_token: user.reset_password_token)
      }, status: :ok
    else
      render json: { errors: "reset token expired" }, status: 400
    end
  end
end
