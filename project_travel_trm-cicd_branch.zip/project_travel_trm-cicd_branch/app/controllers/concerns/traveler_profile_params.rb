module TravelerProfileParams
  extend ActiveSupport::Concern

  def profile_params
    params.require(:profile).permit(:user_id,
                                    :first_name,
                                    :last_name,
                                    :signup_source
    )
  end

  def traveler_info_params
    params.require(:traveler_info).permit(:profile_id,
                                          :grad_year,
                                          :phone_number,
                                          :school_name,
                                          :travel_certainty,
                                          :study_interest,
                                          :status,
                                          :traveler_type,
                                          :other_traveler_type_text,
               countries_of_citizenship: [],
               user_language_attributes: [:traveler_info_id,
                                          :iso_639_3,
                                          :language_type]
                                          )
  end

  def financial_aid_params
    params.require(:financial_info).permit(:traveler_info_id,
                                           :personal_savings,
                                           :scholarship_grant,
                                           :financial_aid,
                                           :parent_donor,
                                           :job,
                                           :fundraising_crowdfunding,
                                           :not_sure,
                                           :receives_federal_financial_aid,
                                           :created_at,
                                           :updated_at,
                                           :other,
                                           :other_financial_aid_text)
  end

  def advising_params
    params.require(:advising).permit(:planning_time,
                                     :cost,
                                     :academic_credit,
                                     :people_left_behind,
                                     :missing_out_at_home,
                                     :picking_a_program,
                                     :not_knowing_anyone,
                                     :housing,
                                     :unsupportive_parent,
                                     :dietary_issues,
                                     :program_acceptance,
                                     :has_spoken_to_advisor,
                                     :traveler_info_id,
                                     :health_safety_issue,
                                     :discrimination_identity_concern,
                                     :no_questions_concerns,
                                     :not_sure,
                                     :other,
                                     :other_concern_question_text)
  end

  def travel_goals_params
    params.require(:travel_goal).permit(:new_places,
                                        :learn_language,
                                        :become_independent,
                                        :have_adventure,
                                        :improve_job_prospects,
                                        :study_or_research,
                                        :learn_new_skills,
                                        :meet_people,
                                        :leave_home,
                                        :family_heritage,
                                        :see_friends,
                                        :not_sure,
                                        :other,
                                        :traveler_info_id)
  end

  def travel_experience_params
    params.require(:travel_experience).permit(:traveler_info_id,
                                              :africa,
                                              :antarctica,
                                              :asia,
                                              :australia,
                                              :europe,
                                              :north_america,
                                              :south_america,
                                              :created_at,
                                              :updated_at,
                                              :has_left_home_country)
  end

  def passport_params
    params.require(:passport).permit(:traveler_info_id,
                                     :alpha2,
                                     :status)
  end

  def program_params
    params.require(:program_preference).permit(:traveler_info_id,
                                               :minimum_duration_weeks,
                                               :maximum_duration_weeks,
                                               :language_immersion)
  end

  def term_params
    params.require(:traveler_term).permit(:program_preference_id,
                                          :start_date,
                                          :end_date)
  end

  def support_params
    params.require(:preferred_support_level).permit(:program_preference_id,
                                                    :full_time_provider_in_city,
                                                    :full_time_provider_in_country,
                                                    :full_time_provider_host_org_in_country,
                                                    :full_time_provider_host_org_in_city,
                                                    :part_time_in_city_or_country,
                                                    :none_necessary,
                                                    :not_sure)
  end
end
