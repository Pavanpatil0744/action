# frozen_string_literal: true

module AgeCalculator
  extend ActiveSupport::Concern

  def calculate_age(dob)
    today = Date.today
    age = today.year - dob.year - ((today.month > dob.month || (today.month == dob.month && today.day >= dob.day)) ? 0 : 1)
    age
  end
end
