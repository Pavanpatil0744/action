# frozen_string_literal: true

module QueryHandler
  extend ActiveSupport::Concern

  def prepared_query(sql_statement, sql_variables)
    sql_variables.each_pair { |k, v| sql_statement = sql_statement.gsub(/#{k.upcase}/, v.to_s) }

    sql_statement
  end

  def query_to_json(query)
    return "[]" if query.empty?

    cte_query = Arel.sql(query)
    cte_table = Arel::Table.new(:orig_query)
    cte_definition = Arel::Nodes::Grouping.new(cte_query)
    cte = Arel::Nodes::As.new(cte_table, cte_definition)
    json = Arel::SelectManager.new.from(cte_table).project(
      [
        Arel::Nodes::NamedFunction.new(
          "ARRAY_TO_JSON",
          [
            Arel::Nodes::NamedFunction.new(
              "ARRAY_AGG",
              [Arel.sql("orig_query")]
            )
          ]
        )
      ]
    ).with(cte)

    ActiveRecord::Base.connection.execute(json.to_sql).values.first.first || "[]"
  end
end
