# frozen_string_literal: true

module ErrorHandler
  extend ActiveSupport::Concern

  def bad_request(model)
    render json: { errors: model.errors.full_messages }, status: :bad_request
  end

  def forbidden
    render json: { message: "Forbidden" }, status: :forbidden
  end

  def invalid_email_response
    render json: { message: "Please enter a valid email address" }, status: :bad_request
  end

  def not_found
    render json: { message: "Not found" }, status: :not_found
  end

  def unauthorized
    render json: { message: "Unauthorized" }, status: :unauthorized
  end

  def unauthorized_email_admin_response
    render json: { message: "Admin users cannot be added to Travel Plans" }, status: :unauthorized
  end

  def unauthorized_email_response
    render json: { message: "Traveler must belong to your account" }, status: :unauthorized
  end
end
