# app/controllers/concerns/custom_authentication.rb

# module CustomAuthentication
#   extend ActiveSupport::Concern

#   included do
#     def current_user
#       # Your custom logic to find the current user
#       token = request.headers["HTTP_X_USER_TOKEN"]&.split(" ")&.last || params["user_token"]
#       @current_user ||= VtAuthenticationToken.find_by(token: token)&.user || super
#     end
#   end
# end
