require 'resources/data/phone_country_codes'
require 'resources/data/relationships'
require 'resources/data/ethnicities'
require 'resources/data/races'

module Client
  class TravelerPlanLogisticsController < BaseController
    SUCCESSFUL_UPDATE_MESSAGE = 'Information was successfully updated'

    before_action :assign_view_data, only: [:edit, :update]

    def destroy
      travel_plan_id = params[:travel_plan_id]
      @traveler_plan_logistic = TravelerPlanLogistic.find(params[:id])
      @traveler_plan_logistic.destroy

      redirect_to "/client/travel_plans/#{travel_plan_id}", notice: "Traveler removed from travel plan"
    end

    def show
      @codes = PhoneCountryCodes::ALL
      @ethnicities = Ethnicities::ALL
      @races = Races::ALL
      @relationships = Relationships::ALL

      @travel_plan_id = params[:travel_plan_id]
    	@traveler_plan_logistic = TravelerPlanLogistic.find(params[:id])
    	@traveler = @traveler_plan_logistic.profile
    	@traveler_info = @traveler.traveler_info

      @presenter = ProfileDetailsPresenter.new(@traveler, client)
    end

    def edit
    end

    def update
      if @traveler_info.update(traveler_info_params)
        flash[:notice] = SUCCESSFUL_UPDATE_MESSAGE
        redirect_to client_travel_plan_traveler_plan_logistic_path(
          travel_plan_id: @travel_plan_id,
          id: @traveler_plan_logistic.id
        )
      else
        flash.now[:alert] = @traveler_info.errors.full_messages
        render :edit
      end
    end

    private

    def traveler_info_params
      params[:traveler_info].permit(Traveler::TravelerInfoParams::PERMITTED)
    end

    def assign_view_data
      @codes = PhoneCountryCodes::ALL
      @ethnicities = Ethnicities::ALL
      @races = Races::ALL
      @relationships = Relationships::ALL
      @travel_plan_id = params[:travel_plan_id]
    	@traveler_plan_logistic = TravelerPlanLogistic.find(params[:id])
    	@profile = @traveler_plan_logistic.profile
    	@traveler_info = @profile.traveler_info
      @readonly_fields = Integrations::ReadOnlyFieldFinder
        .find_read_only_fields_for(@traveler_info)
    end
  end
end
