require 'custom_fields/updater'

module Client
  class ClientAccountsController < BaseController
    after_action :verify_authorized, only: [:update, :update_role_settings, :default_role_settings]
    before_action :no_cache # Otherwise the photo upload still show the old image, which is confusing.
    before_action :create_objects, :set_objects, :set_custom_fields
    before_action :check_permissions, only: [:update_role_settings]
    layout "client/form_with_sub_nav"

    def show
      authorize :client_account, :show?
      set_client
      build_template_program
    end

    def search_custom_field_text
      render json: map_field_ids_to_field_text
    end

    def destroy
      custom_field_id = params[:custom_field_id]
      custom_field_name = params[:custom_field_name]
      CustomField.destroy(custom_field_id)

      redirect_to client_organization_path, notice: "Field \"#{custom_field_name}\" was successfully deleted"
    end

    def update
      old_form_ids = @client.client_account_info.authorized_programs_form_ids if @client.client_account_info.authorized_programs_allow
      update_params_modifications
      create_or_update_custom_fields
      authorize @account

      if @account.update(account_params)
        if @client.client_account_info.authorized_programs_allow
          form_deadline = @client.client_account_info.authorized_programs_form_deadline
          form_ids = @client.client_account_info.authorized_programs_form_ids

          unless form_ids == old_form_ids
            program_range_ids = FormGrouping.where(program_range_id: @client.client_account_info.authorized_programs_ranges_ids, grouping_type: FormGrouping::AUTHORIZED_PROGRAM, client_account_id: @client.id).map(&:program_range_id)
            program_range_ids.each do |program_range_id|
              @program_range = ProgramRange.find_by(id: program_range_id)
              Traveler::Applications::UpdateFormGrouping.update_form_grouping(@client, @program_range, form_deadline, form_ids) if @program_range
            end
          end
        end

        flash[:notice] = __("Your account information has been updated.")
        if current_user.client_user_info.blank?
          redirect_to client_account_path
        else
          redirect_to client_organization_path
        end
      else
        flash.now[:alert] = __("your account information could not be updated at this time.")
        render :show
      end
    end

    def show_role_settings
      set_client
      @client_role_settings = ClientAccountRoleSettings.settings(@client)
      @default_settings = ClientAccountRoleSettings::DEFAULT_SETTINGS
    end

    def update_role_settings
      authorize @account
      ClientAccountRoleSettings.save_settings(client, params[:client_account_info])
      redirect_to client_account_role_settings_path
    end

    def default_role_settings
      authorize @account
      ClientAccountRoleSettings.default_client_settings(client)
      redirect_to client_account_role_settings_path
    end

    private

    def set_custom_fields
      @custom_fields = CustomField.where(client_account_id: @account.id)
    end

    def map_field_ids_to_field_text
      custom_field_ids = params.fetch(:custom_field_ids, {})

      custom_field_ids.flat_map do |custom_field_id|
        CustomFieldText.where(custom_field_id: custom_field_id).map do |field_text|
          { custom_field_id => field_text.text }
        end
      end
    end

    def create_or_update_custom_fields
      if params["custom_fields"]
        CustomFields::Updater.create_custom_fields(params["custom_fields"], @account.id)
      end

      if params["saved_custom_fields"]
        CustomFields::Updater.update_custom_fields(params["saved_custom_fields"])
      end
    end

    def create_objects
      if current_user.client_account.blank?
        current_user.build_client_account.save(validate: false)
        current_user.update(client_account_id: current_user.client_account.id)
      end
    end

    def set_objects
      @account = current_user.client_account
      if @account.client_account_info.blank?
        @account_info = @account.build_client_account_info
        @address = @account_info.build_address
      else
        @account_info = @account.client_account_info
      end

      if @account_info.address.blank?
        @address = @account_info.build_address
      end
    end

    def check_permissions
      render :permissions and return unless policy(:client_account).update_role_settings?
    end

    def account_params
      params.require(:client_account).permit(:org_name,
        client_account_info_attributes: [:id, :department, :authorized_programs_allow,
        :authorized_programs_intro_text, :authorized_programs_mailer_text,
        :authorized_programs_caa_id, :authorized_programs_application_deadline,
        :authorized_programs_form_deadline, :subdomain,
        :description, :phone_country_code, :phone_number, :client_account_id, :logo,
        :authorized_programs_form_ids => [],
        address_attributes: [:id, :street, :secondary_street, :city, :state, :zip, :country] ]
      )
    end

    def update_params_modifications
      # Make subdomains lowercase, and only allow a one-time update.
      if @account_info.subdomain.blank?
        params[:client_account][:client_account_info_attributes][:subdomain].downcase
      else
        params[:client_account][:client_account_info_attributes][:subdomain] = @account_info.subdomain
      end

      # Allow a one-time update of org_name
      unless @account.org_name.blank?
        params[:client_account][:org_name] = @account.org_name
      end

    end
  end
end
