require 'resources/data/phone_country_codes'

module Client
  class ActivityLogisticsController < BaseController
    before_action :load_map_api_key
    before_action :set_country_codes

    def new
      travel_plan_id = params[:travel_plan_id]
      @travel_plan = TravelPlan.find(travel_plan_id)

      @activity_logistic = ActivityLogistic.new
    end

    def create
      travel_plan_id = params[:travel_plan_id]
      @travel_plan = TravelPlan.find(travel_plan_id)

      @activity_logistic = ActivityLogistic.new(activity_logistic_params.merge(travel_plan_id: travel_plan_id))

      if @activity_logistic.save
        redirect_to "/client/travel_plans/#{travel_plan_id}"
      else
        flash.now[:alert] = @activity_logistic.errors.full_messages
        render :new
      end
    end

    def edit
      @travel_plan_id = params[:travel_plan_id]
      @travel_plan = TravelPlan.find(@travel_plan_id)
      @activity_logistic = ActivityLogistic.find(params[:id])
    end

    def update
      @travel_plan_id = params[:travel_plan_id]
      @travel_plan = TravelPlan.find(@travel_plan_id)
      @activity_logistic = ActivityLogistic.find(params[:id])

      if @activity_logistic.update(activity_logistic_params)
        redirect_to "/client/travel_plans/#{@travel_plan.id}/activity_logistics/#{@activity_logistic.id}"
      else
        flash.now[:alert] = @activity_logistic.errors.full_messages
        render :edit
      end
    end

    def show
      @travel_plan_id = params[:travel_plan_id]
      @activity_logistic_id = params[:id]
      @travel_plan = TravelPlan.find(@travel_plan_id)
      @activity_logistic = ActivityLogistic.find(params[:id])

      all_travelers = @travel_plan.traveler_plan_logistics
      activity_logistic_travelers = @activity_logistic.traveler_plan_logistics

      @selected_travelers = all_travelers.merge(activity_logistic_travelers)
      @unselected_travelers = all_travelers - activity_logistic_travelers
    end

    def add_traveler_plan_logistics
      travel_plan_id = params[:travel_plan_id]
      @activity_logistic_id = params[:id]
      @travel_plan = TravelPlan.find(travel_plan_id)
      @activity_logistic = ActivityLogistic.find(params[:activity_logistic_id])

      traveler_plan_logistics = TravelerPlanLogistic.where(id: params[:traveler_plan_logistic_ids])
      @activity_logistic.traveler_plan_logistics << traveler_plan_logistics
      @activity_logistic.traveler_plan_logistics.flatten

      if @activity_logistic.save
        flash.now[:alert] = "Travelers added to housing logistic"
        redirect_to "/client/travel_plans/#{travel_plan_id}/activity_logistics/#{@activity_logistic.id}"
      else
        flash.now[:alert] = @activity_logistic.errors.full_messages
        redirect_to "/client/travel_plans/#{travel_plan_id}/activity_logistics/#{@activity_logistic.id}"
      end
    end

    def remove_traveler_plan_logistics
      travel_plan_id = params[:travel_plan_id]
      @activity_logistic_id = params[:id]
      @travel_plan = TravelPlan.find(travel_plan_id)
      @activity_logistic = ActivityLogistic.find(params[:activity_logistic_id])

      @activity_logistic.traveler_plan_logistics.delete(TravelerPlanLogistic.find(params[:traveler_plan_logistic_id]))

      redirect_to "/client/travel_plans/#{travel_plan_id}/activity_logistics/#{@activity_logistic.id}"
    end

    def destroy
      travel_plan_id = params[:travel_plan_id]
      activity_logistic = ActivityLogistic.find(params[:id])

      activity_logistic.destroy
      redirect_to "/client/travel_plans/#{travel_plan_id}"
    end

    private

    def set_country_codes
      @country_codes = PhoneCountryCodes::ALL
    end

    def load_map_api_key
      @google_map_api_key = Rails.application.secrets.google_map_api_key
    end

    def activity_logistic_params
      params.require(:activity_logistic).permit(:name, :logistic_type, :activity_type, :arrival_date, :departure_date, :travel_plan_id, :country_code, :phone_number, :email, :confirmation_number, :departure_time, :arrival_time, :time_zone, :lat, :long, :address)
    end
  end
end
