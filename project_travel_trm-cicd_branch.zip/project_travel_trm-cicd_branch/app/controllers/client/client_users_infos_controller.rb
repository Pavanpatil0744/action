module Client
  class ClientUsersInfosController < BaseController

    def edit
      if current_user.client_user_info.blank?
        current_user.create_client_user_info.save
      end

      @info = current_user.client_user_info
    end

    def update
      @info = ClientUserInfo.find(params[:user_id])

      if @info.update(info_params)
        flash[:notice] = __("Your information was successfully updated.")
        if current_user.client_account.blank?
          edit_client_client_account_path
        else
          redirect_to client_root_path
        end
      else
        flash.now[:alert] = __("Your information could not be updated at this time.")
        render :edit
      end
    end

    private

    def info_params
      params.require(:client_user_info).permit(:title, :job_title, :suffix, :user_id)
    end
  end
end
