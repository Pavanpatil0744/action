module Client
  class InvitationsController < BaseController

    def invite_single
      redirect_path = request.env["HTTP_REFERER"] || search_client_travelers_path
      authorize :traveler_information, :invite_traveler?

      if traveler_invite.valid?
        TravelerInviter.new(traveler_invitation_params, current_user, client).invite
        redirect_to redirect_path, notice: "New #{t(:traveler)} #{traveler_email} was invited."
      elsif traveler_invite.errors.messages[:base].present? && !traveler_invite.errors.messages[:base].include?("User already exists as traveler.")
        user = User.find_by(email: traveler_invitation_params[:email])
        user.clients << [client]
        user.add_role(:traveler)
        user.save
        redirect_to redirect_path, notice: "#{t(:traveler)} #{traveler_email} was added as a traveler, no invitation was sent as this user already existed as an admin in Via."
      else
        redirect_to redirect_path, alert: "Unable to invite #{t(:traveler)}."
      end
    end

    def invite_multiple
      redirect_path = request.env["HTTP_REFERER"] || search_client_travelers_path
      authorize :traveler_information, :invite_traveler?

      # Update with invite params to ensure anything flagged as _destroy is in fact destroyed before inviting
      @user.update(invite_params) if params[:user]

      # Now send invitations
      if @user.uploads.where(id: params[:uploads]).count > 0
        @user.uploads.where(id: params[:uploads]).each do |invite|
          TravelerCSVInvitationWorker.perform_async(client.id, invite.id, current_user.id)
        end
        redirect_to redirect_path, notice: __("Bulk invitations started.")
      else
        redirect_to redirect_path, alert: __("Please upload one or more bulk invitation CSV files.")
      end
    end

    def upload
      respond_to do |format|
        @user.update(invite_params)
        data = invite_params.to_h
        if @user.errors.size > 0
          @upload = Upload.new(upload_type: :invite, file: data["uploads_attributes"]["0"]["file"])
        else
          @upload = @user.uploads.invites.last
        end
        @errors = @user.errors.to_flash
        flash.clear
        format.json { render json: { upload: @upload.id, block: render_to_string(partial: "upload/invite", layout: false, formats: [:html], locals: { upload: @upload, errors: @errors }) } }
      end
    end

    private

    def traveler_invitation_params
      params.require(:traveler_invitation).permit(:email, :first_name, :last_name)
    end

    def traveler_invite
      @traveler_invite ||= Validators::Client::TravelerInvitations::Invite.new(traveler_invitation_params)
    end

    def traveler_email
      traveler_invitation_params[:email]
    end

    def invite_params
      params.require(:user).permit(uploads_attributes: [:file, :id, :_destroy]).deep_merge(uploads_attributes: { "0" => { upload_type: :invite } })
    end
  end
end
