module Client
  class AccountsController < BaseController

    layout "client/form_with_sub_nav"

    before_action :no_cache # Otherwise profile photo doesn't update, which is confusing.
    before_action :create_objects
    before_action :set_objects

    def show
      @user_using_sso = user_using_sso?
    end

    def update
      update_user(user_params)
      @user.update(profile_params)
      respond_to do |format|
        if @user.errors.any?
          format.html { render :show }
          format.json { render json: @user.errors, status: :unprocessable_entity }
        else
          format.html { redirect_to client_account_path, notice: "Account was successfully updated." }
          format.json { render :show, status: :ok, location: @user }
        end
      end
    end

    private

    def create_objects
      if current_user.client_user_info.blank?
        current_user.create_client_user_info
      end

      if current_user.profile.blank?
        current_user.create_profile
      end
    end

    def set_objects
      @user = current_user
      @experience_options = (0..9).map { |m| ["#{m} Years", m] } << ["10+ Years", 10]
    end

    def update_user(user_params)
      if user_params[:password].blank? && user_params[:password_confirmation].blank?
        user_params.except!(:password, :password_confirmation)
      end

      current_user.update(user_params)

      sign_in :user, current_user, bypass: true
    end

    def user_params
      params.required(:user).permit(*user_permitted_attributes)
    end

    def user_permitted_attributes
      if user_using_sso?
        [:avatar]
      else
        [:avatar, :password, :password_confirmation]
      end
    end

    def profile_params
      params.required(:user).permit(
        profile_attributes: [:id, :first_name, :last_name],
        client_user_info_attributes: [:id, :title, :job_title, :suffix]
      )
    end

    def user_using_sso?
      Sso::UserUsingSso.new(current_user, current_user.client_account).execute
    end
  end
end
