module Client
  class TransportationLogisticsController < BaseController
    before_action :load_map_api_key

    def new
      @travel_plan_id = params[:travel_plan_id]
      @transportation_logistic = TransportationLogistic.new
      @transportation_logistic.transportation_segments.build
    end

    def create
      @travel_plan_id = params[:travel_plan_id]
      @travel_plan = TravelPlan.find(@travel_plan_id)

      @transportation_logistic = TransportationLogistic.new(transportation_logistic_params.merge(travel_plan_id: @travel_plan_id))

      if @transportation_logistic.save
        redirect_to "/client/travel_plans/#{@travel_plan_id}"
      else
        flash.now[:alert] = @transportation_logistic.errors.full_messages
        render :new
      end
    end

    def edit
      @travel_plan_id = params[:travel_plan_id]
      @travel_plan = TravelPlan.find(@travel_plan_id)
      @transportation_logistic = TransportationLogistic.find(params[:id])
    end

    def update
      @travel_plan_id = params[:travel_plan_id]
      @travel_plan = TravelPlan.find(@travel_plan_id)
      @transportation_logistic = TransportationLogistic.find(params[:id])

      if @transportation_logistic.update(transportation_logistic_params)
        redirect_to "/client/travel_plans/#{@travel_plan_id}/transportation_logistics/#{@transportation_logistic.id}"
      else
        flash.now[:alert] = @transportation_logistic.errors.full_messages
        render :edit
      end
    end

    def show
      travel_plan_id = params[:travel_plan_id]
      @transportation_logistic_id = params[:id]
      @travel_plan = TravelPlan.find(travel_plan_id)
      @transportation_logistic = TransportationLogistic.find(params[:id])

      @departure_segment = @transportation_logistic.transportation_segments.first
      @arrival_segment = @transportation_logistic.transportation_segments.last

      all_travelers = @travel_plan.traveler_plan_logistics.includes(:profile)
      transportation_logistic_travelers = @transportation_logistic.traveler_plan_logistics(:profile)

      @selected_travelers = all_travelers.merge(transportation_logistic_travelers)
      @unselected_travelers = all_travelers - transportation_logistic_travelers
    end

    def add_traveler_plan_logistics
      travel_plan_id = params[:travel_plan_id]
      @transportation_logistic_id = params[:id]
      @travel_plan = TravelPlan.find(travel_plan_id)
      @transportation_logistic = TransportationLogistic.find(params[:transportation_logistic_id])

      traveler_plan_logistics = TravelerPlanLogistic.where(id: params[:traveler_plan_logistic_ids])
      @transportation_logistic.traveler_plan_logistics << traveler_plan_logistics
      @transportation_logistic.traveler_plan_logistics.flatten

      if @transportation_logistic.save
        flash.now[:alert] = "Travelers added to housing logistic"
        redirect_to "/client/travel_plans/#{travel_plan_id}/transportation_logistics/#{@transportation_logistic.id}"
      else
        flash.now[:alert] = @transportation_logistic.errors.full_messages
        redirect_to "/client/travel_plans/#{travel_plan_id}/transportation_logistics/#{@transportation_logistic.id}"
      end
    end

    def remove_traveler_plan_logistics
      travel_plan_id = params[:travel_plan_id]
      @transportation_logistic_id = params[:id]
      @travel_plan = TravelPlan.find(travel_plan_id)
      @transportation_logistic = TransportationLogistic.find(params[:transportation_logistic_id])

      @transportation_logistic.traveler_plan_logistics.delete(TravelerPlanLogistic.find(params[:traveler_plan_logistic_id]))

      redirect_to "/client/travel_plans/#{travel_plan_id}/transportation_logistics/#{@transportation_logistic.id}"
    end

    def destroy
      travel_plan_id = params[:travel_plan_id]
      travel_plan = TravelPlan.find(travel_plan_id)
      transportation_logistic = TransportationLogistic.find(params[:id])

      transportation_logistic.transportation_segments.delete_all
      transportation_logistic.destroy

      redirect_to "/client/travel_plans/#{travel_plan_id}"
    end


    private

    def load_map_api_key
      @google_map_api_key = Rails.application.secrets.google_map_api_key
    end

    def transportation_logistic_params
      params.require(:transportation_logistic).permit(:logistic_type, :transportation_type, :confirmation_number,
      	transportation_segments_attributes: [:id, :carrier, :route_number, :arrival_site, :departure_site, :time_zone, :departure_date, :arrival_date, :departure_time, :arrival_time, :arrival_time_zone, :departure_time_zone, :arrival_lat, :arrival_long, :arrival_address, :departure_lat, :departure_long, :departure_address, :_destroy])
    end
  end
end
