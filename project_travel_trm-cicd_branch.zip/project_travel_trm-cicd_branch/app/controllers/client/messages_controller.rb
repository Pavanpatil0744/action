module Client
  class MessagesController < BaseController

    def create
      @user.update(attachment_params) if params[:user]
      @message = Message.new(message_params)
      @message.attachments = @user.uploads.where(id: params[:uploads]).map { |attachment| File.open(attachment.file.path) }
      redirect_path = request.env["HTTP_REFERER"] || search_client_travelers_path
      if @message.save
        traveler_ids = params[:message][:traveler_ids]
        logger.info "#{current_user.name} from #{client.name} created mass message for #{traveler_ids.size} travelers with subject: #{@message.subject}. \nTraveler ids: #{traveler_ids}"
        traveler_ids.each do |traveler_id|
          MessagingWorker.perform_async(traveler_id, client.id, current_user.id, @message.id)
        end
        redirect_to redirect_path, notice: __("Message successfully posted to travelers.")
      else
        redirect_to redirect_path, alert: __("Unable to send messages.")
      end
    end

    private

    def message_params
      params.require(:message).permit(:subject, :body).merge(user: @user)
    end

    def attachment_params
      params.require(:user).permit(:uploads_attributes => [:file, :id, :_destroy]).deep_merge(uploads_attributes: { "0" => { upload_type: :message_attachment } })
    end

  end
end
