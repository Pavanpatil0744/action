module Client
  class NotificationsController < BaseController

    layout "client/form_with_sub_nav"

    def show
      @user = current_user
    end

    def update
      @user = current_user
      if @user.update(traveler_params)
        redirect_to client_notifications_path, notice: __("Successfully updated notification status.")
      else
        redirect_to client_notifications_path, alert: __("Unable to update notification status.")
      end
    end

    private

    def traveler_params
      params.require(:user).permit(:inactive)
    end

  end
end
