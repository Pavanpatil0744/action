module Client
  class SessionsController < Devise::SessionsController
    def new
      super do
        @presenter = SessionPresenter.new(subdomain)
      end
    end

    def destroy
      if logout_url
        sign_out(resource_name)
        redirect_to logout_url
      else
        super
      end
    end

    private

    def logout_url
      @logout_url ||= Sso::Slo::LogoutUrl.new(current_user, subdomain).execute
    end

    def subdomain
      subdomains = request.subdomains - ['api']
      subdomains.last
    end
  end
end
