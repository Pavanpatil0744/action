module Client
  class RegistrationsController < Devise::RegistrationsController

    def create
      super do
        resource.add_role(:super_user)
        trigger_confirmation(resource) if resource.save
      end
    end

    private

    def trigger_confirmation(resource)
      resource.confirmed_at = nil
      resource.send_confirmation_instructions
    end
  end
end
