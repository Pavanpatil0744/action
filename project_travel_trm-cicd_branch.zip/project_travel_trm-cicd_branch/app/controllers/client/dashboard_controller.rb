module Client
  class DashboardController < BaseController

    def index
      redirect_to search_client_travelers_path(q: { sort_by: "activity", sort_dir: "asc", page: 1, funnel_step: "all" })
    end

  end
end
