module Client
  class BaseController < ApplicationController
    before_action :authenticate_user!, except: :bypass_login_to_travel_plans
    before_action :authorize_client, except: :bypass_login_to_travel_plans
    before_action :validate_subdomain
    before_action :set_client, except: :bypass_login_to_travel_plans

    helper_method :client

    def authorize_client
      unless user_signed_in? && current_user.client_user_role? && !current_user.archived?
        sign_out :user
        redirect_to root_path, alert: "Client access denied." and return
      end
    end

    def verify_super_user
      unless user_signed_in? && current_user.is_super_user?
        sign_out :user
        redirect_to root_path, alert: "Client access denied." and return
      end
    end

    def verify_super_user_or_power_user
      unless user_signed_in? && current_user.client_admin_role?
        sign_out :user
        redirect_to root_path, alert: "Client access denied." and return
      end
    end

    def validate_subdomain
      logger.info "subdomain: #{subdomain}"
      if current_user.try(:client_account).try(:client_account_info).try(:subdomain).try(:present?)
        client_subdomain = current_user.client_account.client_account_info.subdomain
        if subdomain.present? && subdomain != client_subdomain
          sign_out :user
          redirect_to root_path, alert: "You attempted to login under the wrong subdomain." and return
        end
      end
    end

    def prevent_free_accounts
      if client.free?
        redirect_to search_client_programs_path(q: { status: "draft" }), alert: "The requested feature is only available for paid accounts." and return
      end
    end

    def allow_enrollment_accounts
      unless client.in_enrollment?
        redirect_to search_client_programs_path(q: { status: "draft" }), alert: "The requested feature is only available for #{ t :enrollment } accounts." and return
      end
    end

    def set_client
      @client ||= current_user.client_account
    end

    def build_template_program
      @available_forms = Form.published_for(current_user.client_account)
    end

    def bypass_login_to_travel_plans
      user = User.find_by(authentication_token: params['token'], id: params['id'])
      sign_in(user)
      redirect_to client_travel_plans_path
    end

    private

    def client
      @client ||= current_user.client_account
    end

  end
end
