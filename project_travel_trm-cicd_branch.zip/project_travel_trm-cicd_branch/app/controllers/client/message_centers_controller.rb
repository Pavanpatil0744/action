module Client
  class MessageCentersController < BaseController

    def show
      # Sort with all unread at top, in order of date, then the rest, in order of date.
      authorize :traveler_information, :view_and_send_messages?
      @unread = []
      @read = []
      current_user.mailbox.inbox.order(:updated_at).each do |c|
        if c.is_unread?(current_user)
          @unread << c
        else
          @read << c
        end
      end
    end
  end
end
