require 'resources/data/phone_country_codes'

module Client
  class HousingLogisticsController < BaseController
    before_action :load_map_api_key
    before_action :set_country_codes

    def new
      travel_plan_id = params[:travel_plan_id]
      @travel_plan = TravelPlan.find(travel_plan_id)
      @housing_logistic = HousingLogistic.new
    end

    def create
      travel_plan_id = params[:travel_plan_id]
      @travel_plan = TravelPlan.find(travel_plan_id)
      @housing_logistic = HousingLogistic.new(housing_logistic_params.merge(travel_plan_id: travel_plan_id))

      if @housing_logistic.save
        redirect_to "/client/travel_plans/#{travel_plan_id}"
      else
        flash.now[:alert] = @housing_logistic.errors.full_messages
        render :new
      end
    end

    def edit
      @travel_plan_id = params[:travel_plan_id]
      @travel_plan = TravelPlan.find(@travel_plan_id)
      @housing_logistic = HousingLogistic.find(params[:id])
    end

    def update
      @travel_plan_id = params[:travel_plan_id]
      @travel_plan = TravelPlan.find(@travel_plan_id)
      @housing_logistic = HousingLogistic.find(params[:id])

      if @housing_logistic.update(housing_logistic_params)
        redirect_to "/client/travel_plans/#{@travel_plan.id}/housing_logistics/#{@housing_logistic.id}"
      else
        flash.now[:alert] = @housing_logistic.errors.full_messages
        render :edit
      end
    end

    def show
      travel_plan_id = params[:travel_plan_id]
      @housing_logistic_id = params[:id]
      @travel_plan = TravelPlan.find(travel_plan_id)
      @housing_logistic = HousingLogistic.find(params[:id])

      all_travelers = @travel_plan.traveler_plan_logistics
      housing_logistic_travelers = @housing_logistic.traveler_plan_logistics

      @selected_travelers = all_travelers.merge(housing_logistic_travelers)
      @unselected_travelers = all_travelers - housing_logistic_travelers
    end

    def add_traveler_plan_logistics
      travel_plan_id = params[:travel_plan_id]
      @housing_logistic_id = params[:id]
      @travel_plan = TravelPlan.find(travel_plan_id)
      @housing_logistic = HousingLogistic.find(params[:housing_logistic_id])

      traveler_plan_logistics = TravelerPlanLogistic.where(id: params[:traveler_plan_logistic_ids])
      @housing_logistic.traveler_plan_logistics << traveler_plan_logistics
      @housing_logistic.traveler_plan_logistics.flatten

      if @housing_logistic.save
        flash.now[:alert] = "Travelers added to housing logistic"
        redirect_to "/client/travel_plans/#{travel_plan_id}/housing_logistics/#{@housing_logistic.id}"
      else
        flash.now[:alert] = @housing_logistic.errors.full_messages
        redirect_to "/client/travel_plans/#{travel_plan_id}/housing_logistics/#{@housing_logistic.id}"
      end
    end

    def remove_traveler_plan_logistics
      travel_plan_id = params[:travel_plan_id]
      @housing_logistic_id = params[:id]
      @travel_plan = TravelPlan.find(travel_plan_id)
      @housing_logistic = HousingLogistic.find(params[:housing_logistic_id])

      @housing_logistic.traveler_plan_logistics.delete(TravelerPlanLogistic.find(params[:traveler_plan_logistic_id]))

      redirect_to "/client/travel_plans/#{travel_plan_id}/housing_logistics/#{@housing_logistic.id}"
    end

    def destroy
      travel_plan_id = params[:travel_plan_id]
      travel_plan = TravelPlan.find(travel_plan_id)
      housing_logistic = HousingLogistic.find(params[:id])

      housing_logistic.destroy

      redirect_to "/client/travel_plans/#{travel_plan_id}"
    end

    private

    def set_country_codes
      @country_codes = PhoneCountryCodes::ALL
    end

    def load_map_api_key
      @google_map_api_key = Rails.application.secrets.google_map_api_key
    end

    def housing_logistic_params
      params.require(:housing_logistic).permit(:name, :logistic_type, :housing_type, :arrival_date, :departure_date, :travel_plan_id, :country_code, :phone_number, :email, :confirmation_number, :arrival_time, :departure_time, :time_zone, :lat, :long, :address)
    end
  end
end
