require 'resources/data/phone_country_codes'

module Client
  class TravelPlansController < BaseController
    before_action :plan_types, :only => [:new, :create, :edit, :update]
    before_action :load_map_api_key
    before_action :set_country_codes
    #before_action :check_license
    before_action :authorize_access

    def index
      @travel_plans = TravelPlan.all
      @presenter = TravelPlans::DashboardPresenter.new
    end

    def show
      travel_plan = TravelPlan.where(client_account_id: client_account.id).find(params[:id])
      @travel_plan = TravelPlanPresenter.new(travel_plan)
      @travel_plan_id = @travel_plan.id
      @traveler_plan_logistics = travel_plan.traveler_plan_logistics.includes(:profile)

      @arrival_logistics = gather_logistics(travel_plan, "Arrival")
      @onsite_logistics = gather_logistics(travel_plan, "Onsite")
      @return_logistics = gather_logistics(travel_plan, "Return")
    end

    def new
      authorize :travel_plans, :create?
      @new_travel_plan = TravelPlan.new
      @travel_plan = TravelPlanPresenter.new(@new_travel_plan)
      @travel_plan.emergency_contacts.build
    end

    def create
      @new_travel_plan = TravelPlan.new(travel_plan_params)
      @new_travel_plan.client_account_id = client_account.id

      if @new_travel_plan.save
        @new_travel_plan.update(emergency_contacts_count: @new_travel_plan.emergency_contacts.count)
        redirect_to "/client/travel_plans/#{@new_travel_plan.id}"
      else
        @travel_plan = TravelPlanPresenter.new(@new_travel_plan)
        flash.now[:alert] = @new_travel_plan.errors.full_messages
        render :new
      end
    end

    def edit
      authorize :travel_plans, :edit?
      travel_plan = TravelPlan.find(params[:id])
      @edit_travel_plan = TravelPlan.find(params[:id])
      @travel_plan = TravelPlanPresenter.new(@edit_travel_plan)
      @travel_plan.emergency_contacts.build
    end

    def bulk_add_travelers
      redirect_path = request.env["HTTP_REFERER"] || future_client_travel_plans_path
      @travel_plan_id = params["bulk_add_travelers"]["travel_plan_id"]
      flash[:alert] = []
      flash[:notice] = []

      if @user.uploads.where(id: params["bulk_add_travelers"]["uploads"]).count > 0
        @user.uploads.where(id: params["bulk_add_travelers"]["uploads"]).each do |uploaded_csv|
          process_csv(uploaded_csv, @travel_plan_id)
        end
        redirect_to redirect_path
      else
        redirect_to redirect_path, alert: "Please upload one or more #{(t :traveler)} invitation CSV files."
      end
    end

    def bulk_add_travelers_sort
      redirect_path = request.env["HTTP_REFERER"] || future_client_travel_plans_path
      @travel_plan_id = params["bulk_add_travelers_sort"]["travel_plan_id"]
      flash[:alert] = []
      flash[:notice] = []

      if @user.uploads.where(id: params[:uploads]).count > 0
        @user.uploads.where(id: params[:uploads]).each do |uploaded_csv|
          sort_travelers(uploaded_csv, @travel_plan_id)
        end
        # redirect_to redirect_path
      else
        redirect_to redirect_path, alert: "Please upload one or more #{(t :traveler)} invitation CSV files."
        return
      end

      respond_to do |format|
        format.js
      end
    end

    def add_single_traveler
      traveler_params = params["traveler"]
      travel_plan_id = params["traveler"]["travel_plan_id"]
      travel_plan = TravelPlan.find(travel_plan_id)
      flash[:alert] = []

      unless traveler_params["first_name"].present? && traveler_params["last_name"].present? && traveler_params["email"].present?
        flash[:alert] = "Please fill out all fields"
        return redirect_to "/client/travel_plans/#{travel_plan_id}"
      end

      traveler_account = client_account.travelers.where(email: traveler_params["email"]).first ||
                         client_account.users.where(email: traveler_params["email"]).first ||
                         Profile.where(email: traveler_params["email"]).where(client_account_id: client_account.id).first

      if !(traveler_account.try(:profile) && traveler_account.try(:profile).try(:user))
        if travel_plan.traveler_plan_logistics.includes(:profile).where("profiles.email" => traveler_params["email"]).present?
          flash[:alert] << "#{traveler_params["email"]} already exists in this plan."
        elsif traveler_account
          traveler_plan_logistic = TravelerPlanLogistic.new(profile_id: traveler_account.id, travel_plan_id: travel_plan_id)
          if traveler_plan_logistic.save
            flash[:notice] = "#{traveler_params["email"]} added"
          else
            flash[:alert] = traveler_plan_logistic.errors.full_messages
          end
        else
          profile = Profile.new(first_name: traveler_params["first_name"], last_name: traveler_params["last_name"], email: traveler_params["email"], client_account_id: client_account.id)

          if profile.save
            traveler_info = TravelerInfo.new(profile_id: profile.id)
            traveler_plan_logistic = TravelerPlanLogistic.new(profile_id: profile.id, travel_plan_id: travel_plan_id)
            if traveler_info.save
              if traveler_plan_logistic.save
                flash[:notice] = "#{traveler_params["email"]} added"
              else
                flash[:alert] = traveler_plan_logistic.errors.full_messages
              end
            else
              flash[:alert] = traveler_info.errors.full_messages
            end
          else
            flash[:alert] = profile.errors.full_messages
          end
        end
      elsif traveler_account.try(:profile) && !(traveler_account.try(:profile).try(:traveler_info) || traveler_account.try(:traveler_info))
        profile = traveler_account.profile

        if profile.try(:email).nil?
          profile.update(override_readonly_fields: true)
          profile.update(email: traveler_account.email)
          profile.update(override_readonly_fields: false)
        end

        traveler_info = TravelerInfo.new(profile_id: profile.id)
        traveler_plan_logistic = TravelerPlanLogistic.new(profile_id: profile.id, travel_plan_id: travel_plan_id)

        if traveler_info.save
          if traveler_plan_logistic.save
            flash[:notice] = "#{traveler_params["email"]} added"
          else
            flash[:alert] = traveler_plan_logistic.errors.full_messages
          end
        else
          flash[:alert] = traveler_info.errors.full_messages
        end
      elsif traveler_account.try(:profile) && (traveler_account.try(:profile).try(:traveler_info) || traveler_account.try(:traveler_info))
        profile = traveler_account.profile

        if travel_plan.traveler_plan_logistics.where(profile_id: profile.id).exists?
          flash[:alert] = "That traveler already exists in this plan."
        else
          if profile.try(:email).nil?
            profile.update(override_readonly_fields: true)
            profile.update(email: traveler_account.email)
            profile.update(override_readonly_fields: false)
          end

          if traveler_account.try(:traveler_info)
            traveler_account.traveler_info.update(profile_id: profile.id)
          end

          traveler_plan_logistic = TravelerPlanLogistic.new(profile_id: profile.id, travel_plan_id: travel_plan_id)

          if traveler_plan_logistic.save
            flash[:notice] = "#{traveler_params["email"]} added"
          else
            flash[:alert] = traveler_plan_logistic.errors.full_messages
          end
        end
      end

      redirect_to "/client/travel_plans/#{travel_plan_id}"
    end

    def update
      @edit_travel_plan = TravelPlan.find(params[:id])
      travel_plan = TravelPlan.find(params[:id])

      if travel_plan.update(travel_plan_params)
        travel_plan.update(emergency_contacts_count: travel_plan.emergency_contacts.count)
        redirect_to "/client/travel_plans/#{travel_plan.id}"
      else
        @travel_plan = TravelPlanPresenter.new(travel_plan)
        flash.now[:alert] = @travel_plan.errors.full_messages
        render :edit
      end
    end

    def destroy
      authorize :travel_plans, :destroy?
      travel_plan = TravelPlan.where(client_account_id: client_account.id).find(params[:id])
      travel_plan.destroy
      redirect_to "/client/travel_plans/future", notice: "Travel plan was deleted."
    end

    def future
      @travel_plans = TravelPlan.future(client_account).map {|travel_plan| TravelPlan.new(travel_plan.attributes)}
      @presenter = TravelPlans::DashboardPresenter.new
      render :index
    end

    def past
      @travel_plans = TravelPlan.past(client_account).map {|travel_plan| TravelPlan.new(travel_plan.attributes)}
      @presenter = TravelPlans::DashboardPresenter.new
      render :index
    end

    def on_site
      @travel_plans = TravelPlan.on_site(client_account).map {|travel_plan| TravelPlan.new(travel_plan.attributes)}
      @presenter = TravelPlans::DashboardPresenter.new
      render :index
    end

    def generate_plan_detail_report
      travelers = []
      selected_fields = []
      travel_plan = TravelPlan.find(params[:id])
      logistics = (travel_plan.housing_logistics + travel_plan.activity_logistics).sort_by { |logistic| logistic[:arrival_date] }
      logistics += travel_plan.transportation_logistics
      travelers = travel_plan.traveler_plan_logistics

      params["report"]["traveler"].each do |key, val|
        if val == "1"
          selected_fields << key
        end
      end

      respond_to do |format|
        format.html
        format.csv { send_data generate_details_csv(travelers, logistics, selected_fields) }
      end
    end

    def generate_plan_summary_report
      travelers = []
      selected_plan_fields = ["name", "plan_type", "address", "start_date", "end_date"]
      selected_traveler_fields = []

      if request.referrer.include?("/client/travel_plans/future")
        travel_plans = TravelPlan.future(client_account).map {|travel_plan| TravelPlan.new(travel_plan.attributes)}
        max_contacts = TravelPlan.future(client_account).maximum(:emergency_contacts_count)
        travel_plans.map do |travel_plan|
          travelers << travel_plan.traveler_plan_logistics.includes(:profile => :traveler_info)
        end
      elsif request.referrer.include?("/client/travel_plans/on_site")
        travel_plans = TravelPlan.on_site(client_account).map {|travel_plan| TravelPlan.new(travel_plan.attributes)}
        max_contacts = TravelPlan.on_site(client_account).maximum(:emergency_contacts_count)
        travel_plans.map do |travel_plan|
          travelers << travel_plan.traveler_plan_logistics.includes(:profile => :traveler_info)
        end
      elsif request.referrer.include?("/client/travel_plans/past")
        travel_plans = TravelPlan.past(client_account).map {|travel_plan| TravelPlan.new(travel_plan.attributes)}
        max_contacts = TravelPlan.past(client_account).maximum(:emergency_contacts_count)
        travel_plans.map do |travel_plan|
          travelers << travel_plan.traveler_plan_logistics.includes(:profile => :traveler_info)
        end
      end

      travelers.flatten!

      params["report"]["plan"].each do |key, val|
        if val == "1"
          if key == "contacts"
            max_contacts.times { selected_plan_fields << key }
          else
            selected_plan_fields << key
          end
        end
      end

      params["report"]["traveler"].each do |key, val|
        if val == "1"
          selected_traveler_fields << key
        end
      end

      respond_to do |format|
        format.html
        format.csv { send_data generate_summary_csv(travelers, selected_plan_fields, selected_traveler_fields) }
      end
    end

    private

    def authorize_access
      authorize :travel_plans, :access_travel_registration?
    end

    def check_license
      unless current_user.try(:client_account).travel_registration
        raise ActionController::RoutingError.new("Sorry! Travel plans are only available to licensed users.")
      end
    end

    def generate_details_csv(travelers, logistics, selected_fields)
      header_dates = ["", ""]
      header_words = ["Traveler Name", "Email"]

      logistics.map do |logistic|
        if logistic.class == TransportationLogistic
          date = "#{logistic.transportation_segments.first.departure_date.strftime("%m/%d/%Y")} - #{logistic.transportation_segments.last.arrival_date.strftime("%m/%d/%Y")}"
          location = "#{logistic.transportation_segments.first.departure_address.chomp(", United States")} to #{logistic.transportation_segments.last.arrival_address.chomp(", United States")}"

          header_dates << date
          header_words << location
        else
          date = logistic.try(:arrival_date).strftime("%m/%d/%Y")
          logistic_type = logistic.try(:activity_type) || logistic.try(:housing_type)

          if logistic.departure_date.present?
            departure_date = logistic.departure_date.strftime("%m/%d/%Y")
            date = "#{date} - #{departure_date}"
          end

          header_dates << date
          header_words << logistic_type
        end
      end

      CSV.generate(encoding: 'UTF-8', headers: true) do |csv|
        csv << header_dates.map
        csv << header_words.map(&:titleize) + selected_fields.map(&:titleize)

        travelers.each do |traveler|
          selected_logistics = ["#{traveler.profile.first_name} #{traveler.profile.last_name}", (traveler.profile.user.try(:email) || traveler.profile.email)]

          logistics.map do |logistic|
            if logistic.class != TransportationSegment && logistic.traveler_plan_logistics.include?(traveler)
              selected_logistics << "X"
            elsif logistic.class == TransportationSegment && logistic.transportation_logistic.traveler_plan_logistics.include?(traveler)
              selected_logistics << "X"
            else
              selected_logistics << ""
            end
          end

          selected_profile_info = selected_fields.map do |attr|
            if attr == "countries_of_citizenship"
              traveler.profile.traveler_info.send(attr).join(",")
            elsif attr == "college_or_faculty"
              traveler.profile.traveler_info.send("places_of_study").join(",")
            elsif attr == "gender"
              traveler.profile.traveler_info.send("gender").try(:humanize)
            elsif attr == "student_id_number"
              traveler.profile.traveler_info.send("student_id")
            else
              traveler.profile.traveler_info.send(attr)
            end
          end
          csv << selected_logistics + selected_profile_info
        end
      end
    end

    def generate_summary_csv(travelers, selected_plan_fields, selected_traveler_fields)
      profile_attributes = %w{ email first_name last_name }

      CSV.generate(encoding: 'UTF-8', headers: true) do |csv|
        csv << profile_attributes.map(&:titleize) + selected_plan_fields.map(&:titleize) + selected_traveler_fields.map(&:titleize)

        travelers.each do |traveler|
          emergency_contact_counter = 0
          default_profile_info = profile_attributes.map{ |attr| traveler.profile.send(attr) }

          selected_plan_info = selected_plan_fields.map do |attr|
            if attr == ("contacts")
              contact = traveler.travel_plan.emergency_contacts[emergency_contact_counter]
              emergency_contact_counter += 1

              "#{contact.try(:first_name)} #{contact.try(:last_name)}\n#{contact.try(:email)}\n#{contact.try(:country_code)} #{contact.try(:phone_number)}"
            else
              traveler.travel_plan.send(attr)
            end
          end

          selected_profile_info = selected_traveler_fields.map do |attr|
            if attr == "countries_of_citizenship"
              traveler.profile.traveler_info.send(attr).join(",")
            elsif attr == "college_or_faculty"
              traveler.profile.traveler_info.send("places_of_study").join(",")
            elsif attr == "gender"
              traveler.profile.traveler_info.send("gender").try(:humanize)
            elsif attr == "student_id_number"
              traveler.profile.traveler_info.send("student_id")
            else
              traveler.profile.traveler_info.send(attr)
            end
          end
          csv << default_profile_info + selected_plan_info + selected_profile_info
        end
      end
    end

    def set_country_codes
      @country_codes = PhoneCountryCodes::ALL
    end

    def sort_travelers(upload, travel_plan_id)
      travel_plan = TravelPlan.find(travel_plan_id)
      @existing_travelers = []
      @existing_admins = []
      @new_travelers = []

      @travel_plan_id = travel_plan_id
      @upload = upload

      parse_csv(upload).each do |traveler|
        profiles = Profile.where(client_account_id: client_account.id)
        traveler_account = client_account.travelers.where(email: traveler[:email]).first.try(:profile) || profiles.where(email: traveler[:email]).first
        admin_account = client_account.users.where(email: traveler[:email]).first

        if traveler[:email].nil? || traveler[:first_name].nil? || traveler[:last_name].nil?
          @disabled = "disabled"
          @notice = "Email, First Name, and Last Name are required for all travelers."
        end

        if traveler_account.present?
          @existing_travelers << {email: traveler[:email], first_name: traveler_account[:first_name], last_name: traveler_account[:last_name]}
        elsif admin_account.present?
          @existing_admins << {email: traveler[:email], first_name: admin_account.profile[:first_name], last_name: admin_account.profile[:last_name]}
        else
          @new_travelers << traveler
        end
      end
    end

    def process_csv(upload, travel_plan_id)
      logger.info "Processing travel plan invitations, file: #{upload.file.path}"

      parse_csv(upload).each do |user_row|
        add_traveler(user_row, travel_plan_id)
      end

      upload.destroy
    end

    def parse_csv(upload)
      SmarterCSV.process(upload.file.path, {})
    end

    def add_traveler(traveler, travel_plan_id)
      travel_plan_id = travel_plan_id
      travel_plan = TravelPlan.find(travel_plan_id)

      traveler_account = client_account.travelers.where(email: traveler[:email]).first ||
                         client_account.users.where(email: traveler[:email]).first ||
                         Profile.where(email: traveler[:email]).where(client_account_id: client_account.id).first

      if !(traveler_account.try(:profile) && traveler_account.try(:profile).try(:user))
        if travel_plan.traveler_plan_logistics.includes(:profile).where("profiles.email" => traveler[:email]).present?
          flash[:alert] << "#{traveler[:email]} already exists in this plan."
        elsif traveler_account
          traveler_plan_logistic = TravelerPlanLogistic.new(profile_id: traveler_account.id, travel_plan_id: travel_plan_id)
          if traveler_plan_logistic.save
            flash[:notice] = "Traveler(s) added"
          else
            flash[:alert] = traveler_plan_logistic.errors.full_messages
          end
        else
          profile = Profile.new(first_name: traveler[:first_name], last_name: traveler[:last_name], email: traveler[:email], client_account_id: client_account.id)
          if profile.save
            traveler_info = TravelerInfo.new(profile_id: profile.id)
            traveler_plan_logistic = TravelerPlanLogistic.new(profile_id: profile.id, travel_plan_id: travel_plan_id)
            if traveler_info.save
              if traveler_plan_logistic.save
                flash[:notice] = "Traveler(s) added"
              else
                flash[:alert] << "Error adding #{traveler[:email]}"
              end
            else
              flash[:alert] << "Error adding #{traveler[:email]}"
            end
          else
            flash[:alert] << "Error adding #{traveler[:email]}"
          end
        end
      elsif traveler_account.try(:profile) && !(traveler_account.try(:profile).try(:traveler_info) || traveler_account.try(:traveler_info))
        profile = traveler_account.profile

        if profile.try(:email).nil?
          profile.update(override_readonly_fields: true)
          profile.update(email: traveler_account.email)
          profile.update(override_readonly_fields: false)
        end

        traveler_info = TravelerInfo.new(profile_id: profile.id)
        traveler_plan_logistic = TravelerPlanLogistic.new(profile_id: profile.id, travel_plan_id: travel_plan_id)

        if traveler_info.save
          if traveler_plan_logistic.save
            flash[:notice] = "Traveler(s) added"
          else
            flash[:alert] << "Error adding #{traveler[:email]}"
          end
        else
          flash[:alert] << "Error adding #{traveler[:email]}"
        end
      elsif traveler_account.try(:profile) && (traveler_account.try(:profile).try(:traveler_info) || traveler_account.try(:traveler_info))
        profile = traveler_account.profile

        if travel_plan.traveler_plan_logistics.where(profile_id: profile.id).exists?
          flash[:alert] << "#{traveler[:email]} already exists in this plan."
        else
          if profile.try(:email).nil?
            profile.update(override_readonly_fields: true)
            profile.update(email: traveler_account.email)
            profile.update(override_readonly_fields: false)
          end

          if traveler_account.try(:traveler_info)
            traveler_account.traveler_info.update(profile_id: profile.id)
          end

          traveler_plan_logistic = TravelerPlanLogistic.new(profile_id: profile.id, travel_plan_id: travel_plan_id)

          if traveler_plan_logistic.save
            flash[:notice] = "Traveler(s) added"
          else
            flash[:alert] << "Error adding #{traveler[:email]}"
          end
        end
      end
    end

    def gather_logistics(travel_plan, logistic_type)
      housing_logistics = travel_plan.housing_logistics.where(logistic_type: logistic_type).to_a
      activity_logistics = travel_plan.activity_logistics.where(logistic_type: logistic_type).to_a
      transportation_logistics = travel_plan.transportation_logistics.where(logistic_type: logistic_type).to_a

      return (housing_logistics + activity_logistics + transportation_logistics).sort_by { |logistic| logistic[:start_date] }
    end

    def load_map_api_key
      @google_map_api_key = Rails.application.secrets.google_map_api_key
    end

    def client_account
      current_user.client_account
    end

    def plan_types
      @plan_types = [
        "Academic Exchange",
        "Artistic Performance",
        "Business",
        "Conference",
        "Cultural Exchange",
        "Faculty or Teacher Led Program",
        "Fellowship or Grant",
        "Full Time Teaching position",
        "Independent or Personal",
        "Internship",
        "Language Exchange",
        "Missions",
        "Professional Exchange",
        "Program ",
        "Program Excursion",
        "Retreat",
        "Seminar",
        "Service or Service-Learning",
        "Sport Competition or Event",
        "Student Teaching",
        "Teaching English",
        "Volunteer",
        "Workshop",
        "Other"
      ]
    end

    def travel_plan_params
      params.require(:travel_plan).permit(:name, :start_date, :end_date, :cost, :deadline, :cost, :description, :plan_type, :lat, :long, :address,
        :emergency_contacts_attributes => [:first_name, :last_name, :email, :country_code, :phone_number, :_destroy, :id])
    end
  end
end
