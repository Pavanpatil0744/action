# module Admin
#   class SessionsController < ActiveAdmin::Devise::SessionsController
#     def create
#       super

#       create_sign_in_log(current_admin_user)
#     end

#     private

#     def create_sign_in_log(user)
#       SignInLog.create(
#         sign_in_type: 'active_admin',
#         user_id: user.id,
#         client_account_id: nil
#       )
#     end
#   end
# end
