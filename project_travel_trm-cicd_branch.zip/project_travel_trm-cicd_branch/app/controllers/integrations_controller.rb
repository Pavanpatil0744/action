# frozen_string_literal: true

class IntegrationsController < ApplicationController
  def sync_user
    user = User.find(params[:id])
    sso_authentication = user.sso_authentications.first
    integration_type = user.integration_config.integration_type

    IntegrationAtLoginWorker.perform_async(sso_authentication.id)

    redirect_to(admin_user_path(user), notice: "#{integration_type} syncing requested.")
  end

  def show_raw_data
    user = User.find(params[:id])
    client_account = user.client
    integration_config = client_account.integration_config
    identifier = user.sso_authentications.first.identifier

    http_client = if client_account.http_v2?
                    Integrations::HttpClientV2.new(client_account, integration_config)
                  else
                    Integrations::HttpClient.new(client_account, integration_config)
                  end

    response = http_client.get_user_data(identifier)

    redirect_to(admin_user_path(user), notice: response)
  end
end
