class DownloadController < ApplicationController
  class DownloadError < StandardError; end

  rescue_from DownloadError, with: :download_error

  def show
    can_download? # Throws exception if not allowed to download, caught with rescue_from
    data = open(attachment.url)
    send_data data.read, filename: attachment.file.filename
  end

  private

  def download
    @download ||= (
      crypt = ActiveSupport::MessageEncryptor.new(Rails.application.secrets.secret_key_base)
      crypt.decrypt_and_verify(Base64.decode64(params[:id]))
    )
  end

  def conversation_id
    message.conversation_id
  end

  def message_id
    download.split("|", 2).first.to_i
  end

  def message
    @message ||= Mailboxer::Message.find(message_id)
  end

  def attachment_index
    download.split("|", 2).last.to_i
  end

  def attachment
    message.attachments[attachment_index]
  end

  def can_download?
    unless user_authorized?
      raise DownloadError.new(__("You are not permitted to view this download.")) unless conversations.include?(conversation_id)
    end
    raise DownloadError.new(__("Sorry, file not found.")) if attachment.blank?
  end

  def user_authorized?
    Client::Downloads::AdminAuthorization.new(@user, message.conversation).execute
  end

  def conversations
    @user.mailbox.inbox.map(&:id)
  end

  def download_error(error)
    flash[:alert] = error.message
    redirect_to :back
  end
end
