# frozen_string_literal: true

class HomeController < ApplicationController
  def index
    render(status: :no_content)
  end
end
