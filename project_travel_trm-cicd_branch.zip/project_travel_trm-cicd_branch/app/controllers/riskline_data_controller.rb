# frozen_string_literal: true

# Note: This will be ran on servers only once
# Created this for dumping data to database tables from riskline platform
class RisklineDataController < ActionController::Base
  def add_risk_levels
    RisklineDataDump::RiskLevelDump.new.call

    render json: { message: "Risk levels Dumped" }, status: 201
  end

  def add_risk_categories
    RisklineDataDump::RiskCategoryDump.new.call

    render json: { message: "Risk Categories Dumped" }, status: 201
  end

  def add_risk_countries
    RisklineDataDump::RiskCountryDump.new.call

    render json: { message: "Risk Countries Dumped" }, status: 201
  end
end
