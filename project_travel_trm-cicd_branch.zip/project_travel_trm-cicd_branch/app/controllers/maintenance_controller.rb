class MaintenanceController < ActionController::Base
  layout "application"

  def index
  end
end
