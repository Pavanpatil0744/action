module Traveler
  class RegistrationsController < Devise::RegistrationsController
    DEFAULT_SIGNUP_SOURCE_DATA = {signup_source: "Self Registration"}

    def new
      super do
        @current_url = current_url
        @source = source
        @presenter = session_presenter
      end
    end

    def create
      @presenter = session_presenter
      super do
        resource.clients << [client_account]
        resource.add_role(:traveler)
        resource.save
        unless resource.errors.present?
          update_tracking(client_account, resource)
          complete_invitation_for(resource)
        end
        resource.errors.delete(:clients)
        Traveler::Builder.new(resource, signup_source_data).execute
        complete_invitation_for(resource)
      end
    end

    private

    def update_tracking(client_account, traveler)
      Traveler::UpdateTracking.new(
        client_account_id: client_account.id,
        event: :register_traveler,
        traveler_id: traveler.id
      ).execute
    end

    def complete_invitation_for(traveler)
      Traveler::CompleteInvitation.new(traveler, client_account.id, signup_source_data).execute
    end

    def session_presenter
      SessionPresenter.new(request.subdomains.last)
    end

    def signup_source_data
      @signup_source_data ||= (
        begin
          Crypto::Secrets.new(Rails.application.secrets.secret_key_base).decrypt(source)
        rescue Crypto::InvalidPayload
          DEFAULT_SIGNUP_SOURCE_DATA
        end
      )
    end

    def source
      params[:source]
    end

    def client_account
      ClientAccountInfo.find_by_subdomain(request.subdomains.last).client_account
    end

    def current_url
      request.base_url + request.path
    end
  end
end
