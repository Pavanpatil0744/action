module Traveler
  class BaseController < ApplicationController
    before_action :authenticate_user!
    before_action :authorize_traveler
    before_action :assign_authenticated_client_account
    before_action :set_traveler
    helper_method :traveler
    helper_method :authenticated_client_account

    def authorize_traveler
      unless user_signed_in? && current_user.is_traveler?
        redirect_to root_path, alert: "#{ (t :traveler).capitalize } access denied."
      end
    end

    def assign_authenticated_client_account
      if session[:authenticated_client_account].blank?
        session[:authenticated_client_account] = current_user.clients
          .select(:id, :org_name)
          .joins(:client_account_info)
          .where("client_account_infos.subdomain = ?", subdomain)
          .first!
      end
    rescue ActiveRecord::RecordNotFound => e
      logger.info "#{current_user.email} was unable to authenticate to requested client account subdomain: #{subdomain}."
      sign_out :user
      redirect_to traveler_new_user_session_path, alert: "#{ (t :traveler).capitalize } access to requested organization denied." and return
    end

    def prevent_free_accounts
      client = authenticated_client_account
      if client.free?
        redirect_to traveler_root_path, alert: "The requested feature is only available for paid accounts." and return
      end
    end

    def set_traveler
      @traveler ||= current_user
    end

    private

    def traveler
      @traveler ||= current_user
    end

    def authenticated_client_account
      current_user.clients.find(session[:authenticated_client_account]["id"])
    end

    def subdomain
      request.subdomains.last
    end
  end
end
