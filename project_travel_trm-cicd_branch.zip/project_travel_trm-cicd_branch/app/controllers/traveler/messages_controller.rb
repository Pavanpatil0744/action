# frozen_string_literal: true

module Traveler
  class MessagesController < BaseController
    def contact_advisor
      admins_to_notify.each do |admin|
        ::Mailers::Admin::ConnectWithAdvisor.email(
          send_to: admin,
          subdomain: subdomain,
          traveler: current_user
        ).deliver_later
      end
      redirect_to traveler_root_path, notice: __("Advisor successfully notified.")
    end

    private

    def admins_to_notify
      scoped_assigned_admins.present? ? scoped_assigned_admins : super_admins
    end

    def scoped_assigned_admins
      @scoped_assigned_admins ||= (
          authenticated_client_account.assigned_admins.where(traveler_id: current_user.id).map do |assigned_admin|
          User.find(assigned_admin.client_user_id)
        end
      )
    end

    def super_admins
      authenticated_client_account.users.with_role(:super_user)
    end
  end
end
