module Traveler
  class DashboardController < BaseController

    def index
      @conversations = current_user.mailbox.inbox.includes(messages: :sender).reverse
      @traveler = current_user
      @dashboard = TravelerDashboardPresenter.new(@traveler, authenticated_client_account, view_context)
      @current_tracking_step = tracking.current_step
    end

    private

    def tracking
      @tracking ||= Traveler::Tracking.new(@traveler, authenticated_client_account.id)
    end
  end
end
