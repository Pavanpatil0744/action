module Traveler
  class ConversationsController < BaseController

    before_action :set_objects, except: [:index, :upload]

    def index
      conversation = current_user.mailbox.inbox.includes(messages: :sender).first
      if conversation
        redirect_to traveler_conversation_path(conversation)
      else
        redirect_to traveler_root_path
      end
    end

    def new
    end

    def show
      @conversation.mark_as_read(current_user)
      @current_tracking_step = tracking.current_step
    end

    def add_message
      @user.update(attachment_params) if params[:user]
      @message = Message.new(message_params)
      @message.attachments = @user.uploads.where(id: params[:uploads]).map { |attachment| File.open(attachment.file.path) }
      if @message.save
        Conversation.traveler_reply(@conversation, current_user, @message)
        redirect_to traveler_conversation_path(@conversation), notice: __("Your message was successfully sent.")
      else
        flash.now[:alert] = @message.errors.full_messages.join(', ')
        render :show
      end
    end

    def upload
      respond_to do |format|
        @user.update(attachment_params)
        data = attachment_params.to_h
        if @user.errors.size > 0
          @upload = Upload.new(upload_type: :message_attachment, file: data["uploads_attributes"]["0"]["file"])
        else
          @upload = @user.uploads.messages.last
        end
        @errors = @user.errors.to_flash
        flash.clear
        format.json { render json: { upload: @upload.id, block: render_to_string(partial: "upload/message", layout: false, formats: [:html], locals: { upload: @upload, errors: @errors }) } }
      end
    end

    private

    def set_objects
      @traveler = current_user
      @dashboard = TravelerDashboardPresenter.new(@traveler, authenticated_client_account, view_context)
      @message = Message.new
      @conversation = current_user.mailbox.conversations.find(params[:id])
      @receipts = @conversation.receipts_for(current_user).order(:created_at)

      @participants = @conversation.messages.order("created_at").last.recipients
      @program_contacts = AssignedAdmin.includes(:client_user)
        .where(client_account: authenticated_client_account, traveler: current_user)
        .map(&:client_user)

      @back = sanitized_referrer || traveler_root_path
    rescue ActiveRecord::RecordNotFound
      redirect_to traveler_root_path, alert: __("Invalid conversation")
    end

    def message_params
      params.require(:message).permit(:subject, :body, :attachment)
    end

    def attachment_params
      params.require(:user).permit(:uploads_attributes => [:file, :id, :_destroy]).deep_merge(uploads_attributes: { "0" => { upload_type: :message_attachment } })
    end

    def tracking
      @tracking ||= Traveler::TrackingStep.new(@traveler, authenticated_client_account.id)
    end
  end
end
