# frozen_string_literal: true

class SubmissionAbility
  include CanCan::Ability

  def initialize(current_user)
    return unless current_user.present?

    can(:create, Submission) do |submission|
      authorize!(:show, submission)

      case submission.type
      when "application"
        check_setting(current_user, :traveler_applications_and_forms_settings, :edit_traveler_applications)
      when "form"
        check_setting(current_user, :traveler_applications_and_forms_settings, :edit_traveler_forms)
      end
    end

    can(:destroy, Submission) do |submission|
      authorize!(:show, submission)

      case submission.type
      when "application"
        check_setting(current_user, :traveler_applications_and_forms_settings, :destroy_traveler_applications)
      when "form"
        check_setting(current_user, :traveler_applications_and_forms_settings, :destroy_traveler_forms)
      end
    end

    can(:index, Array) do |submissions|
      submissions.all? { |submission| can?(:show, submission) }
    end

    can(:show, Submission) do |submission|
      case submission.type
      when "application"
        check_setting(current_user, :traveler_applications_and_forms_settings, :view_traveler_applications)
      when "form"
        check_setting(current_user, :traveler_applications_and_forms_settings, :view_traveler_forms)
      end
    end

    can(:transfer, Submission) do |submission|
      authorize!(:show, submission)

      check_setting(current_user, :traveler_applications_and_forms_settings, :transfer_application)
    end

    can(:update, Submission) do |submission|
      authorize!(:show, submission)

      case submission.type
      when "application"
        check_setting(current_user, :traveler_applications_and_forms_settings, :edit_traveler_applications)
      when "form"
        check_setting(current_user, :traveler_applications_and_forms_settings, :edit_traveler_forms)
      end
    end

    can(:update_tags_notes, Submission) do |submission|
      authorize!(:show, submission)

      case submission.type
      when "application"
        check_setting(current_user, :traveler_applications_and_forms_settings, :add_edit_application_note_review_tag)
      when "form"
        check_setting(current_user, :traveler_applications_and_forms_settings, :add_edit_general_form_note_review_tag)
      end
    end
  end

  def check_setting(user, setting, action)
    admin_role = user.admin_role.name.to_sym
    client_account = user.client_account

    ClientAccountRoleSettings.settings(client_account)[setting][action][admin_role]
  end
end
