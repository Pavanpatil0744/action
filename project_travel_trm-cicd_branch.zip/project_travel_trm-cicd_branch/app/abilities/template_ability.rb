# frozen_string_literal: true

class TemplateAbility
  include CanCan::Ability

  def initialize(current_user, params)
    return unless current_user.present?

    can(:create, Template) do |template|
      case template.template_type_name
      when "Application"
        check_setting(current_user, :application_templates_settings, :create_slash_edit_slash_duplicate)
      when "General Form"
        check_setting(current_user, :form_template_settings, :create_or_duplicate)
      when "Recommendation"
        check_setting(current_user, :recommendation_template_settings, :create_duplicate)
      end
    end

    can(:destroy, Template) do |template|
      case template.template_type_name
      when "Application"
        check_setting(current_user, :application_templates_settings, :delete)
      when "General Form"
        check_setting(current_user, :form_template_settings, :edit_or_delete_draft)
      when "Recommendation"
        check_setting(current_user, :recommendation_template_settings, :edit_delete_draft)
      end
    end

    can(:show, Template) do |template|
      case template.template_type_name
      when "Application"
        check_setting(current_user, :application_templates_settings, :view)
      when "General Form"
        check_setting(current_user, :form_template_settings, :view)
      when "Recommendation"
        check_setting(current_user, :recommendation_template_settings, :view)
      end
    end

    can(:update, Template) do |template|
      if params[:status]
        case template.status
        when "published"
          update_published(template, current_user)
        when "draft", "unpublished"
          case params[:status]
          when 1
            case template.template_type_name
            when "Application"
              check_setting(current_user, :application_templates_settings, :publish)
            when "General Form"
              check_setting(current_user, :form_template_settings, :publish)
            when "Recommendation"
              check_setting(current_user, :recommendation_template_settings, :publish)
            end
          when 0, 2
            update_nonpublished(template, current_user)
          when 3
            case template.template_type_name
            when "Application"
              check_setting(current_user, :application_templates_settings, :inactivate)
            when "General Form"
              check_setting(current_user, :form_template_settings, :inactivate)
            when "Recommendation"
              check_setting(current_user, :recommendation_template_settings, :archive)
            end
          end
        end
      else
        case template.status
        when "published"
          update_published(template, current_user)
        when "draft", "unpublished"
          update_nonpublished(template, current_user)
        end
      end
    end
  end

  def check_setting(user, setting, action)
    admin_role = user.admin_role.name.to_sym
    client_account = user.client_account

    ClientAccountRoleSettings.settings(client_account)[setting][action][admin_role]
  end

  def update_nonpublished(template, user)
    case template.template_type_name
    when "Application"
      check_setting(user, :application_templates_settings, :create_slash_edit_slash_duplicate)
    when "General Form"
      check_setting(user, :form_template_settings, :edit_or_delete_draft)
    when "Recommendation"
      check_setting(user, :recommendation_template_settings, :edit_delete_draft)
    end
  end

  def update_published(template, user)
    case template.template_type_name
    when "Application"
      check_setting(user, :application_templates_settings, :edit_published)
    when "General Form"
      check_setting(user, :form_template_settings, :edit_published)
    when "Recommendation"
      check_setting(user, :recommendation_template_settings, :edit_published_unpublished)
    end
  end
end
