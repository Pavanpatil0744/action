# frozen_string_literal: true

class AutomationAbility
  include CanCan::Ability

  def initialize(current_user)
    return unless current_user.present?

    can(:create, Automation) do |_automation|
      check_setting(current_user, :automation_settings, :create_or_edit)
    end

    can(:index, ActiveRecord::Relation) do |automations|
      automations.all? { |automation| can?(:show, automation) }
    end

    can(:show, Automation) do |_automation|
      check_setting(current_user, :automation_settings, :view)
    end

    can(:update, Automation) do |_automation|
      check_setting(current_user, :automation_settings, :create_or_edit)
    end
  end

  def check_setting(user, setting, action)
    admin_role = user.admin_role.name.to_sym
    client_account = user.client_account

    ClientAccountRoleSettings.settings(client_account)[setting][action][admin_role]
  end
end
