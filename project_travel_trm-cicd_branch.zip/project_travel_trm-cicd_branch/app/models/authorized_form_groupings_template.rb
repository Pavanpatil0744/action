# frozen_string_literal: true

class AuthorizedFormGroupingsTemplate < ActiveRecord::Base
  belongs_to :authorized_form_grouping
  belongs_to :trm_form_template

  delegate :title, to: :trm_form_template, prefix: :trm_form_template, allow_nil: true
end
