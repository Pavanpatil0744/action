# frozen_string_literal: true

class AuthorizedProgramRange < ActiveRecord::Base
  acts_as_paranoid

  belongs_to :client_account
  belongs_to :term_name
  belongs_to :trm_application_template

  has_many :authorized_form_groupings, dependent: :destroy
  has_many :authorized_form_groupings_templates, through: :authorized_form_groupings
  has_many :corresponding_program_ranges, dependent: :destroy
  has_many :program_ranges, through: :corresponding_program_ranges
  has_many :programs, -> { distinct }, through: :program_ranges
  has_many :trm_form_templates, through: :authorized_form_groupings_templates

  accepts_nested_attributes_for :authorized_form_groupings,
                                reject_if: :all_blank,
                                allow_destroy: true

  delegate :name, to: :term_name, allow_nil: true
  delegate :title, to: :trm_application_template, prefix: :trm_application_template, allow_nil: true

  scope :in_order, -> { joins(:term_name).order("term_names.name") }
end
