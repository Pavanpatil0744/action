# frozen_string_literal: true

class AutomationForm < ActiveRecord::Base
  acts_as_paranoid

  belongs_to :automation

  validates :deadline_type, inclusion: { in: %w[by_program_term_date by_month_and_day] }, allow_blank: true
  validates :conjuction, inclusion: { in: %w[before after] }, allow_blank: true
  validates :time, inclusion: { in: %w[start_date end_date] }, allow_blank: true
  validates_presence_of :template_ids
end