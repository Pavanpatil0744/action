# == Schema Information
#
# Table name: caa_essays
#
#  id                            :integer          not null, primary key
#  client_account_application_id :integer
#  title                         :string
#  prompt                        :text
#  created_at                    :datetime         not null
#  updated_at                    :datetime         not null
#

class CaaEssay < ActiveRecord::Base
  has_paper_trail
  validates :client_account_application, presence: true
  belongs_to :client_account_application, touch: true
end
