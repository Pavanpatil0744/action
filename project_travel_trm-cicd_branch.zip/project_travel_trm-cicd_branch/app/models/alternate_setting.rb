class AlternateSetting < ActiveRecord::Base
  has_paper_trail
  belongs_to :client_account
  after_create :set_default_instructions
  BROCHURE_INSTRUCTIONS = "This program is competitive with limited capacity. When you apply, you will be asked to select alternates to serve as backups in case the program fills up."
  RANKING_INSTRUCTIONS = "This program is competitive with limited capacity. Please choose alternate programs in order of preference."
  def set_default_instructions
    self.update(brochure_instruction: BROCHURE_INSTRUCTIONS) if self.brochure_instruction.blank?
    self.update(ranking_instruction: RANKING_INSTRUCTIONS) if self.ranking_instruction.blank?
  end

end
