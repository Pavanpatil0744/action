# frozen_string_literal: true

class AlertNote < ApplicationRecord
  belongs_to :trm_risk_alert
  belongs_to :client_account
  belongs_to :user
end
