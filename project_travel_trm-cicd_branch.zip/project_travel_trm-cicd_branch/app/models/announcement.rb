class Announcement < ActiveRecord::Base
end
