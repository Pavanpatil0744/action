# == Schema Information
#
# Table name: caa_acknowledgements
#
#  id                            :integer          not null, primary key
#  client_account_application_id :integer
#  title                         :string
#  acknowledgement_text          :text
#  created_at                    :datetime         not null
#  updated_at                    :datetime         not null
#

class CaaAcknowledgement < ActiveRecord::Base
  has_paper_trail
  validates :client_account_application, presence: true
  belongs_to :client_account_application, touch: true
end
