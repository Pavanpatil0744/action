class CaaMultipleChoice < ActiveRecord::Base
  has_paper_trail
  validates :client_account_application, presence: true
  belongs_to :client_account_application, touch: true
end
