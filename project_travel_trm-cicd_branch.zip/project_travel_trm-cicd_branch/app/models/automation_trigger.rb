# frozen_string_literal: true

class AutomationTrigger < ActiveRecord::Base
  acts_as_paranoid

  belongs_to :automation
  belongs_to :automation_precondition
  belongs_to :automation_qualifier

  has_many :automation_trigger_conditions, dependent: :destroy
  has_many :automation_conditions, through: :automation_trigger_conditions

  accepts_nested_attributes_for :automation_trigger_conditions,
                                reject_if: :all_blank,
                                allow_destroy: true

  validates_presence_of :automation_precondition_id, :automation_qualifier_id

  def actionable?
    automation_conditions.any?(&:actionable?)
  end
end
