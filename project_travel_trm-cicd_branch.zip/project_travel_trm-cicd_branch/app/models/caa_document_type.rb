# == Schema Information
#
# Table name: caa_document_types
#
#  id            :integer          not null, primary key
#  document_type :string
#  created_at    :datetime         not null
#  updated_at    :datetime         not null
#

class CaaDocumentType < ActiveRecord::Base
  has_paper_trail
end
