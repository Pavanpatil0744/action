# frozen_string_literal: true

# Can be removed once tokens are tested
class AutomationToken < ActiveRecord::Base
  has_many :automation_type_tokens
  has_many :automation_types, through: :automation_type_tokens

  def self.by_automation_type(type)
    joins(:automation_type_tokens)
      .joins("JOIN automation_types on automation_types.id = automation_type_tokens.automation_type_id AND automation_types.
      identifier = '#{type}'")
      .order('automation_type_tokens.order')
  end
end
