# frozen_string_literal: true

class AutomationCondition < ActiveRecord::Base
  include Orderable

  belongs_to :automation_precondition
  belongs_to :program, class_name: Program, foreign_key: :display_name

  has_many :automation_trigger_conditions, dependent: :destroy
  has_many :automation_triggers, through: :automation_trigger_conditions

  validates_presence_of :automation_precondition_id

  delegate :title, to: :program, prefix: :program, allow_nil: true

  alias program_name program_title
end
