class AutomationFormActionHistory < ApplicationRecord
end
