class BackgroundJobInfo < ActiveRecord::Base; end
