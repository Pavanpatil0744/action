# frozen_string_literal: true

class AmenityCategory < ActiveRecord::Base
  include Orderable

  has_many :amenities
end
