# frozen_string_literal: true

class Answer < ActiveRecord::Base
  acts_as_paranoid
  has_paper_trail

  belongs_to :trm_submission
  belongs_to :element

  has_many :payment_logs
  has_many :tapp_recommendations, dependent: :destroy

  delegate :user, to: :trm_submission
  delegate :type, to: :element, prefix: :element, allow_nil: true

  mount_base64_uploader :file, AttachmentUploader

  def self.value_by_field(field)
    joins(:element).find_by("elements.details ->> 'field' = ?", field)&.value&.fetch("value")
  end

  def formatted_value
    hash_value = value.instance_of?(Hash)

    case element_type
    when "ElementCashNet",
         "ElementCashNetWithCode",
         "ElementFee",
         "ElementFlywire",
         "ElementPayflowPro",
         "ElementTouchNet"
      if hash_value && value["value"].instance_of?(Hash)
        value.dig("value", "status")
      elsif hash_value
        value["value"]
      else
        value
      end || ""
    when "ElementDropdownList", "ElementLongAnswer", "ElementMultiChoice", "ElementShortAnswer"
      if hash_value && value["value"].instance_of?(Array)
        value["value"].join("; ")
      elsif hash_value
        value["value"]
      else
        value
      end || ""
    when "ElementFileUpload"
      file.url || ""
    when "ElementRecommendation"
      recommendation_value = value["value"] if hash_value
      recommendation_content = ""
      recommendation_dates = ""
      recommender = ""

      recommendation = if recommendation_value.instance_of?(Array)
                         recommendation_value&.find_all { |rec| rec["submitted"] }
                                             &.sort_by { |rec| rec["submitted_at"] }&.last
                       end

      if recommendation && recommendation["file"].instance_of?(Hash)
        file = recommendation.dig("file", "url")
        sent_at = recommendation["sent_at"]&.to_date&.strftime("%b %d, %Y")
        received_at = recommendation["submitted_at"]&.to_date&.strftime("%b %d, %Y")
        recommendation_content = file || recommendation["recommender_details"]
        recommendation_dates = "Sent: #{sent_at}; Received: #{received_at}"
        recommender = "#{recommendation['recommender_name']}; #{recommendation['recommender_title']}; #{recommendation['recommender_email']}"
      end

      {
        recommender: recommender,
        recommendation_content: recommendation_content,
        recommendation_dates: recommendation_dates
      }
    when "ElementSingleChoice"
      value&.fetch("value")&.titleize || ""
    else
      value&.fetch("value") || ""
    end
  end

  def remove_file_from_s3!
    self.remove_file = true

    save!
  end

  def report_value
    value = element.trm_type.constantize.parse_answer_value(self)

    value.respond_to?(:join) ? value.join(", ") : value
  rescue => e
    "#{element.trm_type}: #{e} -- #{value.is_a?(Hash) ? value['value'] : value.to_s}"
  end
end
