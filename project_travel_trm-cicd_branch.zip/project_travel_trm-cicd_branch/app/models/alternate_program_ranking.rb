# frozen_string_literal: true

class AlternateProgramRanking < ActiveRecord::Base
  has_paper_trail

  belongs_to :program
  belongs_to :program_range
  belongs_to :trm_submission_application
end
