# frozen_string_literal: true

class AdvocateResponseLog < ActiveRecord::Base
  acts_as_paranoid
  has_paper_trail on: :destroy

  belongs_to :submission
end
