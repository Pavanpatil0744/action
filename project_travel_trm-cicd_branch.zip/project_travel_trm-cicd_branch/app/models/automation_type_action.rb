# frozen_string_literal: true

class AutomationTypeAction < ActiveRecord::Base
  belongs_to :automation_action
  belongs_to :automation_type

  validates_presence_of :automation_action_id, :automation_type_id
end
