class AlguruPercentageMatch < ActiveRecord::Base
  has_paper_trail
  belongs_to :traveler_info
  belongs_to :client_account
end
