# frozen_string_literal: true

class ApplicationStatusChangeHistory < ActiveRecord::Base
  belongs_to :trm_submission_application
end
