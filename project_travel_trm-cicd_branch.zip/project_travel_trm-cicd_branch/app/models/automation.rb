# frozen_string_literal: true

class Automation < ActiveRecord::Base
  acts_as_paranoid

  belongs_to :automation_action
  belongs_to :automation_type
  belongs_to :client_account

  has_many :automation_change_logs, dependent: :destroy
  has_many :automation_mailers, dependent: :destroy
  has_many :automation_forms, dependent: :destroy
  has_many :automation_tags, dependent: :destroy
  has_many :automation_triggers, dependent: :destroy
  has_many :send_grid_mailer_histories, dependent: :destroy
  has_many :automation_change_statuses, dependent: :destroy

  accepts_nested_attributes_for :automation_mailers, reject_if: :all_blank, allow_destroy: true
  accepts_nested_attributes_for :automation_triggers, reject_if: :all_blank, allow_destroy: true
  accepts_nested_attributes_for :automation_forms, reject_if: :all_blank, allow_destroy: true
  accepts_nested_attributes_for :automation_change_statuses, reject_if: :all_blank, allow_destroy: true
  accepts_nested_attributes_for :automation_tags, reject_if: :all_blank, allow_destroy: true

  before_save :log_automation_change, on: %i[create update]
  after_commit :update_trigger_display_text, on: %i[create update]

  delegate :display_name, to: :automation_type, prefix: :automation_type

  scope :active, -> { where(active: true) }

  scope :application, (
    lambda do
      joins(:automation_type).where(automation_types: { identifier: "applications" })
    end
  )

  scope :form, (
    lambda do
      joins(:automation_type).where(automation_types: { identifier: "forms" })
    end
  )

  scope :by_precondition, (
    lambda do |precondition|
      joins(automation_triggers: :automation_precondition).where(
        automation_preconditions: { identifier: precondition }
      )
    end
  )

  validates_presence_of :automation_action_id, :automation_type_id, :client_account_id, :name

  def actionable?
    automation_triggers.any?(&:actionable?)
  end

  def update_trigger_display_text
    updated_trigger_display_text = ""

    automation_triggers.order(:created_at).each.with_index(1) do |at, index|
      qualifier = at.automation_qualifier.display_name.downcase
      precondition = at.automation_precondition.display_name.downcase

      conditions = at.automation_conditions.map do |automation_condition|
        display_name = automation_condition.display_name

        qualifier == "program country" ? display_name : display_name.downcase
      end.join(", ")

      prefix = index == 1 ? "When the" : " AND when the"
      suffix = "#{qualifier} #{precondition} #{conditions}"

      updated_trigger_display_text += "#{prefix} #{suffix}"
    end

    update_column("trigger_display_text", updated_trigger_display_text)
  end

  def formatted_trigger_display_text
    text = trigger_display_text

    if text.include?("program is")
      program_ids = get_integers_between_substrings(text, 'program is', 'AND')

      programs = Program.where(id: program_ids)

      programs.each do |program|
        text.gsub!(program.id.to_s, program.title)
      end
    end

    if text.include?('template is')
      template_ids = get_integers_between_substrings(text, 'template is', 'AND')

      templates = Template.where(id: template_ids)

      templates.each do |template|
        text.gsub!(template.id.to_s, template.name)
      end
    end

    if text.include?("term tag is")
      tag_ids = get_integers_between_substrings(text, 'term tag is', 'AND')

      tags = Tag.where(id: tag_ids)

      tags.each do |tag|
        text.gsub!(tag.id.to_s, tag.name)
      end
    end

    text
  end

  private

  def get_integers_between_substrings(string, substring1, substring2)
    regex = /#{substring1}(.*?)(?:#{substring2}|$)/
    matches = string.scan(regex).map do |match|
      match[0].scan(/\b(\d+)\b/).flatten.map(&:to_i)
    end
    matches.flatten
  end

  def log_automation_change
    user = User.current || User.find_by_email("admin@via-trm.com")

    automation_change_logs.build(
      action: new_record? ? "create" : "update",
      active: active,
      name: name,
      trigger_display_text: trigger_display_text,
      updated: new_record? ? [] : changed,
      user_id: user.id,
      user_email: user.email,
      user_first_name: user.first_name || "",
      user_last_name: user.last_name || ""
    )
  end
end
