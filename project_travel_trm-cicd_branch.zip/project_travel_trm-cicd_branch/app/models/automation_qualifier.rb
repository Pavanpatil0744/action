# frozen_string_literal: true

class AutomationQualifier < ActiveRecord::Base
  has_many :automation_preconditions
  has_many :automation_triggers
  has_many :automation_type_qualifiers
  has_many :automation_types, through: :automation_type_qualifiers

  scope :in_order, (
    lambda do
      joins(:automation_type_qualifiers).order("automation_type_qualifiers.order")
    end
  )
end
