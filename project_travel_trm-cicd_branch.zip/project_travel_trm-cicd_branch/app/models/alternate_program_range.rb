# frozen_string_literal: true

class AlternateProgramRange < ActiveRecord::Base
  acts_as_paranoid
  has_paper_trail on: :destroy

  belongs_to :program_range
  belongs_to :submission

  delegate :program_title, to: :program_range
end
