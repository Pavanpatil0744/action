# frozen_string_literal: true

class AuthorizedFormGrouping < ActiveRecord::Base
  acts_as_paranoid

  belongs_to :authorized_program_range

  has_many :authorized_form_groupings_templates, dependent: :destroy
  has_many :trm_form_templates, through: :authorized_form_groupings_templates

  accepts_nested_attributes_for :authorized_form_groupings_templates,
                                reject_if: :all_blank,
                                allow_destroy: true
end
