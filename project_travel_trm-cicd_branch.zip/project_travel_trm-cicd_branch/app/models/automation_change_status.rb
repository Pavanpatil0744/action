class AutomationChangeStatus < ApplicationRecord
  belongs_to :automation
end
