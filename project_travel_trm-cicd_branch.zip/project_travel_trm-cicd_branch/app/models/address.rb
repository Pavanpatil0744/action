# == Schema Information
#
# Table name: addresses
#
#  id               :integer          not null, primary key
#  street           :string
#  secondary_street :string
#  city             :string
#  state            :string
#  country          :string
#  zip              :string
#  type             :string
#  addressable_id   :integer
#  addressable_type :string
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#

class Address < ActiveRecord::Base
  has_paper_trail
  belongs_to :addressable, polymorphic: true

  validates :street, presence: true
  validates :city, presence: true
  validates :state, presence: true
  validates :zip, presence: true

  def ===(other)
    return false if other.blank?
    street == other.street &&
    secondary_street == other.secondary_street &&
    city == other.city &&
    state == other.state &&
    country == other.country
  end

  def same_as(other)
    return false if other.blank?
    street == other.street &&
    secondary_street == other.secondary_street &&
    city == other.city &&
    state == other.state &&
    country == other.country
  end

  def to_html
    [street, secondary_street, "#{city}, #{state} #{zip}"].compact.map { |component| "<p>#{component}</p>" }.join.html_safe
  end
end
