# frozen_string_literal: true

class ApplicationTransferHistory < ActiveRecord::Base
  has_paper_trail

  belongs_to :new_trm_submission_application, class_name: TrmSubmissionApplication
  belongs_to :program_range
  belongs_to :trm_submission_application, class_name: TrmSubmissionApplication
end
