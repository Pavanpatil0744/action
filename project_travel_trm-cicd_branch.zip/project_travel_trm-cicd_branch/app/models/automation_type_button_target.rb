# frozen_string_literal: true

class AutomationTypeButtonTarget < ActiveRecord::Base
  belongs_to :automation_button_target
  belongs_to :automation_type

  validates_presence_of :automation_button_target_id, :automation_type_id
end
