# frozen_string_literal: true

class Advising < ActiveRecord::Base
  has_paper_trail

  belongs_to :traveler_info

  HAS_SPOKEN_TO_ADVISOR = { yes: 1, not_yet: 2 }.freeze

  enum has_spoken_to_advisor: HAS_SPOKEN_TO_ADVISOR

  PARTICIPATION_BARRIER_OPTIONS = [
    "How much time I have to apply and prepare",
    "Cost",
    "Academic credit",
    "Leaving my family or friends behind",
    "Missing out on something back home",
    "Picking the right choice",
    "Discrimination or identity concern",
    "Not knowing anyone",
    "Housing",
    "An unsupportive parent, teacher or mentor",
    "Food issue/dietary restrictions",
    "Getting accepted",
    "Health and/or safety issue",
    "No questions or concerns",
    "I'm not sure",
    "Other"
  ].freeze

  QUESTION_FIELDS = {
    planning_time: __("How much time I have to apply and to plan to go"),
    cost: __("Cost"),
    academic_credit: __("Academic credit"),
    people_left_behind: __("Leaving my friends or family behind"),
    missing_out_at_home: __("Missing out on something back home"),
    picking_a_program: "Picking the right #{t(:program)}",
    discrimination_identity_concern: __("Discrimination or Identity Concern"),
    not_knowing_anyone: __("That I won't know anyone on my #{ t :program }"),
    housing: __("Housing"),
    unsupportive_parent: __("An unsupportive parent, teacher or mentor"),
    dietary_issues: __("Food issue/Dietary restrictions"),
    program_acceptance: "Acceptance into my #{t(:program)}",
    health_safety_issue: __("Health and/or Safety Issue"),
    no_questions_concerns: __("No Questions or Concerns for now"),
    not_sure: __("Not Sure"),
    other: __("Other")
  }.freeze

  def questions_or_concerns
    {
      planning_time: planning_time,
      cost: cost,
      academic_credit: academic_credit,
      people_left_behind: people_left_behind,
      missing_out_at_home: missing_out_at_home,
      picking_a_program: picking_a_program,
      discrimination_identity_concern: discrimination_identity_concern,
      not_knowing_anyone: not_knowing_anyone,
      housing: housing,
      unsupportive_parent: unsupportive_parent,
      dietary_issues: dietary_issues,
      program_acceptance: program_acceptance,
      health_safety_issue: health_safety_issue,
      no_questions_concerns: no_questions_concerns,
      not_sure: not_sure,
      other: other
    }
  end

  def self.question_fields
    QUESTION_FIELDS
  end

  def list
    selected = questions_or_concerns.select { |k, v| k if v == true }

    selected.merge!(Advising.question_fields.select { |k| selected.keys.include? k })

    selected.map { |_k, v| v }
  end

  def comma_separated
    list.join(", ")
  end
end
