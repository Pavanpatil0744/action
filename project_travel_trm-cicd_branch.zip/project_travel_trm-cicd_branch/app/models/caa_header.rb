class CaaHeader < ActiveRecord::Base
  has_paper_trail
  belongs_to :client_account_application, touch: true
  validates :client_account_application, presence: true
end
