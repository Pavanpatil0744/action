# frozen_string_literal: true

class AdvocateStatusHistory < ActiveRecord::Base
  belongs_to :trm_submission
  belongs_to :user
end
