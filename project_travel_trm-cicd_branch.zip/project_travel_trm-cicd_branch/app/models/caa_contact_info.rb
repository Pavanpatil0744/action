class CaaContactInfo < ActiveRecord::Base
  has_paper_trail

  validates :client_account_application, presence: true
  validates :countries_of_citizenship,
            :current_address,
            :date_of_birth,
            :email,
            :emergency_contact,
            :ethnicity,
            :race,
            :gender,
            :grad_year,
            :home_institution,
            :how_did_you_hear,
            :permanent_address,
            :phone,
            :preferred_first_name,
            :preferred_last_name,
            :pronoun,
            :passport_number,
            :passport_expiration_date,
            :passport_issuing_agency,
            :place_of_birth,
            :student_id_number,
            :title, inclusion: { in: [true, false] }
  belongs_to :client_account_application, touch: true

  #TODO: DEN-703 adds many more attributes. incorporate them.
  
  PERSONAL_FORM_ATTRIBUTES = [:countries_of_citizenship, :date_of_birth, :disability,
    :email, :ethnicity, :race, :first_name, :gender, :last_name, :middle_name, :phone,
    :preferred_first_name, :preferred_last_name, :pronoun, :secondary_email, :title,
    :visa_description, :passport_number, :passport_expiration_date,
    :passport_issuing_agency, :place_of_birth]

# NOTE: DEN-701 new current and permanent address fields were added. Incorporate them.

  def self.attributes_for_select
    CaaContactInfo.new.attributes.delete_if{ |key, _value| ["id", "client_account_application_id", "created_at", "updated_at", "hispanic"].include?(key) }
                                 .keys
                                 .sort
  end

  def attributes_selected_for_traveler
    attributes.delete_if{ |key, _value| ["id", "client_account_application_id", "created_at", "updated_at"].include?(key) }
              .delete_if{ |_key, value| value == false }
              .keys
              .sort
  end

  def any_required_for_form?
    current_address || permanent_address || how_did_you_hear || hispanic
  end

  def is_personal_form_required?
    PERSONAL_FORM_ATTRIBUTES.any? {|attribute| send(attribute)}
  end
end
