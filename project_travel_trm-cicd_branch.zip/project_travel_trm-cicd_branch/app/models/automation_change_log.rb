# frozen_string_literal: true

class AutomationChangeLog < ActiveRecord::Base
  acts_as_paranoid

  belongs_to :automation

  scope :initial, -> { find_by_action("create") }
  scope :most_recent, -> { order(created_at: :desc).first }

  validates_presence_of :automation_id
end
