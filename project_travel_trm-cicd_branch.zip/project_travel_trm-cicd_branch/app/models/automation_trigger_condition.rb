# frozen_string_literal: true

class AutomationTriggerCondition < ActiveRecord::Base
  belongs_to :automation_condition
  belongs_to :automation_trigger
  attr_accessor :condition_text, :program_id, :template_id, :term_tag_id, :application_form_tag_id, :cumulative_gpa
end
