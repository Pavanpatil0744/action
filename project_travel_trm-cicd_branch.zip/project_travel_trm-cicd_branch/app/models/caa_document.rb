# == Schema Information
#
# Table name: caa_documents
#
#  id                            :integer          not null, primary key
#  client_account_application_id :integer
#  caa_document_type_id          :integer
#  other_type_text               :string
#  instructions                  :text
#  created_at                    :datetime         not null
#  updated_at                    :datetime         not null
#

class CaaDocument < ActiveRecord::Base
  has_paper_trail
  validates :client_account_application, presence: true
  validates :other_type_text, presence: true, if: :type_other?
  belongs_to :client_account_application, touch: true
  belongs_to :caa_document_type

  def type_other?
    caa_document_type.try(:document_type) == "other"
  end
end
