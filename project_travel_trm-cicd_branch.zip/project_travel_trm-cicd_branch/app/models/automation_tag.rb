# frozen_string_literal: true

class AutomationTag < ActiveRecord::Base
  acts_as_paranoid

  belongs_to :automation

  validates_presence_of :tag_ids
end