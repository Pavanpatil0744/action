# frozen_string_literal: true

class Amenity < ActiveRecord::Base
  has_paper_trail

  belongs_to :amenity_category

  has_many :program_amenities

  delegate :display_name, to: :amenity_category, prefix: :amenity_category
end
