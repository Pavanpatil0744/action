# frozen_string_literal: true

class AdminProgramAttachment < ActiveRecord::Base
  before_destroy :remove_file_from_s3!

  belongs_to :program

  scope :in_order, -> { order(:title) }

  mount_base64_uploader :file, AttachmentUploader

  def remove_file_from_s3!
    self.remove_file = true

    save!
  end
end
