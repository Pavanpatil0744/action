# frozen_string_literal: true

class AutomationAction < ActiveRecord::Base
  has_many :automation_type_actions
  has_many :automation_types, through: :automation_type_actions
  has_many :automations

  def self.by_automation_type(type)
    joins(:automation_type_actions)
      .joins("JOIN automation_types on automation_types.id = automation_type_actions.automation_type_id AND automation_types.
      identifier = '#{type}'")
      .order('automation_type_actions.order')
  end
end
