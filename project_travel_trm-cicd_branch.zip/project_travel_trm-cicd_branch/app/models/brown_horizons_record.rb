# frozen_string_literal: true

class BrownHorizonsRecord < ActiveRecord::Base; end
