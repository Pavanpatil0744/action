# == Schema Information
#
# Table name: caa_doc_attachments
#
#  id                            :integer          not null, primary key
#  client_account_application_id :integer
#  name                          :string
#  instructions                  :text
#  file                          :string
#  created_at                    :datetime         not null
#  updated_at                    :datetime         not null
#

class CaaDocAttachment < ActiveRecord::Base
  has_paper_trail
  validates :client_account_application, presence: true
  mount_uploader :file, CaaDocAttachmentUploader

  belongs_to :client_account_application, touch: true
end
