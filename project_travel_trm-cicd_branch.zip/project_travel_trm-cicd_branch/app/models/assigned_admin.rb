# frozen_string_literal: true

class AssignedAdmin < ActiveRecord::Base
  has_paper_trail

  belongs_to :client_account
  belongs_to :client_user, class_name: User
  belongs_to :traveler, class_name: User

  delegate :full_name_or_email, to: :client_user, prefix: :client_user, allow_nil: true

  scope :assignments_for, (
    lambda do |traveler|
      joins(:client_user).where(traveler_id: traveler.id, users: { archived: false })
    end
  )

  private

  def user
    traveler
  end
end
