# frozen_string_literal: true

class AutomationPrecondition < ActiveRecord::Base
  include Orderable

  belongs_to :automation_qualifier

  has_many :automation_conditions
  has_many :automation_triggers

  validates_presence_of :automation_qualifier_id
end
