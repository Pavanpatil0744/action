class ActivityLogistic < ActiveRecord::Base
  has_paper_trail
  belongs_to :travel_plan
  has_many :traveler_plan_housing_logistics
  has_and_belongs_to_many :traveler_plan_logistics

  validates :logistic_type, :activity_type, :name, :arrival_date, presence: true
  validate :departure_is_after_arrival
  validate :city_is_present

  def missing_location?
    errors.keys.include?(:base)
  end

  private

  def city_is_present
    errors.add(:base, "City can't be blank") if lat.blank? || long.blank?
  end

  def departure_is_after_arrival
    return if arrival_date.blank? || departure_date.blank?

    if arrival_date > departure_date
      errors.add(:departure, "cannot be before the arrival date") 
    elsif arrival_date == departure_date
      return if arrival_time.blank? || departure_time.blank?
      if arrival_time.to_time > departure_time.to_time
        errors.add(:departure, "cannot be before the arrival date") 
      end
    end
  end
end