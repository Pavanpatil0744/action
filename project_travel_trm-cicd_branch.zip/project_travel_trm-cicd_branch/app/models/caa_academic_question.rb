# == Schema Information
#
# Table name: caa_academic_questions
#
#  id                            :integer          not null, primary key
#  client_account_application_id :integer
#  question                      :text
#  instructions                  :text
#  created_at                    :datetime         not null
#  updated_at                    :datetime         not null
#

class CaaAcademicQuestion < ActiveRecord::Base
  has_paper_trail
  validates :client_account_application, presence: true
  belongs_to :client_account_application, touch: true
end
