require 'url_formatter'

# == Schema Information
#
# Table name: caa_payments
#
#  id                            :integer          not null, primary key
#  client_account_application_id :integer
#  title                         :string
#  description                   :string
#  amount                        :string
#  currency                      :string
#  url                           :string
#  created_at                    :datetime         not null
#  updated_at                    :datetime         not null
#

class CaaPayment < ActiveRecord::Base
  has_paper_trail
  before_save :format_url
  validates :client_account_application, presence: true
  belongs_to :client_account_application, touch: true

  private

  def format_url
    self.url = URLFormatter.format(self.url)
  end
end
