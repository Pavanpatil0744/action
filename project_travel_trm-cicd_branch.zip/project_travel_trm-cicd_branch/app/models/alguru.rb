class Alguru
  def initialize(user, client_account_id)
    @user = user
    @client_account_id = client_account_id
  end

  def run
    user_priorities = @user.priorities
    result_set = rank
    grid = active_records_to_array(result_set)
    weighted_priorities = weight_rankings(user_priorities)
    program_result_grid = calc_grid(weighted_priorities, grid)
    sorted_program_ids(program_result_grid)
  end

  def rank
    params = ProgramMatchingParameters.new(@user)
    query = query_template
    query = populate_query(query_template, params)
    Program.find_by_sql(query)
  end

  def active_records_to_array(grid)
    calc_grid = []
    grid.each do |result|
      calc_grid << [
        result.program_id, result.subject_area_match, result.housing_type_match, result.timing_match, result.location_match, result.program_language_match, result.program_type_match
      ]
    end
    calc_grid
  end

  # user_priorities:
  # [subject_area, housing, timing, location, language, program_type]
  def weight_rankings(user_priorities)
    ranked_values = user_priorities.map do |rank|
      case rank
      when 1 then 6
      when 2 then 5
      when 3 then 4
      when 4 then 3
      when 5 then 2
      when 6 then 1
      end
    end
    return ranked_values unless ranked_values.any?(nil)

    Array.new(6, 0)
  end

  # program_result_grid:
  # [[program_id, subject_area, housing, timing, location, language, program_type], [...]]
  def calc_grid(weighted_priorities, program_result_grid)
    program_result_grid.each do |row|
      total = 0
      row.each_with_index do |cell, index|
        next if index.zero? # Skip program_id

        if cell != 0 # Non-matches stay 0
          row[index] = cell + weighted_priorities[index - 1]
          total += row[index]
        end
      end
      row << total
    end
    program_result_grid
  end

  def sorted_program_ids(calculated_grid)
    calculated_grid.sort_by(&:last).reverse!.map { |g| { g.first => g.last } }
  end

  def query_template
    query = <<-SQL
      SELECT
        p.id AS program_id,
        CASE WHEN p.id in (
          SELECT p.id
          FROM programs p
          INNER JOIN program_subjects ps ON ps.program_id = p.id
          INNER JOIN subject_areas sa ON ps.subject_area_id = sa.id
          WHERE sa.name in (%%%subject_area_placeholder%%%)
        ) THEN 1 ELSE 0 END AS subject_area_match,
        CASE WHEN p.id in (
          SELECT p.id
          FROM programs p
          INNER JOIN program_housings ph ON ph.program_id = p.id
          INNER JOIN housing_types ht ON ht.id = ph.housing_type_id
          WHERE ph.included = true
          AND ht.name in (%%%housing_type_placeholder%%%)
        ) THEN 1 ELSE 0 END AS housing_type_match,
        CASE WHEN p.id in (
          SELECT p.id
          FROM programs p
          INNER JOIN program_ranges pr ON pr.program_id = p.id
          WHERE (pr.start_date > %%%timing_start_placeholder%%% AND pr.end_date < %%%timing_end_placeholder%%%)
          OR (pr.start_date is null AND pr.end_date is null)
        ) THEN 1 ELSE 0 END AS timing_match,
        CASE WHEN p.id in (
          SELECT p.id
          FROM programs p
          INNER JOIN program_locations pl ON pl.program_id = p.id
          WHERE pl.alpha2 in (%%%location_placeholder%%%)
        ) THEN 1 ELSE 0 END AS location_match,
        CASE WHEN p.id in (
          SELECT p.id
          FROM programs p
          INNER JOIN program_languages pl ON pl.program_id = p.id
          WHERE pl.iso_639_3 in (%%%program_language_placeholder%%%)
        ) THEN 1 ELSE 0 END AS program_language_match,
        CASE WHEN p.id in (
          SELECT p.id
          FROM programs p
          INNER JOIN program_type_connections ptc ON ptc.program_id = p.id
          INNER JOIN program_types pt ON ptc.program_type_id = pt.id
          WHERE ptc.included = true
          AND pt.name in (%%%program_type_placeholder%%%)
        ) THEN 1 ELSE 0 END AS program_type_match
      FROM programs p
      LEFT JOIN client_account_programs cap on p.id = cap.program_id
      WHERE p.status = %%%status_placeholder%%%
      AND ( p.primary_client_account_id = %%%primary_client_account_placeholder%%%
      OR cap.client_account_id = %%%primary_client_account_placeholder%%% );
    SQL
    query
  end

  def populate_query(query, params)
    query.gsub!("%%%subject_area_placeholder%%%", params.subject_areas)
    query.gsub!("%%%timing_start_placeholder%%%", params.timing.first)
    query.gsub!("%%%timing_end_placeholder%%%", params.timing.last)
    query.gsub!("%%%housing_type_placeholder%%%", params.housing_types)
    query.gsub!("%%%location_placeholder%%%", params.location)
    query.gsub!("%%%program_language_placeholder%%%", params.program_languages)
    query.gsub!("%%%program_type_placeholder%%%", params.program_types)
    query.gsub!("%%%status_placeholder%%%", Program.statuses[:published].to_s)
    query.gsub!("%%%primary_client_account_placeholder%%%", @client_account_id.to_s)
    query
  end
end
