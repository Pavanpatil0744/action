# frozen_string_literal: true

class AutomationType < ActiveRecord::Base
  include Orderable

  has_many :automations
  has_many :automation_type_actions
  has_many :automation_actions, through: :automation_type_actions
  has_many :automation_type_qualifiers
  has_many :automation_qualifiers, through: :automation_type_qualifiers
  has_many :automation_type_button_targets
  has_many :automation_button_targets, through: :automation_type_button_targets
  has_many :automation_type_tokens # Can be removed once tokens are tested
  has_many :automation_tokens, through: :automation_type_tokens # Can be removed once tokens are tested
  has_many :tokenables, as: :tokenable, dependent: :destroy
  has_many :tokens, through: :tokenables
end
