# == Schema Information
#
# Table name: caa_academic_infos
#
#  id                            :integer          not null, primary key
#  client_account_application_id :integer
#  year_in_school                :boolean
#  majors                        :boolean
#  minors                        :boolean
#  gpa                           :boolean
#  language_proficiency          :boolean
#  created_at                    :datetime         not null
#  updated_at                    :datetime         not null
#

class CaaAcademicInfo < ActiveRecord::Base
  has_paper_trail
  validates :client_account_application, presence: true
  belongs_to :client_account_application, touch: true

  def self.attributes_for_select
    CaaAcademicInfo.new.attributes.delete_if{ |key, _value| ["id", "client_account_application_id", "created_at", "updated_at"].include?(key) }
                                  .keys
                                  .sort
  end

  def attributes_selected_for_traveler
    attributes.delete_if{ |key, _value| ["id", "client_account_application_id", "created_at", "updated_at"].include?(key) }
              .delete_if{ |_key, value| value == false }
              .keys
              .sort
  end

  def any_required_for_form?
    year_in_school || primary_major || primary_minor || cumulative_gpa || language_proficiency || major_gpa || secondary_major || secondary_minor || third_minor || hours_earned || honors_status || places_of_study || judicial_status || traveler_type
  end
end
