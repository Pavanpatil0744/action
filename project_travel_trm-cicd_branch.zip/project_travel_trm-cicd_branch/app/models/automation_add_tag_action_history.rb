# frozen_string_literal: true

class AutomationAddTagActionHistory < ApplicationRecord
end
