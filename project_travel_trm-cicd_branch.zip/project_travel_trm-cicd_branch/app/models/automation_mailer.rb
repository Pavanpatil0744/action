# frozen_string_literal: true

class AutomationMailer < ActiveRecord::Base
  acts_as_paranoid

  belongs_to :automation
  belongs_to :automation_button_target

  validates_presence_of :body, :button_text, :subject

  delegate :button_target, to: :automation_button_target
end