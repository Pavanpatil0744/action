class AddCsvToInviteUpload < ActiveRecord::Base
end
