class AuthorizedProgramSettings < ActiveRecord::Base
  has_paper_trail
  DEFAULT_INSTRIUCTIONS_TEXT = "" +
    "You are about to leave this account to begin an application with an authorized external program provider." +
    "In addition to your external application, you also need to request approval from your home campus to go " +
    "on this authorized program. By confirming here, you are adding an approval request form to your dashboard " +
    "which you can complete at any time.\n\n" +
    "Confirm below to go to the authorized program provider's website to begin your application."

  belongs_to :client_account
end
