# frozen_string_literal: true

class SendSafeCheckMessageConfirmation
  include Interactor

  delegate :org_name, :safe_check_phone_number, to: :context

  def call
    twilio_service.send_message(message_body: message_body, phone_number: safe_check_phone_number)
  rescue Twilio::REST::RestError
    context.fail!
  end

  private

  def message_body
    if org_name
      "You're enrolled in SafeCheck with #{org_name}. Msg&data rates may apply. Text 'STOP' to opt out."
    else
      "You're enrolled in SafeCheck. Msg&data rates may apply. Text 'STOP' to opt out."
    end
  end

  def twilio_service
    @twilio_service ||= TwilioService.new(
      ENV["TWILIO_SAFE_CHECK_MESSAGING_SERVICE_SID"],
      ENV["TWILIO_SAFE_CHECK_STATUS_CALLBACK"]
    )
  end
end
