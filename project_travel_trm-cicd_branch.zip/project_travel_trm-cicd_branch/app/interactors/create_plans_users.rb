# frozen_string_literal: true

class CreatePlansUsers
  include Interactor

  delegate :plan, to: :context

  def call
    client_account = plan.client_account
    committed_status = SubmissionStatus.find_by_identifier("committed")
    committed_applications = client_account.application_submissions.where(
      program_range_id: plan.program_range_id,
      submission_status: committed_status
    )
    itinerary_details = plan.plan_activities.where(force_add: true)
    itinerary_details += plan.plan_housings.where(force_add: true)
    itinerary_details += plan.plan_transportations.where(force_add: true)

    committed_applications.each do |application|
      traveler = application.user
      plans_user = plan.plans_users.find_or_create_by(user_id: traveler.id)

      if plans_user.removed? && !plan.cancelled?
        plans_user.update(removed: false)
      elsif !plans_user.removed? && plan.cancelled?
        plans_user.update(removed: true)
      end

      itinerary_details.each do |detail|
        ForceAddPlanDetail.call(plan: plan, plan_detail: detail, plans_user: plans_user)
      end

      ReportPlanUser.find_by_plans_users_id(plans_user.id)&.update(sync_required: true)
      UpdateReportPlanUser.perform_in(10.seconds, plans_user.id)

      ReportPlan.find_by_plan_id(plan.id)&.update(sync_required: true)
      UpdateReportPlan.perform_in(10.seconds, plan.id)

      SendGrid::SendTravelerPlansUserCreationMailer.perform_async(
        client_account.logo.url,
        plan.id,
        plan.name,
        traveler.id
      )
    end
  end
end
