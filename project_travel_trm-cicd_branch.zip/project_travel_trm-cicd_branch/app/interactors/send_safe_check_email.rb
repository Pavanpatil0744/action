# frozen_string_literal: true

class SendSafeCheckEmail
  include Interactor

  delegate :client_user, :plans_user, :receipt_uuid, :safe_check_message, to: :context

  def call
    return unless safe_check_message.email_requested

    client_account_logo = safe_check_message.client_account.logo.url
    short_text = safe_check_message.short_text
    text = safe_check_message.text
    traveler_id = plans_user.user_id

    SendGrid::SendSafeCheckMailer.perform_async(
      client_account_logo,
      receipt_uuid,
      short_text,
      text,
      traveler_id
    )
  end
end
