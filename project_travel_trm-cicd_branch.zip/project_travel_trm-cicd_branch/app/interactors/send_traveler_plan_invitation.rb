# frozen_string_literal: true

class SendTravelerPlanInvitation
  include Interactor

  delegate :plan, :traveler, to: :context

  def call
    client_account = plan.client_account
    client_account_logo = client_account.logo_url
    traveler_id = traveler.id

    SendGrid::SendTravelerPlansUserCreationMailer.perform_async(
      client_account_logo,
      plan.id,
      plan.name,
      traveler_id
    )
  end
end
