# frozen_string_literal: true

class ForceAddPlanDetails
  include Interactor

  delegate :plan, :plans_user, to: :context

  def call
    itinerary_details = plan.plan_activities.where(force_add: true)
    itinerary_details += plan.plan_housings.where(force_add: true)
    itinerary_details += plan.plan_transportations.where(force_add: true)

    itinerary_details.each do |detail|
      ForceAddPlanDetail.call(plan: plan, plan_detail: detail, plans_user: plans_user)
    end
  end
end
