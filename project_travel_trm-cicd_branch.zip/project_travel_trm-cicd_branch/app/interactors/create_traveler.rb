# frozen_string_literal: true

class CreateTraveler
  include Interactor

  delegate :client_account,
           :email,
           :first_name,
           :last_name,
           :password,
           :sign_up_source,
           to: :context

  def call
    traveler = User.new(
      email: email,
      first_name: first_name || "",
      last_name: last_name || "",
      password: password
    )
    profile = traveler.build_profile(
      email: email,
      first_name: first_name || "",
      last_name: last_name || "",
      signup_source: sign_up_source
    )
    traveler_info = traveler.build_traveler_info(profile: profile)

    traveler_info.build_passport

    traveler.add_role(:traveler)
    traveler.clients << client_account

    traveler.save
    traveler.set_reset_password_token unless client_account.sso?

    context.traveler = traveler
    traveler_id = traveler.id

    client_account.event_travelers.where(email: email).update_all(user_id: traveler_id)
    client_account.traveler_invitations.where("LOWER(email) = ?", email).update_all(completed: true)

    UpdateReportTraveler.perform_in(10.seconds, traveler_id)
  end
end
