# frozen_string_literal: true

class CreateDefaultRecommendationTemplate
  include Interactor

  delegate :client_account_id, to: :context

  def call
    client_account = ClientAccount.find(client_account_id)
    recommendation_template_type = TemplateType.find_by(name: "Recommendation", order: 3)
    existing_default_recommendation_template = client_account.templates.find_by(
      default: true,
      template_type_id: recommendation_template_type.id
    )

    context.fail! if existing_default_recommendation_template

    default_recommendation_template = client_account.templates.create!(
      default: true,
      name: "Default Recommendation",
      status: 1,
      template_type: recommendation_template_type
    )
    instructions_header = default_recommendation_template.header_questions.create!(
      text: "Instructions"
    )
    name_short_text = default_recommendation_template.short_text_questions.create!(
      label: "Full Name",
      required: true
    )
    title_short_text = default_recommendation_template.short_text_questions.create!(
      label: "Title",
      required: true
    )
    recommendation_header = default_recommendation_template.header_questions.create!(
      text: "Upload or Type Your Recommendation"
    )
    letter_file_upload = default_recommendation_template.file_upload_questions.create!(
      instructions: "Use the button below to upload your recommendation.",
      label: "Upload Letter of Recommendation"
    )
    type_long_text = default_recommendation_template.long_text_questions.create!(
      instructions: "Type or copy and paste your recommendation below.",
      label: "Typed Letter of Recommendation"
    )

    questions = default_recommendation_template.questions

    file_upload_type = QuestionType.find_by_identifier("file_upload")
    header_type = QuestionType.find_by_identifier("header")
    long_text_type = QuestionType.find_by_identifier("long_text")
    short_text_type = QuestionType.find_by_identifier("short_text")

    instructions = questions.find_by(
      question_type: header_type,
      detailable: instructions_header
    )
    name = questions.find_by(
      question_type: short_text_type,
      detailable: name_short_text
    )
    title = questions.find_by(
      question_type: short_text_type,
      detailable: title_short_text
    )
    recommendation = questions.find_by(
      question_type: header_type,
      detailable: recommendation_header
    )
    file = questions.find_by(
      question_type: file_upload_type,
      detailable: letter_file_upload
    )
    text = questions.find_by(
      question_type: long_text_type,
      detailable: type_long_text
    )

    default_recommendation_template.create_template_layout(
      layout: [
        { id: instructions.id.to_s, position: %w[1 3] },
        { id: name.id.to_s, position: %w[2 3] },
        { id: title.id.to_s, position: %w[3 3] },
        { id: recommendation.id.to_s, position: %w[4 3] },
        { id: file.id.to_s, position: %w[5 3] },
        { id: text.id.to_s, position: %w[6 3] }
      ]
    )
  end
end
