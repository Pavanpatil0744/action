# frozen_string_literal: true

class CreatePlansUser
  include Interactor

  delegate :plan, :plans_user, :traveler, to: :context

  def call
    context.plans_user = plan.plans_users.find_or_create_by(user_id: traveler.id)

    if plans_user.removed? && !plan.cancelled?
      plans_user.update(removed: false)
    elsif !plans_user.removed? && plan.cancelled?
      plans_user.update(removed: true)
    end

    ReportPlanUser.find_by_plans_users_id(plans_user.id)&.update(sync_required: true)
    UpdateReportPlanUser.perform_in(10.seconds, plans_user.id)

    ReportPlan.find_by_plan_id(plan.id)&.update(sync_required: true)
    UpdateReportPlan.perform_in(10.seconds, plan.id)
  end
end
