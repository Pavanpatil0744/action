# frozen_string_literal: true

class BatchInviteTravelers
  include Interactor

  delegate :client_account, :csv, :plan, to: :context

  def call
    travelers = csv.split("\n").drop(1).map do |row|
      row = row.split(",").map(&:strip)

      { email: row[0], first_name: row[1], last_name: row[2] }
    end

    travelers.keep_if { |traveler| traveler[:email].match?(Devise.email_regexp) }

    context.plans_users = []

    travelers.each do |traveler|
      email = traveler[:email]
      client_traveler = client_account.travelers.find_by(email: email)

      next if !client_traveler && User.exists?(email: email)

      plans_user = if client_traveler
                     InviteExistingTraveler.call(
                       plan: plan,
                       traveler: client_traveler
                     )
                   elsif !User.exists?(email: email)
                     password = SecureRandom.base64(15)
                     password = Devise.friendly_token until password.match?(%r{^(?=.*[A-Z])(?=.*[!"#$%&'()*+,-./:;<=>?@\[\\\]^_`{|}~]).{8,}$})
                     InviteNewTraveler.call(
                       client_account: client_account,
                       email: email,
                       first_name: traveler[:first_name],
                       last_name: traveler[:last_name],
                       password: password,
                       plan: plan,
                       sign_up_source: "Via Travel Invitation"
                     )
                   end.plans_user

      context.plans_users << plans_user
    end
  end
end
