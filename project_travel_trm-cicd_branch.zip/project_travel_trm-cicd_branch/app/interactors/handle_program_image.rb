# frozen_string_literal: true

class HandleProgramImage
  include Interactor

  delegate :program, to: :context

  def call
    client_account_id = program.primary_client_account_id

    if program.image_requested?
      program.program_images.destroy_all

      location = program.program_locations.order(:id).first

      image_url = if program.unspecified_location?
                    "https://images.unsplash.com/photo-1600907055749-d6cc7e75efd4?ixid=MnwxNDE1Mjh8MHwxfGFsbHx8fHx8fHx8fDE2MzY2NzA4NzM&ixlib=rb-1.2.1"
                  elsif location
                    locality = location.locality
                    locale = locality.present? ? locality : location.city
                    results = unsplash_service.retrieve_image("#{locale},cityscape")

                    if results.empty?
                      results = unsplash_service.retrieve_image(
                        "#{location.country_common_name},cityscape"
                      )
                    end

                    results.any? ? results[0][:urls][:full] : nil
                  end

      program_image = program.program_images.new(
        client_account_id: client_account_id,
        primary: true
      )

      if image_url
        program_image.background = "#{image_url}&w=1200&h=800"
        program_image.large = "#{image_url}&w=1200&h=800"
        program_image.list = "#{image_url}&w=60&h=60"
        program_image.medium = "#{image_url}&w=340&h=165"
        program_image.original = image_url
        program_image.result = "#{image_url}&w=100&h=100"
        program_image.small = "#{image_url}&w=200&h=65"
        program_image.square = "#{image_url}&w=200&h=200"
      end

      program_image.save
    else
      program.program_images.find(&:default_image?)&.destroy

      unless program.program_images.reload.any?
        program.program_images.create(client_account_id: client_account_id, primary: true)
      end
    end
  end

  private

  def unsplash_service
    @unsplash_service ||= UnsplashService.new
  end
end
