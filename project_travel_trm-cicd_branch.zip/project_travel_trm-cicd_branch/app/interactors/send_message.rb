# frozen_string_literal: true

class SendMessage
  include Interactor

  delegate :admin, :message, :traveler, to: :context

  def call
    client_account = admin.client_account
    conversation = Conversation.conversation(traveler, client_account)

    Conversation.client_reply(traveler, admin, client_account, conversation, message)
  end
end
