# frozen_string_literal: true

class SendGrid::SendPlanDetailCreationMailers
  include Interactor

  delegate :plan_detail, :user, to: :context

  def call
    plan = plan_detail.plan
    plan_id = plan.id
    plan_name = plan.name
    client_account = plan.client_account
    client_account_logo = client_account.logo.url

    if plan_detail.group?
      travelers = plan.active_users

      SendGrid::SendTravelerGroupPlanDetailCreationMailer.perform_async(
        client_account_logo,
        plan_detail.formatted_location,
        plan_detail.formatted_name,
        plan_id,
        plan_name,
        travelers.ids
      )
    else
      admins = client_account.super_users
      admins += plan.group_leads

      SendGrid::SendAdminPlanDetailUpdateMailer.perform_async(
        admins.map(&:id),
        client_account_logo,
        plan_id,
        plan_name,
        user.full_name_or_email
      )
    end
  end
end
