# frozen_string_literal: true

class SendGrid::SendMessageFromAdminMailers
  include Interactor

  delegate :admin, :message, :traveler_ids, to: :context

  def call
    client_account = admin.client_account
    client_account_logo = client_account.logo.url
    admin_ids = client_account.assigned_admins.joins(:client_user).where(traveler_id: traveler_ids)
                              .where(users: { archived: false, inactive: false })
                              .pluck("DISTINCT assigned_admins.client_user_id")
    message_body = message.body
    message_count = traveler_ids.count
    message_subject = message.subject
    sender_full_name_or_email = admin.full_name_or_email
    sender_id = admin.id

    if message_count > 1
      SendGrid::SendAdminBatchMessageMailer.perform_async(
        admin_ids | [sender_id],
        client_account_logo,
        message_body,
        message_count,
        sender_full_name_or_email
      )
    else
      traveler = User.find(traveler_ids.first)

      SendGrid::SendCopiedAdminMessageMailer.perform_async(
        admin_ids - [sender_id],
        client_account_logo,
        message_body,
        message_subject,
        sender_full_name_or_email,
        traveler.id,
        traveler.full_name_or_email
      )
    end

    SendGrid::SendMessageFromAdminToTravelerMailer.perform_async(
      client_account_logo,
      message_body,
      message_subject,
      sender_full_name_or_email,
      traveler_ids
    )
  end
end
