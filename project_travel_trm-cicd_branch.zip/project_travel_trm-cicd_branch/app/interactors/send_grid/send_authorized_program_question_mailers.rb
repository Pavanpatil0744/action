# frozen_string_literal: true

class SendGrid::SendAuthorizedProgramQuestionMailers
  include Interactor

  delegate :client_account,
           :contacts,
           :message_body,
           :program,
           :traveler,
           to: :context

  def call
    authorized_admin_ids = contacts.map(&:id)
    client_account_org_name = client_account.org_name
    internal_admin_ids = client_account.default_message_recipients.pluck(:id)
    program_name = program.title
    program_provider = program.primary_client_account
    program_provider_logo = program_provider.logo.url
    program_provider_org_name = program_provider.org_name
    traveler_email = traveler.email
    traveler_name = traveler.full_name_or_email

    SendGrid::SendQuestionToHomeCampusMailer.perform_async(
      internal_admin_ids,
      client_account.logo.url,
      message_body,
      program_name,
      program_provider_org_name,
      traveler.id,
      traveler_email,
      traveler_name
    )

    if program_provider.free?
      SendGrid::SendQuestionToFreemiumProgramProviderMailer.perform_async(
        authorized_admin_ids,
        client_account_org_name,
        program_name,
        program_provider_logo
      )
    else
      SendGrid::SendQuestionToProgramProviderMailer.perform_async(
        authorized_admin_ids,
        message_body,
        program_name,
        program_provider_logo,
        traveler_email,
        traveler_name
      )
    end

    SendGrid::SendAskAQuestionLeadNotificationMailer.perform_async(
      client_account_org_name,
      program_provider_org_name,
      program_name
    )
  end
end
