# frozen_string_literal: true

class SendGrid::SendPlanCreationMailers
  include Interactor

  delegate :plan, :traveler, to: :context

  def call
    client_account = plan.client_account
    client_account_logo = client_account.logo.url
    plan_id = plan.id
    plan_name = plan.name
    traveler_id = traveler.id

    SendGrid::SendTravelerPlanCreationMailer.perform_async(
      client_account_logo,
      plan_id,
      plan_name,
      traveler_id
    )
    SendGrid::SendAdminPlanCreationMailer.perform_async(
      plan.client_account.super_users.ids,
      client_account_logo,
      plan_id,
      plan_name,
      traveler.full_name_or_email
    )
  end
end
