# frozen_string_literal: true

class SendGrid::CreateMailerHistory
  include Interactor

  delegate :automation_mailer, :objects, :send_grid_mailer_type, to: :context

  def call
    objects.each do |object|
      send_grid_mailer_history = SendGridMailerHistory.new(
        client_account_id: object.client_account_id,
        mailer_type: send_grid_mailer_type.name,
        queued_at: DateTime.current.utc,
        template_id: send_grid_mailer_type.template_id,
        sent_from: send_grid_mailer_type.sent_from,
        sent_to: object.email
      )

      if automation_mailer.present?
        automation = automation_mailer.automation

        send_grid_mailer_history.automation_id = automation.id
        send_grid_mailer_history.automation_name = automation.name
        send_grid_mailer_history.automation_mailer_id = automation_mailer.id
        send_grid_mailer_history.body = automation_mailer.body
        send_grid_mailer_history.button_target = automation_mailer.button_target
        send_grid_mailer_history.button_text = automation_mailer.button_text
        send_grid_mailer_history.preheader = automation_mailer.preheader
        send_grid_mailer_history.subject = automation_mailer.subject
        send_grid_mailer_history.trigger_display_text = automation.formatted_trigger_display_text
      end

      user = User.find_by_id(object.user_id)

      send_grid_mailer_history.user_id = user.id if user

      send_grid_mailer_history.save
    end
  end
end
