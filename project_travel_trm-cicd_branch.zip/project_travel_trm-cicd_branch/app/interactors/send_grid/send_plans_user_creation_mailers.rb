# frozen_string_literal: true

class SendGrid::SendPlansUserCreationMailers
  include Interactor

  delegate :plans_user, :user, to: :context

  def call
    plan = plans_user.plan
    client_account = plan.client_account
    client_account_logo = client_account.logo.url
    plan_id = plan.id
    plan_name = plan.name
    traveler = plans_user.user
    traveler_id = traveler.id

    if user.admin_sign_in? || user.group_lead?(plan)
      SendGrid::SendTravelerPlansUserCreationMailer.perform_async(
        client_account_logo,
        plan_id,
        plan_name,
        traveler_id
      )
    else
      admins = client_account.super_users
      admins += plan.group_leads

      SendGrid::SendAdminPlansUserCreationMailer.perform_async(
        admins.map(&:id),
        client_account_logo,
        plan_id,
        plan_name,
        traveler.full_name_or_email
      )

      SendGrid::SendTravelerPlansUserSelfCreationMailer.perform_async(
        client_account_logo,
        plan_id,
        plan_name,
        traveler_id
      )
    end
  end
end
