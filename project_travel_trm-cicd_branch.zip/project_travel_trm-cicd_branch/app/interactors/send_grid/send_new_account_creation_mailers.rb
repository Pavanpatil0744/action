# frozen_string_literal: true

class SendGrid::SendNewAccountCreationMailers
  include Interactor

  delegate :client_account, :traveler, to: :context

  def call
    admin_ids = client_account.default_message_recipient_ids
    client_account_logo = client_account.logo.url
    traveler_id = traveler.id

    SendGrid::SendAdminNewAccountCreationMailer.perform_async(
      admin_ids,
      client_account_logo,
      traveler_id,
      traveler.full_name_or_email
    )

    SendGrid::SendTravelerNewAccountCreationMailer.perform_async(client_account_logo, traveler_id)
  end
end
