# frozen_string_literal: true

class SendGrid::SendPlanUpdateMailers
  include Interactor

  delegate :active_group_leads,
           :active_travelers,
           :plan,
           :previously_cancelled,
           :updated_fields,
           :user, to: :context

  def call
    active_traveler_ids = active_travelers.map(&:id)
    admins = plan.client_account.default_message_recipients
    admins += active_group_leads
    admin_ids = admins.map(&:id)
    client_account_logo = plan.client_account.logo.url
    plan_canceller = user.full_name_or_email
    plan_id = plan.id
    plan_name = plan.name

    if updated_fields.include?("plan_registration_status_id") && plan.cancelled?
      SendGrid::SendAdminPlanRemovalMailer.perform_async(
        admin_ids,
        client_account_logo,
        plan_canceller,
        plan_name
      )

      SendGrid::SendTravelerPlanRemovalMailer.perform_async(
        client_account_logo,
        plan_canceller,
        plan_name,
        active_traveler_ids
      )
    elsif previously_cancelled && plan.open?
      SendGrid::SendTravelerPlanReinstatementMailer.perform_async(
        client_account_logo,
        plan_name,
        plan.users.ids
      )

      SendGrid::SendAdminPlanReinstatementMailer.perform_async(
        admin_ids,
        client_account_logo,
        plan_id,
        plan_name
      )
    elsif updated_fields.include?("plan_status_id")
      SendGrid::SendTravelerPlanStatusUpdateMailer.perform_async(
        client_account_logo,
        plan_name,
        plan.plan_status_name,
        active_traveler_ids
      )
    elsif plan.group?
      SendGrid::SendTravelerPlanUpdateMailer.perform_async(
        client_account_logo,
        plan_id,
        plan_name,
        active_traveler_ids
      )
    end
  end
end
