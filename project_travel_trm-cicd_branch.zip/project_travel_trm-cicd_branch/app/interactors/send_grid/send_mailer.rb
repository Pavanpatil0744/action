# frozen_string_literal: true

class SendGrid::SendMailer
  include Interactor::Organizer

  organize SendGrid::CallApiService, SendGrid::CreateMailerHistory
end
