# frozen_string_literal: true

class SendGrid::V2::SendApplicationStatusChangeMailers
  include Interactor

  delegate :application, :client_account, :drt_elaps_trigger, to: :context

  def call
    admin_ids = client_account.default_message_recipient_ids
    application_id = application.id
    application_status = application.status.titleize
    application_status = application_status == "Commit" ? "Committed" : application_status
    automations_enabled = client_account.automations_enabled?
    client_account_logo = client_account.logo.url
    program = application.program
    program_provider = program.primary_client_account
    program_range_id = application.program_range_id
    internal_program = program_provider.id == client_account.id
    program_contact = program.program_contact&.user
    program_name = program.title
    program_range = application.program_range
    subject_to_decision_release = application.subject_to_decision_release?
    traveler_id = application.user_id
    traveler_name = application.user.full_name_or_email
    use_exact_dates = program_range.use_exact_dates

    if use_exact_dates
      program_end_date = program_range.end_date.strftime("%b %d, %Y")
      program_start_date = program_range.start_date.strftime("%b %d, %Y")
    else
      program_end_date = program_range.end_date.strftime("%b %Y")
      program_start_date = program_range.start_date.strftime("%b %Y")
    end

    admin_ids |= [program_contact.id] if program_contact&.active? && internal_program

    if internal_program
      if application_status == "Accepted" &&
         !automations_enabled &&
         !subject_to_decision_release

        SendGrid::V2::Mailers::TravelerInternalApplicationAcceptance.perform_async(
          client_account_logo,
          program_end_date,
          program_name,
          program_start_date,
          traveler_id
        )
      elsif application_status != "Accepted" &&
            !automations_enabled &&
            !subject_to_decision_release

        SendGrid::V2::Mailers::TravelerApplicationStatusChange.perform_async(
          application_status,
          client_account_logo,
          program_end_date,
          program_name,
          program_range_id,
          program_start_date,
          traveler_id
        )
      end

      return if drt_elaps_trigger

      SendGrid::V2::Mailers::AdminInternalApplicationStatusChange.perform_async(
        admin_ids,
        application_id,
        application_status,
        client_account_logo,
        program_end_date,
        program_name,
        program_start_date,
        traveler_name
      )
    else
      if application_status == "Accepted" && !automations_enabled
        SendGrid::V2::Mailers::TravelerAuthorizedApplicationAcceptance.perform_async(
          client_account_logo,
          program_end_date,
          program_name,
          program_provider.org_name,
          program_start_date,
          traveler_id
        )
      elsif application_status != "Accepted" && !automations_enabled
        SendGrid::V2::Mailers::TravelerApplicationStatusChange.perform_async(
          application_status,
          client_account_logo,
          program_end_date,
          program_name,
          program_range_id,
          program_start_date,
          traveler_id
        )
      end

      return if drt_elaps_trigger

      SendGrid::V2::Mailers::AdminAuthorizedApplicationStatusChange.perform_async(
        admin_ids,
        application_id,
        application_status,
        client_account_logo,
        program_end_date,
        program_name,
        program_start_date,
        traveler_name
      )
    end
  end
end
