# frozen_string_literal: true

class SendGrid::V2::SendNewInternalApplicationMailers
  include Interactor

  delegate :application, :client_account, to: :context

  def call
    admin_ids = client_account.default_message_recipient_ids
    automations_enabled = client_account.automations_enabled?
    client_account_logo = client_account.logo.url
    program = application.program
    program_contact = program.program_contact.user
    program_name = program.title
    program_range = application.program_range
    use_exact_dates = program_range.use_exact_dates

    if use_exact_dates
      program_end_date = program_range.end_date.strftime("%b %d, %Y")
      program_start_date = program_range.start_date.strftime("%b %d, %Y")
    else
      program_end_date = program_range.end_date.strftime("%b %Y")
      program_start_date = program_range.start_date.strftime("%b %Y")
    end

    admin_ids |= [program_contact.id] if program_contact&.active?

    SendGrid::V2::Mailers::AdminNewInternalApplication.perform_async(
      admin_ids,
      application.id,
      client_account_logo,
      program_end_date,
      program_name,
      program_start_date,
      application.user.full_name_or_email
    )

    return if automations_enabled

    SendGrid::V2::Mailers::TravelerNewInternalApplication.perform_async(
      client_account_logo,
      program_end_date,
      program_name,
      program_range.id,
      program_start_date,
      application.user_id
    )
  end
end
