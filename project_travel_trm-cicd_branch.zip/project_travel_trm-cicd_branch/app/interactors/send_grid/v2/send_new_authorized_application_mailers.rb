# frozen_string_literal: true

class SendGrid::V2::SendNewAuthorizedApplicationMailers
  include Interactor

  delegate :application, :client_account, to: :context

  def call
    authorized_admin_ids = []
    automations_enabled = client_account.automations_enabled?
    client_account_logo = client_account.logo.url
    client_account_org_name = client_account.org_name
    internal_admin_ids = client_account.default_message_recipients.pluck(:id)
    intro_text = client_account.authorized_programs_mailer_text
    program = application.program
    program_contact = program.program_contact.user
    program_name = program.title
    program_provider = program.primary_client_account
    program_provider_logo = program_provider.logo.url
    program_provider_org_name = program_provider.org_name
    program_range = application.program_range
    traveler_id = application.user_id
    traveler_name = application.user.full_name_or_email
    use_exact_dates = program_range.use_exact_dates

    if use_exact_dates
      program_end_date = program_range.end_date.strftime("%b %d, %Y")
      program_start_date = program_range.start_date.strftime("%b %d, %Y")
    else
      program_end_date = program_range.end_date.strftime("%b %Y")
      program_start_date = program_range.start_date.strftime("%b %Y")
    end

    authorized_admin_ids << program_contact.id if program_contact&.active?

    if authorized_admin_ids.empty?
      program_provider.default_message_recipients.each do |message_recipient|
        authorized_admin_ids << message_recipient.id
      end
    end

    SendGrid::V2::Mailers::CampusAdminNewAuthorizedApplication.perform_async(
      internal_admin_ids,
      application.id,
      client_account_logo,
      program_end_date,
      program_name,
      program_provider_org_name,
      program_start_date,
      traveler_name
    )

    if program_provider.free?
      SendGrid::V2::Mailers::FreemiumProviderNewApplication.perform_async(
        authorized_admin_ids,
        program_end_date,
        program_name,
        program_provider_logo,
        program_start_date
      )
    else
      SendGrid::V2::Mailers::ProgramProviderNewApplication.perform_async(
        authorized_admin_ids,
        program_end_date,
        program_name,
        program_provider_logo,
        program_start_date,
        application.user.email,
        traveler_name
      )
    end

    SendGrid::SendNewAuthorizedApplicationLeadNotificationMailer.perform_async(
      client_account_org_name,
      program_name,
      program_provider_org_name
    )

    return if automations_enabled

    SendGrid::V2::Mailers::TravelerNewAuthorizedApplication.perform_async(
      client_account_logo,
      intro_text,
      program_end_date,
      program_name,
      program_provider_org_name,
      program_range.id,
      program_start_date,
      traveler_id
    )
  end
end
