# frozen_string_literal: true

# not in use can be removed
class SendGrid::V2::SendFormStatusChangeMailers
  include Interactor

  delegate :client_account, :form, to: :context

  def call
    admin_ids = client_account.default_message_recipient_ids
    form_name = form.template_name
    form_status = form.status.titleize
    client_account_logo = client_account.logo.url
    program = form.program
    program_provider = program.primary_client_account
    internal_program = program_provider.id == client_account.id
    program_contact = program.program_contact&.user
    program_name = program.title
    program_range = form.program_range
    traveler_id = form.user_id
    traveler_name = form.user.full_name_or_email
    use_exact_dates = program_range.use_exact_dates

    if use_exact_dates
      program_end_date = program_range.end_date.strftime("%b %d, %Y")
      program_start_date = program_range.start_date.strftime("%b %d, %Y")
    else
      program_end_date = program_range.end_date.strftime("%b %Y")
      program_start_date = program_range.start_date.strftime("%b %Y")
    end

    admin_ids |= [program_contact.id] if program_contact&.active? && internal_program

    if internal_program
      SendGrid::V2::Mailers::AdminInternalFormStatusChange.perform_async(
        admin_ids,
        client_account_logo,
        form_name,
        form_status,
        program_end_date,
        program_name,
        program_start_date,
        form.id,
        traveler_name
      )
    else
      SendGrid::V2::Mailers::AdminAuthorizedFormStatusChange.perform_async(
        admin_ids,
        client_account_logo,
        form_name,
        form_status,
        program_end_date,
        program_name,
        program_start_date,
        form.id,
        traveler_name
      )
    end

    return if form.form_automations_enabled?

    SendGrid::V2::Mailers::TravelerFormStatusChange.perform_async(
      client_account_logo,
      form_name,
      form_status,
      program_end_date,
      program_name,
      program_start_date,
      traveler_id
    )
  end
end
