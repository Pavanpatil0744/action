# frozen_string_literal: true

class SendGrid::CallApiService
  include Interactor

  delegate :attachments, :personalizations, :send_grid_mailer_type, to: :context

  def call
    request_body = {
      personalizations: personalizations,
      from: { email: send_grid_mailer_type.sent_from },
      template_id: send_grid_mailer_type.template_id
    }

    request_body.merge!({ attachments: attachments }) if attachments.present?

    connection = SendGrid::API.new(api_key: ENV["SEND_GRID_API_KEY"])

    connection.client.mail._("send").post(request_body: request_body)
  end
end
