# frozen_string_literal: true

class SendGrid::SendPlansUserUpdateMailers
  include Interactor

  delegate :plans_user, :updated_fields, :user, to: :context

  def call
    removed_attribute_updated = updated_fields.include?("removed")

    return unless removed_attribute_updated && plans_user.removed?

    plan = plans_user.plan
    plan_name = plan.name
    client_account = plan.client_account
    client_account_logo = client_account.logo.url
    traveler = plans_user.user
    traveler_id = traveler.id

    if user.admin_sign_in? || user.group_lead?(plan)
      SendGrid::SendTravelerPlansUserRemovalMailer.perform_async(
        client_account_logo,
        plan_name,
        traveler_id
      )
    else
      admins = client_account.super_users
      admins += plan.group_leads

      SendGrid::SendTravelerPlansUserSelfRemovalMailer.perform_async(
        client_account_logo,
        plan_name,
        traveler_id
      )
      SendGrid::SendAdminPlansUserRemovalMailer.perform_async(
        admins.map(&:id),
        client_account_logo,
        plan_name,
        traveler.full_name_or_email
      )
    end
  end
end
