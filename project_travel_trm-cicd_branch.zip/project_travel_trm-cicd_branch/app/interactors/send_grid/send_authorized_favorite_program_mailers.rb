# frozen_string_literal: true

# Sends authorized favorite program mailers
class SendGrid::SendAuthorizedFavoriteProgramMailers
  include Interactor

  delegate :client_account,
           :program,
           :traveler,
           :contacts,
           to: :context

  def call
    authorized_admin_ids = contacts.map(&:id)
    program_name = program.title
    program_provider = program.primary_client_account
    program_provider_logo = program_provider.logo.url
    program_provider_org_name = program_provider.org_name
    traveler_email = traveler.email
    traveler_name = traveler.full_name_or_email

    if program_provider.free?
      SendGrid::AuthorizedProgram::SendFavoriteProgramToFreemiumProgramProviderMailer.perform_async(
        authorized_admin_ids,
        program_provider_logo,
        program_name
      )
    else
      SendGrid::AuthorizedProgram::SendFavoriteProgramToProgramProviderMailer.perform_async(
        authorized_admin_ids,
        program_provider_logo,
        program_name,
        traveler_email,
        traveler_name
      )
    end

    SendGrid::AuthorizedProgram::SendFavoriteProgramLeadNotificationMailer.perform_async(
      program_provider_org_name,
      program_name
    )
  end
end
