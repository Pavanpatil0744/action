# frozen_string_literal: true

class SendGrid::SendPlanDetailUpdateMailers
  include Interactor

  delegate :plan_detail, :updated_fields, :user, to: :context

  def call
    detail_location = plan_detail.formatted_location
    detail_name = plan_detail.formatted_name
    detail_removed = plan_detail.removed?
    plan = plan_detail.plan
    client_account = plan.client_account
    client_account_logo = client_account.logo.url
    plan_id = plan.id
    plan_name = plan.name
    removed_attribute_updated = updated_fields.include?("removed")

    if user.admin_sign_in? || user.group_lead?(plan)
      traveler_ids = plan.active_users.ids

      if removed_attribute_updated && detail_removed
        SendGrid::SendTravelerGroupPlanDetailRemovalMailer.perform_async(
          client_account_logo,
          detail_location,
          detail_name,
          plan_id,
          plan_name,
          traveler_ids
        )
      else
        SendGrid::SendTravelerGroupPlanDetailUpdateMailer.perform_async(
          client_account_logo,
          detail_location,
          detail_name,
          plan_id,
          plan_name,
          traveler_ids
        )
      end
    elsif removed_attribute_updated
      admins = client_account.super_users
      admins += plan.group_leads

      SendGrid::SendAdminPlanDetailUpdateMailer.perform_async(
        admins.map(&:id),
        client_account_logo,
        plan_id,
        plan_name,
        user.full_name_or_email
      )
    end
  end
end
