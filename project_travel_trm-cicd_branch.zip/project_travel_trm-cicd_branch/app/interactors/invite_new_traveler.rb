# frozen_string_literal: true

class InviteNewTraveler
  include Interactor::Organizer

  organize CreateTraveler, CreatePlansUser, ForceAddPlanDetails, SendNewTravelerPlanInvitation
end
