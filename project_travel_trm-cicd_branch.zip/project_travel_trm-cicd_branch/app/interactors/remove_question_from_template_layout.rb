# frozen_string_literal: true

class RemoveQuestionFromTemplateLayout
  include Interactor

  delegate :question_id, :template_layout, to: :context

  def call
    layouts = template_layout.layout
    question_layout = {}
    update_row = false

    layouts.each do |layout|
      position = layout["position"]

      position[0] = (position[0].to_i - 1).to_s if update_row

      next unless layout["id"].to_i == question_id

      question_layout = layout

      break unless position[1].to_i == 3

      update_row = true
    end

    layouts.delete(question_layout)

    template_layout.save
  end
end
