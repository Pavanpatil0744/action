# frozen_string_literal: true

class ForceAddPlanDetail
  include Interactor

  delegate :plan, :plan_detail, :plans_user, to: :context

  def call
    plans_users = plan_detail.plans_users
    plans_users << plans_user unless plans_users.include?(plans_user)

    plans_users_detail = case plan_detail
                         when PlanActivity
                           plan_detail.plans_users_activities.find_by(plans_user: plans_user)
                         when PlanHousing
                           plan_detail.plans_users_housings.find_by(plans_user: plans_user)
                         when PlanTransportation
                           plan_detail.plans_users_transportations.find_by(plans_user: plans_user)
                         end

    plans_users_detail.update(removed: true) if plan.cancelled?

    return if plans_user.removed?

    SendGrid::SendTravelerPlanDetailAdditionMailer.perform_async(
      plan.client_account.logo.url,
      plan_detail.formatted_location,
      plan_detail.formatted_name,
      plan.id,
      plan.name,
      plans_user.user_id
    )
  end
end
