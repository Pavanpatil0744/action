# frozen_string_literal: true

class StandardReports::CreateCsvAndZip
  include Interactor

  delegate :client_account, :submission_type, :report_type, :submission_ids, :program_alias, :report_by, to: :context

  def call
    report_names, reporting_table = reporting_csv_data
    aggregate_csv_reports = {}

    report_names.each do |report_name|
      csv_rows = []

      headers = reporting_table[report_name][:questions]

      reporting_table[report_name][:submission_ids].each do |submission_id|
        row = reporting_table[report_name][:data][submission_id][:base]
        headers.each do |question|
          row << reporting_table[report_name][:data][submission_id][:responses][question]
        end

        csv_rows << row
      end

      aggregate_csv_reports[csv_filename(report_name)] = CSV.generate do |csv|
        csv << (submission_content_csv_headers + headers)

        csv_rows.each { |row| csv << row }
      end
    end

    context.zip_file =
      Zip::OutputStream.write_buffer do |zos|
        aggregate_csv_reports.each do |(filename, content)|
          zos.put_next_entry(filename)
          zos.write content
        end
      end
  end

  private

  def csv_filename(report_name)
    if report_type == 'program_name_and_term'
      submission_content_by_program_name_and_term_csv_filename(report_name)
    else
      submission_content_by_template_csv_filename(report_name)
    end
  end

  def reporting_csv_data
    submission_content_reporting_table = {}
    submission_content_report_names = []

    submissions_for_content_report.each do |submission|
      submission_id = submission.id
      user = submission.user
      program_range = submission.program_range
      program_range_start_date = program_range.start_date&.strftime("%Y%m%d")
      program_range_end_date = program_range.end_date&.strftime("%Y%m%d")
      program = program_range.program

      report_name =
        if report_type == 'program_name_and_term'
          "ViaTRM_#{program.title}_#{program_range_start_date}_#{program_range_end_date}"
        else
          "ViaTRM_#{submission.template_name}_#{DateTime.now.getlocal.strftime("%Y%m%d")}"
        end

      submission_content_report_names << report_name unless submission_content_report_names.include?(report_name)

      submission_content_reporting_table[report_name] ||= { submission_ids: [], data: {}, questions: [] }

      submission_content_reporting_table[report_name][:data][submission_id] = {
        base: report_contents(submission, user, program_range, program),
        responses: {}
      }

      submission_content_reporting_table[report_name][:submission_ids] << submission_id
      responses = submission.responses
      layout = submission.template.template_layout.layout
      questions = submission
                  .template
                  .questions
                  .where("detailable_type not in (?)", non_respondable_types)
                  .sort_by do |que|
                    pos = layout.find { |l| l['id'] == que.id.to_s }
                    pos.present? ? pos['position'][0].to_i : 100
                  end

      submission_content_reporting_table[report_name][:questions].concat(
        questions.map { |que| que.detailable.try(:label) }.compact
      ).uniq!

      submission_content_reporting_table[report_name][:data][submission_id][:responses] = question_mapping(responses)
    end

    [submission_content_report_names, submission_content_reporting_table]
  end

  def report_contents(submission, user, program_range, program)
    if submission_type == 'application'
      application_report_contents(submission, user, program_range, program)
    else
      form_report_contents(submission, user, program_range, program)
    end
  end

  def application_report_contents(submission, user, program_range, program)
    [
      user.preferred_first_name,
      user.preferred_last_name,
      user.first_name,
      user.last_name,
      user.email,
      user.student_id,
      program.title,
      program.locations,
      program_countries(program.program_locations),
      program_cities(program.program_locations),
      program_status(submission),
      submission.term_name,
      program_range.start_date&.strftime("%Y-%m-%d"),
      program_range.end_date&.strftime("%Y-%m-%d"),
      tags(program_range),
      submission.display_status,
      submission.template.name,
      tags(submission),
      submission.created_at.strftime("%b %d, %Y %I:%M %p %Z"),
      submitted_at(submission),
      status_last_updated_at(submission),
      deferred_at(submission),
      deferred_reason(submission),
      withdrawn_at(submission),
      withdrawn_reason(submission),
      submission.submission_review.rating,
      submission.submission_review.notes
    ]
  end

  def form_report_contents(submission, user, program_range, program)
    [
      user.first_name,
      user.last_name,
      user.email,
      user.student_id,
      program.title,
      program.locations,
      program_countries(program.program_locations),
      program_cities(program.program_locations),
      program_status(submission),
      submission.term_name,
      program_range.start_date&.strftime("%Y-%m-%d"),
      program_range.end_date&.strftime("%Y-%m-%d"),
      tags(program_range),
      submission.display_status,
      submission.template.name,
      tags(submission),
      submission.created_at.strftime("%b %d, %Y %I:%M %p %Z"),
      submitted_at(submission),
      status_last_updated_at(submission),
      submission.submission_review.rating,
      submission.submission_review.notes
    ]
  end

  def question_mapping(responses)
    mappings = {}
    responses.each do |res|
      que = res.question.detailable.label
      mappings[que] = content_reporting_value(res)
    end

    mappings
  end

  def content_reporting_value(response)
    case response.respondable_type
    when "DateResponse"
      response.details.value&.strftime("%b %d, %Y")
    when "DropdownResponseGrouping"
      response.details.dropdown_responses.map(&:dropdown_question_option_name).join('; ')
    when "FileUploadResponse", ""
      submission = response.submission
      "https://#{submission.client_account_subdomain}.#{Rails.configuration.front_end_uri}client/form-review/#{submission.id}"
    when "MultipleChoiceResponseGrouping"
      response.details.multiple_choice_responses.sort_by(&:order).map(&:multiple_choice_question_option_name).join('; ')
    when "PaymentResponse"
      response.details.payment_status_name
    when "RecommendationResponse"
      recommendation_requests = response.details.recommendation_requests

      serialized_recommendation_responses = recommendation_requests.map do |rr|
        completed_at = rr.completed_at&.strftime("%b %d, %Y")
        email = rr.user_email
        completed_at.present? ? "#{email} (Completed, #{completed_at})" : "#{email} (Sent)"
      end

      serialized_recommendation_responses.join('; ')
    when "StarRatingResponse"
      response.details.star_rating_question_option_name
    when "LongTextResponse"
      ActionView::Base.full_sanitizer.sanitize(response.details.value)
    else
      response.details.value
    end
  end

  def deferral(submission)
    submission.submission_status_change_logs.where(status: "deferred")&.order(:created_at)&.last
  end

  def deferred_at(submission)
    deferral(submission)&.created_at&.strftime("%b %d, %Y %I:%M %p %Z")
  end

  def deferred_reason(submission)
    deferral(submission)&.display_reasons(true)&.join('; ')
  end

  def withdrawal(submission)
    submission.submission_status_change_logs.where(status: "withdrawn")&.order(:created_at)&.last
  end

  def withdrawn_at(submission)
    withdrawal(submission)&.created_at&.strftime("%b %d, %Y %I:%M %p %Z")
  end

  def withdrawn_reason(submission)
    withdrawal(submission)&.display_reasons(true)&.join('; ')
  end

  def status_last_updated_at(submission)
    submission.submission_status_change_logs.order(:updated_at).last&.updated_at&.strftime("%b %d, %Y %I:%M %p %Z")
  end

  def program_status(submission)
    submission.internal? ? 'Internal' : 'Authorized'
  end

  def submittals(submission)
    submission.submission_status_change_logs.where(status: "submitted")
  end

  def submitted_at(submission)
    submittals(submission)&.order(:created_at)&.last&.created_at&.strftime("%b %d, %Y %I:%M %p %Z")
  end

  def tags(object)
    object.tags.pluck(:name).join('; ')
  end

  def submission_content_by_template_csv_filename(template_name)
    template_name.split(/([ _-])/)
                 .map(&:capitalize)
                 .join.gsub("&", "and")
                 .gsub("@", "at")
                 .gsub(/[^a-zA-Z0-9_-]/, "")
                 .tr(" ", "_") +
      "_" + DateTime.now.getlocal.strftime("%Y%m%d%H%M") + ".csv"
  end

  def submission_content_by_program_name_and_term_csv_filename(slug)
    slug.split(/([ _-])/)
        .map(&:capitalize)
        .join.gsub("&", "and")
        .gsub("@", "at")
        .gsub(/[^a-zA-Z0-9_-]/, "")
        .tr(" ", "_") +
      ".csv"
  end

  def submission_content_csv_headers
    if submission_type == 'application'
      application_content_csv_headers
    else
      form_content_csv_headers
    end
  end

  def application_content_csv_headers
    [
      "Preferred First Name",
      "Preferred Last Name",
      "Profile First Name",
      "Profile Last Name",
      "Profile Email",
      "Student ID",
      "#{program_alias} Name",
      "Location(s)",
      "Program Country(ies)",
      "Program City(ies)",
      "Internal/Authorized",
      "Term Name",
      "Term Start Date",
      "Term End Date",
      "Term Tags",
      "Application Status",
      "Application Template",
      "Application Tag",
      "Application Created On",
      "Application Submitted On",
      "Application Status Last Updated On",
      "Deferred On",
      "Deferred Reason",
      "Withdrawn On",
      "Withdrawn Reason",
      "Review Rating",
      "Review Notes"
    ]
  end

  def form_content_csv_headers
    [
      "Profile First Name",
      "Profile Last Name",
      "Profile Email",
      "Student ID",
      "#{program_alias} Name",
      "Location(s)",
      "Program Country(ies)",
      "Program City(ies)",
      "Internal/Authorized",
      "Term Name",
      "Term Start Date",
      "Term End Date",
      "Term Tags",
      "Application Status",
      "Form Template",
      "Form Tag",
      "Form Created On",
      "Form Submitted On",
      "Form Status Last Updated On",
      "Review Rating",
      "Review Notes"
    ]
  end

  def submissions_for_content_report
    return @submissions_for_content_report if @submissions_for_content_report.present?

    submissions = client_account.submissions

    submissions = submission_type == 'application' ? submissions.application : submissions.form

    submissions.includes(
      :submission_status,
      :template,
      :short_text_responses,
      :long_text_responses,
      :date_responses,
      :signature_responses,
      :recommendation_requests,
      :payment_responses,
      :submission_review,
      :star_rating_responses,
      multiple_choice_response_groupings: [multiple_choice_responses: [:multiple_choice_question_option]],
      dropdown_response_groupings: [dropdown_responses: [:dropdown_question_option]],
      user: [:traveler_info],
      program_range: [:term_name, program: [:primary_client_account, program_locations: [:via_country]]]
    ).where(id: submission_ids_for_report)
  end

  def submission_ids_for_report
    report_by == 'form_groupings' ? corresponding_form_ids : submission_ids
  end

  def corresponding_form_ids
    Submission.where(id: submission_ids).flat_map { |sub| sub.corresponding_forms.pluck(:id) }
  end

  def program_cities(locations)
    locations.map { |loc| loc.city&.strip }.compact.sort.join("; ")
  end

  def program_countries(locations)
    locations.map { |loc| loc.country&.strip }.uniq.compact.sort.join("; ")
  end

  def non_respondable_types
    [
      'FileDownloadQuestion',
      'VideoQuestion',
      'HeaderQuestion',
      'DividerQuestion',
      'ParagraphQuestion'
    ]
  end
end