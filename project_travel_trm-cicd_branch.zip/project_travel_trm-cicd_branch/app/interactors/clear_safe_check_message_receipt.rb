# frozen_string_literal: true

class ClearSafeCheckMessageReceipt
  include Interactor

  delegate :phone_number, :plans_user, :safe_check_message_receipt, to: :context

  def call
    context.plans_user = safe_check_message_receipt.plans_user
    context.phone_number = plans_user.user.safe_check_phone_number
    context.receipt_uuid = safe_check_message_receipt.receipt_uuid
    context.safe_check_message = safe_check_message_receipt.safe_check_message

    safe_check_message_receipt.update(
      delivered_at: nil,
      failed_at: nil,
      failure_message: nil,
      message_sid: nil,
      queued_at: nil,
      sent_at: DateTime.current.utc,
      sent_from: nil,
      sent_to: phone_number
    )
  end
end
