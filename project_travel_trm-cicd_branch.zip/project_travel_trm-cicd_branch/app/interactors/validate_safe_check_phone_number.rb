# frozen_string_literal: true

class ValidateSafeCheckPhoneNumber
  include Interactor

  delegate :phone_number, to: :context

  def call
    context.response = twilio_service.validate(phone_number: phone_number)
  rescue Twilio::REST::RestError
    context.fail!
  end

  private

  def twilio_service
    @twilio_service ||= TwilioService.new(
      ENV["TWILIO_SAFE_CHECK_MESSAGING_SERVICE_SID"],
      ENV["TWILIO_SAFE_CHECK_STATUS_CALLBACK"]
    )
  end
end
