# frozen_string_literal: true

class UpdatePlanDates
  include Interactor

  delegate :plan, to: :context

  def call
    locations = plan.locations
    plan.end_date = locations.maximum(:end_date)
    plan.start_date = locations.minimum(:start_date)

    plan.save if plan.changed?
  end
end
