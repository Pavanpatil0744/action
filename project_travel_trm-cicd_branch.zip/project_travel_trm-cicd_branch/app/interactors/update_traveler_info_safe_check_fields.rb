# frozen_string_literal: true

class UpdateTravelerInfoSafeCheckFields
  include Interactor

  delegate :safe_check_enrollment_status, :safe_check_phone_number, :traveler, to: :context

  def call
    traveler_info = traveler.traveler_info

    traveler_info.update(
      safe_check_enrollment_status: safe_check_enrollment_status,
      safe_check_phone_number: safe_check_phone_number
    )

    plans_users = PlansUser.where(user_id: traveler.id)
    plans_users.each do |plan_user|
      ReportPlanUser.find_by_plans_users_id(plan_user.id)&.update(sync_required: true)
      UpdateReportPlanUser.perform_in(10.seconds, plan_user.id)
    end
  end
end
