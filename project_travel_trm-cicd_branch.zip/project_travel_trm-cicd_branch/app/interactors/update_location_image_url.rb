# frozen_string_literal: true

class UpdateLocationImageUrl
  include Interactor

  delegate :location, to: :context

  def call
    locality = location.locality
    results = unsplash_service.retrieve_image("#{locality},cityscape")

    if results.empty?
      results = unsplash_service.retrieve_image(
        "#{location.country_common_name},cityscape"
      )
    end

    image_url = results.any? ? results[0][:urls][:full] : ""

    location.image_url = image_url
  end

  private

  def unsplash_service
    @unsplash_service ||= UnsplashService.new
  end
end
