# frozen_string_literal: true

class SendNewTravelerPlanInvitation
  include Interactor

  delegate :client_account, :plan, :traveler, to: :context

  def call
    admin_role = traveler.admin_role?
    client_account_logo = client_account.logo_url
    plan_name = plan.name
    traveler_id = traveler.id

    if client_account.sso?
      SendGrid::SendViaTravelSsoLoginMailer.perform_async(
        admin_role,
        client_account_logo,
        plan_name,
        traveler_id
      )
    else
      SendGrid::SendViaTravelPasswordResetMailer.perform_async(
        admin_role,
        client_account_logo,
        plan_name,
        traveler_id
      )
    end
  end
end
