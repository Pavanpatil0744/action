# frozen_string_literal: true

class SendSafeCheckMessage
  include Interactor::Organizer

  organize CreateSafeCheckMessageReceipt, SendSafeCheckSmsMessage, SendSafeCheckEmail
end
