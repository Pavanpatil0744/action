# frozen_string_literal: true

class CreateSafeCheckMessageReceipt
  include Interactor

  delegate :client_user,
           :phone_number,
           :plans_user,
           :receipt_uuid,
           :safe_check_message,
           to: :context

  def call
    traveler = plans_user.user

    context.phone_number = traveler.safe_check_phone_number
    context.receipt_uuid = SecureRandom.uuid
    context.safe_check_message_receipt = SafeCheckMessageReceipt.create(
      receipt_uuid: receipt_uuid,
      sent_at: DateTime.current.utc,
      sent_to: phone_number,
      plans_user: plans_user,
      safe_check_message: safe_check_message
    )
  end
end
