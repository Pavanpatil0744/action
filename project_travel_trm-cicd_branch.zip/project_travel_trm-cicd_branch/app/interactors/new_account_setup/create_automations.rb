# frozen_string_literal: true

class NewAccountSetup::CreateAutomations
  include Interactor

  delegate :client_account, to: :context

  def call
    return unless client_account.enrollment?

    feature_list = client_account.client_feature_list

    feature_list.update(mailer_automations: true) unless feature_list.mailer_automations?

    return if client_account.phase_1_automations_created?

    applications_automation_type = AutomationType.find_by_identifier("applications")
    application_status_changes_to_accepted_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_accepted"
    )
    application_status_changes_to_precondition = AutomationPrecondition.find_by_identifier(
      "application_status_changes_to"
    )
    application_status_qualifier = AutomationQualifier.find_by_identifier("application_status")
    application_program_origin_is_authorized_condition = AutomationCondition.find_by_identifier(
      "application_program_origin_is_authorized"
    )
    application_program_origin_is_internal_condition = AutomationCondition.find_by_identifier(
      "application_program_origin_is_internal"
    )
    application_program_origin_is_precondition = AutomationPrecondition.find_by_identifier(
      "application_program_origin_is"
    )
    application_program_origin_qualifier = AutomationQualifier.find_by_identifier(
      "application_program_origin"
    )
    send_traveler_mailer_action = AutomationAction.find_by_identifier("send_traveler_mailer")
    application_accepted_button_target = AutomationButtonTarget.find_by_identifier(
      "traveler_programs_tab"
    )
    application_accepted_button_text = "Commit"
    application_accepted_subject = "Your Acceptance Decision for {{PROGRAM NAME}} from "\
                                   "{{TERM START DATE}} to {{TERM END DATE}}"

    client_account.automations.create(
      automation_action: send_traveler_mailer_action,
      automation_type: applications_automation_type,
      automation_mailers_attributes: [
        {
          automation_button_target: application_accepted_button_target,
          body: authorized_program_acceptance_body,
          button_text: application_accepted_button_text,
          subject: application_accepted_subject
        }
      ],
      automation_triggers_attributes: [
        {
          automation_precondition: application_status_changes_to_precondition,
          automation_qualifier: application_status_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: application_status_changes_to_accepted_condition.id }
          ]
        },
        {
          automation_precondition: application_program_origin_is_precondition,
          automation_qualifier: application_program_origin_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: application_program_origin_is_authorized_condition.id }
          ]
        }
      ],
      name: "Authorized Program Application Acceptance"
    )

    client_account.automations.create(
      automation_action: send_traveler_mailer_action,
      automation_type: applications_automation_type,
      automation_mailers_attributes: [
        {
          automation_button_target: application_accepted_button_target,
          body: internal_program_acceptance_body,
          button_text: application_accepted_button_text,
          subject: application_accepted_subject
        }
      ],
      automation_triggers_attributes: [
        {
          automation_precondition: application_status_changes_to_precondition,
          automation_qualifier: application_status_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: application_status_changes_to_accepted_condition.id }
          ]
        },
        {
          automation_precondition: application_program_origin_is_precondition,
          automation_qualifier: application_program_origin_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: application_program_origin_is_internal_condition.id }
          ]
        }
      ],
      name: "Internal Program Application Acceptance"
    )

    client_account.update(phase_1_automations_created: true)

    return if client_account.phase_2_automations_created?

    application_deadline_is_1_day_in_the_future_condition = AutomationCondition.find_by_identifier(
      "application_deadline_is_1_day_in_the_future"
    )
    application_deadline_is_3_days_in_the_future_condition = AutomationCondition.find_by_identifier(
      "application_deadline_is_3_days_in_the_future"
    )
    application_deadline_is_7_days_in_the_future_condition = AutomationCondition.find_by_identifier(
      "application_deadline_is_7_days_in_the_future"
    )
    application_deadline_is_precondition = AutomationPrecondition.find_by_identifier(
      "application_deadline_is"
    )
    application_deadline_qualifier = AutomationQualifier.find_by_identifier("application_deadline")
    application_is_started_condition = AutomationCondition.find_by_identifier(
      "application_is_started"
    )
    application_is_precondition = AutomationPrecondition.find_by_identifier("application_is")
    application_qualifier = AutomationQualifier.find_by_identifier("application")
    application_status_changes_to_incomplete_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_incomplete"
    )
    application_status_changes_to_submitted_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_submitted"
    )
    application_status_changes_to_in_review_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_in_review"
    )
    application_status_changes_to_conditionally_accepted_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_conditionally_accepted"
    )
    application_status_changes_to_conditionally_approved_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_conditionally_approved"
    )
    application_status_changes_to_approved_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_approved"
    )
    application_status_changes_to_committed_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_committed"
    )
    application_status_changes_to_nominated_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_nominated"
    )
    application_status_changes_to_waitlisted_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_waitlisted"
    )
    application_status_changes_to_deferred_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_deferred"
    )
    application_status_changes_to_withdrawn_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_withdrawn"
    )
    application_status_changes_to_not_accepted_condition = AutomationCondition.find_by_identifier(
      "application_status_changes_to_not_accepted"
    )
    application_status_is_incomplete_condition = AutomationCondition.find_by_identifier(
      "application_status_is_incomplete"
    )
    application_status_is_precondition = AutomationPrecondition.find_by_identifier(
      "application_status_is"
    )
    traveler_application_target = AutomationButtonTarget.find_by_identifier(
      "traveler_application"
    )
    application_started_button_text = "View Application"
    application_started_subject = "You Have Just Started an Application for {{PROGRAM NAME}} "\
                                  "{{TERM START DATE}} to {{TERM END DATE}}"

    client_account.automations.create(
      automation_action: send_traveler_mailer_action,
      automation_type: applications_automation_type,
      automation_mailers_attributes: [
        {
          automation_button_target: traveler_application_target,
          body: application_deadline_reminder_body,
          button_text: "Complete Now",
          subject: "Your {{PROGRAM NAME}} Application is Due Soon!"
        }
      ],
      automation_triggers_attributes: [
        {
          automation_precondition: application_deadline_is_precondition,
          automation_qualifier: application_deadline_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: application_deadline_is_1_day_in_the_future_condition.id },
            { automation_condition_id: application_deadline_is_3_days_in_the_future_condition.id },
            { automation_condition_id: application_deadline_is_7_days_in_the_future_condition.id }
          ]
        },
        {
          automation_precondition: application_status_is_precondition,
          automation_qualifier: application_status_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: application_status_is_incomplete_condition.id }
          ]
        }
      ],
      name: "Application Deadline Reminder"
    )

    client_account.automations.create(
      automation_action: send_traveler_mailer_action,
      automation_type: applications_automation_type,
      automation_mailers_attributes: [
        {
          automation_button_target: traveler_application_target,
          body: application_status_change_for_all_programs_body,
          button_text: "Continue",
          subject: "Application Status Update for {{PROGRAM NAME}} from {{TERM START DATE}} "\
                   "to {{TERM END DATE}}"
        }
      ],
      automation_triggers_attributes: [
        {
          automation_precondition: application_status_changes_to_precondition,
          automation_qualifier: application_status_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: application_status_changes_to_incomplete_condition.id },
            { automation_condition_id: application_status_changes_to_submitted_condition.id },
            { automation_condition_id: application_status_changes_to_in_review_condition.id },
            { automation_condition_id: application_status_changes_to_conditionally_accepted_condition.id },
            { automation_condition_id: application_status_changes_to_conditionally_approved_condition.id },
            { automation_condition_id: application_status_changes_to_approved_condition.id },
            { automation_condition_id: application_status_changes_to_committed_condition.id },
            { automation_condition_id: application_status_changes_to_nominated_condition.id },
            { automation_condition_id: application_status_changes_to_waitlisted_condition.id },
            { automation_condition_id: application_status_changes_to_deferred_condition.id },
            { automation_condition_id: application_status_changes_to_withdrawn_condition.id },
            { automation_condition_id: application_status_changes_to_not_accepted_condition.id }
          ]
        }
      ],
      name: "Application Status Change for All #{programs_alias.titleize}"
    )

    client_account.automations.create(
      automation_action: send_traveler_mailer_action,
      automation_type: applications_automation_type,
      automation_mailers_attributes: [
        {
          automation_button_target: traveler_application_target,
          body: authorized_application_started_body,
          button_text: application_started_button_text,
          subject: application_started_subject
        }
      ],
      automation_triggers_attributes: [
        {
          automation_precondition: application_is_precondition,
          automation_qualifier: application_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: application_is_started_condition.id }
          ]
        },
        {
          automation_precondition: application_program_origin_is_precondition,
          automation_qualifier: application_program_origin_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: application_program_origin_is_authorized_condition.id }
          ]
        }
      ],
      name: "Authorized Application Started"
    )

    client_account.automations.create(
      automation_action: send_traveler_mailer_action,
      automation_type: applications_automation_type,
      automation_mailers_attributes: [
        {
          automation_button_target: traveler_application_target,
          body: internal_application_started_body,
          button_text: application_started_button_text,
          subject: application_started_subject
        }
      ],
      automation_triggers_attributes: [
        {
          automation_precondition: application_is_precondition,
          automation_qualifier: application_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: application_is_started_condition.id }
          ]
        },
        {
          automation_precondition: application_program_origin_is_precondition,
          automation_qualifier: application_program_origin_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: application_program_origin_is_internal_condition.id }
          ]
        }
      ],
      name: "Internal Application Started"
    )

    client_account.update(phase_2_automations_created: true)

    forms_automation_type = AutomationType.find_by_identifier("forms")
    form_is_added_condition = AutomationCondition.find_by_identifier("form_is_added")
    form_is_precondition = AutomationPrecondition.find_by_identifier("form_is")
    form_qualifier = AutomationQualifier.find_by_identifier("form")
    form_deadline_is_1_day_in_the_future_condition = AutomationCondition.find_by_identifier(
      "form_deadline_is_1_day_in_the_future"
    )
    form_deadline_is_10_days_in_the_future_condition = AutomationCondition.find_by_identifier(
      "form_deadline_is_10_days_in_the_future"
    )
    form_deadline_is_7_days_in_the_future_condition = AutomationCondition.find_by_identifier(
      "form_deadline_is_7_days_in_the_future"
    )
    form_deadline_is_precondition = AutomationPrecondition.find_by_identifier(
      "form_deadline_is"
    )
    form_deadline_qualifier = AutomationQualifier.find_by_identifier("form_deadline")
    form_status_changes_to_not_started_condition = AutomationCondition.find_by_identifier(
      "form_status_changes_to_not_started"
    )
    form_status_changes_to_started_condition = AutomationCondition.find_by_identifier(
      "form_status_changes_to_started"
    )
    form_status_changes_to_submitted_condition = AutomationCondition.find_by_identifier(
      "form_status_changes_to_submitted"
    )
    form_status_changes_to_accepted_condition = AutomationCondition.find_by_identifier(
      "form_status_changes_to_accepted"
    )
    form_status_changes_to_precondition = AutomationPrecondition.find_by_identifier(
      "form_status_changes_to"
    )
    form_status_is_not_started_condition = AutomationCondition.find_by_identifier(
      "form_status_is_not_started"
    )
    form_status_is_started_condition = AutomationCondition.find_by_identifier(
      "form_status_is_started"
    )
    form_status_is_precondition = AutomationPrecondition.find_by_identifier("form_status_is")
    form_status_qualifier = AutomationQualifier.find_by_identifier("form_status")
    send_traveler_mailer_action = AutomationAction.find_by_identifier("send_traveler_mailer")

    client_account.automations.create(
      automation_action: send_traveler_mailer_action,
      automation_type: forms_automation_type,
      automation_mailers_attributes: [
        {
          automation_button_target: AutomationButtonTarget.find_by_identifier("traveler_programs_tab"),
          body: form_added_body,
          button_text: "Complete Forms",
          subject: "You have forms to fill out!"
        }
      ],
      automation_triggers_attributes: [
        {
          automation_precondition: form_is_precondition,
          automation_qualifier: form_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: form_is_added_condition.id }
          ]
        }
      ],
      name: "Form Added"
    )

    client_account.automations.create(
      automation_action: send_traveler_mailer_action,
      automation_type: forms_automation_type,
      automation_mailers_attributes: [
        {
          automation_button_target: AutomationButtonTarget.find_by_identifier("traveler_programs_tab"),
          body: form_status_changes_to_body,
          button_text: "Continue",
          subject: "Form Status Update for {{PROGRAM NAME}}, {{TERM START DATE}} to {{TERM END DATE}}"
        }
      ],
      automation_triggers_attributes: [
        {
          automation_precondition: form_status_changes_to_precondition,
          automation_qualifier: form_status_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: form_status_changes_to_not_started_condition.id },
            { automation_condition_id: form_status_changes_to_started_condition.id },
            { automation_condition_id: form_status_changes_to_submitted_condition.id },
            { automation_condition_id: form_status_changes_to_accepted_condition.id }
          ]
        }
      ],
      name: "Form Status Change for All #{programs_alias.titleize}"
    )

    client_account.automations.create(
      automation_action: send_traveler_mailer_action,
      automation_type: forms_automation_type,
      automation_mailers_attributes: [
        {
          automation_button_target: AutomationButtonTarget.find_by_identifier("traveler_form"),
          body: form_deadline_reminder_body,
          button_text: "Complete now",
          subject: "Your {{FORM NAME}} is due soon!"
        }
      ],
      automation_triggers_attributes: [
        {
          automation_precondition: form_deadline_is_precondition,
          automation_qualifier: form_deadline_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: form_deadline_is_1_day_in_the_future_condition.id },
            { automation_condition_id: form_deadline_is_7_days_in_the_future_condition.id },
            { automation_condition_id: form_deadline_is_10_days_in_the_future_condition.id }
          ]
        },
        {
          automation_precondition: form_status_is_precondition,
          automation_qualifier: form_status_qualifier,
          automation_trigger_conditions_attributes: [
            { automation_condition_id: form_status_is_not_started_condition.id },
            { automation_condition_id: form_status_is_started_condition.id }
          ]
        }
      ],
      name: "Form Deadline Reminder"
    )
  end

  private

  def application_deadline_reminder_body
    <<~HTML
      <body>
        <h3>Hello {{FIRST NAME}},</h3>
        <p>&nbsp;</p>
        <p>
          This is a reminder that the application for {{PROGRAM NAME}} is due on
          {{APPLICATION DEADLINE}}.
        </p>
        <p>&nbsp;</p>
        <p>Click below to complete your application.</p>
      </body>
    HTML
  end

  def application_status_change_for_all_programs_body
    <<~HTML
      <body>
        <h3>Hello {{FIRST NAME}},</h3>
        <p>&nbsp;</p>
        <p>
          You have a new application status for {{PROGRAM NAME}} from {{TERM START DATE}}
          to {{TERM END DATE}}.
        </p>
        <p>&nbsp;</p>
        <p>Application status: {{APPLICATION STATUS}}</p>
      </body>
    HTML
  end

  def authorized_application_started_body
    <<~HTML
      <body>
        <h3>Hello {{FIRST NAME}},</h3>
        <p>&nbsp;</p>
        <p>Congratulations!</p>
        <p>&nbsp;</p>
        <p>
          You have started your {{HOME CAMPUS}} application for the following authorized
          #{program_alias}: {{PROGRAM NAME}} from {{TERM START DATE}} to {{TERM END DATE}}.
        </p>
        <p>&nbsp;</p>
        <p>
          In addition to completing the {{HOME CAMPUS}} application you've just started, you
          also need to fulfill the {{PROGRAM NAME}} application requirements found on the
          {{PROGRAM ORGANIZATION NAME}} website.
        </p>
        <p>&nbsp;</p>
        <p>
          To continue with your {{HOME CAMPUS}} application or track its progress, click
          the link below.
        </p>
        <p>&nbsp;</p>
        <p>#{client_account.authorized_programs_mailer_text}</p>
      </body>
    HTML
  end

  def authorized_program_acceptance_body
    <<~HTML
      <body>
        <h3>Hello {{FIRST NAME}},</h3>
        <p>&nbsp;</p>
        <p>Congratulations!</p>
        <p>&nbsp;</p>
        <p>
          You&rsquo;ve been accepted to {{PROGRAM NAME}} from {{TERM START DATE}}
          to {{TERM END DATE}}.
        </p>
        <p>&nbsp;</p>
        <p>Next steps:</p>
        <ul>
          <li>
            Click "Commit" on your application to let {{HOME CAMPUS}} know you
            intend to go on the #{program_alias} provided by {{PROGRAM ORGANIZATION NAME}}
          </li>
          <li>Complete {{HOME CAMPUS}} pre-departure requirements</li>
          <li>Complete {{PROGRAM ORGANIZATION NAME}} requirements</li>
        </ul>
      </body>
    HTML
  end

  def internal_application_started_body
    <<~HTML
      <body>
        <h3>Hello {{FIRST NAME}},</h3>
        <p>&nbsp;</p>
        <p>
          You have just started an application for {{PROGRAM NAME}} from
          {{TERM START DATE}} to {{TERM END DATE}}. Click the button below to continue!
        </p>
      </body>
    HTML
  end

  def internal_program_acceptance_body
    <<~HTML
      <body>
        <h3>Hello {{FIRST NAME}},</h3>
        <p>&nbsp;</p>
        <p>Congratulations!</p>
        <p>&nbsp;</p>
        <p>
          You&rsquo;ve been accepted to {{PROGRAM NAME}} from {{TERM START DATE}}
          to {{TERM END DATE}}. Take the next step by committing to the #{program_alias}
          and completing your pre-departure requirements.
        </p>
        <p>&nbsp;</p>
      </body>
    HTML
  end

  def form_deadline_reminder_body
    <<~HTML
      <body>
        <h3>Hi {{FIRST NAME}},</h3>
        <p>&nbsp;</p>
        <p>
          This is a reminder that the {{FORM NAME}} for {{PROGRAM NAME}} is due on
          {{FORM DEADLINE DATE}}.
        </p>
        <p>&nbsp;</p>
        <p>Click the button below to complete your form.</p>
      </body>
    HTML
  end

  def form_status_changes_to_body
    <<~HTML
      <body>
        <h3>Hi {{FIRST NAME}},</h3>
        <p>&nbsp;</p>
        <p>
          You have a new form status for {{PROGRAM NAME}}, {{TERM START DATE}} to {{TERM END DATE}}.
        </p>
        <p>&nbsp;</p>
        <p>
          Form Name: {{FORM NAME}}
          <br/>Form status: {{FORM STATUS}}
        </p>
      </body>
    HTML
  end

  def form_added_body
    <<~HTML
      <body>
        <h3>Hi {{FIRST NAME}},</h3>
        <p>&nbsp;</p>
        <p>
          An administrator from {{HOME CAMPUS}} has added one or more forms to your profile
          to complete. Click below to sign in to your account and complete your forms.
        </p>
        <p>&nbsp;</p>
        <p>
          Let's do this!
        </p>
      </body>
    HTML
  end

  def program_alias
    @program_alias ||= use_custom_aliases? ? client_account.alias_program.downcase : "program"
  end

  def programs_alias
    @programs_alias ||= use_custom_aliases? ? client_account.alias_programs.downcase : "programs"
  end

  def use_custom_aliases?
    client_account.use_custom_aliases
  end
end
