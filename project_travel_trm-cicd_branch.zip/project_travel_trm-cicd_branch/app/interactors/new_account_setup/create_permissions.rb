# frozen_string_literal: true

class NewAccountSetup::CreatePermissions
  include Interactor

  delegate :client_account, to: :context

  def call
    TokenType.create(
      name: "48 hours token",
      expiration_duration: 48,
      expiration_unit: "hours",
      client_account_id: client_account.id,
      default: true
    )

    client_account_info = client_account.client_account_info

    client_account_info.update(role_settings: default_role_settings)
  end

  private

  def default_role_settings
    {
      organization_settings: {
        view_organization: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_organization: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        view_edit_intake_settings: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_program_alternates: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_tags: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        create_edit_delete_tags: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        custom_fields: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        }
      },
      user_settings: {
        assign_roles_to_users_up_to_your_level: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        assign_user_permissions_for_all_roles: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        assign_user_permissions_for_support_and_occasional_roles: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        invite_admin_users: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        archive_users: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        assign_users_to_programs: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        }
      },
      program_settings: {
        view_as_admin: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        create_slash_edit_slash_duplicate: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_published: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        publish: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        inactivate: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        authorize_programs: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        archive: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        create_edit_custom_brochure_sections: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        }
      },
      report_settings: {
        download_csv: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        }
      },
      events_settings: {
        view_events: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        create_or_edit_events: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        cancel_events: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        invite_travelers_to_events: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        }
      },
      travel_plans_settings: {
        access_travel_plans: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        create_or_edit_travel_plan_and_itinerary: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        delete_travel_plan_and_itinerary: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        edit_plan_and_registration_status: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        view_travelers: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        }
      },
      traveler_information_settings: {
        view_traveler: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        view_and_send_messages: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        view_traveler_profile: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        edit_traveler_profile: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        view_and_create_notes: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_or_delete_note: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        view_program_preferences: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        edit_program_preferences: {
          super_user: false,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        invite_traveler: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        inactivate_traveler: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        }
      },
      application_templates_settings: {
        view: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        delete: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        create_slash_edit_slash_duplicate: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_published: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        publish: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        inactivate: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        }
      },
      traveler_applications_and_forms_settings: {
        create_traveler_applications: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        create_traveler_forms: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        defer_on_behalf_of_traveler: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        destroy_traveler_applications: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        destroy_traveler_forms: {
          super_user: true,
          power_user: false,
          support_user: false,
          occasional_user: false
        },
        edit_traveler_applications: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_traveler_forms: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        transfer_application: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        view_traveler_applications: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        view_traveler_forms: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true,
          traveler: true
        },
        withdraw_on_behalf_of_traveler: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        add_edit_application_note_review_tag: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        add_edit_general_form_note_review_tag: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        }
      },
      form_template_settings: {
        view: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        },
        create_or_duplicate: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_or_delete_draft: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_published: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        publish: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        inactivate: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        }
      },
      recommendation_template_settings: {
        archive: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        create_duplicate: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_delete_draft: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_published_unpublished: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        publish: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        view: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: true
        }
      },
      automation_settings: {
        create_or_edit: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        view: {
          super_user: true,
          power_user: true,
          support_user: true,
          occasional_user: false
        }
      },
      risk_alerts_settings: {
        send_risk_alert_messages: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        view: {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        create_organization_note:
        {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        },
        edit_delete_organization_note:
        {
          super_user: true,
          power_user: true,
          support_user: false,
          occasional_user: false
        }
      }
    }
  end
end
