# frozen_string_literal: true

class NewAccountSetup::CreateIntakeQuestions
  include Interactor

  delegate :client_account, to: :context

  def call
    intake_questions.each do |question|
      client_account.intake_questions.create(question)
    end
  end

  private

  def intake_questions
    [
      {
        identifier: 'first_name',
        name: 'First Name',
        enabled: true,
        required: true,
        order: 1
      },
      {
        identifier: 'last_name',
        name: 'Last Name',
        enabled: true,
        required: true,
        order: 2
      },
      {
        identifier: 'traveler_type',
        name: 'Traveler Type',
        enabled: true,
        required: true,
        order: 3
      },
      {
        identifier: 'home_institution',
        name: 'Home Institution',
        enabled: true,
        required: true,
        order: 4
      },
      {
        identifier: 'traveler_goals',
        name: 'Traveler Goals / Motivation',
        enabled: true,
        required: true,
        order: 5
      },
      {
        identifier: 'previous_travel_experience',
        name: 'Previous Traveler Experience',
        enabled: true,
        required: true,
        order: 6
      },
      {
        identifier: 'passport',
        name: 'Passport',
        enabled: true,
        required: true,
        order: 7
      },
      {
        identifier: 'countries_of_citizenship',
        name: 'Countries of Citizenship',
        enabled: true,
        required: true,
        order: 8
      },
      {
        identifier: 'questions_or_concerns',
        name: 'Questions / Concerns',
        enabled: true,
        required: true,
        order: 9
      },
      {
        identifier: 'financial_information',
        name: 'Financial Information',
        enabled: true,
        required: true,
        order: 10
      },
      {
        identifier: 'financial_aid',
        name: 'Financial Aid',
        enabled: true,
        required: true,
        order: 11
      },
      {
        identifier: 'particiation_certainty',
        name: 'Participation Certainty',
        enabled: true,
        required: true,
        order: 12
      },
      {
        identifier: 'honors_program',
        name: 'Honors Program',
        enabled: false,
        required: false,
        order: 13
      },
      {
        identifier: 'preferred_pronouns',
        name: 'Preferred Pronouns',
        enabled: false,
        required: false,
        order: 14
      },
      {
        identifier: 'academic_major',
        name: 'Academic Major',
        enabled: false,
        required: false,
        order: 15
      },
      {
        identifier: 'academic_minor',
        name: 'Academic Minor',
        enabled: false,
        required: false,
        order: 16
      },
      {
        identifier: 'year_in_school',
        name: 'Year in School',
        enabled: false,
        required: false,
        order: 17
      },
      {
        identifier: 'anticipated_graduation_year',
        name: 'Anticipated Graduation Year',
        enabled: false,
        required: false,
        order: 18
      },
      {
        identifier: 'cumulative_gpa',
        name: 'Cumulative GPA',
        enabled: false,
        required: false,
        order: 19
      },
      {
        identifier: 'first_generation_status',
        name: 'First-Generation Status',
        enabled: false,
        required: false,
        order: 20
      },
      {
        identifier: 'veteran_status',
        name: 'Veteran Status',
        enabled: false,
        required: false,
        order: 21
      }
    ].freeze
  end
end