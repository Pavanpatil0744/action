# frozen_string_literal: true

class NewAccountSetup::Base
  include Interactor::Organizer

  organize CreatePermissions, CreateAutomations, CreateIntakeQuestions
end
