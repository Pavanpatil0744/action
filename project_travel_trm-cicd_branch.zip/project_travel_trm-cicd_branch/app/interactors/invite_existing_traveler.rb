# frozen_string_literal: true

class InviteExistingTraveler
  include Interactor::Organizer

  organize CreatePlansUser, ForceAddPlanDetails, SendTravelerPlanInvitation
end
