# frozen_string_literal: true

class AddQuestionToTemplateLayout
  include Interactor

  delegate :question, to: :context

  def call
    question_id = question.id.to_s
    template = context.template
    template_layout = template.template_layout
    layout = template_layout.layout
    last_layout_position = layout.empty? ? [0, 0] : layout.last["position"]
    new_row_value = (last_layout_position[0].to_i + 1).to_s
    new_item = { "id" => question_id, "position" => [new_row_value, "3"] }
    new_layout = layout.push(new_item)

    template_layout.update(layout: new_layout)
  end
end
