# frozen_string_literal: true

class ResendSafeCheckMessage
  include Interactor::Organizer

  organize ClearSafeCheckMessageReceipt, SendSafeCheckSmsMessage, SendSafeCheckEmail
end
