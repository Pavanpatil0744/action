# frozen_string_literal: true

class SendSafeCheckSmsMessage
  include Interactor

  delegate :phone_number,
           :receipt_uuid,
           :safe_check_message,
           :safe_check_message_receipt,
           to: :context

  def call
    client_account = safe_check_message.client_account
    message_body = "#{client_account.org_name}: #{safe_check_message.safe_check_message_type.short_text} Click to view & reply."
    subdomain = client_account.client_account_info.subdomain
    safe_check_url = "https://#{subdomain}.#{Rails.configuration.front_end_uri}safecheck/checkin/#{receipt_uuid}"
    shortened_safe_check_url = SafeCheckLink.shorten(safe_check_url)
    utc_timestamp = DateTime.current.utc

    begin
      response = twilio_service.send_message(
        message_body: message_body + "\n\n" + shortened_safe_check_url,
        phone_number: phone_number
      )

      safe_check_message_receipt.update(message_sid: response.sid, queued_at: utc_timestamp)
    rescue Twilio::REST::RestError => e
      message = e.message.split("\n")[1].strip

      safe_check_message_receipt.update(failed_at: utc_timestamp, failure_message: message)
    end
  end

  private

  def twilio_service
    @twilio_service ||= TwilioService.new(
      ENV["TWILIO_SAFE_CHECK_MESSAGING_SERVICE_SID"],
      ENV["TWILIO_SAFE_CHECK_STATUS_CALLBACK"]
    )
  end
end
