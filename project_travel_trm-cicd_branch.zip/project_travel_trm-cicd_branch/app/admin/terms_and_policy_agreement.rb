# frozen_string_literal: true

ActiveAdmin.register TermsAndPolicyAgreement do
  menu(
    if: proc { current_admin_user.email.include?("+aa") },
    label: "Terms of Service",
    priority: 4
  )
  permit_params(:term_of_services, :privacy_policy, :creator_id)

  controller do
    actions(:all, except: %i[destroy edit])
  end

  form(title: "TermsAndPolicyAgreement") do |f|
    inputs("Details") do
      input(:term_of_services)
      input(:privacy_policy)
    end

    f.hidden_field(:creator_id, value: current_admin_user.id)

    actions
  end
end
