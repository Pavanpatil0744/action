# frozen_string_literal: true

ActiveAdmin.register TokenType do
  menu parent: "Resources"
  config.remove_action_item :destroy

  permit_params :name, :client_account_id, :expiration_duration, :expiration_unit, :default

  config.batch_actions = true

  controller do
    actions :all
  end

  index do
    column("Id", sortable: :id, &:id)
    column("Client Account") do |token_type|
      token_type&.client_account&.org_name
    end
    column("Token Type Name", sortable: :name, &:name)
    column("Expiration Duration", sortable: :expiration_duration, &:expiration_duration)
    column("Expiration Unit", sortable: :expiration_unit, &:expiration_unit)
    column("Default", &:default)

    actions defaults: false do |token_type|
      unless token_type.default
        item(
          "Make it default",
          make_default_admin_token_type_path(token_type),
          class: "member_link",
          data: {
            confirm: "Token type will be made as default. Are you sure?"
          },
          method: :patch
        )
      end
    end
  end
  action_item :make_default, only: :show, if: proc { !token_type.default }, priority: 2 do
    link_to(
      "Make it default",
      make_default_admin_automation_path(token_type),
      data: {
        confirm: "Token type will be made as default. Are you sure?"
      },
      method: :patch
    )
  end

  member_action :make_default, method: :patch do
    resource_id = resource.id

    TokenType.where(client_account_id: resource.client_account_id, default: true).update_all(default: false)

    if resource.update(default: true)
      return redirect_to(
        admin_token_types_path,
        alert: "Token Type is #{resource_id}, made default"
      )
    else
      return redirect_to(
        admin_token_types_path,
        alert: "Token Type #{resource_id} has not been default"
      )
    end
  end
end
