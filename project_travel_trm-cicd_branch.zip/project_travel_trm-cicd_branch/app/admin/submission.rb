# frozen_string_literal: true

ActiveAdmin.register Submission do
  config.remove_action_item :destroy

  menu parent: "Resources"

  includes :client_account, :submission_type, :template, :user

  filter :id
  filter :submission_type_identifier,
         as: :select,
         label: "Type",
         collection: {
           "Application" => "application",
           "Form" => "form",
           "Recommendation" => "recommendation"
         }
  filter :client_account_org_name, as: :string, label: "Client Account"
  filter :template_name, as: :string, label: "Template"
  filter :recommendation_requests_token, as: :string, label: "Recommendation Request Token"
  filter :user_email, as: :string, label: "Email"
  filter :user_first_name, as: :string, label: "First Name"
  filter :user_last_name, as: :string, label: "Last Name"

  controller do
    actions :all, except: %i[new edit]

    def scoped_collection
      if current_admin_user.email.include? "internal"
        Submission.includes(:client_account)
                  .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
                  .references(:client_accounts)
                  .with_deleted
      else
        Submission.with_deleted
      end
    end

    def index
      @page_title = "Submissions"

      super
    end

    def show
      @page_title = "#{resource.type.capitalize} ##{resource.id}"

      super
    end

    def destroy
      if resource.deleted?
        return redirect_to(admin_submissions_path, alert: "Submission has already been deleted")
      end

      corresponding_application_id = resource.corresponding_application_id
      resource_id = resource.id

      if resource.application?
        transfer_chain = resource.transfer_chain
        transferred = transfer_chain.length > 1

        if transferred && transfer_chain.first == resource
          SubmissionTransferLog.find_by(submission_id: resource_id).destroy
        elsif transferred && transfer_chain.last == resource
          SubmissionTransferLog.find_by(new_submission_id: resource_id).destroy
        elsif transferred
          return redirect_to(
            admin_submissions_path,
            alert: "Unable to delete submission #{resource_id}, submission has been transferred multiple times"
          )
        end
      end

      if resource.destroy
        if corresponding_application_id
          ReportFormGrouping.find_by_submission_id(corresponding_application_id)
                            &.update(sync_required: true)
          UpdateReportFormGrouping.perform_in(10.seconds, corresponding_application_id)
        end

        user = User.find_by_email("admin@via-trm.com")

        resource.submission_status_change_logs.create(
          reasons: [],
          status: "deleted",
          user_id: user.id,
          user_email: user.email,
          user_first_name: user.first_name || "",
          user_last_name: user.last_name || ""
        )

        redirect_to(
          admin_submissions_path,
          notice: "Submission #{resource_id} successfully deleted"
        )
      else
        redirect_to(admin_submissions_path, alert: "Unable to delete submission #{resource_id}")
      end
    end
  end

  breadcrumb do
    links = [link_to("Admin", admin_root_path)]

    links << link_to("Submissions", admin_submissions_path) if params["action"] == "show"

    links
  end

  index do
    column("Id", sortable: :id, &:id)

    column("Type", sortable: "submission_types.identifier") do |submission|
      submission.type.capitalize
    end

    column("Client Org Name", sortable: "client_accounts.org_name", &:client_account_org_name)
    column("Title", sortable: "templates.name", &:template_name)
    column("Email", sortable: "users.email", &:user_email)
    column("First Name", sortable: "users.first_name", &:user_first_name)
    column("Last Name", sortable: "users.last_name", &:user_last_name)

    column("Created At", sortable: "submissions.created_at") do |submission|
      submission.created_at.strftime("%b %d, %Y %I:%M %p %Z")
    end

    column("Updated At", sortable: "submissions.updated_at") do |submission|
      submission.updated_at.strftime("%b %d, %Y %I:%M %p %Z")
    end

    column("Deleted At", sortable: "submissions.deleted_at") do |submission|
      submission.deleted_at&.strftime("%b %d, %Y %I:%M %p %Z")
    end

    actions defaults: false do |submission|
      item(
        "View",
        admin_submission_path(submission),
        class: "member_link"
      )

      unless submission.deleted?
        item(
          "Delete",
          admin_submission_path(submission),
          class: "member_link",
          data: {
            confirm: "Submission will be deleted and no longer viewable within Via. Are you sure?"
          },
          method: :delete
        )
      end

      if submission.deleted?
        item(
          "Restore",
          restore_admin_submission_path(submission),
          class: "member_link",
          data: {
            confirm: "Submission will be restored and viewable within Via. Are you sure?"
          },
          method: :patch
        )
      end
    end
  end

  show do
    panel "#{submission.type.capitalize} Details" do
      attributes_table_for(submission) do
        client_account = submission.client_account
        program = submission.program
        program_range = submission.program_range
        submission_status_change_logs = submission.submission_status_change_logs
        user = submission.user

        row :id
        row("Type") { submission.type.capitalize }
        row("Client Org Name") { client_account.org_name }
        row("Title") { submission.template_name }
        row("Email") { user&.email }
        row("First Name") { user&.first_name }
        row("Last Name") { user&.last_name }
        row("Admin Status") { submission.status.titleize }
        row("Traveler Status") { submission.traveler_status&.titleize }

        row("Decision Release") do
          submission.form? ? false : submission.subject_to_decision_release?
        end

        row("Authorized Program") do
          submission.recommendation? ? nil : client_account != program.primary_client_account
        end

        row("Program Id") { submission.recommendation? ? nil : program.id }
        row :program_title
        row("Program Term Id") { submission.recommendation? ? nil : program_range.id }

        row("Program Term Start Date") do
          submission.recommendation? ? nil : program_range.start_date.to_date
        end

        row("Program Term End Date") do
          submission.recommendation? ? nil : program_range.end_date.to_date
        end

        row("Created At") { submission.created_at.strftime("%b %d, %Y %I:%M %p %Z") }

        row("Deferred At") do
          deferrals = submission_status_change_logs.where(status: "deferred")

          deferrals&.order(:created_at)&.last&.created_at&.strftime("%b %d, %Y %I:%M %p %Z")
        end

        row("Submitted At") do
          submittals = submission_status_change_logs.where(status: "submitted")

          submittals&.order(:created_at)&.last&.created_at&.strftime("%b %d, %Y %I:%M %p %Z")
        end

        row("Withdrawn At") do
          withdrawals = submission_status_change_logs.where(status: "withdrawn")

          withdrawals&.order(:created_at)&.last&.created_at&.strftime("%b %d, %Y %I:%M %p %Z")
        end

        row("Deleted At") { submission.deleted_at&.strftime("%b %d, %Y %I:%M %p %Z") }
      end
    end
  end

  action_item :destroy, only: :show, if: proc { !submission.deleted? }, priority: 1 do
    link_to(
      "Delete",
      admin_submission_path(submission),
      data: {
        confirm: "Submission will be deleted and no longer viewable within Via. Are you sure?"
      },
      method: :delete
    )
  end

  action_item :restore, only: :show, if: proc { submission.deleted? }, priority: 2 do
    link_to(
      "Restore",
      restore_admin_submission_path(submission),
      data: {
        confirm: "Submission will be restored and viewable within Via. Are you sure?"
      },
      method: :patch
    )
  end

  action_item :show_status_change_log, only: :show, priority: 3 do
    link_to("Show Status Change Log", show_status_change_log_admin_submission_path(submission))
  end

  member_action :show_status_change_log, method: :get do
    history_log = resource.submission_status_change_logs.with_deleted.order(created_at: :asc)
    type = resource.type

    render(
      partial: "show_status_change_log",
      locals: { type: type, history_log: history_log, submission_id: resource.id }
    )
  end

  member_action :restore, method: :patch do
    resource_id = resource.id

    if resource.program_range&.deleted?
      return redirect_to(
        admin_submissions_path,
        alert: "Unable to restore submission #{resource_id}, term has been deleted"
      )
    elsif !resource.deleted?
      return redirect_to(
        admin_submissions_path,
        alert: "Submission #{resource_id} has already been restored"
      )
    end

    resource.restore(recursive: true)

    if resource.application?
      resource.submission_transfer_logs.with_deleted.each(&:restore)

      resource.corresponding_forms.with_deleted.each do |corresponding_form|
        corresponding_form.restore(recursive: true)
      end
    end

    user = User.find_by_email("admin@via-trm.com")

    resource.submission_status_change_logs.create(
      reasons: [],
      status: "restored",
      user_id: user.id,
      user_email: user.email,
      user_first_name: user.first_name || "",
      user_last_name: user.last_name || ""
    )

    redirect_to(admin_submissions_path, notice: "Submission #{resource_id} successfully restored")
  end
end
