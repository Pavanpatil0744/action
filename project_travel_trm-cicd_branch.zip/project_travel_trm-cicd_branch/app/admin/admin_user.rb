# frozen_string_literal: true

ActiveAdmin.register AdminUser do
  before_action :find_user, only: %i[show update destroy]

  menu priority: 1

  permit_params :email, :password, :password_confirmation

  controller do
    actions :all

    def create
      if via_admin_user
        email = admin_user_params[:email].downcase
        admin_user = AdminUser.new(admin_user_params)

        if admin_user.save
          redirect_to(
            admin_admin_users_path,
            notice: "Admin user #{email} has been created!"
          )
        else
          redirect_to(new_admin_admin_user_path, notice: "Unable to create admin user.")
        end
      else
        action_restricted
      end
    end

    def show
      action_restricted unless via_admin_user || self_admin_user
    end

    def update
      if via_admin_user
        @admin_user.assign_attributes(admin_user_params)

        @admin_user.save ? success_redirect : failure_redirect
      elsif @admin_user == current_admin_user
        password_params = admin_user_params.except(:email)

        @admin_user.assign_attributes(password_params)

        @admin_user.save ? success_redirect : failure_redirect
      else
        action_restricted
      end
    end

    def destroy
      email = @admin_user.email

      if via_admin_user && !self_admin_user
        @admin_user.destroy

        redirect_to(
          admin_admin_users_path,
          notice: "Admin user #{email} has been deleted."
        )
      else
        action_restricted
      end
    end

    def action_methods
      if via_admin_user
        super
      else
        super - ["destroy"]
      end
    end

    private

    def admin_user_params
      permitted_params[:admin_user]
    end

    def action_restricted
      redirect_to(:back, alert: "Action restricted.")
    end

    def failure_redirect
      errors = @admin_user.errors.full_messages.join(", ")

      @admin_user.reload

      redirect_to(:back, alert: "Failed to update: #{errors}")
    end

    def find_user
      @admin_user = AdminUser.find(permitted_params[:id])
    end

    def self_admin_user
      @admin_user == current_admin_user
    end

    def success_redirect
      redirect_to(
        admin_admin_user_path(@admin_user),
        notice: "Credentials for admin user #{@admin_user.email} have been updated."
      )
    end

    def via_admin_user
      current_admin_user.email == "admin@via-trm.com"
    end
  end

  filter :email_contains, label: "Email"

  index do
    column :email

    column("Created At", sortable: :created_at) do |admin_user|
      admin_user.created_at.strftime("%b %d, %Y %I:%M %p %Z")
    end

    column("Updated At", sortable: :updated_at) do |admin_user|
      admin_user.updated_at.strftime("%b %d, %Y %I:%M %p %Z")
    end

    actions
  end

  member_action :edit, method: :get do
    self_admin_user = current_admin_user.id == params[:id].to_i
    via_admin_user = current_admin_user.email == "admin@via-trm.com"

    unless self_admin_user || via_admin_user
      redirect_to(admin_admin_users_path, alert: "Action restricted.")
    end
  end

  form do |f|
    f.inputs do
      f.input :email
      f.input :password
      f.input :password_confirmation
    end

    f.actions
  end
end
