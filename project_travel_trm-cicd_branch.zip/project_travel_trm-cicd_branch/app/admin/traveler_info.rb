# frozen_string_literal: true

ActiveAdmin.register TravelerInfo do
  menu false

  config.action_items.delete_if { |item| item.display_on?(:show) }

  controller do
    actions :all, only: %i[index show]
  end
end
