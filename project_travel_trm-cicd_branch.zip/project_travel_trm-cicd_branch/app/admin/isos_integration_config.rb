# frozen_string_literal: true

ActiveAdmin.register IsosIntegrationConfig do
  filter(:client_account)
  menu(label: "ISOS Data Dump", parent: "Integration Configs")
  permit_params(:client_account_id, :via_global, :via_travel)

  controller do
    actions(:all)

    def scoped_collection
      if current_admin_user.email.include?("internal")
        IsosIntegrationConfig.includes(:client_account)
                             .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
                             .references(:client_accounts)
      else
        IsosIntegrationConfig.all
      end
    end

    def show
      @page_title = "ISOS Data Dump Config ##{resource.id}"

      super
    end
  end

  index(title: "ISOS Data Dump Configs") do
    column(:client_account)
    column(:via_global)
    column(:via_travel)

    actions
  end

  form do |_f|
    inputs "Details" do
      input(
        :client_account_id,
        as: :select,
        collection: ClientAccount.select(:id, :org_name).order(:org_name).uniq
      )
      input(:via_global, label: "Via Global")
      input(:via_travel, label: "Via Travel")
    end

    actions
  end

  action_item(:show_data_dump_log, only: :show) do
    link_to(
      "Show Data Dump Log",
      show_data_dump_log_admin_isos_integration_config_path(isos_integration_config)
    )
  end

  member_action(:show_data_dump_log, method: :get) do
    client_account = resource.client_account
    data_dump_log = client_account.isos_data_dump_logs.order(created_at: :desc)

    render(
      partial: "show_data_dump_log",
      locals: { data_dump_log: data_dump_log, org_name: client_account.org_name }
    )
  end
end
