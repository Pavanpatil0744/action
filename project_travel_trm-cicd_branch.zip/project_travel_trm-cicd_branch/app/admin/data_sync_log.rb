# frozen_string_literal: true

ActiveAdmin.register DataSyncLog do
  actions(:index, :show)
  menu(label: "Via TRM - Data Sync", parent: "Integration Logs")

  controller do
    actions :all

    def scoped_collection
      if current_admin_user.email.include?("internal")
        DataSyncLog.includes(:client_account)
                   .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
                   .references(:client_accounts)
      else
        DataSyncLog.all
      end
    end
  end

  filter(
    :client_account,
    collection: ClientAccount.joins(:data_sync_logs).order(:org_name).distinct
  )
  filter(:integration_type, as: :select, collection: DataSyncLog.integration_types)
  filter(:email)
  filter(:filename)
  filter(:success, as: :select, collection: DataSyncLog.successes.transform_keys(&:titleize))
  filter(:batch)
  filter(:created_at, label: "Timestamp", as: :date_range)

  index(title: "Via TRM Data Sync Logs") do
    column(:client_account)
    column(:integration_type)
    column(:email)
    column(:filename)
    column(:success) { |data_sync_log| data_sync_log.success.titleize }
    column(:batch) { |data_sync_log| data_sync_log.batch? ? "Yes" : "No" }
    column(:total_count)

    column("Timestamp", sortable: :created_at) do |data_sync_log|
      data_sync_log.created_at.strftime("%b %d, %Y %I:%M %p %Z")
    end

    actions
  end

  show(title: proc { |data_sync_log| "Via TRM Data Sync Log ##{data_sync_log.id}" }) do
    attributes_table_for(data_sync_log) do
      row(:client_account)
      row(:integration_type)
      row(:email)
      row(:filename)
      row(:success) { |data_sync_log| data_sync_log.success.titleize }
      row(:batch) { |data_sync_log| data_sync_log.batch? ? "Yes" : "No" }
      row(:total_count)
      row(:success_count)
      row(:failure_count)

      row("Processing Errors") do |data_sync_log|
        columns do
          data_sync_log.processing_errors.each do |key, value|
            ul { li("#{key} - #{value}") }
          end
        end
      end

      row("Timestamp") do |data_sync_log|
        data_sync_log.created_at.strftime("%b %d, %Y %I:%M %p %Z")
      end
    end
  end

  action_item :download_csv, only: :show do
    link_to("Download CSV", download_csv_admin_data_sync_log_path(resource)) if resource.file.present?
  end

  member_action :download_csv, method: :get do
    data_sync_log = DataSyncLog.find(params[:id])

    redirect_to(data_sync_log.file.url(query: { "response-content-disposition" => "attachment;" }))
  end

  action_item :show_response_body, only: :show do
    if resource.response_body.present?
      link_to("Show Response Body", show_response_body_admin_data_sync_log_path(resource))
    end
  end

  member_action :show_response_body, method: :get do
    data_sync_log = DataSyncLog.find(params[:id])

    render(plain: data_sync_log.response_body)
  end
end
