# frozen_string_literal: true

ActiveAdmin.register IntegrationSftpSchedule do
  menu(label: "Via TRM - SFTP Schedule", parent: "Integration Configs")
  permit_params(
    :client_account_id,
    :time,
    :time_zone,
    :monday,
    :tuesday,
    :wednesday,
    :thursday,
    :friday,
    :saturday,
    :sunday
  )

  controller do
    actions :all
    def scoped_collection
      if current_admin_user.email.include?("internal")
        IntegrationSftpSchedule.includes(:client_account)
                               .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
                               .references(:client_accounts)
      else
        IntegrationSftpSchedule.all
      end
    end

    def show
      @page_title = "Via TRM SFTP Schedule ##{resource.id}"

      super
    end
  end

  filter(
    :client_account,
    as: :select,
    collection: ClientAccount.joins(:integration_sftp_schedules).in_order
  )

  index(title: "Via TRM SFTP Schedules") do
    column(:client_account)
    column(:time)
    column(:time_zone)
    column(:monday)
    column(:tuesday)
    column(:wednesday)
    column(:thursday)
    column(:friday)
    column(:saturday)
    column(:sunday)

    actions
  end

  show(title: proc { |integration_sftp_schedule| "Via TRM SFTP Schedule ##{integration_sftp_schedule.id}" }) do
    attributes_table_for(integration_sftp_schedule) do
      row(:client_account)
      row(:time)
      row(:time_zone)
      row(:monday)
      row(:tuesday)
      row(:wednesday)
      row(:thursday)
      row(:friday)
      row(:saturday)
      row(:sunday)
      row(:created_at)
      row(:updated_at)
    end
  end

  form do |_f|
    time_collection = [
      "12:00 AM",
      "1:00 AM",
      "2:00 AM",
      "3:00 AM",
      "4:00 AM",
      "5:00 AM",
      "6:00 AM",
      "7:00 AM",
      "8:00 AM",
      "9:00 AM",
      "10:00 AM",
      "11:00 AM",
      "12:00 PM",
      "1:00 PM",
      "2:00 PM",
      "3:00 PM",
      "4:00 PM",
      "5:00 PM",
      "6:00 PM",
      "7:00 PM",
      "8:00 PM",
      "9:00 PM",
      "10:00 PM",
      "11:00 PM"
    ]

    inputs "Basic" do
      input(
        :client_account_id,
        as: :select,
        collection: ClientAccount.joins(:integration_config).select(:id, :org_name).order(:org_name).uniq
      )
      input(:time, as: :select, selected: "3:00 AM", collection: time_collection)
      input(
        :time_zone,
        as: :select,
        collection: ActiveSupport::TimeZone.all.map { |tz| tz.tzinfo.name }.sort,
        selected: "America/New_York"
      )
      input(:monday)
      input(:tuesday)
      input(:wednesday)
      input(:thursday)
      input(:friday)
      input(:saturday)
      input(:sunday)
    end

    actions
  end
end
