# frozen_string_literal: true

ActiveAdmin.register User do
  before_action :find_user, only: %i[edit show update destroy]
  before_action :validate_role, only: %i[create update]

  form partial: "user"

  menu parent: "Resources"

  permit_params :archived,
                :client_account_id,
                :email,
                :first_name,
                :inactive,
                :last_name,
                :password,
                :password_confirmation,
                :via_abroad,
                :via_international,
                :via_contracts,
                :inbound_permission,
                role_ids: []

  controller do
    actions :all

    def scoped_collection
      if current_admin_user.email.include?("internal")
        User.includes(:client_account, :roles)
            .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
            .references(:client_accounts)
            .without_role(:pt_master)
      else
        User.includes(:roles).without_role(:pt_master)
      end
    end

    def create
      email = user_params[:email].downcase
      existing_user = User.find_by_email(email)

      if existing_user
        return redirect_to(
          new_admin_user_path,
          notice: "A user with that email address already exists."
        )
      end

      user = User.new(user_params)
      client_account = user.client_account

      if user.admin_role?
        user.admin_sign_in = true
        user.build_client_user_info

        TravelerInvitation.where("LOWER(email) = ?", email)&.destroy_all
      else
        TravelerInvitation.where("LOWER(email) = ?", email).update_all(completed: true)
      end

      user.clients << client_account
      profile = user.build_profile(email: email, first_name: user.first_name, last_name: user.last_name, signup_source: "Active Admin")
      traveler_info = user.build_traveler_info(profile: profile)

      traveler_info.build_passport

      if user.save
        UpdateReportTraveler.perform_in(10.seconds, user.id) if user.is_traveler?
        Inbound::CreateInboundUsersWorker.perform_async(user.id, user.client.id, true) if user.validate_inbound_permission?

        redirect_to(admin_users_path, notice: "User #{email} has been created!")
      else
        redirect_to(
          new_admin_user_path,
          notice: "Hmm... seems like there's something missing, please try again."
        )
      end
    end

    def update
      old_email = @user.email
      old_permission = @user.inbound_permission
      @user.assign_attributes(user_params)
      @user.assign_attributes(
        first_name: user_params[:first_name]&.strip || "",
        last_name: user_params[:last_name]&.strip || ""
      )

      admin_role = @user.admin_role?
      @user.admin_sign_in = admin_role
      @user.skip_reconfirmation!

      if @user.save
        @user.client_travelers.find_or_create_by(client_account: client_account)

        if @user.validate_inbound_permission?
          Inbound::CreateInboundUsersWorker.perform_async(@user.id, @user.client.id, true)
        end

        update_user_submissions
        update_user_associations

        if old_email != @user.reload.email
          @user.sso_authentications.destroy_all
        end

        if (old_email != @user.email || old_permission != @user.inbound_permission) && @user.validate_inbound_permission?
          Inbound::UpdateInboundUsersWorker.perform_async(@user.id)
        end

        success_redirect
      else
        failure_redirect
      end
    end

    def destroy
      if @user.admin_role?
        if default_message_recipient.nil?
          redirect_to(
            :back,
            alert: "An account's only default message recipient cannot be deleted."
          )
        end

        update_admin_associations
      end

      user_email = @user.email

      if @user.destroy
        TravelerDeletionHistory.create(
          admin_email: "admin@via-trm.com",
          admin_first_name: "admin@via-trm.com",
          admin_id: "admin@via-trm.com",
          admin_last_name: "admin@via-trm.com",
          traveler_email: user_email
        )

        redirect_to(admin_users_path, notice: "User #{user_email} has been deleted.")
      else
        redirect_to(:back, alert: "Unable to delete user.")
      end
    end

    private

    def user_params
      permitted_params[:user]
    end

    def find_user
      @user = User.includes(client_account: :client_account_info).find(permitted_params[:id])
    end

    def assigned_traveler_ids
      client_account&.assigned_admins&.where(client_user_id: @user.id)&.pluck(:traveler_id)
    end

    def client_account
      @user.client_account || @user.clients.first
    end

    def default_message_recipient
      return if client_account&.default_message_recipients&.one? && @user.default_message_recipient

      client_account&.default_message_recipients&.where&.not(id: @user.id, inactive: true, archived: true)&.first
    end

    def admin_program_contacts
      @user.program_contacts
    end

    def program_contact_ids
      admin_program_contacts.pluck(:program_id)
    end

    def validate_role
      role_ids = user_params[:role_ids].reject(&:empty?)

      redirect_to(:back, alert: "Select a user role.") and return if role_ids.empty?
      redirect_to(:back, alert: "Only a single role may be assigned.") and return if role_ids.count > 1
    end

    def failure_redirect
      errors = @user.errors.full_messages.join(", ")

      @user.reload

      redirect_to(:back, alert: "Failed to update. #{errors}")
    end

    def success_redirect
      redirect_to(admin_user_path(@user), notice: "User #{@user.email} successfully updated.")
    end

    def update_admin_associations
      admin_program_contacts&.update_all(user_id: default_message_recipient&.id)

      client_account&.programs&.where(id: program_contact_ids)&.each do |program|
        program_range_ids = program.program_range_ids

        UpdateReportProgram.perform_in(10.seconds, client_account.id, program.id)

        program_range_ids.each do |program_range_id|
          UpdateReportProgramRange.perform_in(10.seconds, client_account.id, program_range_id)
        end
      end

      assigned_traveler_ids&.each do |traveler_id|
        UpdateReportTraveler.perform_in(10.seconds, traveler_id)
      end
    end

    def update_traveler_associations
      user_details = {
        email: user_params[:email],
        first_name: user_params[:first_name],
        last_name: user_params[:last_name]
      }

      @user.event_travelers.update_all(user_details)
      @user.profile&.update(user_details)
      @user.report_event_travelers.update_all(user_details)
      @user.report_submissions.update_all(user_details)
      @user.report_traveler&.update(
        email: user_details[:email],
        profile_first_name: user_details[:first_name],
        profile_last_name: user_details[:last_name]
      )
    end

    def update_user_associations
      @user.admin_role? ? update_admin_associations : update_traveler_associations
    end

    def update_user_submissions
      @user.submissions.each do |submission|
        submission.short_text_responses.each do |response|
          source = response.question.sourceable

          next unless source.is_a?(TravelerInfoField)

          source_name = source.name

          next unless %w[email first_name last_name].include?(source_name)

          case source_name
          when "email"
            response.update(value: user_params[:email])
          when "first_name"
            response.update(value: user_params[:first_name])
          when "last_name"
            response.update(value: user_params[:last_name])
          end
        end
      end
    end
  end

  filter(:id)
  filter(:first_name_contains, label: "First Name")
  filter(:last_name_contains, label: "Last Name")
  filter(:email_contains, label: "Email")
  filter(:client_account_org_name_contains, label: "Organization Name")
  filter(:via_abroad, as: :check_boxes, collection: [['Via Abroad', true]], label: 'Via Abroad')
  filter(:via_contracts, as: :check_boxes, collection: [['Via Contracts', true]], label: 'Via Contracts')
  filter(:via_international, as: :check_boxes, collection: [['Via International', true]], label: 'Via International')
  filter(:inactive)
  filter(:archived)
  filter(:roles, collection: proc { Role.order(:name) }, label: "Role")

  index download_links: false do
    column(:id)
    column(:first_name)
    column(:last_name)
    column(:email)
    column(:authentication_token)

    column("Role", class: "role-width", sortable: 'roles.name') do |user|
      user.roles.all.pluck(:name).map(&:titleize).uniq.join(", ")
    end

    column("Client Org Name") do |user|
      user&.client_account&.org_name || user&.clients&.first&.org_name
    end

    column("Client ID", class: "client-id-width") do |user|
      user&.client_account&.id || user&.clients&.first&.id
    end

    column("Created On", class: "date-width") do |user|
      user.created_at.to_date.strftime("%b %-d, %Y")
    end

    column(:inactive)
    column(:archived)
    column("Become User", class: "become-user-width") do |user|
      # client = user&.client_account || user&.clients&.first
      # link_to("Login", "", id: "user-#{user.id}", class: 'become-user') if client

      admin_sign_in = user.admin_sign_in
      client = user&.client_account || user&.clients&.first
      email = user.email
      freemium = client&.free?
      front_end_uri = Rails.configuration.front_end_uri
      global = client&.via_global?
      lead = client&.lead?
      masquerade = "visitor/masquerade"
      protocol = Rails.env.development? ? "http" : "https"
      subdomain = client&.client_account_info&.subdomain
      token = user.authentication_token
      travel = client&.via_travel?
      user_id = user.id
      url = "#{protocol}://#{subdomain}.#{front_end_uri}#{masquerade}/#{token}/#{email}/#{!admin_sign_in}/#{user_id}/#{client.id}/#{subdomain}/#{freemium}/#{lead}/#{global}/#{travel}"

      link_to("Login", url, target: "_blank") if client
    end

    actions
  end

  show do
    panel "User Details" do
      attributes_table_for user do
        row(:id)
        row(:first_name)
        row(:last_name)
        row(:email)
        row(:authentication_token)
        row("Role") { user.roles.all.pluck(:name).map(&:humanize).join(", ") }
        row(:via_abroad)
        row(:via_contracts)
        row(:via_international)

        row("Client") do
          user.client_account&.org_name || user.clients.first&.org_name
        end

        row("Created On") { user.created_at.to_date }
        row("Last Updated") { user.updated_at.to_date }
        row(:inactive)
        row(:archived)

        row("Traveler Info") do
          if user.traveler_info
            link_to("Show Traveler Info", admin_traveler_info_path(user.traveler_info))
          end
        end

        row("Become User") do
          # client = user&.client_account || user&.clients&.first
          # link_to("Login", "", id: "user-#{user.id}", class: 'become-user') if client

          admin_sign_in = user.admin_sign_in
          client = user&.client_account || user&.clients&.first
          email = user.email
          freemium = client&.free?
          front_end_uri = Rails.configuration.front_end_uri
          global = client&.via_global?
          lead = client&.lead?
          masquerade = "visitor/masquerade"
          protocol = Rails.env.development? ? "http" : "https"
          subdomain = client&.client_account_info&.subdomain
          token = user.authentication_token
          travel = client&.via_travel?
          user_id = user.id
          url = "#{protocol}://#{subdomain}.#{front_end_uri}#{masquerade}/#{token}/#{email}/#{!admin_sign_in}/#{user_id}/#{client.id}/#{subdomain}/#{freemium}/#{lead}/#{global}/#{travel}"

          link_to("Login", url, target: "_blank") if client
        end

        row("Sync Now") do
          if user.sso? && user.data_integration?
            link_to("Sync Now", sync_user_path(user))
          end
        end

        row("Show Data from Client Source") do
          if user.sso? && user.http_api?
            link_to "Show Data from Client Source", dialog_admin_user_path(user), 'data-df-dialog': true, 'data-df-icon': true
          end
        end
      end
    end
  end

  member_action :dialog do
    user = User.find(params[:id])
    client_account = user.client
    integration_config = client_account.integration_config
    identifier = user.sso_authentications.first.identifier

    http_client = if client_account.http_v2?
                    Integrations::HttpClientV2.new(client_account, integration_config)
                  else
                    Integrations::HttpClient.new(client_account, integration_config)
                  end

    response = http_client.get_user_data(identifier) || { "data" => { "No data to show" => "" } }

    context = Arbre::Context.new do
      dl do
        dd response.to_s
      end
    end

    render(plain: context)
  end

  # member_action :user_login_link, method: :get do
  #   user = User.find(params[:id])

  #   admin_sign_in = user.admin_sign_in
  #   client = user&.client_account || user&.clients&.first

  #   if client.present?
  #     email = user.email
  #     freemium = client&.free?
  #     front_end_uri = Rails.configuration.front_end_uri
  #     global = client&.via_global?
  #     lead = client&.lead?
  #     masquerade = "visitor/masquerade"
  #     protocol = Rails.env.development? ? "http" : "https"
  #     subdomain = client&.client_account_info&.subdomain
  #     travel = client&.via_travel?
  #     user_id = user.id

  #     token_type = TokenType.find_by_name('Masquerade link token type')
  #     created_token = AuthenticationToken::TokenService.new(user).create_token(token_type)
  #     token = created_token.token

  #     url = "#{protocol}://#{subdomain}.#{front_end_uri}#{masquerade}/#{token}/#{created_token.expires_at}/#{email}/#{!admin_sign_in}/#{user_id}/#{client.id}/#{subdomain}/#{freemium}/#{lead}/#{global}/#{travel}"

  #     render json: { url: url }, status: 200
  #   else
  #     render json: { error: 'Not Found' }, status: :not_found
  #   end
  # end
end
