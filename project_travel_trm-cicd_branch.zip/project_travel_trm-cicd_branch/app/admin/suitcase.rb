# frozen_string_literal: true

ActiveAdmin.register Suitcase do
  menu parent: "Resources"

  includes :term_name, :application_template

  filter :term_name_name_contains, label: "Term Name"
  filter :application_template_name_contains, label: "Application Template Name"
  filter :client_account_org_name,
         label: "Organization Name",
         as: :select,
         collection: ClientAccount.in_order.pluck(:org_name).reject(&:blank?)
  filter :application_deadline, as: :date_range

  controller do
    actions :all, except: %i[new edit create]
  end

  index do
    column("Id", sortable: :id, &:id)

    column("Organization") do |suitcase|
      suitcase&.client_account&.org_name
    end

    column("Term Name") do |suitcase|
      suitcase&.term_name&.name
    end

    column("Application Template") do |suitcase|
      suitcase&.application_template_name
    end

    column("Application Deadline") do |suitcase|
      suitcase.application_deadline&.strftime("%b %-d, %Y")
    end

    actions
  end

  show do
    panel "Term Details" do
      attributes_table_for(suitcase) do
        row :id
        row("Term Name") { suitcase.name }
        row("Client Org Name") { suitcase.client_account.org_name }
        row("Application Template") { suitcase.application_template_name }
        row("Deadline") { suitcase.application_deadline }
        row("Created At") { suitcase.created_at.strftime('%b %d, %Y %I:%M %p %Z') }
        row("Updated At") { suitcase.updated_at.strftime('%b %d, %Y %I:%M %p %Z') }
      end
    end
  end
end
