# frozen_string_literal: true

ActiveAdmin.register IntegrationConfig do
  menu(label: "Via TRM - Data Sync", parent: "Integration Configs")
  permit_params(
    :api_host,
    :api_endpoint,
    :api_http_method,
    :api_username,
    :api_password,
    :api_key_header,
    :api_key_value,
    :api_identifier_key,
    :client_account_id,
    :client_key,
    :integration_type,
    :sftp_request_host,
    :sftp_request_password,
    :sftp_request_port,
    :sftp_request_remote_directory,
    :sftp_request_username,
    :sftp_response_host,
    :sftp_response_identifier_key,
    :sftp_response_password,
    :sftp_response_port,
    :sftp_response_remote_directory,
    :sftp_response_username
  )

  controller do
    actions :all
    def scoped_collection
      if current_admin_user.email.include?("internal")
        IntegrationConfig.includes(:client_account)
                         .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
                         .references(:client_accounts)
      else
        IntegrationConfig.all
      end
    end

    def create
      params["integration_config"].transform_values! { |v| v == "" ? nil : v }

      super
    end

    def show
      @page_title = "Via TRM Data Sync Config ##{resource.id}"

      super
    end

    def update
      params["integration_config"].transform_values! { |v| v == "" ? nil : v }

      super
    end
  end

  filter(:client_account, as: :select, collection: ClientAccount.joins(:integration_config).in_order)
  filter(:client_key)
  filter(:integration_type, as: :select, collection: IntegrationConfig.integration_types)

  index(title: "Via TRM Data Sync Configs") do
    column(:client_account)
    column(:client_key)
    column(:integration_type)

    actions
  end

  show(title: proc { |integration_config| "Via TRM Data Sync Config ##{integration_config.id}" }) do
    panel "Basic" do
      attributes_table_for(integration_config) do
        row(:client_account)
        row(:client_key)
        row(:integration_type)
      end
    end

    api_integration = integration_config.api_integration?

    if api_integration
      panel "API Configuration (http, http_v2)" do
        attributes_table_for(integration_config) do
          row(:api_host) if integration_config.api_host.present?
          row(:api_endpoint) if integration_config.api_endpoint.present?
          row(:api_http_method) if integration_config.api_http_method.present?
          row(:api_username) if integration_config.api_username.present?
          row(:api_password) if integration_config.api_password.present?
          row(:api_key_header) if integration_config.api_key_header.present?
          row(:api_key_value) if integration_config.api_key_value.present?
          row(:api_identifier_key) if integration_config.api_identifier_key.present?
        end
      end
    end

    sftp_integration = integration_config.sftp_integration?

    if sftp_integration
      panel "SFTP Configuration (sftp, sftp_v2)" do
        attributes_table_for(integration_config) do
          row(:sftp_request_host) if integration_config.sftp_request_host
          row(:sftp_response_host) if integration_config.sftp_response_host
          row(:sftp_request_port) if integration_config.sftp_request_port
          row(:sftp_response_port) if integration_config.sftp_response_port
          row(:sftp_request_username) if integration_config.sftp_request_username
          row(:sftp_response_username) if integration_config.sftp_response_username
          row(:sftp_request_password) if integration_config.sftp_request_password
          row(:sftp_response_password) if integration_config.sftp_response_password
          row(:sftp_request_remote_directory) if integration_config.sftp_request_remote_directory
          row(:sftp_response_remote_directory) if integration_config.sftp_response_remote_directory
          row(:sftp_response_identifier_key) if integration_config.sftp_response_identifier_key
        end
      end
    end
  end

  form do |_f|
    inputs "Basic" do
      input(
        :client_account_id,
        as: :select,
        collection: ClientAccount.select(:id, :org_name).order(:org_name).uniq
      )
      input(:client_key)
      input(:integration_type, as: :select, collection: IntegrationConfig.integration_types.keys)
    end

    inputs "API Configuration (http, http_v2)" do
      input(:api_host)
      input(:api_endpoint)
      input(:api_http_method, as: :select, collection: %w[get post http_get])
      input(:api_username)
      input(:api_password)
      input(:api_key_header)
      input(:api_key_value)
      input(:api_identifier_key)
    end

    inputs "SFTP Configuration (sftp, sftp_v2)" do
      input(:sftp_request_host)
      input(:sftp_response_host)
      input(:sftp_request_port)
      input(:sftp_response_port)
      input(:sftp_request_username)
      input(:sftp_response_username)
      input(:sftp_request_password)
      input(:sftp_response_password)
      input(:sftp_request_remote_directory)
      input(:sftp_response_remote_directory)
      input(:sftp_response_identifier_key)
    end

    actions
  end
end
