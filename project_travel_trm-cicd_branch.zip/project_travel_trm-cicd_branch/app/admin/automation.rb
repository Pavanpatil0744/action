# frozen_string_literal: true

ActiveAdmin.register Automation do
  menu parent: "Resources"

  config.remove_action_item :destroy

  filter :id
  filter :automation_type_id, label: "Automation Type"
  filter :client_account_id, label: "Client Account"

  controller do
    actions :all, except: %i[new edit]

    def scoped_collection
      if current_admin_user.email.include? "internal"
        Automation.includes(:client_account)
             .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
             .references(:client_accounts)
             .with_deleted
      else
        Automation.with_deleted
      end
    end

    def destroy
      automation = Automation.find(params[:id])

      if automation.destroy
        redirect_to(admin_automations_path, notice: "Automation #{params[:id]} successfully deleted")
      else
        redirect_to(admin_automations_path, alert: "Unable to delete automation #{params[:id]}")
      end
    end
  end

  index(title: "Automations") do
    column(:id)
    column(:automation_type_id) do |automation|
      automation.automation_type&.display_name
    end
    column("Automation Name") do |automation|
      automation.name
    end
    column("Organization Name") do |automation|
      automation&.client_account&.org_name
    end
    column("Created At", sortable: :created_at) do |automation|
      automation.created_at.strftime("%b %d, %Y %I:%M %p %Z")
    end
    column("Updated At", sortable: :updated_at) do |automation|
      automation.updated_at.strftime("%b %d, %Y %I:%M %p %Z")
    end

    actions defaults: false do |automation|
      item(
        "View",
        admin_automation_path(automation),
        class: "member_link"
      )

      unless automation.deleted?
        item(
          "Delete",
          admin_automation_path(automation),
          class: "member_link",
          data: {
            confirm: "Automation will be deleted and no longer viewable within Via. Are you sure?"
          },
          method: :delete
        )
      end

      if automation.deleted?
        item(
          "Restore",
          restore_admin_automation_path(automation),
          class: "member_link",
          data: {
            confirm: "Automation will be restored and viewable within Via. Are you sure?"
          },
          method: :patch
        )
      end
    end
  end

  show do
    panel "Automation Details" do
      attributes_table_for(automation) do
        row(:id)
        row(:automation_type_id) do |automation|
          automation.automation_type&.display_name
        end
        row("Automation Name") { automation.name }
        row("Organization Name") { automation&.client_account&.org_name }
        row("Status") { automation.active }
        row("Action Selected") { automation.automation_action.display_name }
      end
    end
  end

  action_item :destroy, only: :show, if: proc { !automation.deleted? }, priority: 1 do
    link_to(
      "Delete",
      admin_automation_path(automation),
      data: {
        confirm: "Automation will be deleted and no longer viewable within Via. Are you sure?"
      },
      method: :delete
    )
  end

  action_item :restore, only: :show, if: proc { automation.deleted? }, priority: 2 do
    link_to(
      "Restore",
      restore_admin_automation_path(automation),
      data: {
        confirm: "Automation will be restored and viewable within Via. Are you sure?"
      },
      method: :patch
    )
  end

  member_action :restore, method: :patch do
    resource_id = resource.id

    resource.restore(recursive: true)

    redirect_to(admin_automations_path, notice: "Automation #{resource_id} successfully restored")
  end
end
