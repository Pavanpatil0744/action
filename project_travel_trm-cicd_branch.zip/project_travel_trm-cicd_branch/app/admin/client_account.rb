# frozen_string_literal: true

ActiveAdmin.register ClientAccount do
  before_action :find_client_account, only: %i[edit show update]

  form partial: "client_account"

  menu parent: "Resources"

  permit_params :comment,
                :hidden,
                :org_name,
                :other_admin_limit,
                :state,
                :status,
                :super_user_limit,
                :connect_functionality_start_date,
                client_account_info_attributes: [
                  :description,
                  :department,
                  :phone_number,
                  :phone_country_code,
                  :subdomain,
                  address_attributes: %i[
                    city
                    country
                    secondary_street
                    state
                    street
                    zip
                  ]
                ],
                client_feature_list_attributes: %i[
                  id
                  contracts
                  courses
                  inbound
                  form_builder
                  legacy
                  mailer_automations
                  program_dashboard
                  reports
                  risk_alerts
                  travel_plans
                  vt_dashboard_view
                  traveler_event_beta_dashboards
                  application_beta_dashboards
                  form_beta_dashboards
                  programs_beta_dashboards
                  reports_beta_dashboards
                ],
                custom_integration_fields_attributes: %i[id comma_separated_mapping name _destroy]

  controller do
    actions :all, except: :destroy

    def scoped_collection
      if current_admin_user.email.include?("internal")
        ClientAccount.internal
      else
        ClientAccount.all
      end
    end

    def create
      client_account = ClientAccount.new(permitted_params[:client_account])

      if client_account.save
        NewAccountSetup::Base.call(client_account: client_account)
        CreateDefaultRecommendationTemplate.call(client_account_id: client_account.id)

        redirect_to(
          admin_client_accounts_path,
          notice: "#{client_account.org_name} has been created!"
        )
      else
        flash[:error] = formatted_error(client_account)

        redirect_to(new_admin_client_account_path)
      end
    end

    def update
      client_account_params = permitted_params[:client_account]
      new_state = ClientAccountState.find(client_account_params[:state])
      old_state = @client_account.state
      old_inbound = @client_account.client_feature_list.inbound
      old_contract = @client_account.client_feature_list.contracts

      if new_state != old_state
        comment = client_account_params[:comment]

        if comment.blank?
          return redirect_to(
            :back,
            notice: "Please add a comment when updating a client account's state."
          )
        end

        ClientAccountStateHistory.create(
          client_account: @client_account,
          new_state: new_state,
          old_state: old_state,
          comment: comment
        )

        @client_account.state = new_state
      end

      client_account_params = client_account_params.except(:state, :comment)
      new_org_name = client_account_params[:org_name]
      old_org_name = @client_account.org_name

      @client_account.assign_attributes(client_account_params)

      if @client_account.save
        NewAccountSetup::CreateAutomations.call(client_account: @client_account)

        unless new_org_name == old_org_name
          @client_account.users.travelers.each do |traveler|
            update_report_traveler(traveler.id)
          end

          @client_account.internal_programs.each do |program|
            update_report_program_associations(program)
          end
        end

        new_inbound = @client_account.client_feature_list.inbound
        new_contract = @client_account.client_feature_list.contracts
        onboard_to_inbound = @client_account.onboard_to_inbound

        if (!@client_account.onboard_to_inbound) ||
          (!onboard_to_inbound && old_inbound != new_inbound && new_inbound) ||
          (!onboard_to_inbound && old_contract != new_contract && new_contract)
          @client_account.update(onboard_to_inbound: true)
          Inbound::OnboardOrganizationWorker.perform_async(@client_account.id)
        elsif (onboard_to_inbound && old_inbound != new_inbound && new_inbound) ||
          (onboard_to_inbound && old_contract != new_contract && new_contract)

          Inbound::UpdateOrganizationWorker.perform_async(@client_account.id)
        end

        success_redirect
      else
        failure_redirect
      end
    end

    private

    def find_client_account
      @client_account = ClientAccount.find(permitted_params[:id])
    end

    def failure_redirect
      flash[:error] = formatted_error(@client_account)

      @client_account.reload

      redirect_to edit_admin_client_account_path(@client_account)
    end

    def success_redirect
      redirect_to(
        admin_client_account_path(@client_account),
        notice: "#{@client_account.org_name} successfully updated."
      )
    end

    def formatted_error(client_account)
      error = "<ul>"

      client_account.errors.full_messages.each do |er|
        error += "<li>#{er.gsub('Client account info address', 'Address')}</li>"
      end

      error += "</ul>"

      error
    end

    def update_report_program_associations(program)
      program_id = program.id

      ReportProgram.where(program_id: program_id).update_all(sync_required: true)
      ReportProgramRange.where(program_range_id: program.program_range_ids)
                        .update_all(sync_required: true)

      UpdateReportProgramAssociations.perform_in(10.seconds, program_id)
    end

    def update_report_traveler(traveler_id)
      ReportTraveler.find_by_user_id(traveler_id)&.update(sync_required: true)
      UpdateReportTraveler.perform_in(10.seconds, traveler_id)
    end
  end

  filter(:id_equals, label: "Organization ID")
  filter(:org_name_contains, label: "Organization Name")
  filter(:client_account_info_subdomain_contains, label: "Organization Subdomain")
  filter(
    :status,
    as: :check_boxes,
    collection: ClientAccount.statuses.to_a.map { |o| [o[0].capitalize, o[1]] }.freeze
  )

  index(download_links: false) do
    column(:id)
    column(:org_name)
    column("State") { |client_account| client_account.state.description.capitalize }
    column(:status) { |client_account| client_account.status.capitalize }
    column(:subdomain)
    column(:super_user_limit)
    column(:other_admin_limit)
    column("Created On") { |client_account| client_account.created_at.to_date }
    column("Last Updated") { |client_account| client_account.updated_at.to_date }
    column(:travel_registration)

    actions
  end

  show do
    panel "Client Account Details" do
      attributes_table_for(client_account) do
        row(:id)
        row("Organization Name") { client_account.org_name }
        row(:state) { client_account.state.description.capitalize }
        row(:status) { client_account.status.capitalize }
        row(:subdomain)
        row(:super_user_limit)
        row(:other_admin_limit)
        row("Created On") { client_account.created_at.to_date }
        row("Last Updated") { client_account.updated_at.to_date }
        row(:travel_registration)
        row(:connect_functionality_start_date)
      end
    end

    panel "Client Account Settings" do
      client_account_info = client_account.client_account_info

      attributes_table_for(client_account_info) do
        row(:id)
        row(:show_intake) { client_account_info.show_intake }
        row(:show_program_match) { client_account_info.show_program_match }
        row(:allow_traveler_deferral) { client_account_info.allow_traveler_deferral }
        row(:allow_traveler_sign_up) { client_account_info.allow_traveler_sign_up }
        row(:limit_applications_by_timeframe) { client_account_info.limit_applications_by_timeframe }
      end
    end

    panel "Request to Withdraw Settings" do
      request_to_withdraw_setting = client_account.request_to_withdraw_setting

      attributes_table_for(request_to_withdraw_setting) do
        row(:id)
        row("Request to Withdraw Active") { request_to_withdraw_setting.active }

        if request_to_withdraw_setting.active
          row(:application_statuses) { request_to_withdraw_setting.application_statuses }
        end
      end
    end

    panel "Alternate Settings" do
      alternate_setting = client_account.alternate_setting

      attributes_table_for(alternate_setting) do
        row(:id)
        row(:accept_alternates) { alternate_setting.accept_alternates }
        row(:minimum_alternates) { alternate_setting.minimum_alternates }
        row(:maximum_alternates) { alternate_setting.maximum_alternates }
      end
    end

    if client_account.custom_integration_fields.any?
      panel "Custom Integration Fields" do
        custom_integration_fields = client_account.custom_integration_fields

        custom_integration_fields.each do |cif|
          attributes_table_for(cif) do
            row(:name) { cif.name }
            row("Mapping") { cif.comma_separated_mapping }
          end
        end
      end
    end
  end

  action_item :edit_field_mappings, only: :show, if: proc { client_account.sis? } do
    link_to("Edit Field Mappings", edit_field_mappings_admin_client_account_path(client_account))
  end

  member_action :edit_field_mappings, method: :get do
    render(
      partial: "edit_field_mappings",
      locals: {
        all_field_mappings: IntegrationField.in_order.pluck(:id, :name),
        client_field_mappings: ClientAccountIntegrationField.where(client_account_id: resource.id),
        client_account: resource
      }
    )
  end

  member_action :update_field_mappings, method: :patch do
    resource.client_account_integration_fields.destroy_all

    enabled_fields = params.find_all { |_k, v| v == "enabled" }.map(&:first)

    enabled_fields.each do |enabled_field|
      integration_field = IntegrationField.find_by_name(enabled_field)

      resource.client_account_integration_fields.create!(
        integration_field: integration_field,
        mapping: params["#{enabled_field}_mapping"].split(",")
      )
    end

    redirect_to(
      admin_client_account_path(resource),
      notice: "#{resource.org_name} field mappings successfully updated."
    )
  end
end
