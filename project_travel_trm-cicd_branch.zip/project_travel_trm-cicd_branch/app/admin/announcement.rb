# frozen_string_literal: true

ActiveAdmin.register Announcement do
  menu parent: "Resources"

  permit_params :body, :class, :enabled, :end_time, :parameters, :start_time, :weight

  config.batch_actions = true

  controller do
    actions :all
  end
end
