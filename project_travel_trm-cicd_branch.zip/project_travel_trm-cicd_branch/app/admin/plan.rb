# frozen_string_literal: true

ActiveAdmin.register Plan do
  menu parent: "Resources"

  includes :client_account

  filter :id
  filter :client_account_org_name_contains, label: "Organization Name"
  filter :name_contains, label: "Plan Name"

  controller do
    actions :all, except: %i[new edit]

    def scoped_collection
      if current_admin_user.email.include? "internal"
        Plan.includes(:client_account)
             .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
             .references(:client_accounts)
      else
        Plan.all
      end
    end

    def index
      @page_title = "Plans"

      super
    end

    def destroy
      id = params[:id]
      plan = Plan.find(id)
      program_range = plan.program_range

      if plan.destroy
        if program_range.present?
          ReportProgramRange.find_by(
            client_account_id: plan.client_account_id,
            program_range_id: program_range.id
          ).update(sync_required: true)
          UpdateReportProgramRange.perform_in(10.seconds, plan.client_account_id, program_range.id)
        end

        redirect_to(admin_plans_path, notice: "Plan #{id} successfully deleted")
      else
        redirect_to(admin_plans_path, alert: "Unable to delete plan #{id}")
      end
    end
  end

  index do
    column("Id", sortable: :id, &:id)
    column("Plan Name", sortable: :name, &:name)
    column("Start Date", sortable: :start_date) { |plan| plan.start_date&.strftime("%b %-d, %Y") }
    column("End Date", sortable: :end_date) { |plan| plan.end_date&.strftime("%b %-d, %Y") }
    column("Client Org Name", sortable: "client_accounts.org_name", &:client_account_org_name)
    column("Owner", &:owner)
    column("Created At", sortable: :created_at) { |plan| plan.created_at.strftime("%b %d, %Y %I:%M %p %Z") }

    actions
  end

  show do
    panel "Plan Details" do
      attributes_table_for(plan) do
        row :id
        row("Plan Name") { plan.name }
        row("Start Date") { plan.start_date&.strftime("%b %-d, %Y") }
        row("End Date") { plan.end_date&.strftime("%b %-d, %Y") }
        row("Client Org Name") { plan.client_account.org_name }
        row("Owner") { plan.owner }
        row("Plan Type") { plan.plan_type }
        row("Program Range ID") { plan.program_range_id }
        row("Group") { plan.group }
        row("Private") { plan.private }
        row("Removed") { plan.removed }
        row("Registration Status") { plan.plan_registration_status }
        row("Status") { plan.plan_status }
        row("Created At") { plan.created_at.strftime("%b %d, %Y %I:%M %p %Z") }
      end
    end
  end
end
