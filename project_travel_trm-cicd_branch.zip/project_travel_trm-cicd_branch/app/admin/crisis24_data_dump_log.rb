# frozen_string_literal: true

ActiveAdmin.register Crisis24DataDumpLog do
  actions(:index, :show)
  menu(label: "Crisis24 Data Dump", parent: "Integration Logs")

  controller do
    actions :all

    def scoped_collection
      if current_admin_user.email.include?("internal")
        Crisis24DataDumpLog.includes(:client_account)
                           .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
                           .references(:client_accounts)
      else
        Crisis24DataDumpLog.all
      end
    end
  end

  filter(
    :client_account,
    collection: ClientAccount.joins(:crisis24_data_dump_logs).order(:org_name).distinct
  )
  filter(:filename)
  filter(:success)
  filter(:upload_id)

  index(title: "Crisis24 Data Dump Logs") do
    column(:client_account)
    column(:integration_type) { |data_dump_log| data_dump_log.integration_type.titleize }
    column(:filename)
    column(:success) { |data_dump_log| data_dump_log.success? ? "Yes" : "No" }
    column(:total_count)
    column(:upload_id)

    column("Timestamp", sortable: :created_at) do |data_dump_log|
      data_dump_log.created_at.strftime("%b %d, %Y %I:%M %p %Z")
    end

    actions
  end

  show(title: proc { |data_dump_log| "Crisis24 Data Dump Log ##{data_dump_log.id}" }) do
    attributes_table_for(crisis24_data_dump_log) do
      row(:client_account)
      row(:integration_type) { |data_dump_log| data_dump_log.integration_type.titleize }
      row(:filename)
      row(:success) { |data_dump_log| data_dump_log.success? ? "Yes" : "No" }
      row(:total_count)
      row(:cancellation_count)
      row(:error_message)
      row(:upload_id)

      row("Timestamp") do |data_dump_log|
        data_dump_log.created_at.strftime("%b %d, %Y %I:%M %p %Z")
      end
    end
  end

  action_item :download_xml, only: :show do
    if resource.file.present?
      link_to("Download XML", download_xml_admin_crisis24_data_dump_log_path(resource))
    end
  end

  member_action :download_xml, method: :get do
    data_dump_log = Crisis24DataDumpLog.find(params[:id])

    redirect_to(data_dump_log.file.url(query: { "response-content-disposition" => "attachment;" }))
  end
end
