# frozen_string_literal: true

ActiveAdmin.register Program do
  menu(label: "Programs", parent: "Resources")

  controller do
    actions(:all, except: %i[new edit destroy])

    def scoped_collection
      if current_admin_user.email.include?("internal")
        Program.includes(:client_accounts)
               .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
               .references(:client_accounts)
      else
        Program.all
      end
    end
  end

  filter(:title)
  filter(:slug)
  filter(:status)

  index(title: "Programs", download_links: false) do
    column(:title)
    column(:slug)
    column(:status)
    column(:created_at)

    actions
  end

  show do
    panel("Program Details") do
      attributes_table_for(program) do
        row(:background_photo) do
          image_tag(program.background_photo, class: "my_image_size")
        end

        row(:title)
        row(:slug)
        row(:major)
        row(:college_or_faculty)
        row(:external_application_url)
        row(:is_authorizable)
        row(:language_immersion)
        row(:inactive_by)
        row(:primary_client_account_id)
        row(:status)
        row(:inactive_at)
        row(:created_at)
        row(:updated_at)
      end
    end
  end
end
