# frozen_string_literal: true

ActiveAdmin.register Event do
  menu parent: "Resources"

  config.remove_action_item :destroy

  includes :client_account

  filter :id
  filter :name, label: "Event Name"
  filter :cancelled, label: "Cancelled"
  filter :client_account_org_name_contains, label: "Organization Name"

  controller do
    actions :all, except: %i[new edit]

    def scoped_collection
      if current_admin_user.email.include? "internal"
        Event.includes(:client_account)
             .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
             .references(:client_accounts)
             .with_deleted
      else
        Event.with_deleted
      end
    end

    def destroy
      event = Event.find(params[:id])

      if event.destroy
        redirect_to(admin_events_path, notice: "Event #{params[:id]} successfully deleted")
      else
        redirect_to(admin_events_path, alert: "Unable to delete event #{params[:id]}")
      end
    end
  end

  index do
    column("Id", sortable: :id, &:id)
    column("Client Account") do |event|
      event&.client_account&.org_name
    end
    column("Event Name", sortable: :name, &:name)
    column("Start Date", sortable: :start) { |event| event.start&.strftime("%b %-d, %Y") }
    column("End Date", sortable: :ending) { |event| event.ending&.strftime("%b %-d, %Y") }
    column("Time Zone", sortable: :timezone, &:timezone)
    column("Cancelled", sortable: :cancelled, &:cancelled)

    actions defaults: false do |event|
      item(
        "View",
        admin_event_path(event),
        class: "member_link"
      )

      unless event.deleted?
        item(
          "Delete",
          admin_event_path(event),
          class: "member_link",
          data: {
            confirm: "Event will be deleted and no longer viewable within Via. Are you sure?"
          },
          method: :delete
        )
      end

      if event.deleted?
        item(
          "Restore",
          restore_admin_event_path(event),
          class: "member_link",
          data: {
            confirm: "Event will be restored and viewable within Via. Are you sure?"
          },
          method: :patch
        )
      end
    end
  end

  show do
    panel "Event Details" do
      attributes_table_for(event) do
        row :id
        row("Event Name") { event.name }
        row("Description") { event.description }
        row("Start Date") { event.start&.strftime("%b %-d, %Y") }
        row("End Date") { event.ending&.strftime("%b %-d, %Y") }
        row("Client Org Name") { event.client_account.org_name }
        row("Time Zone") { event.timezone }
        row("Location") { event.location }
        row("Slug") { event.slug }
        row("Cancelled") { event.cancelled }
        row("Created At") { event.created_at }
        row("Updated At") { event.updated_at }
      end
    end
  end

  action_item :destroy, only: :show, if: proc { !event.deleted? }, priority: 1 do
    link_to(
      "Delete",
      admin_event_path(event),
      data: {
        confirm: "Event will be deleted and no longer viewable within Via. Are you sure?"
      },
      method: :delete
    )
  end

  action_item :restore, only: :show, if: proc { event.deleted? }, priority: 2 do
    link_to(
      "Restore",
      restore_admin_event_path(event),
      data: {
        confirm: "Event will be restored and viewable within Via. Are you sure?"
      },
      method: :patch
    )
  end

  member_action :restore, method: :patch do
    resource_id = resource.id

    resource.restore(recursive: true)

    redirect_to(admin_events_path, notice: "Event #{resource_id} successfully restored")
  end
end
