# frozen_string_literal: true

ActiveAdmin.register SendGridMailerHistory do
  actions(:index, :show)
  filter(:client_account)
  filter(:user_id_equals, label: "Recipient ID")
  filter(:sent_to, label: "Recipient Email")
  filter(:queued_at)
  filter(:trigger_display_text, label: "Trigger")
  menu(parent: "Resources")

  controller do
    def scoped_collection
      if current_admin_user.email.include?("internal")
        SendGridMailerHistory.includes(:client_account, :user)
                             .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
                             .references(:client_accounts)
                             .with_deleted
                             .automated_notifications
      else
        SendGridMailerHistory.includes(:client_account, :user).with_deleted.automated_notifications
      end
    end

    def index
      @page_title = "SendGrid Mailer History Records"

      super
    end

    def show
      @page_title = "SendGrid Mailer History Record ##{resource.id}"

      super
    end
  end

  index do
    column("Subject", &:subject)
    column("Queued On", proc { |sgmh| sgmh.queued_at.strftime("%b %d, %Y %I:%M %p %Z") })
    column("Recipient ID", &:user_id)
    column("Recipient First Name", &:user_first_name)
    column("Recipient Last Name", &:user_last_name)
    column("Recipient Email", &:sent_to)
    column(:client_account)

    actions
  end

  show do
    panel "Attributes" do
      attributes_table_for(send_grid_mailer_history) do
        automation = send_grid_mailer_history.automation

        if automation
          initial_log = automation.automation_change_logs.initial
          created_by = User.find_by_id(initial_log.user_id)
          created_on = initial_log.created_at.strftime("%b %d, %Y %I:%M %p %Z")

          most_recent_log = automation.automation_change_logs.most_recent
          last_modified_by = User.find_by_id(most_recent_log.user_id)
          last_modified_on = most_recent_log.created_at.strftime("%b %d, %Y %I:%M %p %Z")
        end

        row(:id)
        row("Subject", &:subject)
        row("Queued On") { |sgmh| sgmh.queued_at.strftime("%b %d, %Y %I:%M %p %Z") }
        row("Recipient ID", &:user_id)
        row("Recipient First Name", &:user_first_name)
        row("Recipient Last Name", &:user_last_name)
        row("Recipient Email", &:sent_to)
        row(:client_account)
        row("Body", &:body)
        row("Button Text", &:button_text)
        row("Button URL", &:button_target)
        row("Automation Type", &:automation_type_display_name)
        row("Automation Name", &:automation_name)
        row("Automation Triggers", &:trigger_display_text)
        row("Automation Last Modified By") { last_modified_by&.email }
        row("Automation Last Modified On") { last_modified_on }
        row("Automation Created By") { created_by&.email }
        row("Automation Created On") { created_on }
      end
    end
  end
end
