# frozen_string_literal: true

ActiveAdmin.register SsoConfiguration do
  menu(label: "Via TRM - SAML", parent: "Integration Configs")

  permit_params :client_account_id,
                :email_attribute,
                :entity_id,
                :identifier_attribute,
                :logout_url,
                :metadata,
                :metadata_strategy,
                :safe_mode,
                :sso_version

  controller do
    actions(:all)

    def scoped_collection
      if current_admin_user.email.include? "internal"
        SsoConfiguration.includes(:client_account)
                        .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
                        .references(:client_accounts)
      else
        SsoConfiguration.all
      end
    end

    def show
      @page_title = "Via TRM SAML Config ##{resource.id}"

      super
    end
  end

  filter(:client_account, collection: proc { ClientAccount.order(:org_name) })

  index(title: "Via TRM SAML Configs") do
    column(:client_account)
    column(:email_attribute)
    column(:identifier_attribute)
    column(:metadata_strategy)
    column(:sso_version)

    actions
  end

  form do |_f|
    inputs "Details" do
      input(
        :client_account_id,
        as: :select,
        collection: ClientAccount.select(:id, :org_name).order(:org_name).uniq
      )
      input(:sso_version, as: :select, collection: %i[1 2])
      input(:metadata_strategy, as: :select, collection: [%w[File file], %w[URL url]])
      input(:metadata)
      input(:entity_id)
      input(:email_attribute)
      input(:identifier_attribute)
      input(:logout_url)
    end

    actions
  end
end
