# frozen_string_literal: true

ActiveAdmin.register_page "Usages" do
 menu priority: 5

  sidebar :filters, partial: 'filter'

  sidebar :search_status, partial: 'search_status', if: proc { params[:id].present? || params[:org_name].present? || params[:start_date].present? || params[:end_date].present? }

  content do
    if params[:id].present? || params[:org_name].present?
      @client_accounts = current_admin_user.email.include?('internal') ? ClientAccount.internal : ClientAccount

      @client_accounts = @client_accounts.where(id: params[:id]) if params[:id].present?
      @client_accounts = @client_accounts.where("client_accounts.org_name ILIKE ?", "%#{params[:org_name]}%") if params[:org_name].present?

      start_date = params[:start_date]
      end_date = params[:end_date]

      usage_data =
        if start_date.present? || end_date.present?
          @client_accounts.usage_data_by_date_range(start_date, end_date)
        else
          @client_accounts.usage_data_counts
        end
    else
      usage_data = ClientAccount.none
    end

    render partial: 'usage', locals: { clients: usage_data.page(params[:page]).per_page(30) }
  end

  page_action :csv, method: :get do
    if params[:id].present? || params[:org_name].present?
      @client_accounts = current_admin_user.email.include?('internal') ? ClientAccount.internal : ClientAccount

      @client_accounts = @client_accounts.where(id: params[:id]) if params[:id].present?
      @client_accounts = @client_accounts.where("client_accounts.org_name ILIKE ?", "%#{params[:org_name]}%") if params[:org_name].present?

      start_date = params[:start_date]
      end_date = params[:end_date]

      usage_data =
        if start_date.present? || end_date.present?
          @client_accounts.usage_data_by_date_range(start_date, end_date)
        else
          @client_accounts.usage_data_counts
        end
    else
      usage_data = ClientAccount.none
    end

    csv = CSV.generate do |csv|
      csv << ['Id', 'Org Name', '# Committed Applications', '# of Travelers ‘Going’ on a Travel Plan',
              '# SafeCheck Message Sent', '# Connects', 'Active feature flags', 'Total Super User Count / Super User Limits',
              'Total Other Admin Count / Other Admin Limits']

      usage_data.each do |client|
        csv << [
          client.id,
          client.org_name,
          client['application_count'],
          client['travelers_count'],
          client['connects_count'],
          client.client_feature_list.attributes.select { |_, v| v == true }.keys.map(&:humanize).join(', '),
          "#{client.users.active.with_role(:super_user).count} / #{client.super_user_limit}",
          "#{client.users.active.with_any_role(:power_user, :occasional_user, :support_user).count} / #{client.other_admin_limit}"
        ]
      end
    end

    send_data csv, type: 'text/csv; charset=windows-1251; header=present', disposition: "attachment; filename=usages_#{DateTime.now.to_s}.csv"
  end

  action_item :add do
    link_to "Export to CSV", admin_usages_csv_path(id: params[:id], org_name: params[:org_name]), method: :get
  end
end
