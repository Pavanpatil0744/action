# frozen_string_literal: true

ActiveAdmin.register_page "Dashboard" do
  menu label: proc { I18n.t("active_admin.dashboard") }, priority: 0

  content title: proc { I18n.t("active_admin.dashboard") } do
    div class: "blank_slate_container", id: "dashboard_default_message" do
      span class: "blank_slate" do
        span I18n.t("active_admin.dashboard_welcome.welcome")
        small I18n.t("active_admin.dashboard_welcome.call_to_action")
      end
    end

    columns do
      column do
        panel "Stats" do
          users = if current_admin_user.email.include?("internal")
                    User.includes(:client_account)
                        .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
                        .references(:client_accounts)
                  else
                    User.external
                  end

          li "Total users: #{users.size}"
          li "Active admin users: #{users.active.admin.size}"
          li "Active traveler users: #{users.active.traveler.size}"
          li "New users created in the last 30 days: #{users.where('users.created_at > ?', 30.days.ago).size}"
        end
      end
    end
  end
end
