# frozen_string_literal: true

ActiveAdmin.register SamlResponseLog do
  actions(:index, :show)
  menu(label: "Via TRM - SAML", parent: "Integration Logs")

  controller do
    actions(:all)

    def scoped_collection
      if current_admin_user.email.include?("internal")
        SamlResponseLog.includes(:client_account)
                       .where("client_accounts.org_name SIMILAR TO (?)", "%CCFC%|%Test%|%Via%")
                       .references(:client_accounts)
      else
        SamlResponseLog.all
      end
    end
  end

  filter(
    :client_account,
    collection: ClientAccount.joins(:saml_response_logs).order(:org_name).distinct
  )

  index(title: "Via TRM SAML Logs") do
    column(:client_account)
    column("Issuer") { |saml_response_log| saml_response_log.issuers.first }

    column("Attributes") do |saml_response_log|
      columns do
        saml_response_log.saml_attributes.each do |key, value|
          ul { li("#{key} - #{value.join(', ')}") }
        end
      end
    end

    column("SAML Response Valid", &:saml_response_valid?)

    column("SAML Errors") do |saml_response_log|
      columns do
        saml_response_log.saml_errors.each { |error| ul { li(error) } }
      end
    end

    column("Login Successful", &:login_successful?)

    column("Login Errors") do |saml_response_log|
      columns do
        saml_response_log.login_errors.each { |error| ul { li(error) } }
      end
    end

    column("Timestamp", sortable: :created_at) do |saml_response_log|
      saml_response_log.created_at.strftime("%b %d, %Y %I:%M %p %Z")
    end

    actions
  end

  show(title: proc { |saml_response_log| "Via TRM SAML Log ##{saml_response_log.id}" }) do
    attributes_table_for(saml_response_log) do
      row(:client_account)
      row("Issuer") { |saml_response_log| saml_response_log.issuers.first }

      row("Attributes") do |saml_response_log|
        columns do
          saml_response_log.saml_attributes.each do |key, value|
            ul { li("#{key} - #{value.join(', ')}") }
          end
        end
      end

      row("SAML Response Valid", &:saml_response_valid?)

      row("SAML Errors") do |saml_response_log|
        columns do
          saml_response_log.saml_errors.each { |error| ul { li(error) } }
        end
      end

      row("Login Successful", &:login_successful?)

      row("Login Errors") do |saml_response_log|
        columns do
          saml_response_log.login_errors.each { |error| ul { li(error) } }
        end
      end

      row("Timestamp") do |saml_response_log|
        saml_response_log.created_at.strftime("%b %d, %Y %I:%M %p %Z")
      end
    end
  end
end
