# frozen_string_literal: true

class ApplicationMailer < ActionMailer::Base
  default from: proc { Rails.application.secrets.default_sender_email }

  layout "mailer"

  def set_footer_variables(client_account)
    client_account_info = client_account.client_account_info

    @org_name = client_account.org_name
    @theme_color_accent = client_account_info.try(:theme_color_accent)
    @theme_color_dark = client_account_info.try(:theme_color_dark)
    @theme_color_light = client_account_info.try(:theme_color_light)
  end
end
