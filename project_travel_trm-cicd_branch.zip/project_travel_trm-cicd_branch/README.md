# Project Travel TRM
## Contributing
Before being able to pull down any of the code locally, you will need to be added to the
ProjectTravel project by an administrator. You will also need to generate an SSH key pair for your
machine, and add the public key to your account in GitHub. If you run into any permission-related
issues, it’s likely that your SSH key hasn’t been configured properly, or that you haven’t been
added to the ProjectTravel project on GitHub. The latter can only be done by an administrator.

## Setup on macOS
The steps detailed below assume macOS Ventura 13.5.2 is being used in conjunction with an M2
chipset.

### Installing Prerequisites
* Xcode - `$ xcode-select --install`
* Homebrew - `$ /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`

The below commands will also need to be run to make the `brew` command available:
* `$ (echo; echo 'eval "$(/opt/homebrew/bin/brew shellenv)"') >> /Users/USERNAME/SHELL_STARTUP_FILE`
* `$ eval "$(/opt/homebrew/bin/brew shellenv)"`

Be sure to replace USERNAME above with your username, and SHELL_STARTUP_FILE with your shell
startup file. Z shell is the assumed login shell moving forward.

### Installing Dependencies
It is strongly recommended you install a Ruby version manager, and not use the system version of
Ruby. Below are instructions utilizing rbenv, but there are other version managers available as well.

* ImageMagick (for use with CarrierWave) - `$ brew install imagemagick`
* libffi - `$ brew install libffi`
* libpq - `$ brew install libpq`
* libyaml - `$ brew install libyaml`
* OpenSSL - `$ brew install openssl`
* PostgreSQL - `$ brew install postgresql@15`
* rbenv - `$ brew install rbenv`
* Readline - `$ brew install readline`
* Redis - `$ brew install redis`
* ruby-build - `$ brew install ruby-build`
* zlib - `$ brew install zlib`

All dependencies may be installed via Homebrew with one command using:
`brew install imagemagick libffi libpq libyaml openssl postgresql@15 rbenv readline redis ruby-build zlib`

### Installing Ruby
If you have trouble with the below Ruby installation, take a look the step by step guide found
[here](https://programmingzen.com/installing-rbenv-on-zsh-on-macos) (be sure to use Ruby 2.7.7).
* Install Ruby via rbenv - `$ rbenv install 2.7.7`
* Configure your shell - `$ echo 'eval "$(~/.rbenv/bin/rbenv init - zsh)"' >> ~/.zshrc`

If necessary, replace the latter part of the command above with your shell startup file
(.bash_profile, .profile, .zprofile, etc.)
* Reload your shell - `$ source .zshrc`
* Ensure the correct Ruby version is installed - `$ ruby -v`

### Configuration
From your home directory:
* Bypass installing documentation for gems using the command `$ echo "gem: --no-document" >> ~/.gemrc`

From the project directory:
* Install Bundler version 2.1.4 - `$ gem install bundler -v 2.1.4`
* Set Bundler to not use precompiled gems - `$ bundle config set force_ruby_platform true`
* Install PG version 1.4.6 - `gem install pg -v '1.5.3' -- --with-pg-config=/opt/homebrew/Cellar/postgresql@15/15.2_3/bin/pg_config`

The 15.2_3 in the command above may need to be replaced with the actual version of Postgres
installed via Homebrew. Also, it seems like there is a bug with the current version of Bundler that
causes a version of libv8-node with the incorrect platform to be installed, which causes subsequent
issues when trying to install therubyracer. To avoid this, force the install of the correct
libv8-node, followed by installing therubyracer:
* `$ gem install libv8-node -v 16.19.0.0 --platform x86_64-linux-libc`
* `$ gem install mini_racer -v '0.6.4' --source 'https://rubygems.org/'`

Ensure therubyracer installs correctly before proceeding.
* Install Rails version 5.0.7.2 - `$ gem install rails -v 5.0.7.2`
* Install the remaining gems - `$ bundle install`
* Rehash rbenv to make Rails executables available - `$ rbenv rehash`


Additional YML files are required to provide the necessary configurations to run the code, these
will need to be provided by an administrator.
* application.yml
* database.yml
* integrations.yml
* secrets.yml
* inbound.yml

Lastly, the following directories will need to be created:
```
mkdir log
mkdir tmp
mkdir tmp/pids
```

### Starting the Application
Make sure the following services are up and running:
* PostgreSQL
* Redis

To start the Rails server, run the command `$ rails server -e development -p 3090`. Port 3090 is
used to allow the frontend code to run on port 3000. The environment flag can be replaced with an
environment of your choosing. To connect to the Rails console, run the command
`$ rails console development`. Again, development can be replaced with an environment of your
choosing.

### Running Tests
```
$ rake db:test:prepare
$ bundle exec rake
```

### Setting Up a Local Database
Instead of a seed file, we use a snapshot of the staging database. This .sql file will be sent to you.

To import the data you will need a tool like [PGAdmin](https://www.pgadmin.org/download). If using
PGAdmin:
* Click on 'Add new Server'.
 * Server Name = localhost.
* Click on the 'connection' tab.
  * Hostname/address = localhost
  * Port 5432
  * Username = 'the name you put in your database.yml file'

Once the server has been added you can access the database you created previously. If you did not
change the name, the database.yml file defaults the name too ‘dev_database_name_here’.
* Right Click on the database (dev_database_name_here).
  * Click Restore.
* Upload the .sql file you were sent.

It will take some time for this file to upload into the database. You may get a message that the
file 'failed to upload'. To verify the data transfer was successful:

Navigate to: Database > ‘YOUR_DATABASE_NAME’ > Schemas > Tables, click on the 'Statistics' tab.
There should be tuples Inserted. If you have numbers in the table fields, the migration was
successful.
