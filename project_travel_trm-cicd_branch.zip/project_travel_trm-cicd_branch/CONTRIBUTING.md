## Contributing to ViaTRM

When you have some code that is ready to be submitted to ViaTRM’s codebase for review we have a few standard practices that must be done in order to assist others in reviewing your code as well as provide an accurate history that can be reviewed if needed.

- All code changes are to be submitted through GitHub as a pull request
- When working on a bug fix or small feature open a branch off of the master branch w/ a  name that describes what it does (ie. add-passport-options-to-reporting)
- When working on epics a branch will be opened off of master to contain the epic, then all projects for the epic will be done using a branch opened off of the epic branch.
- While not required it is preferred that you save your work by committing often to your branch instead of all at once at the end. This can make it easier for another dev to work through your thought process and can save questions/slack and forth time.
- All PRs must be reviewed and approved by at least 1 other dev before being merged into master.
Reviewers should keep an eye for bugs, logic issue, typos, and code that could be refactored or implemented using a better pattern.
- Once a PR is approved and has passed QA (if appropriate) it can be merged into master or the appropriate epic branch. Please SQUASH & MERGE all commits to keep our master branch commit history easy to read.
- After merging delete the branch.
- Once merged into master deployment should be done using our the [Story Points & Statuses](https://docs.google.com/a/via-trm.com/document/d/1S8VlWCY9yvT_FKtyMnGGSc0SGTQqGidRdIaLk-Xccr0/edit?usp=sharing) doc & `deploy.md`
